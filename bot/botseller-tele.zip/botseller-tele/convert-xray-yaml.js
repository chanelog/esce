// convert-xray-yaml.js
// Module konversi link Xray/V2Ray/Trojan ke format YAML (Clash/OpenClash)
// Standalone module - tidak bergantung pada file lain

'use strict';

const fs   = require('fs');
const path = require('path');

// ==================== HELPER TAMPILAN ====================

function header(title) {
    return `<blockquote><b>${title}</b></blockquote>`;
}

// ==================== YAML HEADER ====================

function buildYamlHeader(proxyType, configName = '') {
    const timestamp = new Date().toLocaleString('id-ID');
    let h  = `# ========================================\n`;
    h     += `# KONFIGURASI ${proxyType.toUpperCase()} - PX STORE\n`;
    h     += `# ========================================\n`;
    h     += `# - Pastikan server dalam keadaan aktif\n`;
    h     += `# - Untuk masalah koneksi, cek status server\n`;
    if (configName) h += `# - Nama: ${configName}\n`;
    h     += `# - Generated on: ${timestamp}\n\n`;
    return h;
}

// ==================== PARSER ====================

function parseVMess(link) {
    const base64Data = link.slice('vmess://'.length);
    let decoded;
    try { decoded = Buffer.from(base64Data, 'base64').toString('utf8'); }
    catch (e) { throw new Error('Gagal decode base64 VMess: ' + e.message); }

    let cfg;
    try { cfg = JSON.parse(decoded); }
    catch (e) { throw new Error('JSON VMess tidak valid: ' + e.message); }

    return {
        type      : 'vmess',
        name      : cfg.ps  || cfg.remarks || cfg.name || 'vmess-proxy',
        server    : cfg.add || cfg.address || cfg.host || cfg.server || '',
        port      : parseInt(cfg.port)  || 443,
        uuid      : cfg.id  || cfg.uuid || cfg.userID || '',
        alterId   : parseInt(cfg.aid)   || parseInt(cfg.alterId) || 0,
        cipher    : cfg.cipher || cfg.security || 'auto',
        tls       : cfg.tls === 'tls'  || cfg.security === 'tls' || false,
        sni       : cfg.sni  || cfg.host || cfg.add || '',
        host      : cfg.host || cfg.add || '',
        network   : cfg.net  || cfg.type || 'tcp',
        path      : cfg.path || '/',
        skipVerify: cfg.skipCertVerify !== undefined ? cfg.skipCertVerify : true,
        udp       : cfg.udp  !== undefined ? cfg.udp : true,
        flow      : '',
    };
}

function parseVLess(link) {
    let url;
    try { url = new URL(link); }
    catch (e) { throw new Error('URL VLESS tidak valid: ' + e.message); }

    const p        = url.searchParams;
    const security = p.get('security') || p.get('encryption') || 'none';

    return {
        type      : 'vless',
        name      : url.hash ? decodeURIComponent(url.hash.slice(1)) : 'vless-proxy',
        server    : url.hostname || '',
        port      : parseInt(url.port) || 443,
        uuid      : url.username || '',
        alterId   : 0,
        cipher    : 'auto',
        tls       : security === 'tls',
        sni       : p.get('sni')  || p.get('host') || url.hostname,
        host      : p.get('host') || p.get('sni')  || url.hostname,
        network   : p.get('type') || p.get('network') || 'tcp',
        path      : p.get('path') || '/',
        skipVerify: true,
        udp       : true,
        flow      : p.get('flow') || '',
    };
}

function parseTrojan(link) {
    let url;
    try { url = new URL(link); }
    catch (e) { throw new Error('URL Trojan tidak valid: ' + e.message); }

    const p = url.searchParams;
    let wsPath = p.get('path') || '/';
    try { wsPath = decodeURIComponent(wsPath); } catch (_) {}

    return {
        type         : 'trojan',
        name         : url.hash ? decodeURIComponent(url.hash.slice(1)) : 'trojan-proxy',
        server       : url.hostname || '',
        port         : parseInt(url.port) || 443,
        password     : url.username || '',
        sni          : p.get('sni')  || p.get('host') || url.hostname,
        host         : p.get('host') || p.get('sni')  || url.hostname,
        allowInsecure: p.get('allowInsecure') === '1' || true,
        network      : p.get('type') || p.get('network') || 'tcp',
        path         : wsPath,
        udp          : true,
    };
}

// ==================== YAML GENERATOR ====================

function _networkOpts(network, wsPath, wsHost) {
    let yaml = '';
    if (network === 'ws') {
        yaml += `    ws-opts:\n`;
        yaml += `      path: "${wsPath}"\n`;
        if (wsHost) { yaml += `      headers:\n`; yaml += `        Host: ${wsHost}\n`; }
    } else if (network === 'grpc') {
        yaml += `    grpc-opts:\n`;
        yaml += `      grpc-service-name: "${wsPath}"\n`;
    } else if (network === 'h2') {
        yaml += `    h2-opts:\n`;
        yaml += `      path: "${wsPath}"\n`;
        if (wsHost) yaml += `      host: ["${wsHost}"]\n`;
    } else if (network === 'tcp' && wsHost) {
        yaml += `    http-opts:\n`;
        yaml += `      headers:\n`;
        yaml += `        Host: ${wsHost}\n`;
    }
    return yaml;
}

function generateV2RayYaml(cfg, configName = '') {
    if (!cfg.uuid || !cfg.server) throw new Error('Konfigurasi tidak valid: UUID atau server kosong');
    const proxyType = cfg.type === 'vless' ? 'vless' : 'vmess';
    let yaml = buildYamlHeader(proxyType, configName);
    yaml += 'proxies:\n';
    yaml += `  - name: ${cfg.name}\n`;
    yaml += `    server: ${cfg.server}\n`;
    yaml += `    port: ${cfg.port}\n`;
    yaml += `    type: ${proxyType}\n`;
    yaml += `    uuid: ${cfg.uuid}\n`;
    if (proxyType === 'vmess') { yaml += `    alterId: ${cfg.alterId}\n`; yaml += `    cipher: ${cfg.cipher}\n`; }
    yaml += `    tls: ${cfg.tls}\n`;
    yaml += `    skip-cert-verify: ${cfg.skipVerify}\n`;
    if (cfg.sni) yaml += `    servername: ${cfg.sni}\n`;
    yaml += `    network: ${cfg.network}\n`;
    yaml += _networkOpts(cfg.network, cfg.path, cfg.host);
    if (proxyType === 'vless' && cfg.flow) yaml += `    flow: ${cfg.flow}\n`;
    yaml += `    udp: ${cfg.udp}\n`;
    return yaml;
}

function generateTrojanYaml(cfg, configName = '') {
    if (!cfg.password || !cfg.server) throw new Error('Konfigurasi Trojan tidak valid: password atau server kosong');
    let yaml = buildYamlHeader('trojan', configName);
    yaml += 'proxies:\n';
    yaml += `  - name: ${cfg.name}\n`;
    yaml += `    server: ${cfg.server}\n`;
    yaml += `    port: ${cfg.port}\n`;
    yaml += `    type: trojan\n`;
    yaml += `    password: ${cfg.password}\n`;
    yaml += `    skip-cert-verify: ${cfg.allowInsecure}\n`;
    if (cfg.sni) yaml += `    sni: ${cfg.sni}\n`;
    yaml += `    network: ${cfg.network}\n`;
    yaml += _networkOpts(cfg.network, cfg.path, cfg.host);
    yaml += `    udp: ${cfg.udp}\n`;
    return yaml;
}

// ==================== ENTRY POINT ====================

function convertLink(link) {
    link = link.trim();
    if (link.startsWith('vmess://'))  { const cfg = parseVMess(link);  return { yaml: generateV2RayYaml(cfg),  cfg, configType: 'VMess Link'  }; }
    if (link.startsWith('vless://'))  { const cfg = parseVLess(link);  return { yaml: generateV2RayYaml(cfg),  cfg, configType: 'VLESS Link'  }; }
    if (link.startsWith('trojan://')) { const cfg = parseTrojan(link); return { yaml: generateTrojanYaml(cfg), cfg, configType: 'Trojan Link' }; }
    throw new Error('Format link tidak dikenali. Harus diawali vmess://, vless://, atau trojan://');
}

// ==================== STATE MANAGEMENT ====================

const xrayUserStates = new Map();

// ==================== TELEGRAM UI ====================
// Semua fungsi menerima helpers { sendMenu, sendTempMessage, trackMessage }
// agar pesan ikut sistem auto-delete yang sama dengan menu lain di bot.js

async function showToolsXrayMenu(ctx, helpers) {
    const { sendMenu } = helpers;
    const text =
        `${header('𝐂𝐎𝐍𝐕𝐄𝐑𝐓 𝐗𝐑𝐀𝐘 𝐓𝐎 𝐘𝐀𝐌𝐋')}\n` +
        `<blockquote>` +
        `<b>· Format Input:</b> VMess, VLESS, Trojan\n` +
        `<b>· Format Output:</b> YAML (Clash / OpenClash)\n` +
        `<b>· Proses:</b> Lokal, cepat, tanpa batas` +
        `</blockquote>`;

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: 'VMess / VLESS', callback_data: 'xraytool_type_v2ray'  },
                    { text: 'Trojan',        callback_data: 'xraytool_type_trojan' },
                ],
                [{ text: 'Cara Penggunaan', callback_data: 'xraytool_help'   }],
                [{ text: 'Kembali ke Menu', callback_data: 'main_menu'       }],
            ],
        },
    };

    // sendMenu: hapus temp, kirim, track sebagai 'menu' (hapus saat berpindah)
    await sendMenu(ctx, text, keyboard);
}

async function showToolsXrayHelp(ctx, helpers) {
    const { sendMenu } = helpers;
    const text =
        `${header('𝐂𝐀𝐑𝐀 𝐏𝐄𝐍𝐆𝐆𝐔𝐍𝐀𝐀𝐍')}\n` +
        `<blockquote>` +
        `<b>Langkah-langkah:</b>\n` +
        `<b>1.</b> Pilih tipe link (VMess/VLESS atau Trojan)\n` +
        `<b>2.</b> Kirim link lengkap ke bot\n` +
        `<b>3.</b> Terima file YAML siap pakai\n\n` +
        `<b>Contoh VMess:</b>\n` +
        `<code>vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIsInBvcnQiOjQ0M...</code>\n\n` +
        `<b>Contoh VLESS:</b>\n` +
        `<code>vless://uuid@example.com:443?security=tls&amp;type=ws&amp;path=/vless#nama</code>\n\n` +
        `<b>Contoh Trojan:</b>\n` +
        `<code>trojan://password@example.com:443?sni=example.com&amp;type=ws#nama</code>` +
        `</blockquote>`;

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Kembali', callback_data: 'tools_xray_menu' }],
            ],
        },
    };

    await sendMenu(ctx, text, keyboard);
}

async function promptXrayInput(ctx, type, helpers) {
    const { sendMenu, sendTempMessage } = helpers;
    const userId = ctx.from.id.toString();
    xrayUserStates.set(userId, { step: 'input_config', type });

    const label = type === 'v2ray' ? 'VMess / VLESS' : 'Trojan';
    const fmt   = type === 'v2ray'
        ? `<code>vmess://...</code>  atau  <code>vless://...</code>`
        : `<code>trojan://...</code>`;

    const text =
        `${header(`𝐊𝐎𝐍𝐕𝐄𝐑𝐒𝐈 ${label.toUpperCase()}`)}\n` +
        `<blockquote>` +
        `Silakan kirim link ${label} Anda:\n\n` +
        `<b>Format:</b> ${fmt}` +
        `</blockquote>`;

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Batal', callback_data: 'tools_xray_menu' }],
            ],
        },
    };

    // Kirim sebagai 'menu' agar terhapus otomatis saat berpindah halaman
    await sendMenu(ctx, text, keyboard);

    // Timeout 3 menit — kirim notif sebagai temp (hapus 5 detik)
    setTimeout(() => {
        if (xrayUserStates.has(userId)) {
            xrayUserStates.delete(userId);
            sendTempMessage(ctx,
                `${header('𝐒𝐄𝐒𝐈 𝐇𝐀𝐁𝐈𝐒')}\n<blockquote>Waktu input habis. Klik menu Tools untuk mencoba lagi.</blockquote>`
            ).catch(() => {});
        }
    }, 3 * 60 * 1000);
}

async function processXrayInput(ctx, text, helpers) {
    const { sendMenu, sendTempMessage, trackMessage } = helpers;
    const userId = ctx.from.id.toString();

    // Pesan "memproses" sebagai temp (akan hapus sendiri)
    const processingMsg = await sendTempMessage(ctx,
        `${header('𝐌𝐄𝐌𝐏𝐑𝐎𝐒𝐄𝐒')}\n<blockquote>Sedang mengonversi link...</blockquote>`
    );

    try {
        const { yaml, cfg, configType } = convertLink(text);
        xrayUserStates.delete(userId);

        // Hapus pesan "memproses" lebih awal (tidak tunggu 5 detik)
        try { await ctx.deleteMessage(processingMsg.message_id); } catch (_) {}

        // Buat file sementara
        const tempDir = path.join(__dirname, 'temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename  = `xray-${cfg.type}-${timestamp}.yaml`;
        const filePath  = path.join(tempDir, filename);
        fs.writeFileSync(filePath, yaml, 'utf8');

        const tls    = cfg.tls !== undefined ? cfg.tls : false;
        const server = cfg.server || '-';
        const sni    = cfg.sni   || 'Tidak ada';

        const caption =
            `${header('𝐊𝐎𝐍𝐕𝐄𝐑𝐒𝐈 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋')}\n` +
            `<blockquote>` +
            `<b>· Tipe:</b> ${cfg.type.toUpperCase()}\n` +
            `<b>· Format Input:</b> ${configType}\n` +
            `<b>· Server:</b> ${server}\n` +
            `<b>· Protocol:</b> ${cfg.type}\n` +
            `<b>· TLS:</b> ${tls ? 'Aktif' : 'Tidak aktif'}\n` +
            `<b>· SNI:</b> ${sni}\n` +
            `<b>· Generated:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
            `<b>Cara Penggunaan:</b>\n` +
            `· OpenClash: salin file ke konfigurasi\n` +
            `· Aplikasi lain: import file YAML\n\n` +
            `<b>Author:</b> PeyxDev` +
            `</blockquote>`;

        // Kirim file — track sebagai 'result' (tidak hapus otomatis, sama seperti hasil create akun)
        const docMsg = await ctx.replyWithDocument(
            { source: filePath, filename },
            { caption, parse_mode: 'HTML' }
        );
        if (docMsg?.message_id) await trackMessage(ctx, docMsg.message_id, 'result');

        fs.unlink(filePath, () => {});

        // Preview YAML — track sebagai 'result' agar tidak hilang
        const preview = yaml.length > 1000
            ? yaml.slice(0, 1000) + '\n\n... (file lengkap tersedia di atas)'
            : yaml;

        const previewMsg = await ctx.reply(
            `${header('𝐏𝐑𝐄𝐕𝐈𝐄𝐖 𝐇𝐀𝐒𝐈𝐋')}\n<blockquote><code>${preview}</code></blockquote>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: 'Konversi Lagi', callback_data: 'tools_xray_menu' },
                            { text: 'Menu Utama',    callback_data: 'main_menu'       },
                        ],
                    ],
                },
            }
        );
        if (previewMsg?.message_id) await trackMessage(ctx, previewMsg.message_id, 'result');

    } catch (err) {
        xrayUserStates.delete(userId);
        try { await ctx.deleteMessage(processingMsg.message_id); } catch (_) {}

        // Pesan error sebagai menu agar terhapus saat berpindah halaman
        const errText =
            `${header('𝐆𝐀𝐆𝐀𝐋 𝐌𝐄𝐍𝐆𝐎𝐍𝐕𝐄𝐑𝐒𝐈')}\n` +
            `<blockquote>` +
            `<b>Error:</b> ${err.message}\n\n` +
            `<b>Tips:</b>\n` +
            `· Salin link secara lengkap dari aplikasi client\n` +
            `· Pastikan tidak ada spasi di awal atau akhir\n` +
            `· Format: <code>vmess://</code>, <code>vless://</code>, atau <code>trojan://</code>` +
            `</blockquote>`;

        const keyboard = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Coba Lagi', callback_data: 'tools_xray_menu' },
                        { text: 'Bantuan',   callback_data: 'xraytool_help'   },
                    ],
                ],
            },
        };

        await sendMenu(ctx, errText, keyboard);
    }
}

// ==================== CALLBACK HANDLER ====================
// Dipanggil dari bot.on('callback_query') di bot.js
// helpers = { sendMenu, sendTempMessage, trackMessage }

async function handleXrayToolCallback(ctx, data, helpers) {
    if (data === 'tools_xray_menu')      { await showToolsXrayMenu(ctx, helpers);          return true; }
    if (data === 'xraytool_help')        { await showToolsXrayHelp(ctx, helpers);          return true; }
    if (data === 'xraytool_type_v2ray')  { await promptXrayInput(ctx, 'v2ray',  helpers);  return true; }
    if (data === 'xraytool_type_trojan') { await promptXrayInput(ctx, 'trojan', helpers);  return true; }
    return false;
}

// ==================== TEXT HANDLER ====================
// Dipanggil dari bot.on('text') di bot.js

async function handleXrayToolText(ctx, helpers) {
    const userId = ctx.from.id.toString();
    const state  = xrayUserStates.get(userId);
    if (!state || state.step !== 'input_config') return false;

    const text = (ctx.message.text || '').trim();

    if (text.toLowerCase() === 'cancel') {
        xrayUserStates.delete(userId);
        await helpers.sendTempMessage(ctx,
            `${header('𝐃𝐈𝐁𝐀𝐓𝐀𝐋𝐊𝐀𝐍')}\n<blockquote>Konversi dibatalkan.</blockquote>`
        );
        return true;
    }

    await processXrayInput(ctx, text, helpers);
    return true;
}

// ==================== EXPORT ====================

module.exports = {
    showToolsXrayMenu,
    handleXrayToolCallback,
    handleXrayToolText,
    xrayUserStates,
    convertLink,
};
