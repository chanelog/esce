// ==================== admin.js ====================
// Module berisi seluruh logic ADMIN DASHBOARD bot Telegram PX STORE.
// Dipindahkan dari bot.js (66 fungsi) TANPA mengubah isi/logic sama sekali —
// hanya dibungkus jadi module terpisah dengan dependency injection.
//
// Cara pakai di bot.js:
//   const adminModule = require('./admin.js')({ ...semua dependency... });
//   const { showAdminDashboard, showAdminServerMenu, ... } = adminModule;
//
// CATATAN PENTING soal variable yang nilainya bisa berubah (mutable) di bot.js
// seperti SERVERS, GITHUB_TOKEN, PAKASIR_SLUG, dst — semuanya di-passing sebagai
// pasangan getter/setter FUNGSI (bukan value langsung). Ini supaya module ini
// selalu baca/tulis nilai TERBARU dari bot.js, bukan snapshot basi saat awal
// require. Sudah diverifikasi dengan ESLint (no-undef) supaya tidak ada
// dependency yang kelewat.

module.exports = function initAdminModule(deps) {
    const {
        CONFIG,
        Markup,
        addIpToRepo,
        addPaket,
        formatHarga,
        formatRp,
        formatTimestamp,
        generateServerId,
        generateTxId,
        getAllAkunCount,
        getAllResellerList,
        getDiskonReseller,
        getDiskonResellerPersen,
        setDiskonReseller,
        getAllSewa,
        getAllSewaBot,
        getAllUsersWithDetails,
        getBackupList,
        getEdurcDomain,
        getHargaSCExtraIp,
        getHargaTambahIpPerHari,
        getHargaTambahIpPerJam,
        getHeader,
        getLisensiFilePath,
        getPaketById,
        getPaketList,
        getSaldo,
        getScGithubBranch,
        getScGithubOwner,
        getScGithubRepo,
        getScGithubToken,
        getUserName,
        getUserStats,
        getUserStatsAll,
        hapusLisensiDanUpload,
        hitungHargaBotSeller,
        hitungHargaSC,
        isAdmin,
        isReseller,
        isSewaBotAktif,
        isSewaScAktif,
        kurangiSaldo,
        listIpFromRepo,
        loadAkun,
        getTotalSlotData,
        setTotalSlotUsedManual,
        loadBackupIndex,
        loadSaldo,
        loadTransaksi,
        removeIpFromRepo,
        removePaket,
        saveServers,
        sendMenu,
        sendResultMessage,
        sendTempMessage,
        setEdurcDomain,
        setHargaBotSeller30Hari,
        setHargaBotSellerLifetime,
        setHargaSC30Hari,
        setHargaSCExtraIp,
        setScGithubBranch,
        setScGithubOwner,
        setScGithubRepo,
        setScGithubToken,
        sewaSCModule,
        simpanTransaksi,
        sshModule,
        tambahSaldo,
        tambahSewaRecord,
        isTopupBonusAktif,
        setTopupBonusAktif,
        getTopupBonusTiers,
        setTopupBonusTier,
        removeTopupBonusTier,
        formatRibuanSingkat,
        trojanModule,
        updateConfig,
        updateEnvValue,
        userStates,
        vlessModule,
        vmessModule,
        zivpnModule,
        getAutoBackupEnabled,
        getAutoBackupIntervalMinutes,
        getServers,
        getGithubToken,
        setGithubToken,
        getGithubOwner,
        setGithubOwner,
        getGithubRepo,
        setGithubRepo,
        getGithubBranch,
        setGithubBranch,
        getPakasirAktif,
        getPakasirApiKey,
        setPakasirApiKey,
        getPakasirSlug,
        setPakasirSlug,
        getPakasirMerchantName,
        setPakasirMerchantName,
        getDanaAktif,
        getDanaNama,
        setDanaNama,
        getDanaNomor,
        setDanaNomor,
        getGopayAktif,
        getGopayNama,
        setGopayNama,
        getGopayNomor,
        setGopayNomor,
        getQrisDinamisAktif,
        getQrisStatis
    } = deps;

    // ==================== SAFE WRAPPER: DISKON RESELLER ====================
    // Fallback ini mencegah bot crash ("X is not a function") kalau bot.js
    // belum di-update untuk pass getDiskonReseller/getDiskonResellerPersen/
    // setDiskonReseller ke admin.js. Begitu bot.js sudah benar, fungsi asli
    // dari reseller.js otomatis dipakai.
    function safeGetDiskonResellerPersen() {
        if (typeof getDiskonResellerPersen === 'function') return getDiskonResellerPersen();
        if (typeof getDiskonReseller === 'function') return Math.round(getDiskonReseller() * 100 * 100) / 100;
        console.error('[Reseller] getDiskonResellerPersen/getDiskonReseller belum di-inject dari reseller.js ke admin.js (cek bot.js)');
        return 50;
    }
    function safeSetDiskonReseller(persen) {
        if (typeof setDiskonReseller === 'function') return setDiskonReseller(persen);
        throw new Error('setDiskonReseller belum di-inject dari reseller.js ke admin.js — tambahkan di deps saat require admin.js pada bot.js');
    }

// ==================== CACHE SINGKAT: LIST AKUN PER SERVER (REMOTE) ====================
// List akun (trojan/vless/vmess/ssh/zivpn) didapat dengan request ke server VPN yang
// bersangkutan (SSH/API), yang butuh waktu (bisa 1-3 detik+). Kalau di-fetch ulang setiap
// kali admin pindah halaman (next/prev) pada listing yang SAMA, jadinya kerasa lag padahal
// datanya juga belum tentu berubah dalam hitungan detik. Solusi: cache singkat per
// (serverId + tipe) dengan TTL 20 detik — klik pindah halaman dalam jendela itu pakai data
// cache (instan, tanpa request ulang ke server). Begitu masuk ulang lewat 20 detik, atau
// setelah ada aksi delete (cache di-invalidate manual), data di-fetch fresh lagi.
const _serverAkunListCache = new Map(); // key: `${serverId}::${type}` -> { data, ts }
const _SERVER_AKUN_CACHE_TTL = 20000;

async function _fetchServerAkunListRaw(server, type) {
    if (type === 'zivpn') {
        const result = await zivpnModule.zivpnList(server);
        if (result && result.success && result.users) {
            return result.users.map(u => ({
                username: u.password || u.username || '-',
                expired: u.expired || u.expiry_date || '-',
                status: u.status || 'active',
                iplimit: u.ip_limit || u.ipLimit || 0,
                type: 'zivpn'
            }));
        }
        return [];
    }
    if (type === 'ssh') {
        const result = await sshModule.listSSH(server);
        if (result && result.success && result.data) {
            return result.data.map(u => ({
                username: u.username || '-',
                expired: u.expired || '-',
                status: u.status || 'active',
                iplimit: u.ip_limit || 0,
                type: 'ssh'
            }));
        }
        return [];
    }
    if (type === 'trojan') {
        const r = await trojanModule.listTrojan(server).catch(() => null);
        if (r && r.success && r.data) {
            return r.data.map(u => ({ username: u.username, expired: u.expired || '-', status: u.status || 'active', iplimit: u.ip_limit || 0, type: 'trojan' }));
        }
        return [];
    }
    if (type === 'vless') {
        const r = await vlessModule.listVless(server).catch(() => null);
        if (r && r.success && r.data) {
            return r.data.map(u => ({ username: u.username, expired: u.expired || '-', status: u.status || 'active', iplimit: u.ip_limit || 0, type: 'vless' }));
        }
        return [];
    }
    if (type === 'vmess') {
        const r = await vmessModule.listVmess(server).catch(() => null);
        if (r && r.success && r.data) {
            return r.data.map(u => ({ username: u.username, expired: u.expired || '-', status: u.status || 'active', iplimit: u.ip_limit || 0, type: 'vmess' }));
        }
        return [];
    }
    return [];
}

// Ambil list akun 1 tipe dari cache (kalau masih fresh) atau fetch baru dari server.
async function getServerAkunListCached(serverId, server, type) {
    const key = `${serverId}::${type}`;
    const now = Date.now();
    const cached = _serverAkunListCache.get(key);
    if (cached && (now - cached.ts) < _SERVER_AKUN_CACHE_TTL) {
        return cached.data;
    }
    const data = await _fetchServerAkunListRaw(server, type);
    _serverAkunListCache.set(key, { data, ts: now });
    return data;
}

// Cek apakah SEMUA tipe yang dibutuhkan sudah ada di cache & masih fresh (dipakai untuk
// memutuskan perlu tidaknya tampilkan pesan "Mengambil data...").
function isServerAkunListCached(serverId, types) {
    const now = Date.now();
    return types.every(t => {
        const c = _serverAkunListCache.get(`${serverId}::${t}`);
        return c && (now - c.ts) < _SERVER_AKUN_CACHE_TTL;
    });
}

// Hapus cache — dipanggil setelah ada aksi yang mengubah data akun di server (delete dll)
// supaya listing berikutnya tidak menampilkan data basi.
function invalidateServerAkunListCache(serverId, type = null) {
    if (type) {
        _serverAkunListCache.delete(`${serverId}::${type}`);
    } else {
        for (const key of [..._serverAkunListCache.keys()]) {
            if (key.startsWith(`${serverId}::`)) _serverAkunListCache.delete(key);
        }
    }
}

// Emoji ikon per tipe server, dipakai di semua tampilan daftar server
function getServerTypeIcon(type) {
    const icons = {
        ssh: '🔐',
        zivpn: '🧬',
        xray: '🌐',
        trojan: '🛡',
        vless: '⚡',
        vmess: '🌀'
    };
    return icons[type] || '🖥';
}

// ==================== SLOT SERVER (KAPASITAS AKUN PER SERVER) ====================
// server.maxSlot = jumlah maksimum akun AKTIF (non-trial) yang boleh ada di server
// tersebut secara bersamaan. null/undefined = Unlimited (tanpa batas, default).
// Akun trial TIDAK dihitung karena sifatnya sementara (durasi menit).
//
// PENTING: SSH & XRAY (dan tipe lain) yang menunjuk ke apiUrl yang sama adalah
// SATU server fisik yang sama, cuma beda nama/type saja (mis. "Server1" type ssh
// dan "Server2" type xray = server yang sama persis). Jadi slot (terpakai
// maupun total) HARUS disatukan/dihitung gabungan lintas semua entri server
// yang apiUrl-nya sama, bukan dihitung terpisah per entri.
function getServerGroupKey(server) {
    return String(server?.apiUrl || '').trim().toLowerCase().replace(/\/+$/, '');
}

// Ambil semua entri server (ssh, xray, dst) yang merupakan server fisik yang sama
function getServersInGroup(server) {
    const key = getServerGroupKey(server);
    if (!server || !key) return server ? [server] : [];
    return Object.values(getServers()).filter(s => getServerGroupKey(s) === key);
}

// Slot total (maxSlot) berlaku untuk seluruh grup — ambil dari entri manapun
// dalam grup yang sudah punya nilai (biasanya diset lewat entri SSH).
function getEffectiveMaxSlot(server) {
    const group = getServersInGroup(server);
    for (const s of group) {
        if (s && s.maxSlot != null) return s.maxSlot;
    }
    return null;
}

// Jumlah akun aktif (non-trial) digabung untuk SEMUA entri server dalam satu grup.
// MURNI baca counter dari totalslot.json (naik/turun tiap create/hapus akun).
// TIDAK PERNAH scan akun.json di sini. Belum ada data sama sekali = dianggap 0.
function getJumlahAkunAktifPerServerGroup(server) {
    if (!server) return 0;
    const cached = getTotalSlotData();
    const entry = cached[server.id];
    return entry ? entry.used : 0;
}

// Dipertahankan untuk kompatibilitas (hitung per-id saja, tanpa gabungan grup)
function getJumlahAkunAktifPerServer(serverId) {
    const akun = loadAkun();
    const server = getServers()[serverId];
    let total = 0;
    for (const uid in akun) {
        const list = akun[uid] || [];
        for (const a of list) {
            if (a.status !== 'active' || a.isTrial) continue;
            const sameServer = (a.serverId && a.serverId === serverId) ||
                                (!a.serverId && a.serverName && server && a.serverName === server.name);
            if (sameServer) total++;
        }
    }
    return total;
}

function getSlotInfo(server) {
    if (!server) return { unlimited: true, used: 0, max: null, sisa: null, penuh: false };
    const max = getEffectiveMaxSlot(server);
    // Slot Terpakai SELALU dihitung/ditampilkan apa adanya, terlepas dari Slot
    // Total sudah diset atau belum — keduanya adalah 2 nilai independen, bukan
    // satu menghapus/menyembunyikan yang lain.
    const used = getJumlahAkunAktifPerServerGroup(server);
    if (max == null) {
        return { unlimited: true, used, max: null, sisa: null, penuh: false };
    }
    const sisa = Math.max(0, max - used);
    return { unlimited: false, used, max, sisa, penuh: used >= max };
}

// Label singkat slot, dipakai di daftar/list server (mis. "✅ 3 tersisa — Terpakai 9/12")
function formatSlotLabel(server) {
    const info = getSlotInfo(server);
    if (info.unlimited) return `♾️ Unlimited — Terpakai ${info.used}`;
    if (info.penuh) return `❌ PENUH — Terpakai ${info.used}/${info.max}`;
    return `✅ ${info.sisa} tersisa — Terpakai ${info.used}/${info.max}`;
}

// ==================== QUOTA PER SERVER ====================
// server.quotaGb = override quota (GB) khusus untuk server ini.
// null/undefined = pakai CONFIG.DEFAULT_QUOTA (global). 0 = Unlimited.
function getEffectiveQuota(server) {
    if (server && server.quotaGb != null) return server.quotaGb;
    return CONFIG.DEFAULT_QUOTA;
}

function formatQuotaLabel(value) {
    return (value === 0 || value == null) ? 'Unlimited' : `${value} GB`;
}

async function showAdminSewaBotMenu(ctx) {
    const semua = getAllSewaBot();
    const now = new Date();
    const aktif = semua.filter(s => new Date(s.masaAktif) >= now).length;
    const expired = semua.length - aktif;
    const statusAktif = isSewaBotAktif();

    const text = `${getHeader('𝘼𝘿𝙈𝙄𝙉 – 𝙎𝙀𝙒𝘼 𝘽𝙊𝙏 𝙎𝙀𝙇𝙇𝙀𝙍')}
<blockquote>👁 <b>Status Menu:</b> ${statusAktif ? 'Tampil ✅' : 'Disembunyikan 🙈'}
📄 <b>Total Lisensi:</b> ${semua.length}
✅ <b>Aktif:</b> ${aktif}
❌ <b>Expired:</b> ${expired}</blockquote>

<blockquote>💵 <b>Harga 30 Hari:</b> ${formatRp(hitungHargaBotSeller(30))}
💵 <b>Harga 60 Hari:</b> ${formatRp(hitungHargaBotSeller(60))}
💵 <b>Harga 90 Hari:</b> ${formatRp(hitungHargaBotSeller(90))}
♾ <b>Harga Lifetime:</b> ${formatRp(hitungHargaBotSeller(null))}</blockquote>

<blockquote>📁 <b>File Lisensi:</b> <code>${getLisensiFilePath()}</code></blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: statusAktif ? '🙈 𝙎𝙚𝙢𝙗𝙪𝙣𝙮𝙞𝙠𝙖𝙣 𝘽𝙪𝙩𝙩𝙤𝙣 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩' : '👁 𝙏𝙖𝙢𝙥𝙞𝙡𝙠𝙖𝙣 𝘽𝙪𝙩𝙩𝙤𝙣 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩', callback_data: 'admin_bot_toggle_visibility' }],
        [{ text: '📋 𝙇𝙞𝙨𝙩 𝙎𝙚𝙢𝙪𝙖 𝙇𝙞𝙨𝙚𝙣𝙨𝙞', callback_data: 'admin_bot_list' }],
        [{ text: '🗑 𝙍𝙚𝙫𝙤𝙠𝙚/𝙃𝙖𝙥𝙪𝙨 𝙏𝙤𝙠𝙚𝙣', callback_data: 'admin_bot_revoke' }],
        [{ text: '💵 𝙀𝙙𝙞𝙩 𝙃𝙖𝙧𝙜𝙖 30 𝙃𝙖𝙧𝙞', callback_data: 'admin_edit_harga_bot_30' }],
        [{ text: '♾ 𝙀𝙙𝙞𝙩 𝙃𝙖𝙧𝙜𝙖 𝙇𝙞𝙛𝙚𝙩𝙞𝙢𝙚', callback_data: 'admin_edit_harga_bot_lifetime' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_dashboard', style: 'danger' }],
    ]);
    await sendMenu(ctx, text, keyboard);
}

async function showAdminSewaBotList(ctx) {
    const semua = getAllSewaBot();
    if (semua.length === 0) {
        await sendMenu(ctx, `${getHeader('𝙇𝙄𝙎𝙏 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏')}\n<blockquote>ℹ️ Belum ada lisensi terdaftar.</blockquote>`,
            Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_sewa_bot', style: 'danger' }]]));
        return;
    }
    const aktifCount = semua.filter(s => new Date(s.masaAktif) >= new Date()).length;
    let text = `${getHeader('𝙇𝙄𝙎𝙏 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏')}
<blockquote>📄 <b>Total:</b> ${semua.length}  ✅ <b>Aktif:</b> ${aktifCount}  ❌ <b>Expired:</b> ${semua.length - aktifCount}</blockquote>\n`;
    semua.forEach((s, i) => {
        const aktif = new Date(s.masaAktif) >= new Date();
        text += `\n🪪 <b>${i + 1}. ${s.nama}</b>
<blockquote>🌐 <code>${s.ip}</code>
🔑 <b>Token:</b> <code>${s.token}</code>
👤 <b>UserId:</b> <code>${s.userId}</code>
📅 <b>Exp:</b> ${s.masaAktif} ${aktif ? '✅' : '❌'}</blockquote>\n`;
    });
    await sendMenu(ctx, text, Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_sewa_bot', style: 'danger' }]]));
}

async function startAdminBotRevoke(ctx) {
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_bot_revoke_input' });
    await sendMenu(ctx,
        `${getHeader('𝙍𝙀𝙑𝙊𝙆𝙀 𝙏𝙊𝙆𝙀𝙉 𝘽𝙊𝙏')}\n<blockquote>Ketik token yang ingin direvoke/dihapus dari lisensi.json:</blockquote>`,
        Markup.inlineKeyboard([[{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_bot', style: 'danger' }]])
    );
}

async function processAdminBotRevokeInput(ctx, message) {
    const userId = ctx.from.id.toString();
    const token = message.trim();
    if (token.toLowerCase() === 'cancel') {
        userStates.delete(userId);
        await showAdminSewaBotMenu(ctx);
        return;
    }
    try {
        const ok = await hapusLisensiDanUpload(token);
        userStates.delete(userId);
        if (ok) {
            await sendResultMessage(ctx, ` Token <code>${token}</code> berhasil direvoke & dihapus dari lisensi.json.`);
        } else {
            await sendTempMessage(ctx, ` Token <code>${token}</code> tidak ditemukan di lisensi.json.`);
        }
        await showAdminSewaBotMenu(ctx);
    } catch (e) {
        userStates.delete(userId);
        await sendTempMessage(ctx, ` Gagal revoke token: ${(e.message || e).toString().slice(0, 200)}`);
        await showAdminSewaBotMenu(ctx);
    }
}

async function showAdminTopupBonusMenu(ctx) {
    const aktif = isTopupBonusAktif();
    const tiers = getTopupBonusTiers();

    let tierLines = '';
    if (tiers.length === 0) {
        tierLines = 'ℹ️ Belum ada tier bonus.';
    } else {
        tierLines = tiers.map((t, i) => {
            const rangeLabel = t.maxAmount == null
                ? `${formatRibuanSingkat(t.minAmount)} ke atas`
                : `${formatRibuanSingkat(t.minAmount)} - ${formatRibuanSingkat(t.maxAmount)}`;

            const bonusMin = Math.floor(t.minAmount * t.persen / 100);
            const totalMin = t.minAmount + bonusMin;
            let contohText = `Topup ${formatRp(t.minAmount)} → total <b>${formatRp(totalMin)}</b>`;
            if (t.maxAmount != null) {
                const bonusMax = Math.floor(t.maxAmount * t.persen / 100);
                const totalMax = t.maxAmount + bonusMax;
                contohText = `Topup ${formatRp(t.minAmount)} → total <b>${formatRp(totalMin)}</b>\n     Topup ${formatRp(t.maxAmount)} → total <b>${formatRp(totalMax)}</b>`;
            }

            return `<b>${i + 1}. ${rangeLabel}</b> → <b>+${t.persen}%</b>\n     ${contohText}`;
        }).join('\n\n');
    }

    const text = `${getHeader('𝘼𝘿𝙈𝙄𝙉 – 𝘿𝙄𝙎𝙆𝙊𝙉 & 𝘽𝙊𝙉𝙐𝙎 𝙏𝙊𝙋𝙐𝙋')}
<blockquote><b>· Status:</b> ${aktif ? ' Aktif — tampil di menu utama' : ' Nonaktif'}
<b>· Total Tier:</b> ${tiers.length}</blockquote>

<blockquote>${tierLines}</blockquote>

<blockquote>ℹ️ "Total" = nominal topup + bonus, langsung dihitungkan biar tidak bingung. Tier tertinggi bisa dibuat tanpa batas atas.</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: aktif ? '🙈 𝙉𝙤𝙣𝙖𝙠𝙩𝙞𝙛𝙠𝙖𝙣 𝘽𝙤𝙣𝙪𝙨' : '👁 𝘼𝙠𝙩𝙞𝙛𝙠𝙖𝙣 𝘽𝙤𝙣𝙪𝙨', callback_data: 'admin_topup_bonus_toggle' }],
        [{ text: '➕ 𝙏𝙖𝙢𝙗𝙖𝙝 𝙏𝙞𝙚𝙧', callback_data: 'admin_topup_bonus_add' }],
        [{ text: '🗑 𝙃𝙖𝙥𝙪𝙨 𝙏𝙞𝙚𝙧', callback_data: 'admin_topup_bonus_remove' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_dashboard', style: 'danger' }],
    ]);
    await sendMenu(ctx, text, keyboard);
}

// Alur tambah tier sekarang STEP BY STEP (3 langkah), bukan satu baris format:
// Step 1 -> nominal MINIMAL topup untuk tier ini
// Step 2 -> nominal MAKSIMAL topup untuk tier ini (atau "0" / "tanpa batas" jika tier tertinggi)
// Step 3 -> persen bonus untuk rentang tersebut
async function startAdminTopupBonusAdd(ctx) {
    const userId = ctx.from.id.toString();
    const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝙏𝙄𝙀𝙍 𝘽𝙊𝙉𝙐𝙎 𝙏𝙊𝙋𝙐𝙋 – 𝙇𝘼𝙉𝙂𝙆𝘼𝙃 𝟭/𝟯')}
<blockquote>📝 Kirim nominal <b>MINIMAL</b> topup untuk tier ini.

Contoh: <code>10000</code> (artinya tier berlaku mulai topup 10rb)</blockquote>`;
    userStates.set(userId, { action: 'admin_topup_bonus_add_input', step: 1 });
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_topup_bonus', style: 'danger' }],
    ]));
}

async function processAdminTopupBonusAddInput(ctx, message) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (message.trim().toLowerCase() === 'cancel') {
        userStates.delete(userId);
        await showAdminTopupBonusMenu(ctx);
        return;
    }
    if (!state) {
        await showAdminTopupBonusMenu(ctx);
        return;
    }

    // ---------- STEP 1: nominal minimal ----------
    if (state.step === 1) {
        const minAmount = parseInt(message.replace(/\D/g, ''));
        if (isNaN(minAmount) || minAmount < 1) {
            await sendTempMessage(ctx, ' Nominal minimal topup tidak valid!\n\nKirim ulang nominal minimal.');
            return;
        }
        userStates.set(userId, { action: 'admin_topup_bonus_add_input', step: 2, minAmount });
        const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝙏𝙄𝙀𝙍 𝘽𝙊𝙉𝙐𝙎 𝙏𝙊𝙋𝙐𝙋 – 𝙇𝘼𝙉𝙂𝙆𝘼𝙃 𝟮/𝟯')}
<blockquote>✅ Minimal topup: <b>${formatRp(minAmount)}</b>

📝 Sekarang kirim nominal <b>MAKSIMAL</b> topup untuk tier ini.

Contoh: <code>50000</code> (tier berlaku untuk topup ${formatRp(minAmount)} s/d 50rb)

Jika ini tier tertinggi (tanpa batas atas), ketik <code>0</code> atau tekan tombol di bawah.</blockquote>`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '♾️ 𝙏𝙖𝙣𝙥𝙖 𝘽𝙖𝙩𝙖𝙨 𝘼𝙩𝙖𝙨 (𝙏𝙞𝙚𝙧 𝙏𝙚𝙧𝙩𝙞𝙣𝙜𝙜𝙞)', callback_data: 'admin_topup_bonus_unlimited' }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_topup_bonus', style: 'danger' }],
        ]));
        return;
    }

    // ---------- STEP 2: nominal maksimal (0 = tanpa batas) ----------
    if (state.step === 2) {
        const raw = message.trim().toLowerCase();
        let maxAmount;
        if (raw === '0' || raw === 'tanpa batas' || raw === 'unlimited') {
            maxAmount = null;
        } else {
            maxAmount = parseInt(message.replace(/\D/g, ''));
            if (isNaN(maxAmount) || maxAmount < 1) {
                await sendTempMessage(ctx, ' Nominal maksimal tidak valid!\n\nKirim ulang nominal maksimal, ketik <code>0</code> untuk tanpa batas.');
                return;
            }
            if (maxAmount <= state.minAmount) {
                await sendTempMessage(ctx, ` Nominal maksimal harus lebih besar dari minimal (${formatRp(state.minAmount)})!\n\nKirim ulang nominal maksimal.`);
                return;
            }
        }
        await proceedTopupBonusAddToStep3(ctx, userId, state.minAmount, maxAmount);
        return;
    }

    // ---------- STEP 3: persen bonus ----------
    if (state.step === 3) {
        const persen = parseFloat(message.replace(/[^\d.]/g, ''));
        if (isNaN(persen) || persen <= 0 || persen > 100) {
            await sendTempMessage(ctx, ' Persen bonus tidak valid! Harus antara 1-100.\n\nKirim ulang persen bonus.');
            return;
        }

        const { minAmount, maxAmount } = state;
        userStates.delete(userId);
        try {
            setTopupBonusTier(minAmount, maxAmount, persen);
            const rangeLabel = maxAmount == null ? `${formatRp(minAmount)} ke atas` : `${formatRp(minAmount)} - ${formatRp(maxAmount)}`;
            await sendTempMessage(ctx, ` Tier bonus berhasil disimpan!\n<b>· Rentang Topup:</b> ${rangeLabel}\n<b>· Bonus:</b> +${persen}%`);
        } catch(e) {
            await sendTempMessage(ctx, ` Gagal simpan tier: ${e.message}`);
        }
        await showAdminTopupBonusMenu(ctx);
        return;
    }
}

// Helper bersama: lanjut ke step 3 (input persen bonus) setelah minAmount & maxAmount didapat.
// Dipakai baik dari input teks manual (step 2) maupun tombol "Tanpa Batas Atas".
async function proceedTopupBonusAddToStep3(ctx, userId, minAmount, maxAmount) {
    userStates.set(userId, { action: 'admin_topup_bonus_add_input', step: 3, minAmount, maxAmount });
    const rangeLabel = maxAmount == null ? `${formatRp(minAmount)} ke atas` : `${formatRp(minAmount)} - ${formatRp(maxAmount)}`;
    const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝙏𝙄𝙀𝙍 𝘽𝙊𝙉𝙐𝙎 𝙏𝙊𝙋𝙐𝙋 – 𝙇𝘼𝙉𝙂𝙆𝘼𝙃 𝟯/𝟯')}
<blockquote>✅ Rentang topup: <b>${rangeLabel}</b>

📝 Terakhir, kirim <b>PERSEN BONUS</b> untuk rentang ini (1-100).

Contoh: <code>5</code> (bonus +5%)</blockquote>`;
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_topup_bonus', style: 'danger' }],
    ]));
}

// Handler tombol "♾️ Tanpa Batas Atas" di step 2 — langsung set maxAmount = null
// tanpa admin harus ketik "0" manual. Hanya valid kalau state sedang di step 2.
async function processAdminTopupBonusUnlimited(ctx) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'admin_topup_bonus_add_input' || state.step !== 2) {
        await showAdminTopupBonusMenu(ctx);
        return;
    }
    await proceedTopupBonusAddToStep3(ctx, userId, state.minAmount, null);
}

async function startAdminTopupBonusRemove(ctx) {
    const tiers = getTopupBonusTiers();
    if (tiers.length === 0) {
        await sendTempMessage(ctx, 'Belum ada tier bonus yang terdaftar.');
        await showAdminTopupBonusMenu(ctx);
        return;
    }
    const text = `${getHeader('𝙃𝘼𝙋𝙐𝙎 𝙏𝙄𝙀𝙍 𝘽𝙊𝙉𝙐𝙎 𝙏𝙊𝙋𝙐𝙋')}
<blockquote>🗑 Pilih tier yang ingin dihapus:</blockquote>`;
    const keyboard = Markup.inlineKeyboard([
        ...tiers.map(t => {
            const rangeLabel = t.maxAmount == null
                ? `${formatRibuanSingkat(t.minAmount)}+`
                : `${formatRibuanSingkat(t.minAmount)}-${formatRibuanSingkat(t.maxAmount)}`;
            return [{ text: `🗑 ${rangeLabel} → +${t.persen}%`, callback_data: `admin_topup_bonus_del_${t.minAmount}` }];
        }),
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_topup_bonus', style: 'danger' }],
    ]);
    await sendMenu(ctx, text, keyboard);
}

async function processAdminTopupBonusRemove(ctx, minAmount) {
    const ok = removeTopupBonusTier(minAmount);
    if (ok) {
        await sendTempMessage(ctx, ` Tier bonus min ${formatRp(minAmount)} berhasil dihapus.`);
    } else {
        await sendTempMessage(ctx, ` Tier tidak ditemukan atau sudah dihapus.`);
    }
    await showAdminTopupBonusMenu(ctx);
}

async function showAdminSewaScMenu(ctx) {
    const semua = getAllSewa();
    const now = new Date();
    const aktif = semua.filter(s => new Date(s.masaAktif) >= now).length;
    const expired = semua.length - aktif;
    const paketList = getPaketList();
    const hargaExtra = getHargaSCExtraIp();
    const statusAktif = isSewaScAktif();

    let paketLines = '';
    paketList.forEach(p => {
        paketLines += `<b>  ${p.icon} ${p.label} → ${formatRp(hitungHargaSC(1, p.jumlahHari))}</b>\n`;
    });

    const text = `${getHeader('𝘼𝘿𝙈𝙄𝙉 – 𝙎𝙀𝙒𝘼 𝙎𝘾')}
<blockquote><b>· Status Menu:</b> ${statusAktif ? ' Tampil' : ' Disembunyikan'}
<b>· Total Sewa:</b> ${semua.length}
<b>· Aktif:</b> ${aktif}
<b>· Expired:</b> ${expired}
<b></b>
<b>· Harga Saat Ini (IP ke-1):</b>
${paketLines.trimEnd()}
<b></b>
<b>· IP ke-2 dst → ${formatRp(hargaExtra)} / IP</b></blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: statusAktif ? '🙈 𝙎𝙚𝙢𝙗𝙪𝙣𝙮𝙞𝙠𝙖𝙣 𝘽𝙪𝙩𝙩𝙤𝙣 𝙎𝙚𝙬𝙖 𝙎𝘾' : '👁 𝙏𝙖𝙢𝙥𝙞𝙡𝙠𝙖𝙣 𝘽𝙪𝙩𝙩𝙤𝙣 𝙎𝙚𝙬𝙖 𝙎𝘾', callback_data: 'admin_sc_toggle_visibility' }],
        [{ text: '📋 𝙇𝙞𝙨𝙩 𝙎𝙚𝙢𝙪𝙖 𝙄𝙋 𝘼𝙠𝙩𝙞𝙛', callback_data: 'admin_sc_list' }],
        [{ text: '✏️ 𝙀𝙙𝙞𝙩 𝙄𝙋/𝙉𝙖𝙢𝙖', callback_data: 'admin_sc_edit_list' }],
        [{ text: '👤 𝙏𝙖𝙢𝙗𝙖𝙝 𝙎𝙚𝙬𝙖 𝙐𝙣𝙩𝙪𝙠 𝙐𝙨𝙚𝙧', callback_data: 'admin_sc_adduser' }],
        [{ text: '➕ 𝙏𝙖𝙢𝙗𝙖𝙝 𝙄𝙋 𝙈𝙖𝙣𝙪𝙖𝙡', callback_data: 'admin_sc_add' }],
        [{ text: '🗑 𝙃𝙖𝙥𝙪𝙨 𝙄𝙋 𝙙𝙖𝙧𝙞 𝙍𝙚𝙥𝙤', callback_data: 'admin_sc_remove' }],
        [{ text: '➕ 𝙏𝙖𝙢𝙗𝙖𝙝 𝘽𝙪𝙩𝙩𝙤𝙣 𝙋𝙖𝙠𝙚𝙩', callback_data: 'admin_sc_paket_add' }],
        [{ text: '🗑 𝙃𝙖𝙥𝙪𝙨 𝘽𝙪𝙩𝙩𝙤𝙣 𝙋𝙖𝙠𝙚𝙩', callback_data: 'admin_sc_paket_remove' }],
        [{ text: '✏️ 𝙀𝙙𝙞𝙩 𝙃𝙖𝙧𝙜𝙖 𝙎𝘾 30 𝙃𝙖𝙧𝙞', callback_data: 'admin_edit_harga_sc_30' }],
        [{ text: '✏️ 𝙀𝙙𝙞𝙩 𝙃𝙖𝙧𝙜𝙖 𝙎𝘾 𝙇𝙞𝙛𝙚𝙩𝙞𝙢𝙚', callback_data: 'admin_edit_harga_sc_lifetime' }],
        [{ text: '✏️ 𝙀𝙙𝙞𝙩 𝙃𝙖𝙧𝙜𝙖 𝙄𝙋 𝙏𝙖𝙢𝙗𝙖𝙝𝙖𝙣', callback_data: 'admin_edit_harga_sc_extra' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_dashboard', style: 'danger' }],
    ]);
    await sendMenu(ctx, text, keyboard);
}

async function showAdminScList(ctx) {
    let text = `${getHeader('𝙇𝙄𝙎𝙏 𝙄𝙋 𝙍𝙀𝙋𝙊 𝙀𝙎𝘾𝙀')}\n`;
    try {
        const entries = await listIpFromRepo();
        if (entries.length === 0) {
            text += `<blockquote>ℹ️ Belum ada IP terdaftar di repo.</blockquote>`;
        } else {
            entries.forEach((e, i) => {
                text += `<blockquote><b>${i + 1}. <code>${e.ip}</code></b>\n<b>· Nama:</b> ${e.nama}\n<b>· Exp:</b> ${e.masaAktif}</blockquote>\n`;
            });
        }
    } catch(err) {
        text += `<blockquote> Gagal baca repo: ${err.message}</blockquote>`;
    }
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_sewa_sc', style: 'danger' }],
    ]));
}

async function showAdminScEditList(ctx) {
    let text = `${getHeader('𝙀𝘿𝙄𝙏 𝙄𝙋/𝙉𝘼𝙈𝘼 𝙎𝘾')}\n`;
    let entries = [];
    try {
        entries = await listIpFromRepo();
    } catch(err) {
        await sendMenu(ctx, `${text}<blockquote> Gagal baca repo: ${err.message}</blockquote>`,
            Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_sewa_sc', style: 'danger' }]]));
        return;
    }

    if (entries.length === 0) {
        await sendMenu(ctx, `${text}<blockquote>ℹ️ Belum ada IP terdaftar di repo.</blockquote>`,
            Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_sewa_sc', style: 'danger' }]]));
        return;
    }

    text += `<blockquote>✏️ Pilih IP yang ingin diedit (Nama & IP):</blockquote>`;
    const buttons = entries.map(e => ([{
        text: `✏️ ${e.nama} – ${e.ip}`,
        callback_data: `admin_sc_edit_${e.ip}`,
    }]));
    buttons.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_sewa_sc', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(buttons));
}

async function startAdminScEdit(ctx, ip) {
    const userId = ctx.from.id.toString();
    let entries = [];
    try {
        entries = await listIpFromRepo();
    } catch(err) {
        await sendTempMessage(ctx, ` Gagal baca repo: ${err.message}`);
        await showAdminSewaScMenu(ctx);
        return;
    }
    const rec = entries.find(e => e.ip === ip);
    if (!rec) {
        await sendTempMessage(ctx, ' Data IP tidak ditemukan (mungkin sudah dihapus/diubah).');
        await showAdminScEditList(ctx);
        return;
    }

    userStates.set(userId, {
        action: 'admin_sc_edit',
        step: 'input_nama',
        ipLama: rec.ip,
        namaLama: rec.nama,
        masaAktifLama: rec.masaAktif,
    });

    const text = `${getHeader('𝙀𝘿𝙄𝙏 𝙄𝙋/𝙉𝘼𝙈𝘼 𝙎𝘾')}
<blockquote><b>· Nama Saat Ini:</b> ${rec.nama}
<b>· IP Saat Ini:</b> <code>${rec.ip}</code>
<b>· Exp:</b> ${rec.masaAktif}
<b></b>
<b>Langkah 1/2 — Nama Baru</b>
Ketik nama baru untuk label ini:
<i>(contoh: Server-SG, NodeBaru, dll)</i></blockquote>`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sc_edit_list', style: 'danger' }],
    ]));
}

async function processAdminScEditInput(ctx, message, state) {
    const userId = ctx.from.id.toString();

    if (message.trim().toLowerCase() === 'cancel') {
        userStates.delete(userId);
        await showAdminScEditList(ctx);
        return;
    }

    // ── step input_nama ──
    if (state.step === 'input_nama') {
        const nama = message.trim();
        if (!nama || nama.length < 2) {
            await sendTempMessage(ctx, ' Nama terlalu pendek (minimal 2 karakter).');
            return;
        }
        userStates.set(userId, { ...state, step: 'input_ip', namaBaru: nama });

        const text = `${getHeader('𝙀𝘿𝙄𝙏 𝙄𝙋/𝙉𝘼𝙈𝘼 𝙎𝘾')}
<blockquote><b>· Nama Baru:</b> ${nama}
<b></b>
<b>Langkah 2/2 — IP Baru</b>
Ketik IP server baru:
<i>(contoh: 103.12.34.56)</i></blockquote>`;

        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sc_edit_list', style: 'danger' }],
        ]));
        return;
    }

    // ── step input_ip ──
    if (state.step === 'input_ip') {
        const ip = message.trim();
        if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) {
            await sendTempMessage(ctx, ' Format IP tidak valid!\n\nContoh: <code>103.12.34.56</code>');
            return;
        }

        userStates.set(userId, {
            action: 'admin_sc_edit_confirm',
            ipLama: state.ipLama,
            namaLama: state.namaLama,
            masaAktifLama: state.masaAktifLama,
            namaBaru: state.namaBaru,
            ipBaru: ip,
        });

        const text = `${getHeader('𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙀𝘿𝙄𝙏')}
<blockquote><b>· Sebelum:</b>
  Nama: ${state.namaLama}
  IP: <code>${state.ipLama}</code>
<b>· Sesudah:</b>
  Nama: ${state.namaBaru}
  IP: <code>${ip}</code>
<b>· Exp (tidak berubah):</b> ${state.masaAktifLama}
<b></b>
⚠️ IP lama akan dihapus dari repo dan diganti IP baru.</blockquote>`;

        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '✅ 𝙔𝙖, 𝙎𝙞𝙢𝙥𝙖𝙣', callback_data: 'admin_sc_edit_confirm' }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sc_edit_list', style: 'danger' }],
        ]));
        return;
    }
}

async function processAdminScEditKonfirmasi(ctx) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);

    if (!state || state.action !== 'admin_sc_edit_confirm') {
        await showAdminScEditList(ctx);
        return;
    }

    const { ipLama, namaLama, masaAktifLama, namaBaru, ipBaru } = state;
    userStates.delete(userId);

    try {
        await removeIpFromRepo(ipLama);
        await addIpToRepo(namaBaru, masaAktifLama, ipBaru);
        await sendResultMessage(ctx,
            `${getHeader('𝙀𝘿𝙄𝙏 𝙄𝙋/𝙉𝘼𝙈𝘼 𝘽𝙀𝙍𝙃𝘼𝙎𝙄𝙇')}
<blockquote><b>· Nama:</b> ${namaLama} → ${namaBaru}
<b>· IP:</b> <code>${ipLama}</code> → <code>${ipBaru}</code>
<b>· Exp:</b> ${masaAktifLama}</blockquote>`);
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal edit IP/Nama: ${(e.message || e).toString().slice(0, 200)}`);
    }
    await showAdminSewaScMenu(ctx);
}

async function startAdminScAddUser(ctx) {
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_sc_adduser', step: 'input_userid' });

    const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙒𝘼 𝙐𝙉𝙏𝙐𝙆 𝙐𝙎𝙀𝙍')}
<blockquote>👤 Data ini akan otomatis muncul di <b>"IP Aktif Saya"</b> milik user tersebut.
<b></b>
<b>Langkah 1/4 — User ID</b>
Ketik Telegram User ID (angka) target:
<i>(contoh: 7661292905)</i></blockquote>`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
    ]));
}

async function processAdminScAddUserInput(ctx, message, state) {
    const adminId = ctx.from.id.toString();

    if (message.trim().toLowerCase() === 'cancel') {
        userStates.delete(adminId);
        await showAdminSewaScMenu(ctx);
        return;
    }

    // ── step 1: User ID ──
    if (state.step === 'input_userid') {
        const targetUserId = message.trim();
        if (!/^\d{5,15}$/.test(targetUserId)) {
            await sendTempMessage(ctx, ' User ID tidak valid! Harus berupa angka Telegram User ID.');
            return;
        }
        const targetName = await getUserName(targetUserId, ctx);
        userStates.set(adminId, { ...state, step: 'input_nama', targetUserId, targetName });

        const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙒𝘼 𝙐𝙉𝙏𝙐𝙆 𝙐𝙎𝙀𝙍')}
<blockquote><b>· User:</b> ${targetName} (<code>${targetUserId}</code>)
<b></b>
<b>Langkah 2/4 — Nama Label</b>
Ketik nama untuk label ini:
<i>(contoh: Server-SG, NodeBaru, dll)</i></blockquote>`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
        ]));
        return;
    }

    // ── step 2: Nama ──
    if (state.step === 'input_nama') {
        const nama = message.trim();
        if (!nama || nama.length < 2) {
            await sendTempMessage(ctx, ' Nama terlalu pendek (minimal 2 karakter).');
            return;
        }
        userStates.set(adminId, { ...state, step: 'input_ip', nama });

        const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙒𝘼 𝙐𝙉𝙏𝙐𝙆 𝙐𝙎𝙀𝙍')}
<blockquote><b>· Nama:</b> ${nama}
<b></b>
<b>Langkah 3/4 — IP Server</b>
Ketik IP server:
<i>(contoh: 103.12.34.56)</i></blockquote>`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
        ]));
        return;
    }

    // ── step 3: IP ──
    if (state.step === 'input_ip') {
        const ip = message.trim();
        if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) {
            await sendTempMessage(ctx, ' Format IP tidak valid!\n\nContoh: <code>103.12.34.56</code>');
            return;
        }
        userStates.set(adminId, { ...state, step: 'input_expiry', ip });

        const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙒𝘼 𝙐𝙉𝙏𝙐𝙆 𝙐𝙎𝙀𝙍')}
<blockquote><b>· IP:</b> <code>${ip}</code>
<b></b>
<b>Langkah 4/4 — Masa Aktif</b>
Ketik tanggal expired (<code>YYYY-MM-DD</code>), atau ketik <code>lifetime</code> untuk paket Lifetime:
<i>(contoh: 2025-12-31)</i></blockquote>`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
        ]));
        return;
    }

    // ── step 4: Masa Aktif ──
    if (state.step === 'input_expiry') {
        const raw = message.trim();
        let masaAktif, jumlahHari;
        if (raw.toLowerCase() === 'lifetime') {
            masaAktif = '2099-12-31';
            jumlahHari = null;
        } else {
            if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
                await sendTempMessage(ctx, ' Format tanggal salah! Gunakan YYYY-MM-DD atau ketik <code>lifetime</code>.');
                return;
            }
            const expDate = new Date(raw);
            if (isNaN(expDate.getTime())) {
                await sendTempMessage(ctx, ' Tanggal tidak valid!');
                return;
            }
            masaAktif = raw;
            jumlahHari = Math.max(1, Math.ceil((expDate - new Date()) / (1000 * 60 * 60 * 24)));
        }

        userStates.set(adminId, {
            action: 'admin_sc_adduser_confirm',
            targetUserId: state.targetUserId,
            targetName: state.targetName,
            nama: state.nama,
            ip: state.ip,
            masaAktif,
            jumlahHari,
        });

        const text = `${getHeader('𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙒𝘼')}
<blockquote><b>· User:</b> ${state.targetName} (<code>${state.targetUserId}</code>)
<b>· Nama:</b> ${state.nama}
<b>· IP:</b> <code>${state.ip}</code>
<b>· Masa Aktif:</b> ${masaAktif === '2099-12-31' ? '♾ Lifetime' : masaAktif}
<b></b>
ℹ️ Sewa ini gratis (admin-granted), akan langsung tampil di "IP Aktif Saya" milik user & di-push ke repo.</blockquote>`;

        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '✅ 𝙔𝙖, 𝙏𝙖𝙢𝙗𝙖𝙝𝙠𝙖𝙣', callback_data: 'admin_sc_adduser_confirm' }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
        ]));
        return;
    }
}

async function processAdminScAddUserKonfirmasi(ctx) {
    const adminId = ctx.from.id.toString();
    const state = userStates.get(adminId);

    if (!state || state.action !== 'admin_sc_adduser_confirm') {
        await showAdminSewaScMenu(ctx);
        return;
    }

    const { targetUserId, targetName, nama, ip, masaAktif, jumlahHari } = state;
    userStates.delete(adminId);

    const txId = generateTxId();
    let repoOk = false;
    let repoErr = '';
    try {
        tambahSewaRecord(targetUserId, nama, ip, masaAktif, jumlahHari, 0, txId);
        try {
            await addIpToRepo(nama, masaAktif, ip);
            repoOk = true;
        } catch(e) {
            repoErr = e.message || String(e);
            console.error('[AdminSC] Gagal push IP ke repo:', repoErr);
        }

        const resultText = repoOk
            ? `${getHeader('𝙎𝙀𝙒𝘼 𝘽𝙀𝙍𝙃𝘼𝙎𝙄𝙇 𝘿𝙄𝙏𝘼𝙈𝘽𝘼𝙃')}
<blockquote><b>· User:</b> ${targetName} (<code>${targetUserId}</code>)
<b>· Nama:</b> ${nama}
<b>· IP:</b> <code>${ip}</code>
<b>· Masa Aktif:</b> ${masaAktif === '2099-12-31' ? '♾ Lifetime' : masaAktif}
<b>· Repo:</b> Tersinkron
<b></b>
✅ Otomatis muncul di "IP Aktif Saya" milik user.</blockquote>`
            : `${getHeader('𝙎𝙀𝙒𝘼 𝘿𝙄𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝘽𝘼𝙂𝙄𝘼𝙉')}
<blockquote><b>· Data lokal user sudah tersimpan & tampil di "IP Aktif Saya".</b>
<b>· Repo:</b> Gagal — <code>${repoErr}</code>
⚠️ IP belum aktif di panel SC, sinkronkan manual lewat "Tambah IP Manual".</blockquote>`;

        await sendResultMessage(ctx, resultText);
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal tambah sewa: ${(e.message || e).toString().slice(0, 200)}`);
    }
    await showAdminSewaScMenu(ctx);
}

async function startAdminScAdd(ctx) {
    const userId = ctx.from.id.toString();
    const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝙄𝙋 𝙈𝘼𝙉𝙐𝘼𝙇')}
<blockquote>📝 Kirim data dalam format:
<code>nama|masa_aktif|IP</code>
Contoh:
<code>Peyx|2025-12-31|103.12.34.56</code></blockquote>`;
    userStates.set(userId, { action: 'admin_sc_add_input' });
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
    ]));
}

async function processAdminScAddInput(ctx, message) {
    const userId = ctx.from.id.toString();
    const parts = message.split('|').map(p => p.trim());
    if (parts.length < 3 || !parts[0] || !parts[1] || !parts[2]) {
        await sendTempMessage(ctx, ' Format salah!\n\nFormat: <code>nama|masa_aktif|IP</code>\nContoh: <code>Peyx|2025-12-31|103.12.34.56</code>');
        return;
    }
    const [nama, masaAktif, ip] = parts;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(masaAktif)) {
        await sendTempMessage(ctx, ' Format tanggal salah! Gunakan YYYY-MM-DD\nContoh: <code>2025-12-31</code>');
        return;
    }
    userStates.delete(userId);
    try {
        await addIpToRepo(nama, masaAktif, ip);
        await sendTempMessage(ctx, ` IP <code>${ip}</code> berhasil ditambahkan ke repo esce!\n<b>· Nama:</b> ${nama}\n<b>· Exp:</b> ${masaAktif}`);
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal tambah IP: ${e.message}`);
    }
    await showAdminSewaScMenu(ctx);
}

async function startAdminScRemove(ctx) {
    const userId = ctx.from.id.toString();
    const text = `${getHeader('𝙃𝘼𝙋𝙐𝙎 𝙄𝙋 𝘿𝘼𝙍𝙄 𝙍𝙀𝙋𝙊')}
<blockquote>📝 Kirim IP yang ingin dihapus:
<code>103.12.34.56</code></blockquote>`;
    userStates.set(userId, { action: 'admin_sc_remove_input' });
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
    ]));
}

async function processAdminScRemoveInput(ctx, message) {
    const userId = ctx.from.id.toString();
    const ip = message.trim();
    if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) {
        await sendTempMessage(ctx, ' Format IP tidak valid!');
        return;
    }
    userStates.delete(userId);
    try {
        await removeIpFromRepo(ip);
        await sendTempMessage(ctx, ` IP <code>${ip}</code> berhasil dihapus dari repo esce.`);
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal hapus IP: ${e.message}`);
    }
    await showAdminSewaScMenu(ctx);
}

async function startAdminScPaketAdd(ctx) {
    const userId = ctx.from.id.toString();
    const text = `${getHeader('𝙏𝘼𝙈𝘽𝘼𝙃 𝘽𝙐𝙏𝙏𝙊𝙉 𝙋𝘼𝙆𝙀𝙏')}
<blockquote>📝 Kirim data paket dalam format:
<code>label|jumlah_hari</code>

Untuk paket Lifetime, isi <code>jumlah_hari</code> dengan <code>lifetime</code>.

Contoh:
<code>180 Hari|180</code>
<code>Lifetime Promo|lifetime</code></blockquote>`;
    userStates.set(userId, { action: 'admin_sc_paket_add_input' });
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
    ]));
}

async function processAdminScPaketAddInput(ctx, message) {
    const userId = ctx.from.id.toString();
    const parts = message.split('|').map(p => p.trim());
    if (parts.length < 2 || !parts[0] || !parts[1]) {
        await sendTempMessage(ctx, ' Format salah!\n\nFormat: <code>label|jumlah_hari</code>\nContoh: <code>180 Hari|180</code>');
        return;
    }
    const [label, hariRaw] = parts;
    let jumlahHari;
    if (hariRaw.toLowerCase() === 'lifetime') {
        jumlahHari = null;
    } else {
        jumlahHari = parseInt(hariRaw.replace(/\D/g, ''));
        if (isNaN(jumlahHari) || jumlahHari < 1) {
            await sendTempMessage(ctx, ' Jumlah hari tidak valid! Gunakan angka atau <code>lifetime</code>.');
            return;
        }
    }
    userStates.delete(userId);
    try {
        const paket = addPaket(label, jumlahHari);
        const hargaPaket = hitungHargaSC(1, jumlahHari);
        await sendTempMessage(ctx, ` Button paket <b>${paket.label}</b> berhasil ditambahkan!\n<b>· Harga IP ke-1:</b> ${formatRp(hargaPaket)}`);
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal tambah paket: ${e.message}`);
    }
    await showAdminSewaScMenu(ctx);
}

async function startAdminScPaketRemove(ctx) {
    const paketList = getPaketList();
    if (paketList.length === 0) {
        await sendTempMessage(ctx, 'Belum ada button paket yang terdaftar.');
        await showAdminSewaScMenu(ctx);
        return;
    }
    const text = `${getHeader('𝙃𝘼𝙋𝙐𝙎 𝘽𝙐𝙏𝙏𝙊𝙉 𝙋𝘼𝙆𝙀𝙏')}
<blockquote>🗑 Pilih paket yang ingin dihapus:</blockquote>`;
    const keyboard = Markup.inlineKeyboard([
        ...paketList.map(p => [{ text: ` ${p.icon} ${p.label}`, callback_data: `admin_sc_paket_del_${p.id}` }]),
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_sewa_sc', style: 'danger' }],
    ]);
    await sendMenu(ctx, text, keyboard);
}

async function processAdminScPaketRemove(ctx, paketId) {
    const paket = getPaketById(paketId);
    const ok = removePaket(paketId);
    if (ok) {
        await sendTempMessage(ctx, ` Button paket <b>${paket ? paket.label : paketId}</b> berhasil dihapus.`);
    } else {
        await sendTempMessage(ctx, ` Paket tidak ditemukan atau sudah dihapus.`);
    }
    await showAdminSewaScMenu(ctx);
}

async function showAdminBackupMenu(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const index = loadBackupIndex();
    const totalBackup = Object.keys(index).length;
    const githubStatus = getGithubToken() ? ` <code>${getGithubOwner()}/${getGithubRepo()}</code>` : ` Token belum diset`;
    const autoStatus = getAutoBackupEnabled()
        ? ` Aktif (setiap ${getAutoBackupIntervalMinutes()} menit)`
        : ` Tidak aktif`;

    const text = `${getHeader(' 𝘽𝘼𝘾𝙆𝙐𝙋 & 𝙍𝙀𝙎𝙏𝙊𝙍𝙀')}
<blockquote><b>· Total Backup   :</b> ${totalBackup} file
<b>· Auto Backup    :</b> ${autoStatus}
<b>· GitHub Repo    :</b> ${githubStatus}
<b>· Folder Lokal   :</b> <code>./backups/</code></blockquote>

 Setiap backup diberi <b>ID random</b> dan otomatis diupload ke GitHub.

Pilih aksi:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '💾 𝘽𝙖𝙘𝙠𝙪𝙥 𝙈𝙖𝙣𝙪𝙖𝙡 𝙎𝙚𝙠𝙖𝙧𝙖𝙣𝙜', callback_data: 'admin_backup_manual' }],
        [{ text: '📋 𝙇𝙞𝙝𝙖𝙩 𝘿𝙖𝙛𝙩𝙖𝙧 𝘽𝙖𝙘𝙠𝙪𝙥', callback_data: 'admin_backup_list' }],
        [{ text: '🔃 𝙍𝙚𝙨𝙩𝙤𝙧𝙚 𝘽𝙖𝙘𝙠𝙪𝙥', callback_data: 'admin_backup_restore_list' }],
        [{ text: '🗑 𝙃𝙖𝙥𝙪𝙨 𝘽𝙖𝙘𝙠𝙪𝙥', callback_data: 'admin_backup_delete_list' }],
        getAutoBackupEnabled()
            ? [{ text: '⏹ 𝙈𝙖𝙩𝙞𝙠𝙖𝙣 𝘼𝙪𝙩𝙤 𝘽𝙖𝙘𝙠𝙪𝙥', callback_data: 'admin_backup_auto_stop' }]
            : [{ text: '▶ 𝘼𝙠𝙩𝙞𝙛𝙠𝙖𝙣 𝘼𝙪𝙩𝙤 𝘽𝙖𝙘𝙠𝙪𝙥', callback_data: 'admin_backup_auto_setup' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminBackupList(ctx, page = 0) {
    if (!isAdmin(ctx.from.id)) return;

    let list = [];
    try { list = await getBackupList(); } catch(e) { list = Object.values(loadBackupIndex()).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)); }

    if (list.length === 0) {
        await sendTempMessage(ctx, ` Belum ada file backup.\n\nGunakan <b>Backup Manual</b> untuk membuat backup pertama.`);
        await showAdminBackupMenu(ctx);
        return;
    }

    const itemsPerPage = 8;
    const totalPages = Math.ceil(list.length / itemsPerPage);
    const start = page * itemsPerPage;
    const pageItems = list.slice(start, start + itemsPerPage);

    let text = `${getHeader(' 𝘿𝘼𝙁𝙏𝘼𝙍 𝘽𝘼𝘾𝙆𝙐𝙋')}
<blockquote><b>· Total File:</b> ${list.length}
<b>· Halaman:</b> ${page + 1}/${totalPages}</blockquote>\n\n`;

    pageItems.forEach((entry, i) => {
        const icon  = entry.label === 'auto' ? '' : (entry.remoteOnly ? '' : '');
        const ghBadge = entry.githubUploaded ? ' ' : '';
        const dateStr = entry.createdAt ? new Date(entry.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : '-';
        text += `${start + i + 1}. ${icon} <code>${entry.id}</code>${ghBadge}\n    ${entry.label || '-'}   ${dateStr}\n\n`;
    });

    const navButtons = [];
    if (page > 0) navButtons.push({ text: '◀ 𝙋𝙧𝙚𝙫', callback_data: `admin_backup_list_page_${page - 1}` });
    if (page < totalPages - 1) navButtons.push({ text: '𝙉𝙚𝙭𝙩 ▶', callback_data: `admin_backup_list_page_${page + 1}` });

    const keyboard = Markup.inlineKeyboard([
        ...(navButtons.length > 0 ? [navButtons] : []),
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_backup_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminBackupRestoreList(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    let list = [];
    try { list = await getBackupList(); } catch(e) { list = Object.values(loadBackupIndex()).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)); }

    if (list.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada backup tersedia untuk direstore.`);
        await showAdminBackupMenu(ctx);
        return;
    }

    const text = `${getHeader(' 𝙋𝙄𝙇𝙄𝙃 𝘽𝘼𝘾𝙆𝙐𝙋 𝙐𝙉𝙏𝙐𝙆 𝙍𝙀𝙎𝙏𝙊𝙍𝙀')}

 <b>Perhatian!</b> Restore akan <b>menimpa data saat ini</b> dengan data dari backup yang dipilih (server, user, akun, saldo, transaksi).

Pilih backup ( = tersimpan di GitHub):`;

    const buttons = list.slice(0, 10).map(entry => {
        const icon  = entry.githubUploaded ? '' : '';
        const dateStr = entry.createdAt ? new Date(entry.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day:'2-digit', month:'2-digit', year:'2-digit', hour:'2-digit', minute:'2-digit' }) : '-';
        return [{ text: `${icon} [${entry.id}] ${entry.label || '-'}  ${dateStr}`, callback_data: `admin_backup_restore_confirm_${entry.id}` }];
    });
    buttons.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_backup_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(buttons));
}

async function showAdminBackupDeleteList(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const index = loadBackupIndex();
    const list  = Object.values(index).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));

    if (list.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada backup untuk dihapus.`);
        await showAdminBackupMenu(ctx);
        return;
    }

    const text = `${getHeader(' 𝙃𝘼𝙋𝙐𝙎 𝘽𝘼𝘾𝙆𝙐𝙋')}

Pilih backup yang ingin dihapus (hanya dari lokal + index):`;

    const buttons = list.slice(0, 10).map(entry => [
        { text: ` [${entry.id}] ${entry.label || '-'}`, callback_data: `admin_backup_delete_confirm_${entry.id}` }
    ]);
    buttons.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_backup_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(buttons));
}

async function showAdminAutoBackupSetup(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const text = `${getHeader(' 𝙎𝙀𝙏𝙐𝙋 𝘼𝙐𝙏𝙊 𝘽𝘼𝘾𝙆𝙐𝙋')}
<blockquote><b>· Status:</b> ${getAutoBackupEnabled() ? ` Aktif (${getAutoBackupIntervalMinutes()} mnt)` : ' Tidak aktif'}</blockquote>

Pilih interval auto backup:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '⏱ 𝙎𝙚𝙩𝙞𝙖𝙥 30 𝙈𝙚𝙣𝙞𝙩', callback_data: 'admin_backup_auto_set_30' }],
        [{ text: '⏱ 𝙎𝙚𝙩𝙞𝙖𝙥 1 𝙅𝙖𝙢', callback_data: 'admin_backup_auto_set_60' }],
        [{ text: '⏱ 𝙎𝙚𝙩𝙞𝙖𝙥 3 𝙅𝙖𝙢', callback_data: 'admin_backup_auto_set_180' }],
        [{ text: '⏱ 𝙎𝙚𝙩𝙞𝙖𝙥 6 𝙅𝙖𝙢', callback_data: 'admin_backup_auto_set_360' }],
        [{ text: '⏱ 𝙎𝙚𝙩𝙞𝙖𝙥 12 𝙅𝙖𝙢', callback_data: 'admin_backup_auto_set_720' }],
        [{ text: '⏱ 𝙎𝙚𝙩𝙞𝙖𝙥 24 𝙅𝙖𝙢', callback_data: 'admin_backup_auto_set_1440' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_backup_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminDashboard(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const { jumlahUser, totalSaldo, totalAkun, totalTransaksi, txHariIni, totalTxHariIni } = getUserStats();
    
    const text = `${getHeader(' 𝘿𝘼𝙎𝙃𝘽𝙊𝘼𝙍𝘿')}
<blockquote>👥 <b>User:</b> ${jumlahUser}   🔑 <b>Akun:</b> ${totalAkun}
💰 <b>Saldo:</b> ${formatRp(totalSaldo)}
🧾 <b>Transaksi:</b> ${totalTransaksi} <i>(hari ini ${txHariIni} · ${formatRp(totalTxHariIni)})</i>
🖥 <b>Server Aktif:</b> ${Object.keys(getServers()).length}</blockquote>
<b>· Update:</b> ${formatTimestamp()}`;
    
    const keyboard = Markup.inlineKeyboard([
    [{ text: '📊 𝙎𝙩𝙖𝙩𝙞𝙨𝙩𝙞𝙠 𝘽𝙤𝙩', callback_data: 'admin_statistik_bot' }],
    [{ text: '👥 𝙇𝙞𝙝𝙖𝙩 𝙎𝙚𝙢𝙪𝙖 𝙐𝙨𝙚𝙧', callback_data: 'admin_list_users' }],
    [{ text: '👑 𝙈𝙖𝙣𝙖𝙜𝙚 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧', callback_data: 'admin_manage_reseller' }],
    [{ text: '🔑 𝙇𝙞𝙝𝙖𝙩 𝙎𝙚𝙢𝙪𝙖 𝘼𝙠𝙪𝙣', callback_data: 'admin_list_akun' }],
    [{ text: '🖥 𝙇𝙞𝙨𝙩 𝘼𝙠𝙪𝙣 𝙋𝙚𝙧 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_akun_per_server' }],
    [{ text: '📊 𝙍𝙞𝙬𝙖𝙮𝙖𝙩 𝙏𝙧𝙖𝙣𝙨𝙖𝙠𝙨𝙞', callback_data: 'admin_transaksi' }],
    [{ text: '🔌 𝙎𝙚𝙬𝙖 𝙎𝘾', callback_data: 'admin_sewa_sc' }],
    [{ text: '🤖 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩 𝙎𝙚𝙡𝙡𝙚𝙧', callback_data: 'admin_sewa_bot' }],
    [{ text: '🎁 𝘿𝙞𝙨𝙠𝙤𝙣 & 𝘽𝙤𝙣𝙪𝙨 𝙏𝙤𝙥𝙪𝙥', callback_data: 'admin_topup_bonus' }],
    [{ text: '📢 𝘽𝙧𝙤𝙖𝙙𝙘𝙖𝙨𝙩', callback_data: 'admin_broadcast' }],
    [{ text: '⚙️ 𝙀𝙙𝙞𝙩 𝘿𝙖𝙩𝙖 𝘽𝙤𝙩', callback_data: 'admin_edit_data' }],
    [{ text: '🖥 𝙎𝙚𝙧𝙫𝙚𝙧 𝙈𝙖𝙣𝙖𝙜𝙚𝙢𝙚𝙣𝙩', callback_data: 'admin_server_menu' }],
    [{ text: ` 𝘽𝙖𝙘𝙠𝙪𝙥 & 𝙍𝙚𝙨𝙩𝙤𝙧𝙚${getAutoBackupEnabled() ? ' ' : ''}`, callback_data: 'admin_backup_menu' }],
    [{ text: '🔄 𝙍𝙚𝙨𝙩𝙖𝙧𝙩 𝘽𝙤𝙩', callback_data: 'admin_restart_bot' }],
    [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'main_menu', style: 'danger' }]
]);
    
    await sendMenu(ctx, text, keyboard);
}

async function showAdminStatistikBot(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const { jumlahUser, totalSaldo, totalAkun, totalTransaksi, txHariIni, totalTxHariIni } = getUserStats();
    const saldoData = loadSaldo();
    const transaksi = loadTransaksi();
    const akun = loadAkun();
    
    let totalIpLimit = 0;
    let totalTrial = 0;
    let totalPremium = 0;
    
    for (const uid in akun) {
        for (const ak of akun[uid]) {
            totalIpLimit += ak.iplimit || 1;
            if (ak.isTrial) totalTrial++;
            else totalPremium++;
        }
    }
    
    const saldoEntries = Object.entries(saldoData).sort(([,a],[,b]) => b - a).slice(0, 5);
    const topNames = await Promise.all(saldoEntries.map(([uid]) => getUserName(uid, ctx)));
    const topUsers = saldoEntries.map(([, bal], i) => `${i+1}. ${topNames[i]} : ${formatRp(bal)}`);
    
    const txTypes = {};
    transaksi.forEach(t => { txTypes[t.type] = (txTypes[t.type] || 0) + 1; });
    
    const text = `${getHeader(' 𝙎𝙏𝘼𝙏𝙄𝙎𝙏𝙄𝙆 𝘽𝙊𝙏')}
<blockquote><b>· Total User :</b> ${jumlahUser}
<b>· Total Akun :</b> ${totalAkun}
<b>· Total IP Limit :</b> ${totalIpLimit}
<b>· Total Saldo :</b> ${formatRp(totalSaldo)}
<b>· Total Transaksi :</b> ${totalTransaksi}
<b>· Tx Hari Ini :</b> ${txHariIni} (${formatRp(totalTxHariIni)})
<b>· Server Aktif :</b> ${Object.keys(getServers()).length}
<b>· Harga :</b> ${formatHarga()}
<b>· Max Trial :</b> ${CONFIG.MAX_TRIAL_MENIT} menit
<b>· Max Trial/Hari :</b> ${CONFIG.MAX_TRIAL_PER_USER}x</blockquote>

<b>📦 Statistik Akun</b>
<blockquote><b>· Premium Akun :</b> ${totalPremium}
<b>· Trial Akun :</b> ${totalTrial}
<b>· Rata-rata IP/Akun :</b> ${totalAkun > 0 ? (totalIpLimit / totalAkun).toFixed(1) : 0}</blockquote>

<b>🏆 Top User (Saldo)</b>
<blockquote>${topUsers.length > 0 ? topUsers.join('\n') : '📭 Belum ada data'}</blockquote>

<b>🧾 Statistik Transaksi</b>
<blockquote><b>· Topup :</b> ${txTypes.topup || 0}x
<b>· Create :</b> ${txTypes.create || 0}x
<b>· Renew :</b> ${txTypes.renew || 0}x
<b>· Admin :</b> ${(txTypes.admin_add || 0) + (txTypes.admin_reduce || 0)}x</blockquote>

<b>· Update:</b> ${formatTimestamp()}`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔄 𝙍𝙚𝙛𝙧𝙚𝙨𝙝', callback_data: 'admin_statistik_bot' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

async function showAdminManageResellerList(ctx, page = 0) {
    if (!isAdmin(ctx.from.id)) return;

    const allReseller = getAllResellerList();
    const aktifList = allReseller.filter(r => r.aktif);
    const nonaktifList = allReseller.filter(r => !r.aktif);
    const diskonPersen = safeGetDiskonResellerPersen();

    if (allReseller.length === 0) {
        const text = `${getHeader(' 𝙈𝘼𝙉𝘼𝙂𝙀 𝙍𝙀𝙎𝙀𝙇𝙇𝙀𝙍')}
<blockquote><b>· Harga Join Res. :</b> ${formatRp(CONFIG.BIAYA_DAFTAR_RESELLER)}
<b>· Diskon Reseller :</b> ${diskonPersen}%</blockquote>

Belum ada user yang pernah berstatus reseller.

Anda tetap bisa menjadikan <b>user mana pun</b> sebagai reseller: cari usernya lalu aktifkan dari halaman manage user.`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '💰 𝙃𝙖𝙧𝙜𝙖 𝙅𝙤𝙞𝙣 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧',  callback_data: 'admin_edit_harga_reseller'  }],
            [{ text: '🏷 𝘿𝙞𝙨𝙠𝙤𝙣 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧',      callback_data: 'admin_edit_diskon_reseller' }],
            [{ text: '🔍 𝘾𝙖𝙧𝙞 / 𝙏𝙖𝙢𝙗𝙖𝙝 𝙐𝙨𝙚𝙧 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧', callback_data: 'admin_search_users' }],
            [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
        ]));
        return;
    }

    const itemsPerPage = 8;
    const totalPages = Math.ceil(allReseller.length / itemsPerPage);
    const start = page * itemsPerPage;
    const end = start + itemsPerPage;
    const pageEntries = allReseller.slice(start, end);

    let msg = `${getHeader(' 𝙈𝘼𝙉𝘼𝙂𝙀 𝙍𝙀𝙎𝙀𝙇𝙇𝙀𝙍')}
<blockquote><b>· Harga Join Res. :</b> ${formatRp(CONFIG.BIAYA_DAFTAR_RESELLER)}
<b>· Diskon Reseller :</b> ${diskonPersen}%
<b>· Total Reseller Aktif:</b> ${aktifList.length}
<b>· Total Pernah Nonaktif:</b> ${nonaktifList.length}</blockquote>
<b>· Halaman ${page + 1}/${totalPages}</b>

Tap nama untuk toggle status ON/OFF:

`;

    const keyboard = Markup.inlineKeyboard([]);

    const pageNames = await Promise.all(pageEntries.map(r => getUserName(r.userId, ctx)));
    for (let i = 0; i < pageEntries.length; i++) {
        const r = pageEntries[i];
        const name = pageNames[i];
        const statusIcon = r.aktif ? '🟢' : '⚪️';
        const toggleAction = r.aktif ? 'off' : 'on';
        keyboard.reply_markup.inline_keyboard.push([
            { text: `${statusIcon} ${name.substring(0, 22)}`, callback_data: `admin_manage_user_${r.userId}` },
            { text: r.aktif ? '🔴 OFF' : '🟢 ON', callback_data: `admin_reseller_list_${toggleAction}_${page}_${r.userId}` }
        ]);
    }

    const navButtons = [];
    if (page > 0) {
        navButtons.push({ text: '◀ 𝙎𝙚𝙗𝙚𝙡𝙪𝙢𝙣𝙮𝙖', callback_data: `admin_manage_reseller_page_${page - 1}` });
    }
    if (page < totalPages - 1) {
        navButtons.push({ text: '𝙎𝙚𝙡𝙖𝙣𝙟𝙪𝙩𝙣𝙮𝙖 ▶', callback_data: `admin_manage_reseller_page_${page + 1}` });
    }
    if (navButtons.length > 0) {
        keyboard.reply_markup.inline_keyboard.push(navButtons);
    }

    keyboard.reply_markup.inline_keyboard.push([
        { text: '💰 𝙃𝙖𝙧𝙜𝙖 𝙅𝙤𝙞𝙣 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧',  callback_data: 'admin_edit_harga_reseller'  },
        { text: '🏷 𝘿𝙞𝙨𝙠𝙤𝙣 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧',      callback_data: 'admin_edit_diskon_reseller' }
    ]);
    keyboard.reply_markup.inline_keyboard.push([
        { text: '🔍 𝘾𝙖𝙧𝙞 / 𝙏𝙖𝙢𝙗𝙖𝙝 𝙐𝙨𝙚𝙧 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧', callback_data: 'admin_search_users' }
    ]);
    keyboard.reply_markup.inline_keyboard.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]);

    await sendMenu(ctx, msg, keyboard);
}

async function showAdminListUsers(ctx, page = 0) {
    if (!isAdmin(ctx.from.id)) return;
    
    const allUsers = getAllUsersWithDetails();
    
    if (allUsers.length === 0) {
        await sendTempMessage(ctx, `📭 Belum ada user yang menggunakan bot.`);
        return;
    }
    
    const itemsPerPage = 8;
    const totalPages = Math.ceil(allUsers.length / itemsPerPage);
    page = Math.max(0, Math.min(page, totalPages - 1));
    const start = page * itemsPerPage;
    const end = start + itemsPerPage;
    const pageEntries = allUsers.slice(start, end);
    
    // Hitung statistik
    const stats = getUserStatsAll();
    
    let msg = `${getHeader(' 𝙎𝙀𝙈𝙐𝘼 𝙋𝙀𝙉𝙂𝙂𝙐𝙉𝘼 𝘽𝙊𝙏')}
<blockquote><b>📊 STATISTIK</b>
<b>· Total Pengguna:</b> ${stats.totalUsers}
<b>· Punya Saldo:</b> ${stats.usersWithSaldo} user
<b>· Punya Akun:</b> ${stats.usersWithAkun} user
<b>· Pernah Transaksi:</b> ${stats.usersWithTransaksi} user
<b>· Pernah Trial:</b> ${stats.usersWithTrial} user

<b>· Total Saldo:</b> ${formatRp(stats.totalSaldo)}
<b>· Total Akun:</b> ${stats.totalAkun}
<b>· Total Transaksi:</b> ${stats.totalTransaksi}</blockquote>
<b>· Halaman ${page + 1} dari ${totalPages}</b>

`;
    
    const keyboard = Markup.inlineKeyboard([]);
    
    const pageNamesUsers = await Promise.all(pageEntries.map(u => getUserName(u.userId, ctx)));
    for (let i = 0; i < pageEntries.length; i++) {
        const user = pageEntries[i];
        const name = pageNamesUsers[i];
        
        // Tentukan icon berdasarkan aktivitas
        let icon = '👤';
        if (user.saldo > 0) icon = '💰';
        else if (user.akunCount > 0) icon = '🔑';
        else if (user.transaksiCount > 0) icon = '🧾';
        else if (user.trialCount > 0) icon = '🎁';
        
        keyboard.reply_markup.inline_keyboard.push([
            { text: `${icon} ${name.substring(0, 25)}`, callback_data: `admin_manage_user_${user.userId}` }
        ]);
    }
    
    // Navigation buttons
    const navButtons = [];
    if (page > 0) {
        navButtons.push({ text: '◀ 𝙎𝙚𝙗𝙚𝙡𝙪𝙢𝙣𝙮𝙖', callback_data: `admin_list_users_page_${page - 1}` });
    }
    if (page < totalPages - 1) {
        navButtons.push({ text: '𝙎𝙚𝙡𝙖𝙣𝙟𝙪𝙩𝙣𝙮𝙖 ▶', callback_data: `admin_list_users_page_${page + 1}` });
    }
    if (navButtons.length > 0) {
        keyboard.reply_markup.inline_keyboard.push(navButtons);
    }
    
    keyboard.reply_markup.inline_keyboard.push([
        { text: '🔍 𝘾𝙖𝙧𝙞 𝙐𝙨𝙚𝙧', callback_data: 'admin_search_users' }
    ]);
    keyboard.reply_markup.inline_keyboard.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]);
    
    await sendMenu(ctx, msg, keyboard);
}

async function showAdminSearchUsers(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_search_users' });
    const text = `${getHeader(' 𝘾𝘼𝙍𝙄 𝙐𝙎𝙀𝙍')}

Ketik <b>nama</b> atau <b>User ID</b> yang ingin dicari:

<i>Contoh: "budi", "toko", atau "123456789"</i>`;
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_list_users', style: 'danger' }]
    ]));
}

async function showAdminSearchResults(ctx, keyword) {
    if (!isAdmin(ctx.from.id)) return;

    const allUsers = getAllUsersWithDetails();
    const kw = keyword.toLowerCase().trim();

    // Pisahkan dulu: yang cocok langsung dari userId (tanpa perlu API call)
    const results = [];
    const needLookup = [];
    for (const user of allUsers) {
        if (user.userId.toLowerCase().includes(kw)) {
            results.push({ user, name: null });
        } else {
            needLookup.push(user);
        }
    }

    // Cek nama via Telegram — paralel dengan batas concurrency (bukan satu-satu
    // sequential) supaya tidak menghabiskan waktu lama menunggu seluruh user base,
    // sekaligus tidak membanjiri Telegram API dengan ratusan request bersamaan.
    const CONCURRENCY = 15;
    for (let i = 0; i < needLookup.length; i += CONCURRENCY) {
        const batch = needLookup.slice(i, i + CONCURRENCY);
        await Promise.all(batch.map(async (user) => {
            try {
                const chat = await ctx.telegram.getChat(parseInt(user.userId));
                const name = chat.first_name || chat.username || 'User';
                const fullName = [chat.first_name, chat.last_name].filter(Boolean).join(' ');
                if (fullName.toLowerCase().includes(kw) || (chat.username || '').toLowerCase().includes(kw)) {
                    results.push({ user, name: fullName || name });
                }
            } catch (e) {
                // user tidak bisa di-resolve, skip kecuali sudah cocok userId
            }
        }));
    }

    if (results.length === 0) {
        const text = `❌ Tidak ditemukan user dengan keyword <b>"${keyword}"</b>.\n\nCoba kata kunci lain.`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '🔍 𝘾𝙖𝙧𝙞 𝙇𝙖𝙜𝙞', callback_data: 'admin_search_users' }],
            [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙛𝙩𝙖𝙧 𝙐𝙨𝙚𝙧', callback_data: 'admin_list_users', style: 'danger' }]
        ]));
        return;
    }

    // Resolve nama untuk hasil yang belum di-resolve (paralel)
    await Promise.all(results.map(async (r) => {
        if (!r.name) r.name = await getUserName(r.user.userId, ctx);
    }));

    results.sort((a, b) => b.user.saldo - a.user.saldo);

    let msg = `${getHeader(' 𝙃𝘼𝙎𝙄𝙇 𝙋𝙀𝙉𝘾𝘼𝙍𝙄𝘼𝙉')}
<blockquote><b>· Keyword:</b> <i>"${keyword}"</i>
<b>· Ditemukan:</b> ${results.length} user</blockquote>
`;

    const keyboard = Markup.inlineKeyboard([]);
    const maxShow = Math.min(10, results.length);

    for (let i = 0; i < maxShow; i++) {
        const { user, name } = results[i];
        let icon = '👤';
        if (user.saldo > 0) icon = '💰';
        else if (user.akunCount > 0) icon = '🔑';

        msg += `
<blockquote><b>${icon} ${name}</b>
🆔 <code>${user.userId}</code>
💰 <b>Saldo:</b> ${formatRp(user.saldo)}
🔑 <b>Akun:</b> ${user.akunCount} · 🧾 <b>Tx:</b> ${user.transaksiCount}</blockquote>`;

        keyboard.reply_markup.inline_keyboard.push([
            { text: `${icon} ${name.substring(0, 30)}`, callback_data: `admin_manage_user_${user.userId}` }
        ]);
    }

    if (results.length > maxShow) {
        msg += `\n\n<i>...dan ${results.length - maxShow} user lainnya. Perjelas keyword untuk hasil lebih spesifik.</i>`;
    }

    keyboard.reply_markup.inline_keyboard.push([
        { text: '🔍 𝘾𝙖𝙧𝙞 𝙇𝙖𝙜𝙞', callback_data: 'admin_search_users' }
    ]);
    keyboard.reply_markup.inline_keyboard.push([
        { text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙛𝙩𝙖𝙧 𝙐𝙨𝙚𝙧', callback_data: 'admin_list_users', style: 'danger' }
    ]);

    await sendMenu(ctx, msg, keyboard);
}

async function showAdminManageUser(ctx, targetUserId) {
    if (!isAdmin(ctx.from.id)) return;
    
    const targetName = await getUserName(targetUserId, ctx);
    const currentSaldo = getSaldo(targetUserId);
    const akun = loadAkun();
    const userAkun = akun[targetUserId] || [];
    const isResellerTarget = isReseller(targetUserId);
    
    const text = `${getHeader(` 𝙈𝘼𝙉𝘼𝙂𝙀 𝙎𝘼𝙇𝘿𝙊 𝙐𝙎𝙀𝙍`)}
<blockquote><b>· Nama:</b> ${targetName}
<b>· User ID:</b> <code>${targetUserId}</code>
<b>· Saldo Saat Ini:</b> ${formatRp(currentSaldo)}
<b>· Jumlah Akun:</b> ${userAkun.length}
<b>· Status:</b> ${isResellerTarget ? '👑 Reseller (Aktif)' : '👤 Member'}</blockquote>

Pilih aksi yang ingin dilakukan:`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '➕ 𝙏𝙖𝙢𝙗𝙖𝙝 𝙎𝙖𝙡𝙙𝙤', callback_data: `admin_add_saldo_user_${targetUserId}` }],
        [{ text: '➖ 𝙆𝙪𝙧𝙖𝙣𝙜𝙞 𝙎𝙖𝙡𝙙𝙤', callback_data: `admin_reduce_saldo_user_${targetUserId}` }],
        [{ text: '🔑 𝙇𝙞𝙝𝙖𝙩 𝘼𝙠𝙪𝙣 𝙐𝙨𝙚𝙧', callback_data: `admin_user_akun_${targetUserId}` }],
        isResellerTarget
            ? [{ text: '🔴 𝙉𝙤𝙣𝙖𝙠𝙩𝙞𝙛𝙠𝙖𝙣 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧', callback_data: `admin_reseller_off_${targetUserId}` }]
            : [{ text: '👑 𝙅𝙖𝙙𝙞𝙠𝙖𝙣 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧', callback_data: `admin_reseller_on_${targetUserId}` }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙛𝙩𝙖𝙧 𝙐𝙨𝙚𝙧', callback_data: 'admin_list_users', style: 'danger' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

async function showAdminEditSaldoAmount(ctx, mode, targetUserId) {
    if (!isAdmin(ctx.from.id)) return;
    
    const adminId = ctx.from.id.toString();
    const targetName = await getUserName(targetUserId, ctx);
    const currentSaldo = getSaldo(targetUserId);
    
    userStates.set(adminId, { 
        action: `admin_${mode}_saldo_amount`, 
        targetUserId, 
        targetName,
        currentSaldo 
    });
    
    const nominalButtons = [];
    const nominalValues = [10000, 25000, 50000, 100000, 200000, 500000];
    const row = [];
    for (const val of nominalValues) {
        row.push({ text: formatRp(val), callback_data: `admin_${mode}_nominal_${val}` });
        if (row.length === 2) {
            nominalButtons.push([...row]);
            row.length = 0;
        }
    }
    if (row.length > 0) nominalButtons.push(row);
    
    const text = `${getHeader(` ${mode === 'add' ? 'TAMBAH' : 'KURANGI'} 𝙎𝘼𝙇𝘿𝙊`)}
    
<b>Target User:</b> ${targetName}
<b>User ID:</b> <code>${targetUserId}</code>
<b>Saldo Saat Ini:</b> ${formatRp(currentSaldo)}


<b>Pilih nominal:</b>

Atau ketik nominal langsung (contoh: 75000)`;
    
    const keyboard = Markup.inlineKeyboard([
        ...nominalButtons,
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙖𝙣𝙖𝙜𝙚 𝙐𝙨𝙚𝙧', callback_data: `admin_manage_user_${targetUserId}`, style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

async function processAdminEditSaldoNominal(ctx, mode, amount, targetUserId, targetName) {
    if (!isAdmin(ctx.from.id)) return;
    
    const adminId = ctx.from.id.toString();
    const currentSaldo = getSaldo(targetUserId);
    
    if (mode === 'reduce' && currentSaldo < amount) {
        await sendTempMessage(ctx, ` Saldo tidak cukup!\nSaldo saat ini: ${formatRp(currentSaldo)}`);
        return;
    }
    
    if (mode === 'add') {
        const newBal = tambahSaldo(targetUserId, amount);
        simpanTransaksi({ 
            txId: generateTxId(), 
            userId: targetUserId, 
            userName: targetName,
            type: 'admin_add', 
            amount, 
            keterangan: `Admin tambah saldo dari ${ctx.from.first_name}`, 
            waktu: new Date().toISOString(), 
            status: 'success' 
        });
        await sendResultMessage(ctx, ` Saldo <b>${targetName}</b> ditambah ${formatRp(amount)}\n Saldo baru: ${formatRp(newBal)}`);
    } else {
        const newBal = kurangiSaldo(targetUserId, amount);
        simpanTransaksi({ 
            txId: generateTxId(), 
            userId: targetUserId,
            userName: targetName,
            type: 'admin_reduce', 
            amount, 
            keterangan: `Admin kurangi saldo dari ${ctx.from.first_name}`, 
            waktu: new Date().toISOString(), 
            status: 'success' 
        });
        await sendResultMessage(ctx, ` Saldo <b>${targetName}</b> dikurangi ${formatRp(amount)}\n Saldo baru: ${formatRp(newBal)}`);
    }
    
    userStates.delete(adminId);
    await showAdminManageUser(ctx, targetUserId);
}

async function showAdminListAkun(ctx, page = 0) {
    if (!isAdmin(ctx.from.id)) return;
    
    const akun = loadAkun();
    const entries = Object.entries(akun).sort(([,a],[,b]) => b.length - a.length);
    
    if (entries.length === 0) {
        await sendTempMessage(ctx, ` Belum ada akun.`);
        return;
    }
    
    const itemsPerPage = 10;
    const totalPages = Math.ceil(entries.length / itemsPerPage);
    const start = page * itemsPerPage;
    const end = start + itemsPerPage;
    const pageEntries = entries.slice(start, end);
    
    let msg = `${getHeader(' 𝙎𝙀𝙈𝙐𝘼 𝘼𝙆𝙐𝙉 𝙐𝙎𝙀𝙍')}
<blockquote><b>· Total User:</b> ${entries.length} user
<b>· Total Akun:</b> ${getAllAkunCount()}
<b>· Halaman:</b> ${page + 1}/${totalPages}</blockquote>

`;
    
    const pageNamesAkun = await Promise.all(pageEntries.map(([uid]) => getUserName(uid, ctx)));
    for (let i = 0; i < pageEntries.length; i++) {
        const [uid, akuns] = pageEntries[i];
        const name = pageNamesAkun[i];
        msg += `${start + i + 1}. <b>${name}</b> - ${akuns.length} akun\n`;
        
        for (let idx = 0; idx < Math.min(3, akuns.length); idx++) {
            const ak = akuns[idx];
            const type = ak.serviceType?.toUpperCase() || 'VPN';
            msg += `    ${idx+1}. ${type} - <code>${ak.username || ak.password}</code> (${ak.expired})\n`;
        }
        if (akuns.length > 3) msg += `    ... dan ${akuns.length - 3} akun lainnya\n`;
        msg += '\n';
    }
    
    const keyboard = Markup.inlineKeyboard([]);
    const navButtons = [];
    if (page > 0) {
        navButtons.push({ text: '◀ 𝙎𝙚𝙗𝙚𝙡𝙪𝙢𝙣𝙮𝙖', callback_data: `admin_list_akun_page_${page - 1}` });
    }
    if (page < totalPages - 1) {
        navButtons.push({ text: '𝙎𝙚𝙡𝙖𝙣𝙟𝙪𝙩𝙣𝙮𝙖 ▶', callback_data: `admin_list_akun_page_${page + 1}` });
    }
    if (navButtons.length > 0) {
        keyboard.reply_markup.inline_keyboard.push(navButtons);
    }
    keyboard.reply_markup.inline_keyboard.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]);
    
    await sendMenu(ctx, msg, keyboard);
}

async function showAdminUserAkun(ctx, targetUserId, page = 0) {
    if (!isAdmin(ctx.from.id)) return;
    
    const akun = loadAkun();
    const userAkun = akun[targetUserId] || [];
    const targetName = await getUserName(targetUserId, ctx);
    
    if (userAkun.length === 0) {
        await sendTempMessage(ctx, `📭 User ${targetName} tidak memiliki akun.`);
        return;
    }
    
    const totalTrial = userAkun.filter(a => a.isTrial).length;
    const totalPremium = userAkun.length - totalTrial;
    
    const itemsPerPage = 5;
    const totalPages = Math.ceil(userAkun.length / itemsPerPage);
    page = Math.max(0, Math.min(page, totalPages - 1));
    const start = page * itemsPerPage;
    const end = start + itemsPerPage;
    const pageAkun = userAkun.slice(start, end);
    
    let msg = `${getHeader(` 𝘼𝙆𝙐𝙉 𝙐𝙎𝙀𝙍: ${targetName}`)}
<blockquote><b>· Total Akun:</b> ${userAkun.length} <i>(${totalPremium} premium · ${totalTrial} trial)</i>
<b>· User ID:</b> <code>${targetUserId}</code></blockquote>
`;
    
    for (let i = 0; i < pageAkun.length; i++) {
        const ak = pageAkun[i];
        const type = (ak.serviceType || 'vpn').toLowerCase();
        const typeIcon = getServerTypeIcon(type);
        const typeLabel = type.toUpperCase();
        const trialTag = ak.isTrial ? ' · 🎁 Trial' : '';
        const expDate = ak.expired || '-';
        const createdDate = ak.createdAt ? new Date(ak.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) : '-';
        
        msg += `
<blockquote><b>${typeIcon} ${typeLabel}</b>${trialTag}
👤 <code>${ak.username || ak.password || '-'}</code>
📅 <b>Expired:</b> ${expDate}
🌐 <b>IP Limit:</b> ${ak.iplimit ?? '-'}
🕒 <b>Dibuat:</b> ${createdDate}</blockquote>`;
    }
    
    msg += `
<b>· Halaman ${page + 1} dari ${totalPages}</b>`;
    
    const keyboard = Markup.inlineKeyboard([]);
    const navButtons = [];
    if (page > 0) {
        navButtons.push({ text: '◀ 𝙎𝙚𝙗𝙚𝙡𝙪𝙢𝙣𝙮𝙖', callback_data: `admin_user_akun_${targetUserId}_page_${page - 1}` });
    }
    if (page < totalPages - 1) {
        navButtons.push({ text: '𝙎𝙚𝙡𝙖𝙣𝙟𝙪𝙩𝙣𝙮𝙖 ▶', callback_data: `admin_user_akun_${targetUserId}_page_${page + 1}` });
    }
    if (navButtons.length > 0) {
        keyboard.reply_markup.inline_keyboard.push(navButtons);
    }
    keyboard.reply_markup.inline_keyboard.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙖𝙣𝙖𝙜𝙚 𝙐𝙨𝙚𝙧', callback_data: `admin_manage_user_${targetUserId}`, style: 'danger' }]);
    
    await sendMenu(ctx, msg, keyboard);
}

const ADMIN_TX_ICON_MAP = {
    topup: '💳', create: '➕', renew: '🔁',
    payg_create: '⚡', payg_deduct: '⏱', payg_stop: '⏹', payg_delete: '🗑',
    reseller_join: '🤝', admin_add: '📥', admin_reduce: '📤',
    sewa_sc: '🔌', sewa_sc_perpanjang: '🔌', sewa_bot: '🤖', sewa_bot_perpanjang: '🤖'
};
const ADMIN_TX_NAME_MAP = {
    topup: 'Topup Saldo', create: 'Create Akun', renew: 'Renew Akun',
    payg_create: 'PAYG Aktif', payg_deduct: 'PAYG / Jam', payg_stop: 'PAYG Stop', payg_delete: 'PAYG Hapus',
    reseller_join: 'Daftar Reseller', admin_add: 'Saldo Masuk', admin_reduce: 'Saldo Kurang',
    sewa_sc: 'Sewa SC', sewa_sc_perpanjang: 'Perpanjang SC', sewa_bot: 'Sewa Bot', sewa_bot_perpanjang: 'Perpanjang Bot'
};

async function showAdminTransaksi(ctx, page = 0) {
    if (!isAdmin(ctx.from.id)) return;
    
    const transaksi = loadTransaksi().slice().sort((a, b) => new Date(b.waktu) - new Date(a.waktu));
    if (transaksi.length === 0) {
        await sendTempMessage(ctx, `📭 Belum ada transaksi.`);
        return;
    }
    
    const totalNominal = transaksi.reduce((sum, t) => sum + (t.amount || 0), 0);
    
    const itemsPerPage = 5;
    const totalPages = Math.ceil(transaksi.length / itemsPerPage);
    page = Math.max(0, Math.min(page, totalPages - 1));
    const start = page * itemsPerPage;
    const end = start + itemsPerPage;
    const pageTransaksi = transaksi.slice(start, end);
    
    let msg = `${getHeader(' 𝙍𝙄𝙒𝘼𝙔𝘼𝙏 𝙏𝙍𝘼𝙉𝙎𝘼𝙆𝙎𝙄')}
<blockquote><b>· Total Transaksi:</b> ${transaksi.length}
<b>· Total Nominal:</b> ${formatRp(totalNominal)}</blockquote>
`;
    
    // Ambil nama user PARALEL (bukan satu-satu di dalam loop dengan await berurutan) —
    // kalau berurutan, tiap transaksi yang belum punya userName tersimpan bakal nunggu
    // 1 round-trip getChat() ke Telegram sendiri-sendiri, jadi total delay-nya menumpuk.
    const pageUserNames = await Promise.all(
        pageTransaksi.map(t => (t.userName ? Promise.resolve(t.userName) : (t.userId ? getUserName(t.userId, ctx) : Promise.resolve('-'))))
    );

    for (let i = 0; i < pageTransaksi.length; i++) {
        const t = pageTransaksi[i];
        const txDate = t.waktu ? new Date(t.waktu).toLocaleDateString('id-ID', {
            day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
        }) : '-';
        const typeIcon = ADMIN_TX_ICON_MAP[t.type] || '📄';
        const typeName = ADMIN_TX_NAME_MAP[t.type] || (t.type || 'Lainnya');
        const statusIcon = t.status === 'success' ? '✅' : (t.status ? '⏳' : '✅');
        const statusLabel = t.status === 'success' ? 'Sukses' : (t.status || 'Sukses');
        const userName = pageUserNames[i];
        const ket = (t.keterangan || '-').substring(0, 40) + ((t.keterangan || '').length > 40 ? '...' : '');
        
        msg += `
<blockquote><b>${typeIcon} ${typeName}</b>
👤 ${userName} <code>(${t.userId || '-'})</code>
💰 <b>Nominal:</b> ${formatRp(t.amount || 0)}
📝 ${ket}
🕒 ${txDate}
${statusIcon} <b>Status:</b> ${statusLabel}</blockquote>`;
    }
    
    msg += `
<b>· Halaman ${page + 1} dari ${totalPages}</b>`;
    
    const keyboard = Markup.inlineKeyboard([]);
    const navButtons = [];
    if (page > 0) {
        navButtons.push({ text: '◀ 𝙎𝙚𝙗𝙚𝙡𝙪𝙢𝙣𝙮𝙖', callback_data: `admin_transaksi_page_${page - 1}` });
    }
    if (page < totalPages - 1) {
        navButtons.push({ text: '𝙎𝙚𝙡𝙖𝙣𝙟𝙪𝙩𝙣𝙮𝙖 ▶', callback_data: `admin_transaksi_page_${page + 1}` });
    }
    if (navButtons.length > 0) {
        keyboard.reply_markup.inline_keyboard.push(navButtons);
    }
    keyboard.reply_markup.inline_keyboard.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]);
    
    await sendMenu(ctx, msg, keyboard);
}

async function showAdminEditData(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const pakasirStatusIcon = getPakasirAktif() ? ' ON' : ' OFF';
    const danaStatusIcon    = getDanaAktif()    ? ' ON' : ' OFF';
    const gopayStatusIcon   = getGopayAktif()   ? ' ON' : ' OFF';
    const qrisDinamisStatusIcon = getQrisDinamisAktif() ? ' ON' : ' OFF';

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝘽𝙊𝙏')}
<blockquote><b>· Pengaturan Umum</b>
<b>· QRIS Dinamis :</b> ${qrisDinamisStatusIcon}
<b>· Pakasir :</b> ${pakasirStatusIcon}
<b>· DANA :</b> ${danaStatusIcon}
<b>· GoPay:</b> ${gopayStatusIcon}
<b>· GitHub (Backup &amp; Sewa SC)</b></blockquote>

Pilih kategori pengaturan:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '⚙️ 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣 𝙐𝙢𝙪𝙢',    callback_data: 'admin_settings_umum'    }],
        [{ text: ` 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣 𝙌𝙍𝙄𝙎 𝘿𝙞𝙣𝙖𝙢𝙞𝙨`, callback_data: 'admin_settings_qris'    }],
        [{ text: ` 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣 𝙋𝙖𝙠𝙖𝙨𝙞𝙧`,  callback_data: 'admin_settings_pakasir' }],
        [{ text: ` 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣 𝘿𝘼𝙉𝘼`,     callback_data: 'admin_settings_dana'    }],
        [{ text: ` 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣 𝙂𝙤𝙋𝙖𝙮`,    callback_data: 'admin_settings_gopay'   }],
        [{ text: '💰 𝘾𝙚𝙠 𝙋𝙚𝙢𝙗𝙖𝙮𝙖𝙧𝙖𝙣 (𝙈𝙖𝙣𝙪𝙖𝙡)', callback_data: 'admin_settings_cekbayar' }],
        [{ text: '🐙 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣 𝙂𝙞𝙩𝙃𝙪𝙗',   callback_data: 'admin_settings_github'  }],
        [{ text: '🖼 𝙂𝙖𝙣𝙩𝙞 𝙂𝙖𝙢𝙗𝙖𝙧 𝙈𝙚𝙣𝙪', callback_data: 'admin_edit_header_main' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function startAdminEditHeaderMain(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_edit_header_image_main' });

    await sendMenu(ctx,
        `${getHeader('🖼 𝙂𝘼𝙉𝙏𝙄 𝙂𝘼𝙈𝘽𝘼𝙍 𝙃𝙀𝘼𝘿𝙀𝙍 𝙈𝙀𝙉𝙐 𝙐𝙏𝘼𝙈𝘼')}\n<blockquote>Kirim foto/gambar baru untuk dijadikan header menu utama.\n\n<b>· Format:</b> JPG/PNG\n<b>· Rekomendasi:</b> rasio landscape (mis. 16:9)</blockquote>`,
        Markup.inlineKeyboard([[{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_edit_data', style: 'danger' }]])
    );
}

async function showAdminSettingsUmum(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝙐𝙈𝙐𝙈')}
<blockquote><b>· Harga per hari  :</b> Rp ${CONFIG.HARGA_PER_HARI_PER_IP}
<b>· Harga Tambahan VPN EDURC:</b> +Rp ${CONFIG.HARGA_EDURC_PER_HARI}/hari (di atas harga server)
<b>· Harga Tambahan SSH CloudFront:</b> +Rp ${CONFIG.HARGA_EDURC_PER_HARI}/hari (di atas harga server)
<b>· Harga Tambah IP :</b> Rp ${CONFIG.HARGA_TAMBAH_IP_PER_BULAN}/bulan (~Rp ${getHargaTambahIpPerHari()}/hari)
<b>· Max Trial       :</b> ${CONFIG.MAX_TRIAL_MENIT} menit
<b>· Max Trial/Hari  :</b> ${CONFIG.MAX_TRIAL_PER_USER}x
<b>· Max IP Limit    :</b> ${CONFIG.MAX_IP_LIMIT} IP
<b>· Minimal Topup   :</b> ${formatRp(CONFIG.MIN_TOPUP)}
<b>· Default Quota   :</b> ${CONFIG.DEFAULT_QUOTA === 0 ? 'Unlimited' : CONFIG.DEFAULT_QUOTA + ' GB'}
<b>· Fee QRIS        :</b> ${CONFIG.QRIS_FEE_PERSEN > 0 ? CONFIG.QRIS_FEE_PERSEN + '%' : ' Tidak aktif'}</blockquote>

Pilih yang ingin diedit:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '💰 𝙃𝙖𝙧𝙜𝙖 𝙥𝙚𝙧 𝙃𝙖𝙧𝙞',          callback_data: 'admin_edit_harga'           }],
        [{ text: '💰 𝙃𝙖𝙧𝙜𝙖 𝙏𝙖𝙢𝙗𝙖𝙝 𝙄𝙋 (/𝙗𝙪𝙡𝙖𝙣)', callback_data: 'admin_edit_harga_tambah_ip' }],
        [{ text: '⏱ 𝙈𝙖𝙭 𝙏𝙧𝙞𝙖𝙡 (𝙢𝙚𝙣𝙞𝙩)',        callback_data: 'admin_edit_trial_menit'     }],
        [{ text: '⏱ 𝙈𝙖𝙭 𝙏𝙧𝙞𝙖𝙡 𝙥𝙚𝙧 𝙃𝙖𝙧𝙞',       callback_data: 'admin_edit_trial_per_hari'  }],
        [{ text: '📶 𝙈𝙖𝙭 𝙄𝙋 𝙇𝙞𝙢𝙞𝙩',             callback_data: 'admin_edit_ip_limit'        }],
        [{ text: '💳 𝙈𝙞𝙣𝙞𝙢𝙖𝙡 𝙏𝙤𝙥𝙪𝙥',            callback_data: 'admin_edit_min_topup'       }],
        [{ text: '📦 𝘿𝙚𝙛𝙖𝙪𝙡𝙩 𝙌𝙪𝙤𝙩𝙖 (𝙂𝘽)',        callback_data: 'admin_edit_default_quota'   }],
        [{ text: '🏧 𝙁𝙚𝙚 𝙌𝙍𝙄𝙎 (%)',              callback_data: 'admin_edit_qris_fee'        }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣',    callback_data: 'admin_edit_data', style: 'danger'            }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminSettingsQris(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const qrisStatus = getQrisStatis()
        ? ` Terpasang (${getQrisStatis().length} karakter)`
        : ` Belum diatur`;
    const qrisDinamisStatusIcon = getQrisDinamisAktif() ? ' ON' : ' OFF';

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝙌𝙍𝙄𝙎 𝘿𝙄𝙉𝘼𝙈𝙄𝙎')}
<blockquote><b>· QRIS Statis  :</b> ${qrisStatus}
<b>· QRIS Dinamis :</b> ${qrisDinamisStatusIcon}
<b>· Merchant Name:</b> ${CONFIG.MERCHANT_NAME}</blockquote>

Pilih yang ingin diedit:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: ` 𝙌𝙍𝙄𝙎 𝘿𝙞𝙣𝙖𝙢𝙞𝙨: ${qrisDinamisStatusIcon}`, callback_data: 'admin_qris_dinamis_toggle' }],
        [{ text: '✏️ 𝙀𝙙𝙞𝙩 𝙌𝙍𝙄𝙎 𝙎𝙩𝙧𝙞𝙣𝙜',                       callback_data: 'admin_edit_qris'           }],
        [{ text: '📷 𝙐𝙥𝙡𝙤𝙖𝙙 𝙂𝙖𝙢𝙗𝙖𝙧 𝙌𝙍𝙄𝙎',                    callback_data: 'admin_edit_qris_image'     }],
        [{ text: '🏪 𝙉𝙖𝙢𝙖 𝙈𝙚𝙧𝙘𝙝𝙖𝙣𝙩',                          callback_data: 'admin_edit_merchant_name'  }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣',                  callback_data: 'admin_edit_data', style: 'danger'           }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminSettingsPakasir(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const pakasirApiDisplay = getPakasirApiKey()
        ? ` ${getPakasirApiKey().substring(0, 6)}...${getPakasirApiKey().slice(-4)}`
        : ` Belum diset`;
    const pakasirStatusIcon = getPakasirAktif() ? ' ON' : ' OFF';

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝙋𝘼𝙆𝘼𝙎𝙄𝙍')}
<blockquote><b>· Status          :</b> ${pakasirStatusIcon}
<b>· API Key         :</b> ${pakasirApiDisplay}
<b>· Slug Proyek     :</b> ${getPakasirSlug() || ' Belum diset'}
<b>· Merchant Pakasir:</b> ${getPakasirMerchantName() || '(sama dengan: ' + CONFIG.MERCHANT_NAME + ')'}</blockquote>

Pilih yang ingin diedit:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: ` 𝙋𝙖𝙠𝙖𝙨𝙞𝙧: ${pakasirStatusIcon}`,  callback_data: 'admin_pakasir_toggle'        }],
        [{ text: '🔐 𝙋𝙖𝙠𝙖𝙨𝙞𝙧 𝘼𝙋𝙄 𝙆𝙚𝙮',                callback_data: 'admin_edit_pakasir_apikey'   }],
        [{ text: '🔗 𝙋𝙖𝙠𝙖𝙨𝙞𝙧 𝙎𝙡𝙪𝙜 𝙋𝙧𝙤𝙮𝙚𝙠',            callback_data: 'admin_edit_pakasir_slug'     }],
        [{ text: '🏪 𝙉𝙖𝙢𝙖 𝙈𝙚𝙧𝙘𝙝𝙖𝙣𝙩 𝙋𝙖𝙠𝙖𝙨𝙞𝙧',          callback_data: 'admin_edit_pakasir_merchant' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣',          callback_data: 'admin_edit_data', style: 'danger'             }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminSettingsDana(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const danaStatusIcon = getDanaAktif() ? ' ON' : ' OFF';

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝘿𝘼𝙉𝘼')}
<blockquote><b>· Status :</b> ${danaStatusIcon}
<b>· Nomor  :</b> ${getDanaNomor() || ' Belum diset'}
<b>· Nama   :</b> ${getDanaNama()  || ' Belum diset'}</blockquote>

Pilih yang ingin diedit:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: ` 𝘿𝘼𝙉𝘼: ${danaStatusIcon}`,      callback_data: 'admin_dana_toggle'     }],
        [{ text: '📱 𝙉𝙤𝙢𝙤𝙧 𝘿𝘼𝙉𝘼', callback_data: 'admin_edit_dana_nomor' },
         { text: '👤 𝙉𝙖𝙢𝙖 𝘿𝘼𝙉𝘼',  callback_data: 'admin_edit_dana_nama'  }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣',        callback_data: 'admin_edit_data', style: 'danger'       }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminSettingsGopay(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const gopayStatusIcon = getGopayAktif() ? ' ON' : ' OFF';

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝙂𝙊𝙋𝘼𝙔')}
<blockquote><b>· Status :</b> ${gopayStatusIcon}
<b>· Nomor  :</b> ${getGopayNomor() || ' Belum diset'}
<b>· Nama   :</b> ${getGopayNama()  || ' Belum diset'}</blockquote>

Pilih yang ingin diedit:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: ` 𝙂𝙤𝙋𝙖𝙮: ${gopayStatusIcon}`,     callback_data: 'admin_gopay_toggle'     }],
        [{ text: '📱 𝙉𝙤𝙢𝙤𝙧 𝙂𝙤𝙋𝙖𝙮', callback_data: 'admin_edit_gopay_nomor' },
         { text: '👤 𝙉𝙖𝙢𝙖 𝙂𝙤𝙋𝙖𝙮',  callback_data: 'admin_edit_gopay_nama'  }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣',         callback_data: 'admin_edit_data', style: 'danger'        }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminSettingsGithub(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝙂𝙄𝙏𝙃𝙐𝘽')}
<blockquote><b>· Repo Backup</b>  → Token, Owner, Repo &amp; Branch sendiri
<b>· Repo Sewa SC</b> → Token, Owner, Repo &amp; Branch sendiri</blockquote>

Pilih kategori repo yang ingin diedit:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '📁 𝙍𝙚𝙥𝙤 𝘽𝙖𝙘𝙠𝙪𝙥',   callback_data: 'admin_settings_github_backup' }],
        [{ text: '📁 𝙍𝙚𝙥𝙤 𝙎𝙚𝙬𝙖 𝙎𝘾',  callback_data: 'admin_settings_github_sewasc' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙋𝙚𝙣𝙜𝙖𝙩𝙪𝙧𝙖𝙣', callback_data: 'admin_edit_data', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminSettingsGithubBackup(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const ghTokenDisplay = getGithubToken()
        ? ` ${getGithubToken().substring(0, 6)}...${getGithubToken().slice(-4)}`
        : ` Belum diset`;

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝙂𝙄𝙏𝙃𝙐𝘽 𝘽𝘼𝘾𝙆𝙐𝙋')}
<blockquote><b>· Token  :</b> ${ghTokenDisplay}
<b>· Owner  :</b> ${getGithubOwner()  || ' Belum diset'}
<b>· Repo   :</b> ${getGithubRepo()   || ' Belum diset'}
<b>· Branch :</b> ${getGithubBranch() || 'main'}</blockquote>

Repo ini dipakai khusus untuk menyimpan <b>file backup</b> bot.

Pilih yang ingin diedit:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔐 𝙏𝙤𝙠𝙚𝙣 𝘽𝙖𝙘𝙠𝙪𝙥',  callback_data: 'admin_edit_github_token'  },
         { text: '👤 𝙊𝙬𝙣𝙚𝙧 𝘽𝙖𝙘𝙠𝙪𝙥',  callback_data: 'admin_edit_github_owner'  }],
        [{ text: '📁 𝙍𝙚𝙥𝙤 𝘽𝙖𝙘𝙠𝙪𝙥',   callback_data: 'admin_edit_github_repo'   },
         { text: '🌿 𝘽𝙧𝙖𝙣𝙘𝙝 𝘽𝙖𝙘𝙠𝙪𝙥', callback_data: 'admin_edit_github_branch' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙂𝙞𝙩𝙃𝙪𝙗', callback_data: 'admin_settings_github', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showAdminSettingsGithubSewaSc(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const scToken = getScGithubToken();
    const scOwner = getScGithubOwner();
    const scRepo   = getScGithubRepo();
    const scBranch = getScGithubBranch();

    const scTokenDisplay = scToken
        ? ` ${scToken.substring(0, 6)}...${scToken.slice(-4)}`
        : ` Belum diset`;

    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝙂𝙄𝙏𝙃𝙐𝘽 𝙎𝙀𝙒𝘼 𝙎𝘾')}
<blockquote><b>· Token  :</b> ${scTokenDisplay}
<b>· Owner  :</b> ${scOwner  || ' Belum diset'}
<b>· Repo   :</b> ${scRepo   || ' Belum diset'}
<b>· Branch :</b> ${scBranch || 'main'}</blockquote>

Repo ini dipakai khusus untuk menyimpan data <b>IP Sewa SC Tunneling</b> (file <code>ip</code> &amp; <code>ipx</code>).

Pilih yang ingin diedit:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔐 𝙏𝙤𝙠𝙚𝙣 𝙎𝙚𝙬𝙖 𝙎𝘾',  callback_data: 'admin_edit_sc_github_token'  },
         { text: '👤 𝙊𝙬𝙣𝙚𝙧 𝙎𝙚𝙬𝙖 𝙎𝘾',  callback_data: 'admin_edit_sc_github_owner'  }],
        [{ text: '📁 𝙍𝙚𝙥𝙤 𝙎𝙚𝙬𝙖 𝙎𝘾',   callback_data: 'admin_edit_sc_github_repo'   },
         { text: '🌿 𝘽𝙧𝙖𝙣𝙘𝙝 𝙎𝙚𝙬𝙖 𝙎𝘾', callback_data: 'admin_edit_sc_github_branch' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙂𝙞𝙩𝙃𝙪𝙗', callback_data: 'admin_settings_github', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

// Tombol "❌ Batal" untuk alur handleAdminEditValue/processAdminEditValue.
// callback_data-nya menyimpan field agar tombol tahu mau kembali ke menu mana
// (menggantikan cara lama: admin harus ketik teks "cancel").
function editValueCancelKeyboard(field) {
    return Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: `admin_edit_cancel_${field}`, style: 'danger' }]
    ]);
}

async function handleAdminEditValue(ctx, field, prompt) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    
    // Store the prompt and field information
    userStates.set(userId, { 
        action: `admin_edit_${field}`, 
        editField: field,
        prompt: prompt 
    });
    
    await sendMenu(ctx, prompt, editValueCancelKeyboard(field));
}

// Logika "batal" bersama untuk handleAdminEditValue: dipakai baik saat admin
// mengetik teks "cancel" (fallback lama, tetap didukung) maupun saat menekan
// tombol "❌ Batal" (callback_data: admin_edit_cancel_<field>).
async function cancelAdminEditValue(ctx, field) {
    const userId = ctx.from.id.toString();
    userStates.delete(userId);
    if (['harga_sc_30','harga_sc_lifetime'].includes(field)) {
        await showAdminSewaScMenu(ctx);
    } else if (['harga_bot_30','harga_bot_lifetime'].includes(field)) {
        await showAdminSewaBotMenu(ctx);
    } else if (['pakasir_apikey','pakasir_slug','pakasir_merchant'].includes(field)) {
        await showAdminSettingsPakasir(ctx);
    } else if (['dana_nomor','dana_nama'].includes(field)) {
        await showAdminSettingsDana(ctx);
    } else if (['gopay_nomor','gopay_nama'].includes(field)) {
        await showAdminSettingsGopay(ctx);
    } else if (['github_token','github_owner','github_repo','github_branch'].includes(field)) {
        await showAdminSettingsGithubBackup(ctx);
    } else if (['sc_github_token','sc_github_owner','sc_github_repo','sc_github_branch'].includes(field)) {
        await showAdminSettingsGithubSewaSc(ctx);
    } else if (['harga_edurc'].includes(field)) {
        await showAdminServerMenu(ctx);
    } else if (['qris_fee'].includes(field)) {
        await showAdminSettingsUmum(ctx);
    } else if (['merchant_name'].includes(field)) {
        await showAdminSettingsQris(ctx);
    } else if (['harga_reseller', 'diskon_reseller'].includes(field)) {
        await showAdminManageResellerList(ctx);
    } else {
        await showAdminSettingsUmum(ctx);
    }
}

async function processAdminEditValue(ctx, msg, field) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    
    // FIX: Get the text properly from the message
    let input;
    if (typeof msg === 'string') {
        input = msg;
    } else if (msg && msg.text) {
        input = msg.text.trim();
    } else if (ctx && ctx.message && ctx.message.text) {
        input = ctx.message.text.trim();
    } else if (ctx && ctx.update && ctx.update.message && ctx.update.message.text) {
        input = ctx.update.message.text.trim();
    } else {
        await sendTempMessage(ctx, ` Error: Tidak dapat membaca input.`);
        return;
    }
    
    if (input.toLowerCase() === 'cancel') {
        await cancelAdminEditValue(ctx, field);
        return;
    }
    
    let newValue;
    
    switch(field) {
        case 'harga':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 100) {
                await sendTempMessage(ctx, ` Harga tidak valid. Minimal Rp 100`);
                return;
            }
            updateConfig('HARGA_PER_HARI_PER_IP', newValue);
            await sendResultMessage(ctx, ` Harga berhasil diubah menjadi <b>Rp ${newValue}</b> /hari/IP\n\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'harga_edurc':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 100) {
                await sendTempMessage(ctx, ` Harga tidak valid. Minimal Rp 100`);
                return;
            }
            updateConfig('HARGA_EDURC_PER_HARI', newValue);
            await sendResultMessage(ctx, ` Tambahan harga diubah menjadi <b>+Rp ${newValue}</b> /hari\n\n Ditambahkan di atas harga server/global.\n Berlaku untuk VPN EDURC dan SSH CloudFront.\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'harga_tambah_ip':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 0) {
                await sendTempMessage(ctx, ` Harga tidak valid. Masukkan angka positif (dalam Rupiah per bulan)\nContoh: <code>3000</code>`);
                return;
            }
            updateConfig('HARGA_TAMBAH_IP_PER_BULAN', newValue);
            await sendResultMessage(ctx,
                ` Harga Tambah IP diubah menjadi <b>Rp ${newValue.toLocaleString('id-ID')}/bulan</b>\n` +
                `   ≈ Rp ${getHargaTambahIpPerHari().toLocaleString('id-ID')}/hari\n` +
                `   ≈ Rp ${getHargaTambahIpPerJam().toLocaleString('id-ID')}/jam\n\n` +
                ` Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'trial_menit':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 1) {
                await sendTempMessage(ctx, ` Durasi tidak valid`);
                return;
            }
            updateConfig('MAX_TRIAL_MENIT', newValue);
            await sendResultMessage(ctx, ` Max Trial diubah menjadi <b>${newValue} menit</b>\n\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'trial_per_hari':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 1) {
                await sendTempMessage(ctx, ` Batas tidak valid`);
                return;
            }
            updateConfig('MAX_TRIAL_PER_USER', newValue);
            await sendResultMessage(ctx, ` Max Trial per hari diubah menjadi <b>${newValue} x/hari</b>\n\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'ip_limit':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 1) {
                await sendTempMessage(ctx, ` IP Limit tidak valid`);
                return;
            }
            updateConfig('MAX_IP_LIMIT', newValue);
            updateConfig('DEFAULT_IP_LIMIT', newValue);
            await sendResultMessage(ctx, ` Max IP Limit diubah menjadi <b>${newValue} IP</b>\n\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'min_topup':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 1000) {
                await sendTempMessage(ctx, ` Minimal Topup tidak valid (min Rp 1.000)`);
                return;
            }
            updateConfig('MIN_TOPUP', newValue);
            await sendResultMessage(ctx, ` Minimal Topup diubah menjadi ${formatRp(newValue)}\n\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'default_quota':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 0) {
                await sendTempMessage(ctx, ` Quota tidak valid. Masukkan angka positif atau 0 untuk unlimited`);
                return;
            }
            updateConfig('DEFAULT_QUOTA', newValue);
            const quotaText = newValue === 0 ? 'Unlimited' : `${newValue} GB`;
            await sendResultMessage(ctx, ` Default Quota diubah menjadi <b>${quotaText}</b>\n\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'harga_reseller':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 0) {
                await sendTempMessage(ctx, ` Harga tidak valid. Masukkan angka positif (contoh: 50000)`);
                return;
            }
            updateConfig('BIAYA_DAFTAR_RESELLER', newValue);
            await sendResultMessage(ctx, ` Harga Join Reseller diubah menjadi <b>${formatRp(newValue)}</b>\n\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'diskon_reseller':
            newValue = parseFloat(input);
            if (isNaN(newValue) || newValue < 0 || newValue >= 100) {
                await sendTempMessage(ctx, ` Diskon tidak valid. Masukkan angka 0–99\nContoh: <code>50</code> untuk diskon 50%`);
                return;
            }
            try {
                safeSetDiskonReseller(newValue);
            } catch (e) {
                await sendTempMessage(ctx, ` Gagal menyimpan: fungsi diskon reseller belum terhubung ke bot.js. Cek console log.`);
                console.error('[Reseller]', e.message);
                return;
            }
            await sendResultMessage(ctx, ` Diskon Reseller diubah menjadi <b>${newValue}%</b>\n\n Berlaku untuk semua harga create &amp; renew reseller.\n Perubahan langsung berlaku tanpa restart.`);
            break;
        case 'harga_sc_30':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 1000) {
                await sendTempMessage(ctx, ` Harga tidak valid. Minimal Rp 1.000`);
                return;
            }
            setHargaSC30Hari(newValue);
            updateEnvValue('HARGA_SC_PER_IP_30HARI', newValue.toString());
            await sendResultMessage(ctx,
                ` <b>Harga SC 30 Hari diubah menjadi ${formatRp(newValue)}</b>\n\n` +
                `· 60 Hari → ${formatRp(hitungHargaSC(1, 60))}\n` +
                `· 90 Hari → ${formatRp(hitungHargaSC(1, 90))}\n\n` +
                ` Perubahan langsung berlaku tanpa restart.`
            );
            userStates.delete(userId);
            await showAdminSewaScMenu(ctx);
            return;
        case 'harga_sc_lifetime':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 1000) {
                await sendTempMessage(ctx, ` Harga tidak valid. Minimal Rp 1.000`);
                return;
            }
            sewaSCModule._setHargaSCLifetime(newValue);
            updateEnvValue('HARGA_SC_LIFETIME', newValue.toString());
            await sendResultMessage(ctx,
                ` <b>Harga SC Lifetime diubah menjadi ${formatRp(newValue)}</b> / IP\n\n` +
                ` Perubahan langsung berlaku tanpa restart.`
            );
            userStates.delete(userId);
            await showAdminSewaScMenu(ctx);
            return;
        case 'harga_sc_extra':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 0) {
                await sendTempMessage(ctx, ` Harga tidak valid. Masukkan angka positif atau 0 (contoh: 25000)`);
                return;
            }
            setHargaSCExtraIp(newValue);
            updateEnvValue('HARGA_SC_EXTRA_IP', newValue.toString());
            await sendResultMessage(ctx,
                ` <b>Harga IP Tambahan diubah menjadi ${formatRp(newValue)}</b> / IP\n\n` +
                ` Perubahan langsung berlaku tanpa restart.`
            );
            userStates.delete(userId);
            await showAdminSewaScMenu(ctx);
            return;
        case 'harga_bot_30':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 1000) {
                await sendTempMessage(ctx, ` Harga tidak valid. Minimal Rp 1.000`);
                return;
            }
            setHargaBotSeller30Hari(newValue);
            updateEnvValue('HARGA_BOT_SELLER_30HARI', newValue.toString());
            await sendResultMessage(ctx,
                ` <b>Harga Sewa Bot 30 Hari diubah menjadi ${formatRp(newValue)}</b>\n\n` +
                `· 60 Hari → ${formatRp(hitungHargaBotSeller(60))}\n` +
                `· 90 Hari → ${formatRp(hitungHargaBotSeller(90))}\n\n` +
                ` Perubahan langsung berlaku tanpa restart.`
            );
            userStates.delete(userId);
            await showAdminSewaBotMenu(ctx);
            return;
        case 'harga_bot_lifetime':
            newValue = parseInt(input);
            if (isNaN(newValue) || newValue < 1000) {
                await sendTempMessage(ctx, ` Harga tidak valid. Minimal Rp 1.000`);
                return;
            }
            setHargaBotSellerLifetime(newValue);
            updateEnvValue('HARGA_BOT_SELLER_LIFETIME', newValue.toString());
            await sendResultMessage(ctx,
                ` <b>Harga Sewa Bot Lifetime diubah menjadi ${formatRp(newValue)}</b>\n\n` +
                ` Perubahan langsung berlaku tanpa restart.`
            );
            userStates.delete(userId);
            await showAdminSewaBotMenu(ctx);
            return;
        case 'qris_fee':
            newValue = parseFloat(input);
            if (isNaN(newValue) || newValue < 0 || newValue > 10) {
                await sendTempMessage(ctx, ` Fee tidak valid. Masukkan angka 0–10\nContoh: <code>0.7</code> untuk 0.7%`);
                return;
            }
            updateConfig('QRIS_FEE_PERSEN', newValue);
            const feeText = newValue === 0 ? 'Tidak aktif (0%)' : `${newValue}%`;
            await sendResultMessage(ctx, ` Fee QRIS diubah menjadi <b>${feeText}</b>\n\nBerlaku untuk QRIS Dinamis dan QRIS Pakasir.\n\n Perubahan langsung berlaku tanpa restart.`);
            break;

        case 'merchant_name':
            if (!input || input.length < 3) {
                await sendTempMessage(ctx, ` Nama merchant terlalu pendek`);
                return;
            }
            updateConfig('MERCHANT_NAME', input);
            await sendResultMessage(ctx, ` Nama Merchant diubah menjadi <b>${input}</b>\n\n Perubahan langsung berlaku tanpa restart.`);
            break;

        //  GitHub Settings 
        case 'github_token':
            if (!input || input.length < 10) {
                await sendTempMessage(ctx, ` Token tidak valid. Masukkan GitHub Personal Access Token yang benar.`);
                return;
            }
            setGithubToken(input);
            updateEnvValue('GITHUB_TOKEN', input);
            await sendResultMessage(ctx,
                ` <b>GitHub Token berhasil diubah!</b>\n` +
                ` Token: <code>${input.substring(0,6)}...${input.slice(-4)}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'github_owner':
            if (!input || input.length < 1) {
                await sendTempMessage(ctx, ` Owner tidak boleh kosong.`);
                return;
            }
            setGithubOwner(input);
            updateEnvValue('GITHUB_OWNER', input);
            await sendResultMessage(ctx,
                ` <b>GitHub Owner berhasil diubah!</b>\n` +
                ` Owner: <code>${input}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'github_repo':
            if (!input || input.length < 1) {
                await sendTempMessage(ctx, ` Nama repo tidak boleh kosong.`);
                return;
            }
            setGithubRepo(input);
            updateEnvValue('GITHUB_REPO', input);
            await sendResultMessage(ctx,
                ` <b>GitHub Repo berhasil diubah!</b>\n` +
                ` Repo: <code>${getGithubOwner()}/${input}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'github_branch':
            if (!input || input.length < 1) {
                await sendTempMessage(ctx, ` Nama branch tidak boleh kosong.`);
                return;
            }
            setGithubBranch(input);
            updateEnvValue('GITHUB_BRANCH', input);
            await sendResultMessage(ctx,
                ` <b>GitHub Branch berhasil diubah!</b>\n` +
                ` Branch: <code>${input}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'sc_github_token':
            if (!input || input.length < 10) {
                await sendTempMessage(ctx, ` Token tidak valid. Masukkan GitHub Personal Access Token yang benar.`);
                return;
            }
            setScGithubToken(input);
            updateEnvValue('SC_GITHUB_TOKEN', input);
            await sendResultMessage(ctx,
                ` <b>Token Sewa SC berhasil diubah!</b>\n` +
                ` Token: <code>${input.substring(0,6)}...${input.slice(-4)}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'sc_github_owner':
            if (!input || input.length < 1) {
                await sendTempMessage(ctx, ` Owner tidak boleh kosong.`);
                return;
            }
            setScGithubOwner(input);
            updateEnvValue('SC_GITHUB_OWNER', input);
            await sendResultMessage(ctx,
                ` <b>Owner Sewa SC berhasil diubah!</b>\n` +
                ` Owner: <code>${input}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'sc_github_repo':
            if (!input || input.length < 1) {
                await sendTempMessage(ctx, ` Nama repo tidak boleh kosong.`);
                return;
            }
            setScGithubRepo(input);
            updateEnvValue('SC_GITHUB_REPO', input);
            await sendResultMessage(ctx,
                ` <b>Repo Sewa SC berhasil diubah!</b>\n` +
                ` Repo: <code>${getScGithubOwner()}/${input}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'sc_github_branch':
            if (!input || input.length < 1) {
                await sendTempMessage(ctx, ` Nama branch tidak boleh kosong.`);
                return;
            }
            setScGithubBranch(input);
            updateEnvValue('SC_GITHUB_BRANCH', input);
            await sendResultMessage(ctx,
                ` <b>Branch Sewa SC berhasil diubah!</b>\n` +
                ` Branch: <code>${input}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        //  Pakasir Settings 
        case 'pakasir_apikey':
            if (!input || input.length < 5) {
                await sendTempMessage(ctx, ` API Key tidak valid. Masukkan API Key Pakasir yang benar.`);
                return;
            }
            setPakasirApiKey(input);
            updateEnvValue('PAKASIR_API_KEY', input);
            await sendResultMessage(ctx,
                ` <b>Pakasir API Key berhasil diset!</b>\n` +
                ` Key: <code>${input.substring(0,6)}...${input.slice(-4)}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'pakasir_slug':
            if (!input || input.length < 1) {
                await sendTempMessage(ctx, ` Slug tidak boleh kosong.`);
                return;
            }
            setPakasirSlug(input.trim().toLowerCase());
            updateEnvValue('PAKASIR_SLUG', getPakasirSlug());
            await sendResultMessage(ctx,
                ` <b>Pakasir Slug Proyek berhasil diset!</b>\n` +
                ` Slug: <code>${getPakasirSlug()}</code>\n` +
                ` URL Bayar: <code>https://app.pakasir.com/pay/${getPakasirSlug()}/{amount}</code>\n\n` +
                ` Berlaku langsung tanpa restart.`
            );
            break;

        case 'pakasir_merchant':
            setPakasirMerchantName((input.trim() === '-') ? '' : input.trim());
            updateEnvValue('PAKASIR_MERCHANT_NAME', getPakasirMerchantName());
            await sendResultMessage(ctx,
                ` <b>Nama Merchant Pakasir berhasil diubah!</b>\n` +
                ` Merchant: <b>${getPakasirMerchantName() || '(menggunakan ' + CONFIG.MERCHANT_NAME + ')'}</b>\n\n` +
                ` Berlaku langsung tanpa restart.\n` +
                ` Tip: Kosongkan untuk fallback ke Nama Merchant utama (<b>${CONFIG.MERCHANT_NAME}</b>).`
            );
            break;

        //  DANA Settings 
        case 'dana_nomor':
            if (!input || input.trim().length < 6) {
                await sendTempMessage(ctx, ` Nomor DANA tidak valid.`);
                return;
            }
            setDanaNomor(input.trim());
            updateEnvValue('DANA_NOMOR', getDanaNomor());
            await sendResultMessage(ctx,
                ` <b>Nomor DANA berhasil diubah!</b>\n` +
                ` Nomor: <code>${getDanaNomor()}</code>\n\n Berlaku langsung tanpa restart.`
            );
            break;
        case 'dana_nama':
            if (!input || input.trim().length < 2) {
                await sendTempMessage(ctx, ` Nama DANA tidak valid.`);
                return;
            }
            setDanaNama(input.trim());
            updateEnvValue('DANA_NAMA', getDanaNama());
            await sendResultMessage(ctx,
                ` <b>Nama pemilik DANA berhasil diubah!</b>\n` +
                ` Nama: <b>${getDanaNama()}</b>\n\n Berlaku langsung tanpa restart.`
            );
            break;

        //  GoPay Settings 
        case 'gopay_nomor':
            if (!input || input.trim().length < 6) {
                await sendTempMessage(ctx, ` Nomor GoPay tidak valid.`);
                return;
            }
            setGopayNomor(input.trim());
            updateEnvValue('GOPAY_NOMOR', getGopayNomor());
            await sendResultMessage(ctx,
                ` <b>Nomor GoPay berhasil diubah!</b>\n` +
                ` Nomor: <code>${getGopayNomor()}</code>\n\n Berlaku langsung tanpa restart.`
            );
            break;
        case 'gopay_nama':
            if (!input || input.trim().length < 2) {
                await sendTempMessage(ctx, ` Nama GoPay tidak valid.`);
                return;
            }
            setGopayNama(input.trim());
            updateEnvValue('GOPAY_NAMA', getGopayNama());
            await sendResultMessage(ctx,
                ` <b>Nama pemilik GoPay berhasil diubah!</b>\n` +
                ` Nama: <b>${getGopayNama()}</b>\n\n Berlaku langsung tanpa restart.`
            );
            break;
    }
    
    userStates.delete(userId);
    // Kembali ke submenu yang sesuai setelah simpan
    if (['pakasir_apikey','pakasir_slug','pakasir_merchant'].includes(field)) {
        await showAdminSettingsPakasir(ctx);
    } else if (['dana_nomor','dana_nama'].includes(field)) {
        await showAdminSettingsDana(ctx);
    } else if (['gopay_nomor','gopay_nama'].includes(field)) {
        await showAdminSettingsGopay(ctx);
    } else if (['github_token','github_owner','github_repo','github_branch'].includes(field)) {
        await showAdminSettingsGithubBackup(ctx);
    } else if (['sc_github_token','sc_github_owner','sc_github_repo','sc_github_branch'].includes(field)) {
        await showAdminSettingsGithubSewaSc(ctx);
    } else if (['harga_edurc'].includes(field)) {
        await showAdminServerMenu(ctx);
    } else if (['qris_fee'].includes(field)) {
        await showAdminSettingsUmum(ctx);
    } else if (['merchant_name'].includes(field)) {
        await showAdminSettingsQris(ctx);
    } else if (['harga_reseller', 'diskon_reseller'].includes(field)) {
        await showAdminManageResellerList(ctx);
    } else {
        await showAdminSettingsUmum(ctx);
    }
}

async function showAdminServerMenu(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const servers = Object.values(getServers());
    let list = '';
    servers.forEach(s => { list += `\n${getServerTypeIcon(s.type)} <b>${s.name}</b>  <i>${s.type.toUpperCase()}</i>`; });
    
    const text = `${getHeader(' 𝙎𝙀𝙍𝙑𝙀𝙍 𝙈𝘼𝙉𝘼𝙂𝙀𝙈𝙀𝙉𝙏')}
<blockquote>📊 <b>Total Server:</b> ${servers.length}</blockquote>
${servers.length > 0 ? `\n🗂 <b>Daftar Server</b>${list}` : '\n⚠️ Belum ada server'}`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '🖥 𝙇𝙞𝙝𝙖𝙩 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_server_list' }],
        [{ text: '➕ 𝙏𝙖𝙢𝙗𝙖𝙝 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_server_add' }],
        [{ text: '✏️ 𝙀𝙙𝙞𝙩 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_server_edit' }],
        [{ text: '💰 𝙀𝙙𝙞𝙩 𝙃𝙖𝙧𝙜𝙖 𝙥𝙚𝙧 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_server_harga_list' }],
        [{ text: '📦 𝙀𝙙𝙞𝙩 𝙌𝙪𝙤𝙩𝙖 𝙥𝙚𝙧 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_server_quota_list' }],
        [{ text: '🎯 𝙀𝙙𝙞𝙩 𝙎𝙡𝙤𝙩 𝙥𝙚𝙧 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_server_slot_list' }],
        [{ text: '💰 𝙏𝙖𝙢𝙗𝙖𝙝𝙖𝙣 𝙃𝙖𝙧𝙜𝙖 𝙀𝘿𝙐𝙍𝘾/𝘾𝙁', callback_data: 'admin_edit_harga_edurc' }],
        [{ text: '🗑 𝙃𝙖𝙥𝙪𝙨 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_server_delete' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

async function showAdminServerList(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const servers = Object.values(getServers());
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server.`);
        return;
    }
    
    let text = `${getHeader(' 𝘿𝘼𝙁𝙏𝘼𝙍 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote>📊 <b>Total Server:</b> ${servers.length}</blockquote>\n`;
    for (const s of servers) {
        const icon = getServerTypeIcon(s.type);
        const hargaInfo = s.hargaPerHari != null
            ? `💰 <b>Rp ${s.hargaPerHari.toLocaleString('id-ID')}/hari</b> <i>(custom)</i>`
            : `💰 Rp ${CONFIG.HARGA_PER_HARI_PER_IP.toLocaleString('id-ID')}/hari <i>(global)</i>`;
        const quotaInfo = s.quotaGb != null
            ? `📦 <b>${formatQuotaLabel(s.quotaGb)}</b> <i>(custom)</i>`
            : `📦 ${formatQuotaLabel(CONFIG.DEFAULT_QUOTA)} <i>(global)</i>`;

        let domainBiasa = s.apiUrl;
        try { domainBiasa = new URL(s.apiUrl).hostname; } catch (_) {
            domainBiasa = String(s.apiUrl || '').replace(/^https?:\/\//, '').split(':')[0];
        }
        const cdnDomain = getEdurcDomain(s.id);
        const cdnLabel = cdnDomain ? `<code>${cdnDomain}</code>` : '<i>belum disetel</i>';

        text += `\n${icon} <b>${s.name}</b>  <i>${s.type.toUpperCase()}</i>
<blockquote>🔗 <code>${s.apiUrl}</code>
🔑 <code>${s.authKey}</code>
🌐 𝘿𝙤𝙢𝙖𝙞𝙣 𝘽𝙞𝙖𝙨𝙖: <code>${domainBiasa}</code>
🛡 𝘿𝙤𝙢𝙖𝙞𝙣 𝙀𝘿𝙐𝙍𝘾/𝘾𝘿𝙉: ${cdnLabel}
${hargaInfo}
${quotaInfo}
🎯 <b>Slot:</b> ${formatSlotLabel(s)}</blockquote>\n`;
    }
    
    const keyboard = Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_server_menu', style: 'danger' }]]);
    await sendMenu(ctx, text, keyboard);
}

async function showAdminServerAdd(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_server_add', step: 'input_name' });
    
    const text = `${getHeader(' 𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙍𝙑𝙀𝙍')}

<b>· LANGKAH 1/4 - Masukkan Nama Server</b>

Contoh: Server SG 01`;
    
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]
    ]));
}

async function processAdminServerAddName(ctx, name) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'admin_server_add') return;
    
    if (name.length < 3) {
        await sendTempMessage(ctx, ` Nama server terlalu pendek (minimal 3 karakter)`);
        return;
    }
    
    userStates.set(userId, { ...state, step: 'input_type', data: { name } });
    
    const text = `${getHeader(' 𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙍𝙑𝙀𝙍')}

 Nama Server: <b>${name}</b>

<b>· LANGKAH 2/4 - Pilih Tipe Server</b>

Silakan pilih tipe server:`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔑 𝙎𝙎𝙃', callback_data: 'admin_server_type_ssh' }],
        [{ text: '⚡ 𝙓𝙍𝘼𝙔 (𝙏𝙍𝙊𝙅𝘼𝙉/𝙑𝙇𝙀𝙎𝙎/𝙑𝙈𝙀𝙎𝙎)', callback_data: 'admin_server_type_xray' }],
        [{ text: '🌐 𝙕𝙄𝙑𝙋𝙉', callback_data: 'admin_server_type_zivpn' }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

async function processAdminServerAddType(ctx, type) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'admin_server_add') return;
    
    userStates.set(userId, { ...state, step: 'input_domain', data: { ...state.data, type } });
    
    const text = `${getHeader(' 𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙍𝙑𝙀𝙍')}

 Nama Server: <b>${state.data.name}</b>
 Tipe Server: <b>${type}</b>

<b>· LANGKAH 3/4 - Masukkan Domain dan Port</b>

Format: <b>domain:port</b>
Contoh: <code>vps123.example.com:8585</code>`;
    
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]
    ]));
}

async function processAdminServerAddDomain(ctx, domainPort) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'admin_server_add') return;
    
    const lastColonIndex = domainPort.lastIndexOf(':');
    if (lastColonIndex === -1) {
        await sendTempMessage(ctx, ` Format salah! Gunakan: <b>domain:port</b>\nContoh: <code>vps123.example.com:8585</code>`);
        return false;
    }
    
    const domain = domainPort.substring(0, lastColonIndex);
    const portStr = domainPort.substring(lastColonIndex + 1);
    const port = parseInt(portStr);
    
    if (isNaN(port)) {
        await sendTempMessage(ctx, ` Port harus berupa angka!`);
        return false;
    }
    
    userStates.set(userId, { ...state, step: 'input_authkey', data: { ...state.data, domain, port } });
    
    const text = `${getHeader(' 𝙏𝘼𝙈𝘽𝘼𝙃 𝙎𝙀𝙍𝙑𝙀𝙍')}

 Nama Server: <b>${state.data.name}</b>
 Tipe Server: <b>${state.data.type}</b>
 Domain: <b>${domain}</b>
 Port: <b>${port}</b>

<b>· LANGKAH 4/4 - Masukkan API Key / Auth Key</b>

Masukkan API Key yang digunakan untuk autentikasi ke server.`;
    
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]
    ]));
}

async function processAdminServerAddAuthKey(ctx, authKey) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'admin_server_add') return;
    
    if (authKey.length < 5) {
        await sendTempMessage(ctx, ` API Key terlalu pendek!`);
        return;
    }
    
    const newId = generateServerId();
    getServers()[newId] = { 
        id: newId, 
        name: state.data.name, 
        apiUrl: `http://${state.data.domain}:${state.data.port}`, 
        authKey: authKey, 
        type: state.data.type 
    };
    saveServers(getServers());
    
    userStates.delete(userId);
    
    const text = `<b>· Server ${state.data.name} berhasil ditambahkan!</b>

 URL: <code>${state.data.domain}:${state.data.port}</code>
 Auth Key: <code>${authKey}</code>
 Tipe: ${state.data.type}`;
    
    await sendResultMessage(ctx, text);
    await showAdminServerMenu(ctx);
}

async function showAdminServerEdit(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const servers = Object.values(getServers());
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server untuk diedit.`);
        return;
    }
    
    const text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙎𝙀𝙍𝙑𝙀𝙍')}

 Pilih server yang akan diedit:`;
    
    const keyboard = Markup.inlineKeyboard([]);
    
    for (const s of servers) {
        const icon = getServerTypeIcon(s.type);
        keyboard.reply_markup.inline_keyboard.push([
            { text: `${icon} ${s.name} (${s.type.toUpperCase()})`, callback_data: `admin_edit_server_${s.id}` }
        ]);
    }
    keyboard.reply_markup.inline_keyboard.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]);
    
    await sendMenu(ctx, text, keyboard);
}

async function processAdminServerEditSelect(ctx, serverId) {
    if (!isAdmin(ctx.from.id)) return;
    
    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        await showAdminServerMenu(ctx);
        return;
    }
    
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_server_edit_field', serverId, server });
    
    const icon = getServerTypeIcon(server.type);
    const cdnDomain = getEdurcDomain(serverId);
    const cdnLabel = cdnDomain ? `<code>${cdnDomain}</code>` : '<i>belum disetel</i>';
    let domainBiasa = server.apiUrl;
    try { domainBiasa = new URL(server.apiUrl).hostname; } catch (_) {
        domainBiasa = String(server.apiUrl || '').replace(/^https?:\/\//, '').split(':')[0];
    }

    const text = `${getHeader(` 𝙀𝘿𝙄𝙏 𝙎𝙀𝙍𝙑𝙀𝙍: ${server.name}`)}

<b>📋 Data Saat Ini</b>
<blockquote>${icon} <b>Nama:</b> ${server.name}
🏷 <b>Tipe:</b> <i>${server.type.toUpperCase()}</i>
🔗 <b>API URL:</b> <code>${server.apiUrl}</code>
🔑 <b>Auth Key:</b> <code>${server.authKey}</code>
🌐 <b>Domain Biasa:</b> <code>${domainBiasa}</code>
🛡 <b>Domain CDN (EDURC):</b> ${cdnLabel}</blockquote>

 Pilih field yang akan diedit:`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '🏷 𝙉𝙖𝙢𝙖 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_edit_field_name' }],
        [{ text: '🔗 𝘼𝙋𝙄 𝙐𝙍𝙇', callback_data: 'admin_edit_field_apiurl' }],
        [{ text: '🔐 𝘼𝙪𝙩𝙝 𝙆𝙚𝙮', callback_data: 'admin_edit_field_authkey' }],
        [{ text: '🖥 𝙏𝙞𝙥𝙚 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: 'admin_edit_field_type' }],
        [{ text: '🌐 𝘿𝙤𝙢𝙖𝙞𝙣 𝘾𝘿𝙉 (𝙀𝘿𝙐𝙍𝘾)', callback_data: 'admin_edit_field_cdn' }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

async function processAdminServerEditField(ctx, field, serverId) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'admin_server_edit_field') return;
    
    userStates.set(userId, { ...state, editField: field, step: 'input_value' });
    
    let prompt = '';
    switch(field) {
        case 'name':
            prompt = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙉𝘼𝙈𝘼 𝙎𝙀𝙍𝙑𝙀𝙍')}

 Masukkan nama baru untuk server <b>${state.server.name}</b>

Contoh: Server SG Premium`;
            break;
        case 'apiurl':
            prompt = `${getHeader(' 𝙀𝘿𝙄𝙏 𝘼𝙋𝙄 𝙐𝙍𝙇')}

 Masukkan API URL baru untuk server <b>${state.server.name}</b>

Format: <b>http://domain:port</b>
Contoh: <code>http://vps123.example.com:8585</code>`;
            break;
        case 'authkey':
            prompt = `${getHeader(' 𝙀𝘿𝙄𝙏 𝘼𝙐𝙏𝙃 𝙆𝙀𝙔')}

 Masukkan Auth Key baru untuk server <b>${state.server.name}</b>`;
            break;
        case 'cdn':
            const cdnDomainNow = getEdurcDomain(serverId);
            const cdnKeyboard = Markup.inlineKeyboard([
                ...(cdnDomainNow ? [[{ text: '🗑 𝙃𝙖𝙥𝙪𝙨 𝘿𝙤𝙢𝙖𝙞𝙣 𝘾𝘿𝙉', callback_data: 'admin_edit_cdn_clear' }]] : []),
                [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]
            ]);
            await sendMenu(ctx, `${getHeader('🌐 𝙀𝘿𝙄𝙏 𝘿𝙊𝙈𝘼𝙄𝙉 𝘾𝘿𝙉 (𝙀𝘿𝙐𝙍𝘾)')}

 Masukkan domain CDN baru untuk server <b>${state.server.name}</b>

Domain ini akan menggantikan address/host/SNI pada hasil <b>VPN EDURC</b> (Trojan/VLess/VMess), atau domain pada hasil <b>SSH CloudFront</b>, untuk server ini.

Domain saat ini: ${cdnDomainNow ? `<code>${cdnDomainNow}</code>` : '<i>belum disetel</i>'}

Contoh: <code>cdn.cloudflare-example.com</code>`, cdnKeyboard);
            return;
        case 'type':
            const keyboard = Markup.inlineKeyboard([
                [{ text: '🔑 𝙎𝙎𝙃', callback_data: 'admin_edit_type_ssh' }],
                [{ text: '⚡ 𝙓𝙍𝘼𝙔', callback_data: 'admin_edit_type_xray' }],
                [{ text: '🌐 𝙕𝙄𝙑𝙋𝙉', callback_data: 'admin_edit_type_zivpn' }],
                [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]
            ]);
            await sendMenu(ctx, `${getHeader(' 𝙀𝘿𝙄𝙏 𝙏𝙄𝙋𝙀 𝙎𝙀𝙍𝙑𝙀𝙍')}

 Pilih tipe baru untuk server <b>${state.server.name}</b>

Tipe saat ini: ${state.server.type}`, keyboard);
            return;
    }
    
    await sendMenu(ctx, prompt, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]
    ]));
}

async function processAdminServerEditValue(ctx, value, field, serverId) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'admin_server_edit_field') return;
    
    let updated = false;
    
    switch(field) {
        case 'name':
            if (value.length < 3) {
                await sendTempMessage(ctx, ` Nama server terlalu pendek (minimal 3 karakter)`);
                return;
            }
            getServers()[serverId].name = value;
            updated = true;
            break;
        case 'apiurl':
            let apiUrl = value.replace(/\/$/, '');
            if (!apiUrl.startsWith('http://') && !apiUrl.startsWith('https://')) {
                apiUrl = 'http://' + apiUrl;
            }
            getServers()[serverId].apiUrl = apiUrl;
            updated = true;
            break;
        case 'authkey':
            if (value.length < 5) {
                await sendTempMessage(ctx, ` Auth Key terlalu pendek (minimal 5 karakter)`);
                return;
            }
            getServers()[serverId].authKey = value;
            updated = true;
            break;
        case 'type':
            getServers()[serverId].type = value;
            updated = true;
            break;
        case 'cdn':
            const newCdnDomain = value.replace(/^https?:\/\//, '').replace(/\/.*$/, '').trim();
            if (newCdnDomain.length < 3) {
                await sendTempMessage(ctx, ` Domain CDN terlalu pendek / tidak valid.`);
                return;
            }
            setEdurcDomain(serverId, newCdnDomain);
            userStates.delete(userId);
            await sendResultMessage(ctx, ` Domain CDN (EDURC) untuk server "<b>${state.server.name}</b>" berhasil disetel ke <code>${newCdnDomain}</code>!`);
            await showAdminServerMenu(ctx);
            return;
    }
    
    if (updated) {
        saveServers(getServers());
        userStates.delete(userId);
        
        await sendResultMessage(ctx, ` Server "<b>${state.server.name}</b>" berhasil diupdate!`);
        await showAdminServerMenu(ctx);
    }
}

async function showAdminServerHargaList(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const servers = Object.values(getServers());
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server untuk diedit harganya.`);
        return;
    }

    let text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙃𝘼𝙍𝙂𝘼 𝙋𝙀𝙍 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b>ℹ Harga Global:</b> Rp ${CONFIG.HARGA_PER_HARI_PER_IP.toLocaleString('id-ID')}/hari/IP</blockquote>

Pilih server untuk mengubah harganya:`;

    const buttons = servers.map(s => {
        const harga = s.hargaPerHari != null
            ? `Rp ${s.hargaPerHari.toLocaleString('id-ID')}/hari`
            : `(global)`;
        const icon = getServerTypeIcon(s.type);
        return [{ text: `${icon} ${s.name} — 💰 ${harga}`, callback_data: `admin_server_harga_edit_${s.id}` }];
    });
    buttons.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙎𝙚𝙧𝙫𝙚𝙧 𝙈𝙖𝙣𝙖𝙜𝙚𝙢𝙚𝙣𝙩', callback_data: 'admin_server_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(buttons));
}

async function showAdminServerHargaEdit(ctx, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_edit_server_harga', serverId });

    const currentHarga = server.hargaPerHari != null
        ? `Rp ${server.hargaPerHari.toLocaleString('id-ID')}/hari (custom)`
        : `Rp ${CONFIG.HARGA_PER_HARI_PER_IP.toLocaleString('id-ID')}/hari (global)`;

    const text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙃𝘼𝙍𝙂𝘼 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b>Server :</b> ${server.name}
<b>Harga  :</b> ${currentHarga}</blockquote>

Kirim harga baru per hari/IP (angka saja, contoh: <code>500</code>).
Kirim <code>reset</code> untuk kembali ke harga global.`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '🔄 𝙍𝙚𝙨𝙚𝙩 𝙠𝙚 𝙃𝙖𝙧𝙜𝙖 𝙂𝙡𝙤𝙗𝙖𝙡', callback_data: `admin_server_harga_reset_${serverId}` }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_harga_list', style: 'danger' }]
    ]));
}

async function processAdminServerHargaInput(ctx, input, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();

    if (input.trim().toLowerCase() === 'reset') {
        getServers()[serverId].hargaPerHari = null;
        saveServers(getServers());
        userStates.delete(userId);
        await sendResultMessage(ctx,
            ` Harga server <b>${server.name}</b> direset ke harga global (Rp ${CONFIG.HARGA_PER_HARI_PER_IP.toLocaleString('id-ID')}/hari/IP).`
        );
        await showAdminServerHargaList(ctx);
        return;
    }

    const harga = parseInt(input.replace(/\D/g, ''));
    if (isNaN(harga) || harga < 1) {
        await sendTempMessage(ctx, ` Harga tidak valid. Masukkan angka positif.\nContoh: <code>500</code>`);
        return;
    }

    getServers()[serverId].hargaPerHari = harga;
    saveServers(getServers());
    userStates.delete(userId);
    await sendResultMessage(ctx,
        ` Harga server <b>${server.name}</b> diubah ke <b>Rp ${harga.toLocaleString('id-ID')}/hari/IP</b>.`
    );
    await showAdminServerHargaList(ctx);
}

async function showAdminServerQuotaList(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const servers = Object.values(getServers());
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server untuk diedit quotanya.`);
        return;
    }

    let text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙌𝙐𝙊𝙏𝘼 𝙋𝙀𝙍 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b>ℹ Quota Global:</b> ${formatQuotaLabel(CONFIG.DEFAULT_QUOTA)}</blockquote>

Pilih server untuk mengubah quotanya:`;

    const buttons = servers.map(s => {
        const quota = s.quotaGb != null
            ? formatQuotaLabel(s.quotaGb)
            : `(global)`;
        const icon = getServerTypeIcon(s.type);
        return [{ text: `${icon} ${s.name} — 📦 ${quota}`, callback_data: `admin_server_quota_edit_${s.id}` }];
    });
    buttons.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙎𝙚𝙧𝙫𝙚𝙧 𝙈𝙖𝙣𝙖𝙜𝙚𝙢𝙚𝙣𝙩', callback_data: 'admin_server_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(buttons));
}

async function showAdminServerQuotaEdit(ctx, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_edit_server_quota', serverId });

    const currentQuota = server.quotaGb != null
        ? `${formatQuotaLabel(server.quotaGb)} (custom)`
        : `${formatQuotaLabel(CONFIG.DEFAULT_QUOTA)} (global)`;

    const text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙌𝙐𝙊𝙏𝘼 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b>Server :</b> ${server.name}
<b>Quota  :</b> ${currentQuota}</blockquote>

Kirim quota baru dalam GB (angka saja, contoh: <code>50</code>).
Kirim <code>0</code> untuk Unlimited.
Kirim <code>reset</code> untuk kembali ke quota global.`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '🔄 𝙍𝙚𝙨𝙚𝙩 𝙠𝙚 𝙌𝙪𝙤𝙩𝙖 𝙂𝙡𝙤𝙗𝙖𝙡', callback_data: `admin_server_quota_reset_${serverId}` }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_quota_list', style: 'danger' }]
    ]));
}

async function processAdminServerQuotaInput(ctx, input, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();

    if (input.trim().toLowerCase() === 'cancel') {
        userStates.delete(userId);
        await showAdminServerQuotaEdit(ctx, serverId);
        return;
    }

    if (input.trim().toLowerCase() === 'reset') {
        getServers()[serverId].quotaGb = null;
        saveServers(getServers());
        userStates.delete(userId);
        await sendResultMessage(ctx,
            ` Quota server <b>${server.name}</b> direset ke quota global (${formatQuotaLabel(CONFIG.DEFAULT_QUOTA)}).`
        );
        await showAdminServerQuotaList(ctx);
        return;
    }

    const quota = parseInt(input.replace(/\D/g, ''));
    if (isNaN(quota) || quota < 0) {
        await sendTempMessage(ctx, ` Quota tidak valid. Masukkan angka 0 (Unlimited) atau lebih.\nContoh: <code>50</code>`);
        return;
    }

    getServers()[serverId].quotaGb = quota;
    saveServers(getServers());
    userStates.delete(userId);
    await sendResultMessage(ctx,
        ` Quota server <b>${server.name}</b> diubah ke <b>${formatQuotaLabel(quota)}</b>.`
    );
    await showAdminServerQuotaList(ctx);
}

// Satukan server yang apiUrl-nya sama (SSH & XRAY dkk di server fisik yang sama)
// jadi HANYA SATU baris — wakilnya selalu entri bertipe SSH bila ada di grup itu.
function getServerSlotGroupRepresentatives() {
    const allServers = Object.values(getServers());
    const groups = new Map();
    for (const s of allServers) {
        const key = getServerGroupKey(s) || `__no_group_${s.id}`;
        const existing = groups.get(key);
        if (!existing || (s.type === 'ssh' && existing.type !== 'ssh')) {
            groups.set(key, s);
        }
    }
    return Array.from(groups.values());
}

async function showAdminServerSlotList(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const servers = getServerSlotGroupRepresentatives();
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server untuk diedit slotnya.`);
        return;
    }

    let text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙎𝙇𝙊𝙏 𝙋𝙀𝙍 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote>ℹ️ <b>Slot</b> = batas maksimum akun aktif (non-trial) yang boleh dibuat di satu server. Kosongkan / reset untuk <b>Unlimited</b>.
🔗 Server dengan mode/tipe berbeda (mis. SSH &amp; XRAY) di alamat yang sama dianggap <b>satu server fisik</b>, jadi slotnya digabung dan cukup diwakili satu baris.</blockquote>
`;

    for (const s of servers) {
        const icon = getServerTypeIcon(s.type);
        const info = getSlotInfo(s);
        const statusIcon = info.unlimited ? '♾️' : (info.penuh ? '❌' : '✅');
        const slotTerpakai = `${info.used}`;
        const slotTotal = info.unlimited ? 'Unlimited' : `${info.max}`;
        text += `\n${icon} <b>${s.name}</b> ${statusIcon}
<blockquote>🎯 <b>Slot Terpakai:</b> ${slotTerpakai}
📦 <b>Slot Total:</b> ${slotTotal}</blockquote>`;
    }

    text += `\n\nPilih server untuk mengubah slotnya:`;

    const buttons = servers.map(s => {
        const icon = getServerTypeIcon(s.type);
        return [{ text: `${icon} ${s.name}`, callback_data: `admin_server_slot_edit_${s.id}` }];
    });
    buttons.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙎𝙚𝙧𝙫𝙚𝙧 𝙈𝙖𝙣𝙖𝙜𝙚𝙢𝙚𝙣𝙩', callback_data: 'admin_server_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(buttons));
}

// Halaman overview slot 1 server — HANYA menampilkan info + pilihan mau edit
// yang mana (Slot Total ATAU Slot Terpakai). Tidak langsung set userState di
// sini supaya tidak ada input teks "nyasar" sebelum admin benar-benar pilih.
async function showAdminServerSlotEdit(ctx, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();
    userStates.delete(userId);

    const info = getSlotInfo(server);
    const slotTerpakai = `${info.used}`;
    const slotTotal = info.unlimited ? '♾️ Unlimited' : `${info.max}`;

    const group = getServersInGroup(server);
    const groupLabel = group.length > 1
        ? `\n<b>Gabungan  :</b> ${group.map(s => `${s.name} (${s.type.toUpperCase()})`).join(', ')}`
        : '';

    const text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙎𝙇𝙊𝙏 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b>Server        :</b> ${server.name}${groupLabel}
🎯 <b>Slot Terpakai :</b> ${slotTerpakai}
📦 <b>Slot Total    :</b> ${slotTotal}</blockquote>

Pilih mau edit yang mana:`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '📦 𝙀𝙙𝙞𝙩 𝙎𝙡𝙤𝙩 𝙏𝙤𝙩𝙖𝙡', callback_data: `admin_server_slot_total_edit_${serverId}` }],
        [{ text: '🎯 𝙀𝙙𝙞𝙩 𝙎𝙡𝙤𝙩 𝙏𝙚𝙧𝙥𝙖𝙠𝙖𝙞', callback_data: `admin_server_slot_terpakai_edit_${serverId}` }],
        [{ text: '🔄 𝙍𝙚𝙨𝙚𝙩 𝙠𝙚 𝙐𝙣𝙡𝙞𝙢𝙞𝙩𝙚𝙙', callback_data: `admin_server_slot_reset_${serverId}` }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_slot_list', style: 'danger' }]
    ]));
}

// Halaman khusus edit SLOT TOTAL — baru set userState di sini, setelah admin
// benar-benar menekan tombol "Edit Slot Total".
async function showAdminServerSlotTotalEdit(ctx, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_edit_server_slot', serverId });

    const info = getSlotInfo(server);
    const slotTerpakai = `${info.used}`;
    const slotTotal = info.unlimited ? '♾️ Unlimited' : `${info.max}`;

    const group = getServersInGroup(server);
    const groupLabel = group.length > 1
        ? `\n<b>Gabungan  :</b> ${group.map(s => `${s.name} (${s.type.toUpperCase()})`).join(', ')}`
        : '';

    const text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙎𝙇𝙊𝙏 𝙏𝙊𝙏𝘼𝙇')}
<blockquote><b>Server        :</b> ${server.name}${groupLabel}
🎯 <b>Slot Terpakai :</b> ${slotTerpakai}
📦 <b>Slot Total    :</b> ${slotTotal}</blockquote>

Kirim jumlah slot maksimum baru (angka saja, contoh: <code>50</code>).
Kirim <code>reset</code> untuk kembali ke Unlimited.`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: `admin_server_slot_edit_${serverId}`, style: 'danger' }]
    ]));
}

async function showAdminServerSlotTerpakaiEdit(ctx, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'admin_edit_server_slot_terpakai', serverId });

    const info = getSlotInfo(server);
    const slotTerpakai = `${info.used}`;
    const slotTotal = info.unlimited ? '♾️ Unlimited' : `${info.max}`;

    const group = getServersInGroup(server);
    const groupLabel = group.length > 1
        ? `\n<b>Gabungan  :</b> ${group.map(s => `${s.name} (${s.type.toUpperCase()})`).join(', ')}`
        : '';

    const text = `${getHeader(' 𝙀𝘿𝙄𝙏 𝙎𝙇𝙊𝙏 𝙏𝙀𝙍𝙋𝘼𝙆𝘼𝙄')}
<blockquote><b>Server        :</b> ${server.name}${groupLabel}
🎯 <b>Slot Terpakai :</b> ${slotTerpakai}
📦 <b>Slot Total    :</b> ${slotTotal}</blockquote>

⚠️ Angka ini murni counter manual — naik/turun otomatis tiap ada akun baru dibuat/dihapus di server ini, TAPI tidak pernah di-scan ulang dari akun.json. Kalau angkanya meleset (mis. ada penghapusan lewat jalur lain), koreksi manual di sini.

Kirim jumlah slot terpakai baru (angka saja, contoh: <code>5</code>).`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: `admin_server_slot_edit_${serverId}`, style: 'danger' }]
    ]));
}

async function processAdminServerSlotTerpakaiInput(ctx, input, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();

    if (input.trim().toLowerCase() === 'cancel') {
        userStates.delete(userId);
        await showAdminServerSlotEdit(ctx, serverId);
        return;
    }

    const used = parseInt(input.replace(/\D/g, ''));
    if (isNaN(used) || used < 0) {
        await sendTempMessage(ctx, ` Jumlah tidak valid. Masukkan angka 0 atau lebih.\nContoh: <code>5</code>`);
        return;
    }

    setTotalSlotUsedManual(server, used);
    userStates.delete(userId);

    const infoNow = getSlotInfo(getServers()[serverId]);
    await sendResultMessage(ctx,
        ` Slot Terpakai server <b>${server.name}</b> diubah manual jadi <b>${used}</b>${!infoNow.unlimited ? ` (dari total ${infoNow.max}${infoNow.penuh ? ' — ⚠️ sudah PENUH' : ''})` : ''}.\n\n<i>ℹ️ Mulai sekarang angka ini akan naik/turun otomatis tiap ada akun baru dibuat/dihapus di server ini — TIDAK di-scan ulang dari akun.json.</i>`
    );
    await showAdminServerSlotList(ctx);
}

async function processAdminServerSlotInput(ctx, input, serverId) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    const userId = ctx.from.id.toString();

    if (input.trim().toLowerCase() === 'reset') {
        getServers()[serverId].maxSlot = null;
        saveServers(getServers());
        userStates.delete(userId);
        await sendResultMessage(ctx,
            ` Slot server <b>${server.name}</b> direset ke <b>Unlimited</b> (tanpa batas).`
        );
        await showAdminServerSlotList(ctx);
        return;
    }

    const slot = parseInt(input.replace(/\D/g, ''));
    if (isNaN(slot) || slot < 1) {
        await sendTempMessage(ctx, ` Jumlah slot tidak valid. Masukkan angka positif.\nContoh: <code>50</code>`);
        return;
    }

    getServers()[serverId].maxSlot = slot;
    saveServers(getServers());
    const infoNow = getSlotInfo(getServers()[serverId]);
    userStates.delete(userId);
    await sendResultMessage(ctx,
        ` Slot server <b>${server.name}</b> diubah ke:\n🎯 Slot Terpakai: <b>${infoNow.used}</b>\n📦 Slot Total: <b>${slot}</b>${infoNow.penuh ? '\n— ⚠️ sudah PENUH' : ''}`
    );
    await showAdminServerSlotList(ctx);
}

async function showAdminServerDelete(ctx) {
    if (!isAdmin(ctx.from.id)) return;

    const servers = Object.values(getServers());
    const text = `${getHeader(' 𝙃𝘼𝙋𝙐𝙎 𝙎𝙀𝙍𝙑𝙀𝙍')}

 <b>PERINGATAN:</b> Tindakan ini tidak dapat dibatalkan!

 Pilih server yang akan dihapus:`;
    
    const keyboard = Markup.inlineKeyboard([]);
    
    for (const s of servers) {
        const icon = getServerTypeIcon(s.type);
        keyboard.reply_markup.inline_keyboard.push([
            { text: `${icon} ${s.name} (${s.type.toUpperCase()})`, callback_data: `admin_delete_server_${s.id}` }
        ]);
    }
    keyboard.reply_markup.inline_keyboard.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_server_menu', style: 'danger' }]);
    
    await sendMenu(ctx, text, keyboard);
}

async function processAdminServerDelete(ctx, serverId) {
    if (!isAdmin(ctx.from.id)) return;
    
    const serverName = getServers()[serverId]?.name;
    if (!serverName) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        await showAdminServerMenu(ctx);
        return;
    }
    
    delete getServers()[serverId];
    saveServers(getServers());
    
    await sendResultMessage(ctx, ` Server "<b>${serverName}</b>" berhasil dihapus!`);
    await showAdminServerMenu(ctx);
}

async function showAdminAkunPerServer(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const servers = Object.values(getServers());
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Belum ada server terdaftar.`);
        await showAdminDashboard(ctx);
        return;
    }
    
    const text = `${getHeader('𝙇𝙄𝙎𝙏 𝘼𝙆𝙐𝙉 𝙋𝙀𝙍 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote>🗂 <b>— 𝙋𝙄𝙇𝙄𝙃 𝙎𝙀𝙍𝙑𝙀𝙍 —</b>
📡 Pilih salah satu server di bawah untuk
melihat daftar akun secara <b>live</b> dari API</blockquote>
<blockquote>🖥 <b>· Total Server:</b> ${servers.length}</blockquote>`;
    
    const keyboard = Markup.inlineKeyboard([]);
    for (const s of servers) {
        const icon = getServerTypeIcon(s.type);
        keyboard.reply_markup.inline_keyboard.push([
            { text: `${icon} ${s.name} · ${s.type.toUpperCase()}`, callback_data: `admin_server_list_akun_${s.id}` }
        ]);
    }
    keyboard.reply_markup.inline_keyboard.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]);
    
    await sendMenu(ctx, text, keyboard);
}

async function showAdminXrayTypeSelect(ctx, serverId, action = 'list') {
    if (!isAdmin(ctx.from.id)) return;
    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        await showAdminAkunPerServer(ctx);
        return;
    }
    const actionLabel = action === 'list' ? '📋 LIST' : '🗑 DELETE';
    const text = `${getHeader(`${actionLabel} 𝘼𝙆𝙐𝙉 𝙓𝙍𝘼𝙔`)}
<blockquote>🌐 <b>· Server:</b> ${server.name}</blockquote>
<blockquote>🎛 <b>— 𝙋𝙄𝙇𝙄𝙃 𝙏𝙄𝙋𝙀 𝘼𝙆𝙐𝙉 —</b>
Silakan pilih protokol akun yang ingin
ditampilkan pada server ini</blockquote>`;
    const cbPrefix = action === 'list' ? `admin_xray_list_type_${serverId}` : `admin_del_srv_type`;
    const keyboard = Markup.inlineKeyboard([
        [
            { text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: `${cbPrefix}_trojan` },
            { text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: `${cbPrefix}_vless` }
        ],
        [
            { text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: `${cbPrefix}_vmess` }
        ],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: `admin_server_list_akun_${serverId}`, style: 'danger' }]
    ]);
    await sendMenu(ctx, text, keyboard);
}

async function showAdminServerAkunList(ctx, serverId, page = 0, xrayType = null) {
    if (!isAdmin(ctx.from.id)) return;
    
    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        await showAdminAkunPerServer(ctx);
        return;
    }

    // Jika server xray dan belum pilih tipe, tampilkan pilihan tipe dulu
    if (server.type === 'xray' && !xrayType) {
        const text = `${getHeader('📋 𝙇𝙄𝙎𝙏 𝘼𝙆𝙐𝙉 𝙓𝙍𝘼𝙔')}
<blockquote>🌐 <b>· Server:</b> ${server.name}</blockquote>
<blockquote>🎛 <b>— 𝙋𝙄𝙇𝙄𝙃 𝙏𝙄𝙋𝙀 𝘼𝙆𝙐𝙉 —</b>
Pilih protokol akun yang ingin dilihat</blockquote>`;
        const keyboard = Markup.inlineKeyboard([
            [
                { text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: `admin_xray_list_type_${serverId}_trojan` },
                { text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: `admin_xray_list_type_${serverId}_vless` }
            ],
            [
                { text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: `admin_xray_list_type_${serverId}_vmess` }
            ],
            [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_akun_per_server', style: 'danger' }]
        ]);
        await sendMenu(ctx, text, keyboard);
        return;
    }
    
    // Tentukan tipe apa saja yang perlu diambil, lalu cek dulu apakah semuanya sudah ada
    // di cache (fresh) — kalau iya, SKIP pesan "Mengambil data..." karena akan instan
    // (data diambil dari cache, tidak ada request baru ke server).
    const typesNeeded = server.type === 'zivpn' ? ['zivpn']
        : server.type === 'ssh' ? ['ssh']
        : xrayType ? [xrayType]
        : ['trojan', 'vless', 'vmess'];

    if (!isServerAkunListCached(serverId, typesNeeded)) {
        await sendTempMessage(ctx, ` Mengambil data akun dari server <b>${server.name}</b>...`);
    }

    try {
        let users = [];
        for (const t of typesNeeded) {
            const data = await getServerAkunListCached(serverId, server, t);
            users = users.concat(data);
        }
        
        const typeLabel = xrayType ? ` - ${xrayType.toUpperCase()}` : '';

        if (users.length === 0) {
            const keyboard = Markup.inlineKeyboard([
                [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: server.type === 'xray' ? `admin_server_list_akun_${serverId}` : 'admin_akun_per_server', style: 'danger' }]
            ]);
            await sendMenu(ctx, `${getHeader(`🖥 ${server.name}${typeLabel}`)}
<blockquote>📭 <b>— 𝙆𝙊𝙎𝙊𝙉𝙂 —</b>
Belum ada akun terdaftar di server ini.</blockquote>`, keyboard);
            return;
        }
        
        const itemsPerPage = 10;
        const totalPages = Math.ceil(users.length / itemsPerPage);
        const start = page * itemsPerPage;
        const pageUsers = users.slice(start, start + itemsPerPage);
        
        const numberEmoji = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];
        const statusIcon = (status) => {
            const s = (status || '').toLowerCase();
            if (s === 'active' || s === 'aktif') return '✅';
            if (s === 'expired' || s === 'expire') return '❌';
            if (s === 'trial') return '🎁';
            if (s === 'suspended' || s === 'nonaktif') return '⛔';
            return '🔸';
        };
        
        let text = `${getHeader(`🖥 𝘼𝙆𝙐𝙉 𝙎𝙀𝙍𝙑𝙀𝙍: ${server.name}${typeLabel}`)}\n`;
        text += `<blockquote>📊 <b>— 𝙄𝙉𝙁𝙊 𝙎𝙀𝙍𝙑𝙀𝙍 —</b>\n`;
        text += `🌐 <b>· Server:</b> ${server.name}\n`;
        text += `🔧 <b>· Tipe:</b> ${server.type.toUpperCase()}${typeLabel}\n`;
        text += `👥 <b>· Total Akun:</b> ${users.length}\n`;
        text += `📄 <b>· Halaman:</b> ${page + 1}/${totalPages}</blockquote>\n`;
        text += `<blockquote>📋 <b>— 𝘿𝘼𝙁𝙏𝘼𝙍 𝘼𝙆𝙐𝙉 —</b>\n`;
        
        for (let i = 0; i < pageUsers.length; i++) {
            const u = pageUsers[i];
            const icon = getServerTypeIcon(u.type);
            const num = numberEmoji[i] || `${start + i + 1}.`;
            text += `${num} ${icon} <b>${u.type.toUpperCase()}</b> · <code>${u.username}</code>\n`;
            text += `　　⏰ Expired: ${u.expired}\n`;
            text += `　　📶 IP Limit: ${u.iplimit} · ${statusIcon(u.status)} ${u.status}\n`;
            if (i < pageUsers.length - 1) text += `\n`;
        }
        text += `</blockquote>`;
        
        const keyboard = Markup.inlineKeyboard([]);
        
        // Navigasi halaman
        const navButtons = [];
        if (page > 0) {
            const prevCb = xrayType
                ? `admin_xray_list_page_${serverId}_${xrayType}_${page - 1}`
                : `admin_server_list_akun_${serverId}_page_${page - 1}`;
            navButtons.push({ text: '◀ 𝙋𝙧𝙚𝙫', callback_data: prevCb });
        }
        if (page < totalPages - 1) {
            const nextCb = xrayType
                ? `admin_xray_list_page_${serverId}_${xrayType}_${page + 1}`
                : `admin_server_list_akun_${serverId}_page_${page + 1}`;
            navButtons.push({ text: '𝙉𝙚𝙭𝙩 ▶', callback_data: nextCb });
        }
        if (navButtons.length > 0) keyboard.reply_markup.inline_keyboard.push(navButtons);
        
        // Tombol delete
        keyboard.reply_markup.inline_keyboard.push([
            { text: '🗑 𝘿𝙚𝙡𝙚𝙩𝙚 𝘼𝙠𝙪𝙣 𝙙𝙞 𝙎𝙚𝙧𝙫𝙚𝙧 𝙄𝙣𝙞', callback_data: `admin_server_delete_akun_select_${serverId}` }
        ]);

        // Tombol kembali: jika xray kembali ke pilih tipe, selain itu ke list server
        const backCb = server.type === 'xray'
            ? `admin_server_list_akun_${serverId}`
            : 'admin_akun_per_server';
        keyboard.reply_markup.inline_keyboard.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: backCb, style: 'danger' }]);
        
        await sendMenu(ctx, text, keyboard);
        
    } catch (err) {
        await sendTempMessage(ctx, ` Error mengambil data: ${err.message}`);
        await showAdminAkunPerServer(ctx);
    }
}

async function showAdminDeleteAkunServer(ctx, serverId) {
    if (!isAdmin(ctx.from.id)) return;
    
    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }
    
    // Untuk xray, tanya dulu tipe service
    if (server.type === 'xray') {
        const text = `${getHeader(' 𝘿𝙀𝙇𝙀𝙏𝙀 𝘼𝙆𝙐𝙉 𝘿𝙄 𝙎𝙀𝙍𝙑𝙀𝙍')}\n\n<b>· Server:</b> ${server.name}\n<b>· Tipe Server:</b> XRAY\n\n\nPilih tipe akun yang akan dihapus:`;
        const keyboard = Markup.inlineKeyboard([
            [
                { text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: `admin_del_srv_type_${serverId}_trojan` },
                { text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: `admin_del_srv_type_${serverId}_vless` }
            ],
            [{ text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: `admin_del_srv_type_${serverId}_vmess` }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: `admin_server_list_akun_${serverId}`, style: 'danger' }]
        ]);
        await sendMenu(ctx, text, keyboard);
    } else {
        // SSH atau ZIVPN: langsung tampilkan list button
        await showAdminDeleteAkunList(ctx, serverId, server.type, 0);
    }
}

async function showAdminDeleteAkunList(ctx, serverId, serviceType, page = 0) {
    if (!isAdmin(ctx.from.id)) return;
    
    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    if (!isServerAkunListCached(serverId, [serviceType])) {
        await sendTempMessage(ctx, ` Mengambil daftar akun <b>${serviceType.toUpperCase()}</b> dari server <b>${server.name}</b>...`);
    }

    try {
        const users = (await getServerAkunListCached(serverId, server, serviceType))
            .map(u => ({ username: u.username || '-', expired: u.expired || '-' }));

        if (users.length === 0) {
            const backCb = server.type === 'xray'
                ? `admin_server_delete_akun_select_${serverId}`
                : `admin_server_list_akun_${serverId}`;
            const keyboard = Markup.inlineKeyboard([
                [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: backCb, style: 'danger' }]
            ]);
            await sendMenu(ctx, `${getHeader(' 𝘿𝙀𝙇𝙀𝙏𝙀 𝘼𝙆𝙐𝙉')}\n\n Tidak ada akun <b>${serviceType.toUpperCase()}</b> di server ini.`, keyboard);
            return;
        }

        const itemsPerPage = 8;
        const totalPages = Math.ceil(users.length / itemsPerPage);
        const start = page * itemsPerPage;
        const pageUsers = users.slice(start, start + itemsPerPage);

        const typeIcon = { ssh: '', trojan: '', vless: '', vmess: '', zivpn: '' };
        const icon = typeIcon[serviceType] || '';

        let text = `${getHeader(' 𝘿𝙀𝙇𝙀𝙏𝙀 𝘼𝙆𝙐𝙉 𝘿𝙄 𝙎𝙀𝙍𝙑𝙀𝙍')}\n`;
        text += `\n`;
        text += `<b>· Server:</b> ${server.name}\n`;
        text += `<b>· Tipe:</b> ${serviceType.toUpperCase()}\n`;
        text += `<b>· Total Akun:</b> ${users.length}\n`;
        text += `<b>· Halaman:</b> ${page + 1}/${totalPages}\n`;
        text += `\n\n`;
        text += ` Pilih akun yang akan dihapus:`;

        const keyboard = Markup.inlineKeyboard([]);

        // Tombol username per akun
        for (const u of pageUsers) {
            const label = `${icon} ${u.username}  (${u.expired})`;
            // encode username aman untuk callback_data: ganti spasi dengan ~
            const safeUser = u.username.replace(/ /g, '~');
            keyboard.reply_markup.inline_keyboard.push([
                { text: label, callback_data: `admin_do_del_akun_${serverId}_${serviceType}_${safeUser}` }
            ]);
        }

        // Navigasi halaman
        const navButtons = [];
        if (page > 0) navButtons.push({ text: '◀ 𝙋𝙧𝙚𝙫', callback_data: `admin_del_akun_page_${serverId}_${serviceType}_${page - 1}` });
        if (page < totalPages - 1) navButtons.push({ text: '𝙉𝙚𝙭𝙩 ▶', callback_data: `admin_del_akun_page_${serverId}_${serviceType}_${page + 1}` });
        if (navButtons.length > 0) keyboard.reply_markup.inline_keyboard.push(navButtons);

        // Tombol cari & kembali
        keyboard.reply_markup.inline_keyboard.push([
            { text: '🔍 𝘾𝙖𝙧𝙞 𝙉𝙖𝙢𝙖', callback_data: `admin_del_akun_search_${serverId}_${serviceType}` }
        ]);
        const backCb = server.type === 'xray'
            ? `admin_server_delete_akun_select_${serverId}`
            : `admin_server_list_akun_${serverId}`;
        keyboard.reply_markup.inline_keyboard.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: backCb, style: 'danger' }]);

        await sendMenu(ctx, text, keyboard);

    } catch (err) {
        await sendTempMessage(ctx, ` Error mengambil daftar akun: ${err.message}`);
        await showAdminAkunPerServer(ctx);
    }
}

async function eksekusiAdminDeleteAkunServer(ctx, serverId, serviceType, username) {
    if (!isAdmin(ctx.from.id)) return;

    const server = getServers()[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        return;
    }

    await sendTempMessage(ctx, ` Menghapus akun <code>${username}</code> dari server <b>${server.name}</b>...`);
    
    try {
        let result;
        if (serviceType === 'zivpn') {
            result = await zivpnModule.zivpnDelete(server, username);
        } else if (serviceType === 'ssh') {
            result = await sshModule.deleteSSH(server, username);
        } else if (serviceType === 'trojan') {
            result = await trojanModule.deleteTrojan(server, username);
        } else if (serviceType === 'vless') {
            result = await vlessModule.deleteVless(server, username);
        } else if (serviceType === 'vmess') {
            result = await vmessModule.deleteVmess(server, username);
        }
        
        if (result && result.success) {
            // Akun baru saja dihapus dari server → cache list lama jadi basi, hapus supaya
            // listing berikutnya fetch fresh (bukan nampilin akun yang sudah dihapus).
            invalidateServerAkunListCache(serverId, serviceType);
            await sendResultMessage(ctx, ` Akun <code>${username}</code> berhasil dihapus dari server <b>${server.name}</b>!`);
        } else {
            await sendTempMessage(ctx, ` Gagal hapus: ${result?.message || 'Unknown error'}`);
        }
    } catch (err) {
        await sendTempMessage(ctx, ` Error: ${err.message}`);
    }
    
    // Kembali ke list delete akun agar bisa hapus lagi
    await showAdminDeleteAkunList(ctx, serverId, serviceType, 0);
}

async function showAdminDeleteAkunSearch(ctx, serverId, serviceType) {
    if (!isAdmin(ctx.from.id)) return;
    const adminId = ctx.from.id.toString();
    const server = getServers()[serverId];
    if (!server) { await sendTempMessage(ctx, ' Server tidak ditemukan!'); return; }

    userStates.set(adminId, {
        action: 'admin_del_akun_search',
        serverId,
        serviceType
    });

    const text = `${getHeader(' 𝘾𝘼𝙍𝙄 𝘼𝙆𝙐𝙉 𝙐𝙉𝙏𝙐𝙆 𝘿𝙄𝙃𝘼𝙋𝙐𝙎')}
<blockquote><b>· Server:</b> ${server.name}
<b>· Tipe:</b> ${serviceType.toUpperCase()}</blockquote>

Ketik <b>sebagian nama</b> akun yang ingin dicari:

<i>Contoh: "user01", "budi", "abc"</i>`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: `admin_del_akun_page_${serverId}_${serviceType}_0`, style: 'danger' }]
    ]));
}

async function showAdminDeleteAkunSearchResult(ctx, keyword) {
    const adminId = ctx.from.id.toString();
    const state = userStates.get(adminId);
    if (!state || state.action !== 'admin_del_akun_search') return;
    userStates.delete(adminId);

    const { serverId, serviceType } = state;
    const server = getServers()[serverId];
    if (!server) { await sendTempMessage(ctx, ' Server tidak ditemukan!'); return; }

    if (!isServerAkunListCached(serverId, [serviceType])) {
        await sendTempMessage(ctx, ` Mencari akun "<b>${keyword}</b>" di server <b>${server.name}</b>...`);
    }

    try {
        const users = (await getServerAkunListCached(serverId, server, serviceType))
            .map(u => ({ username: u.username || '-', expired: u.expired || '-' }));

        const kw = keyword.toLowerCase().trim();
        const filtered = users.filter(u => u.username.toLowerCase().includes(kw));

        const backCb = server.type === 'xray'
            ? `admin_server_delete_akun_select_${serverId}`
            : `admin_server_list_akun_${serverId}`;

        if (filtered.length === 0) {
            const keyboard = Markup.inlineKeyboard([
                [{ text: '🔍 𝘾𝙖𝙧𝙞 𝙇𝙖𝙜𝙞', callback_data: `admin_del_akun_search_${serverId}_${serviceType}` }],
                [{ text: '📋 𝙇𝙞𝙝𝙖𝙩 𝙎𝙚𝙢𝙪𝙖', callback_data: `admin_del_akun_page_${serverId}_${serviceType}_0` }],
                [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: backCb, style: 'danger' }]
            ]);
            await sendMenu(ctx, `${getHeader(' 𝙃𝘼𝙎𝙄𝙇 𝙋𝙀𝙉𝘾𝘼𝙍𝙄𝘼𝙉')}\n\n Tidak ditemukan akun dengan nama <b>"${keyword}"</b>.`, keyboard);
            return;
        }

        const typeIcon = { ssh: '', trojan: '', vless: '', vmess: '', zivpn: '' };
        const icon = typeIcon[serviceType] || '';

        let text = `${getHeader(' 𝙃𝘼𝙎𝙄𝙇 𝙋𝙀𝙉𝘾𝘼𝙍𝙄𝘼𝙉')}\n`;
        text += `\n`;
        text += `<b>· Server:</b> ${server.name}\n`;
        text += `<b>· Keyword:</b> "${keyword}"\n`;
        text += `<b>· Ditemukan:</b> ${filtered.length} akun\n`;
        text += `\n\n`;
        text += ` Pilih akun yang akan dihapus:`;

        const keyboard = Markup.inlineKeyboard([]);
        for (const u of filtered) {
            const label = `${icon} ${u.username}  (${u.expired})`;
            const safeUser = u.username.replace(/ /g, '~');
            keyboard.reply_markup.inline_keyboard.push([
                { text: label, callback_data: `admin_do_del_akun_${serverId}_${serviceType}_${safeUser}` }
            ]);
        }
        keyboard.reply_markup.inline_keyboard.push([
            { text: '🔍 𝘾𝙖𝙧𝙞 𝙇𝙖𝙜𝙞', callback_data: `admin_del_akun_search_${serverId}_${serviceType}` }
        ]);
        keyboard.reply_markup.inline_keyboard.push([
            { text: '📋 𝙇𝙞𝙝𝙖𝙩 𝙎𝙚𝙢𝙪𝙖', callback_data: `admin_del_akun_page_${serverId}_${serviceType}_0` }
        ]);
        keyboard.reply_markup.inline_keyboard.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: backCb, style: 'danger' }]);

        await sendMenu(ctx, text, keyboard);

    } catch (err) {
        await sendTempMessage(ctx, ` Error pencarian: ${err.message}`);
        await showAdminDeleteAkunList(ctx, serverId, serviceType, 0);
    }
}

    return {
        showAdminSewaBotMenu,
        showAdminSewaBotList,
        startAdminBotRevoke,
        processAdminBotRevokeInput,
        showAdminTopupBonusMenu,
        startAdminTopupBonusAdd,
        processAdminTopupBonusAddInput,
        processAdminTopupBonusUnlimited,
        startAdminTopupBonusRemove,
        processAdminTopupBonusRemove,
        showAdminSewaScMenu,
        showAdminScList,
        showAdminScEditList,
        startAdminScEdit,
        processAdminScEditInput,
        processAdminScEditKonfirmasi,
        startAdminScAddUser,
        processAdminScAddUserInput,
        processAdminScAddUserKonfirmasi,
        startAdminScAdd,
        processAdminScAddInput,
        startAdminScRemove,
        processAdminScRemoveInput,
        startAdminScPaketAdd,
        processAdminScPaketAddInput,
        startAdminScPaketRemove,
        processAdminScPaketRemove,
        showAdminBackupMenu,
        showAdminBackupList,
        showAdminBackupRestoreList,
        showAdminBackupDeleteList,
        showAdminAutoBackupSetup,
        showAdminDashboard,
        showAdminStatistikBot,
        showAdminManageResellerList,
        showAdminListUsers,
        showAdminSearchUsers,
        showAdminSearchResults,
        showAdminManageUser,
        showAdminEditSaldoAmount,
        processAdminEditSaldoNominal,
        showAdminListAkun,
        showAdminUserAkun,
        showAdminTransaksi,
        showAdminEditData,
        startAdminEditHeaderMain,
        showAdminSettingsUmum,
        showAdminSettingsQris,
        showAdminSettingsPakasir,
        showAdminSettingsDana,
        showAdminSettingsGopay,
        showAdminSettingsGithub,
        showAdminSettingsGithubBackup,
        showAdminSettingsGithubSewaSc,
        handleAdminEditValue,
        processAdminEditValue,
        cancelAdminEditValue,
        showAdminServerMenu,
        showAdminServerList,
        showAdminServerAdd,
        processAdminServerAddName,
        processAdminServerAddType,
        processAdminServerAddDomain,
        processAdminServerAddAuthKey,
        showAdminServerEdit,
        processAdminServerEditSelect,
        processAdminServerEditField,
        processAdminServerEditValue,
        showAdminServerHargaList,
        showAdminServerHargaEdit,
        processAdminServerHargaInput,
        showAdminServerQuotaList,
        showAdminServerQuotaEdit,
        processAdminServerQuotaInput,
        getEffectiveQuota,
        showAdminServerSlotList,
        showAdminServerSlotEdit,
        showAdminServerSlotTotalEdit,
        processAdminServerSlotInput,
        showAdminServerSlotTerpakaiEdit,
        processAdminServerSlotTerpakaiInput,
        showAdminServerDelete,
        processAdminServerDelete,
        showAdminAkunPerServer,
        showAdminXrayTypeSelect,
        showAdminServerAkunList,
        showAdminDeleteAkunServer,
        showAdminDeleteAkunList,
        eksekusiAdminDeleteAkunServer,
        showAdminDeleteAkunSearch,
        showAdminDeleteAkunSearchResult
    };
};
