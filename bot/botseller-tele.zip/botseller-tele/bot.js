// bot.js - Telegram VPN Bot with QRIS Payment & Admin Dashboard (ADMIN BUTTON BASED)
require('dotenv').config();
const { Telegraf, Markup, session } = require('telegraf');
const QRCode = require('qrcode');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { createCanvas, loadImage } = require('canvas');
const jsQR = require('jsqr');

// Import modules
const sshModule = require('./ssh.js');
const trojanModule = require('./trojan.js');
const vlessModule = require('./vless.js');
const vmessModule = require('./vmess.js');
const zivpnModule = require('./zivpn.js');
// ==================== IMPORT BROADCAST MODULE ====================
const broadcastModule = require('./broadcast.js');
// ==================== IMPORT RESELLER MODULE ====================
const resellerModule = require('./reseller.js');
// ==================== IMPORT SEWA SC MODULE ====================
const sewaSCModule = require('./sewaSC.js');
// ==================== IMPORT CONVERT XRAY YAML MODULE ====================
const xrayYamlModule = require('./convert-xray-yaml.js');
// ==================== IMPORT SEWA BOT SELLER MODULE ====================
const sewaBotSellerModule = require('./sewaBotSeller.js');
const {
    isSewaBotAktif,
    setSewaBotAktif,
    getBotPaketList,
    getBotPaketById,
    hitungHargaBotSeller,
    formatTanggalExpiryBot,
    generateLisensiToken,
    tambahLisensiDanUpload,
    perpanjangLisensiDanUpload,
    hapusLisensiDanUpload,
    checkDanHapusLisensiExpired,
    tambahSewaBotRecord,
    perpanjangSewaBotRecord,
    getSewaBotByUser,
    getSewaBotByToken,
    getAllSewaBot,
    getLisensiPublicUrl,
    getLisensiFilePath,
    setHargaBotSeller30Hari,
    getHargaBotSeller30Hari,
    setHargaBotSellerLifetime,
    getHargaBotSellerLifetime,
} = sewaBotSellerModule;
const {
    hitungHargaSC,
    hitungHargaSatuIp,
    breakdownHargaSC,
    formatTanggalExpiry,
    hitungTanggalPerpanjangan,
    addIpToRepo,
    removeIpFromRepo,
    updateIpExpiryInRepo,
    listIpFromRepo,
    tambahSewaRecord,
    getSewaByUser,
    getAllSewa,
    hapusSewaRecord,
    perpanjangSewaRecord,
    updateSewaIpNama,
    setHargaSC30Hari,
    getHargaSC30Hari,
    getHargaSCLifetime,
    _setHargaSCLifetime,
    setHargaSCExtraIp,
    getHargaSCExtraIp,
    isSewaScAktif,
    setSewaScAktif,
    getPaketList,
    getPaketById,
    addPaket,
    removePaket,
    getScGithubRepo,
    setScGithubRepo,
    getScGithubBranch,
    setScGithubBranch,
    getScGithubToken,
    setScGithubToken,
    getScGithubOwner,
    setScGithubOwner,
} = sewaSCModule;
const {
    isReseller,
    getLabelStatus,
    formatInfoReseller,
    hitungHargaReseller,
    daftarReseller,
    updateResellerActivity,
    checkAndCleanReseller,
    BIAYA_DAFTAR_RESELLER,
    setResellerStatusByAdmin,
    getAllResellerList,
    getDiskonReseller,
    getDiskonResellerPersen,
    setDiskonReseller,
} = resellerModule;

// ==================== KONFIGURASI DARI .ENV ====================
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const NOTIF_BOT_TOKEN = process.env.NOTIF_BOT_TOKEN || BOT_TOKEN; // Token bot khusus notifikasi
const ADMIN_IDS = process.env.ADMIN_IDS
    ? process.env.ADMIN_IDS.split(',').map(id => {
        const trimmed = id.trim();
        if (/^\d+$/.test(trimmed)) return parseInt(trimmed);
        return trimmed;
    })
    : [];
const TELEGRAM_GROUP_ID = process.env.TELEGRAM_GROUP_ID ? parseInt(process.env.TELEGRAM_GROUP_ID) : null;

// ==================== RUNTIME BOT ====================
const BOT_START_TIME = Date.now();

function formatRuntime() {
    const diffMs = Date.now() - BOT_START_TIME;
    const totalSeconds = Math.floor(diffMs / 1000);
    const hari = Math.floor(totalSeconds / 86400);
    const jam = Math.floor((totalSeconds % 86400) / 3600);
    const menit = Math.floor((totalSeconds % 3600) / 60);
    const detik = totalSeconds % 60;

    const parts = [];
    if (hari > 0) parts.push(`${hari}h`);
    if (jam > 0) parts.push(`${jam}j`);
    if (menit > 0) parts.push(`${menit}m`);
    if (parts.length === 0) parts.push(`${detik}d`);

    return parts.join(' ');
}

// ==================== CONFIG DINAMIS (bisa diubah tanpa restart) ====================
const CONFIG = {
    HARGA_PER_HARI_PER_IP: parseInt(process.env.HARGA_PER_HARI_PER_IP) || 267,
    HARGA_EDURC_PER_HARI:  parseInt(process.env.HARGA_EDURC_PER_HARI)  || 667,
    MAX_TRIAL_MENIT:       parseInt(process.env.MAX_TRIAL_MENIT)        || 30,
    MAX_TRIAL_PER_USER:    parseInt(process.env.MAX_TRIAL_PER_USER)     || 2,
    MAX_IP_LIMIT:          parseInt(process.env.MAX_IP_LIMIT)           || 1,
    DEFAULT_IP_LIMIT:      parseInt(process.env.DEFAULT_IP_LIMIT)       || 1,
    DEFAULT_QUOTA:         parseInt(process.env.DEFAULT_QUOTA)          || 0,
    MIN_TOPUP:             parseInt(process.env.MIN_TOPUP)              || 5000,
    MERCHANT_NAME:         process.env.MERCHANT_NAME                    || 'PEYX STORE',
    QRIS_FEE_PERSEN:       parseFloat(process.env.QRIS_FEE_PERSEN)      || 0,      // % fee QRIS (contoh: 0.7 = 0.7%)
    BIAYA_DAFTAR_RESELLER: parseInt(process.env.BIAYA_DAFTAR_RESELLER)  || (resellerModule.BIAYA_DAFTAR_RESELLER || 50000), // harga join reseller
};

function updateConfig(key, value) {
    CONFIG[key] = value;
    updateEnvValue(key, value.toString());
    console.log(`[Config] ${key} = ${value}`);
}

let QRIS_STATIS = process.env.QRIS_STATIS || '';
const QRIS_API_URL = process.env.QRIS_API_URL || 'https://api-mininxd.vercel.app/qris';
let QRIS_DINAMIS_AKTIF = process.env.QRIS_DINAMIS_AKTIF !== 'false'; // true by default

// ==================== KONFIGURASI PAKASIR ====================
let PAKASIR_API_KEY         = process.env.PAKASIR_API_KEY         || '';
let PAKASIR_SLUG            = process.env.PAKASIR_SLUG            || '';   // slug proyek di Pakasir
let PAKASIR_AKTIF           = process.env.PAKASIR_AKTIF           === 'true';  // false by default
let PAKASIR_TAMPIL          = process.env.PAKASIR_TAMPIL          !== 'false'; // true by default jika Pakasir aktif
let PAKASIR_MERCHANT_NAME   = process.env.PAKASIR_MERCHANT_NAME   || '';   // nama merchant khusus Pakasir (kosong = fallback ke MERCHANT_NAME)
// PAKASIR_TAMPIL = apakah metode Pakasir ditampilkan di menu topup user

// ==================== KONFIGURASI DANA ====================
let DANA_AKTIF   = process.env.DANA_AKTIF   === 'true';  // false by default
let DANA_NOMOR   = process.env.DANA_NOMOR   || '';       // nomor HP DANA
let DANA_NAMA    = process.env.DANA_NAMA    || '';       // nama pemilik DANA

// ==================== KONFIGURASI GOPAY ====================
let GOPAY_AKTIF  = process.env.GOPAY_AKTIF  === 'true';  // false by default
let GOPAY_NOMOR  = process.env.GOPAY_NOMOR  || '';       // nomor HP GoPay
let GOPAY_NAMA   = process.env.GOPAY_NAMA   || '';       // nama pemilik GoPay

// ==================== KONFIGURASI CEK PEMBAYARAN (DANA/GOPAY/QRIS MANUAL) ====================
// CEK_PEMBAYARAN_MODE menentukan cara user "menyelesaikan" topup manual (DANA/GoPay/QRIS manual):
//   'upload' -> user WAJIB kirim screenshot bukti transfer (divalidasi OCR) -> perilaku lama/default
//   'button' -> user klik tombol "Cek Pembayaran" (pengganti webhook otomatis, TANPA bukti/OCR)
// PENTING: mode 'button' TIDAK memverifikasi pembayaran secara nyata (tidak ada pengecekan ke bank/e-wallet).
// Untuk mencegah user klik langsung tanpa transfer, ada jeda minimal (CEK_PEMBAYARAN_DELAY detik)
// sebelum tombol tersebut boleh menyetujui & mencairkan saldo.
let CEK_PEMBAYARAN_MODE  = (process.env.CEK_PEMBAYARAN_MODE === 'button') ? 'button' : 'upload'; // 'upload' default (lebih aman)
let CEK_PEMBAYARAN_DELAY = parseInt(process.env.CEK_PEMBAYARAN_DELAY) || 90; // detik, jeda minimal sebelum tombol boleh approve

const HEADER_IMAGE_PATH = process.env.HEADER_IMAGE_PATH || path.join(__dirname, 'assets', 'px.png');
const HEADER_PANEL_VPN = process.env.HEADER_PANEL_VPN || path.join(__dirname, 'assets', 'panel-vpn.png');
const HEADER_PANEL_SC  = process.env.HEADER_PANEL_SC  || path.join(__dirname, 'assets', 'panel-sc.png');

const CONFIG_FILE = path.join(__dirname, 'server.json');
const SALDO_FILE = path.join(__dirname, 'saldo.json');
const TRANSAKSI_FILE = path.join(__dirname, 'transaksi.json');
const STATS_FILE = path.join(__dirname, 'stats.json'); // counter statistik permanen (total transaksi & tx harian), tidak ikut terpotong seperti transaksi.json
const TRIAL_FILE = path.join(__dirname, 'trial.json');
const AKUN_FILE = path.join(__dirname, 'akun.json');
// File cache "slot terpakai per server" — dihitung ulang otomatis setiap kali
// akun.json berubah (lewat saveAkun), supaya cek slot tidak perlu scan ulang
// seluruh akun.json setiap request.
const TOTALSLOT_FILE = path.join(__dirname, 'totalslot.json');
const USERS_FILE = path.join(__dirname, 'users.json');
const QRIS_CENTER_ICON = path.join(__dirname, 'assets', 'icon.png');
const IMAGE_HASH_FILE = path.join(__dirname, 'used_image_hashes.json'); // hash gambar bukti yang sudah pernah dipakai
const EDURC_FILE = path.join(__dirname, 'edurc.json'); // domain CDN per server (fitur VPN EDURC)
const WILDCARD_FILE = path.join(__dirname, 'wildcard.json'); // daftar domain bug wildcard (fitur Mode Wildcard ganti bug link)
const BUG_FILE = path.join(__dirname, 'bug.json'); // daftar bug xray (fitur Bug Xray ganti address/SNI saja, terpisah dari wildcard)
const TOPUP_BONUS_FILE = path.join(__dirname, 'topup_bonus.json'); // konfigurasi diskon/bonus topup per persen (fitur Admin Diskon Topup)


// ==================== GLOBAL CRASH GUARD ====================
// Cegah bot mati karena unhandled promise rejection atau uncaught exception
process.on("unhandledRejection", (reason) => {
    console.error("[CrashGuard] Unhandled Promise Rejection:", reason?.message || reason);
});
process.on("uncaughtException", (err) => {
    console.error("[CrashGuard] Uncaught Exception:", err.message);
    // Jangan process.exit() — biarkan bot tetap jalan
});

// ==================== BOT INIT ====================
const bot = new Telegraf(BOT_TOKEN);
bot.use(session());

// ==================== NOTIF BOT (token terpisah) ====================
// Jika NOTIF_BOT_TOKEN diisi di .env, notifikasi dikirim via bot berbeda
// Jika tidak, fallback ke bot utama
const notifBot = NOTIF_BOT_TOKEN !== BOT_TOKEN
    ? new Telegraf(NOTIF_BOT_TOKEN)
    : bot;

console.log(' Main Bot Token:', BOT_TOKEN ? ' Loaded' : ' Not found');
console.log(' Notif Bot Token:', NOTIF_BOT_TOKEN !== BOT_TOKEN ? ' Loaded (terpisah)' : ' Sama dengan main bot');

let SERVERS = {};
const userStates = new Map();
const pendingQRIS = new Map();
const pendingDANA = new Map();   // sesi topup DANA pending (menunggu bukti foto)
const pendingGOPAY = new Map();  // sesi topup GoPay pending (menunggu bukti foto)
const messageHistory = new Map();
let headerMedia = null;
let headerFileId    = null; // Cache file_id Telegram menu utama
let headerFileIdVPN = null; // Cache file_id Telegram panel VPN
let headerFileIdSC  = null; // Cache file_id Telegram panel SC

// ==================== IN-MEMORY JSON CACHE ====================
// Menghindari baca disk berulang di setiap request — disk I/O adalah bottleneck utama.
// Setiap file JSON hanya dibaca dari disk saat pertama kali atau setelah ditulis (invalidasi otomatis).
const _jsonCache = {
    saldo:     { data: null },
    transaksi: { data: null },
    trial:     { data: null },
    akun:      { data: null },
    users:     { data: null },
    servers:   { data: null },
    edurc:     { data: null },
    wildcard:  { data: null },
    bug:       { data: null },
    topupBonus:{ data: null },
    stats:     { data: null },
    totalslot: { data: null },
};

function _cacheGet(key, file, defaultVal) {
    if (_jsonCache[key].data !== null) return _jsonCache[key].data;
    try {
        if (fs.existsSync(file)) {
            _jsonCache[key].data = JSON.parse(fs.readFileSync(file, 'utf8'));
        } else {
            _jsonCache[key].data = defaultVal;
        }
    } catch(e) {
        _jsonCache[key].data = defaultVal;
    }
    return _jsonCache[key].data;
}

// ==================== WRITE KHUSUS UNTUK 'users' (DIDEBOUNCE) ====================
// registerUser() dipanggil di SETIAP interaksi (klik tombol, chat, foto) dari SEMUA user.
// Kalau ditulis ke disk secara synchronous tiap kali (seperti sebelumnya), event loop
// Node.js akan freeze sejenak setiap kali — dan itu ngeblock SEMUA user lain juga.
// Solusi: data tetap langsung ter-update di memory (jadi fungsi lain yang baca data users
// tetap dapat data terbaru, perilaku tidak berubah), tapi PENULISAN ke disk digabung
// (debounce) dan dibuat async (tidak blocking).
let _usersWriteTimer = null;
let _usersPendingSince = 0;
let _pendingUsersWrite = null; // { file, data }
const _USERS_DEBOUNCE_MS = 2000;   // tunggu jeda 2 detik tanpa aktivitas baru sebelum nulis
const _USERS_MAX_WAIT_MS = 10000;  // tapi maksimal nunda 10 detik walau bot terus sibuk

function _flushUsersWrite() {
    clearTimeout(_usersWriteTimer);
    _usersWriteTimer = null;
    if (!_pendingUsersWrite) return;
    const { file, data } = _pendingUsersWrite;
    _pendingUsersWrite = null;
    _usersPendingSince = 0;
    fs.writeFile(file, JSON.stringify(data, null, 2), (err) => {
        if (err) console.error('[_cacheSet] Gagal menyimpan users.json:', err.message);
    });
}

function _scheduleUsersWrite(file, data) {
    _pendingUsersWrite = { file, data };
    const now = Date.now();
    if (!_usersPendingSince) _usersPendingSince = now;

    clearTimeout(_usersWriteTimer);
    if (now - _usersPendingSince >= _USERS_MAX_WAIT_MS) {
        // Sudah kelamaan ditunda (bot lagi rame terus) → paksa tulis sekarang.
        _flushUsersWrite();
    } else {
        _usersWriteTimer = setTimeout(_flushUsersWrite, _USERS_DEBOUNCE_MS);
    }
}

function _cacheSet(key, file, data) {
    _jsonCache[key].data = data;

    if (key === 'users') {
        _scheduleUsersWrite(file, data);
        return;
    }

    // Data lain (saldo, transaksi, akun, trial, servers, edurc) = data penting/finansial,
    // jadi tetap ditulis LANGSUNG (tidak di-debounce, tidak ditunda) supaya tidak ada
    // risiko data hilang. TAPI pakai fs.writeFile ASYNC (bukan writeFileSync) —
    // versi Sync menahan seluruh event loop Node.js selama proses tulis berlangsung,
    // yang berarti SEMUA user lain yang sedang klik tombol di saat bersamaan ikut ngelag,
    // walau menu yang mereka buka sama sekali tidak berhubungan dengan transaksi ini.
    // Versi async ini dikerjakan di background oleh libuv (thread pool), jadi bot tetap
    // responsif untuk user lain, sementara data tetap tersimpan ke disk saat itu juga
    // (bukan didebounce/ditunda seperti 'users').
    const json = JSON.stringify(data, null, 2);
    fs.writeFile(file, json, (err) => {
        if (err) console.error(`[_cacheSet] Gagal menyimpan ${key}:`, err.message);
    });
}

function _cacheInvalidate(key) {
    _jsonCache[key].data = null;
}

// Pastikan write users.json yang masih ditunda benar-benar tersimpan sebelum bot mati
// (pm2 restart, deploy ulang, Ctrl+C, dll) supaya data lastSeen/user baru tidak hilang.
function _flushAllPendingWrites() {
    _flushUsersWrite();
}
process.on('SIGINT', () => { _flushAllPendingWrites(); process.exit(0); });
process.on('SIGTERM', () => { _flushAllPendingWrites(); process.exit(0); });

// ==================== ANTI SPAM: HASH GAMBAR BUKTI PEMBAYARAN ====================
// Sistem pengecekan gambar identik dengan beranda.js
// Hash dihitung dari konten gambar → disimpan permanen di file JSON
// Gambar yang sama TIDAK BISA dipakai di topup manapun, kapanpun

function loadImageHashes() {
    try {
        if (fs.existsSync(IMAGE_HASH_FILE)) {
            return JSON.parse(fs.readFileSync(IMAGE_HASH_FILE, 'utf8'));
        }
    } catch(e) {
        console.error('[ImageHash] Error loading hashes:', e.message);
    }
    return [];
}

function saveImageHashes(hashes) {
    try {
        fs.writeFileSync(IMAGE_HASH_FILE, JSON.stringify(hashes, null, 2));
    } catch(e) {
        console.error('[ImageHash] Error saving hashes:', e.message);
    }
}

// Generate hash dari base64 konten gambar (algoritma sama dengan beranda.js)
function generateImageHash(base64Data) {
    const sample = base64Data.substring(0, 1000);
    let hash = 0;
    for (let i = 0; i < sample.length; i++) {
        const char = sample.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // 32-bit integer
    }
    return hash.toString();
}

// Validasi keunikan gambar — return { isValid, message, hash }
function validateImageUniqueness(base64Data) {
    const hash = generateImageHash(base64Data);
    const usedHashes = loadImageHashes();

    if (usedHashes.includes(hash)) {
        return {
            isValid: false,
            message: ' <b>Gambar ini sudah pernah digunakan untuk transaksi sebelumnya!</b>\n\nHarap kirim screenshot bukti pembayaran yang baru/berbeda.',
            hash: hash
        };
    }

    return { isValid: true, message: 'Valid', hash: hash };
}

// Simpan hash gambar setelah transaksi berhasil (tidak bisa dipakai lagi)
function markImageHashUsed(hash) {
    const usedHashes = loadImageHashes();
    if (!usedHashes.includes(hash)) {
        usedHashes.push(hash);
        saveImageHashes(usedHashes);
        console.log(`[ImageHash]  Hash disimpan: ${hash}`);
    }
}

// ==================== VALIDASI BUKTI TRANSFER (OCR Lokal — Tesseract.js) ====================
// Gratis, offline, tidak butuh API key.
// Alur:
//   1. Preprocessing gambar: resize ke 1400px, grayscale, kontras, sharpen (toleran layar besar/kecil)
//   2. Multi-pass OCR: PSM 6 → PSM 3 → PSM 11 sebagai fallback
//   3. Bersihkan noise OCR: O→0, l→1, S→5, dll.
//   4. Cek kata kunci status berhasil
//   5. Ekstrak nominal secara universal (tidak bergantung konteks Rp, ambil angka terbesar)
//   6. Ekstrak & validasi tanggal = hari ini (WIB)

let Tesseract = null;
function getTesseract() {
    if (!Tesseract) {
        try {
            Tesseract = require('tesseract.js');
        } catch(e) {
            console.error('[ValidasiBukti] tesseract.js belum terinstall. Jalankan: npm install tesseract.js');
        }
    }
    return Tesseract;
}

// Kata kunci yang wajib ada agar dianggap bukti transfer sah
const KEYWORD_BERHASIL = [
    'berhasil', 'sukses', 'success', 'transfer berhasil',
    'pembayaran berhasil', 'transaksi berhasil', 'selesai',
    'completed', 'approved', 'diterima', 'berhasil dikirim',
    'pengiriman berhasil', 'telah dikirim', 'sudah dikirim', 'terkirim', 'dikirim'
];

// Nama bank / e-wallet yang dikenali
const NAMA_BANK = [
    'bca', 'mandiri', 'bri', 'bni', 'cimb', 'danamon', 'permata', 'bsi',
    'gopay', 'ovo', 'dana', 'shopeepay', 'linkaja', 'jenius', 'flip',
    'seabank', 'jago', 'blu', 'livin', 'digibank', 'ocbc', 'maybank',
    'm-banking', 'mobile banking', 'internet banking', 'mybca', 'klikbca',
    'livin by mandiri', 'brimo', 'bni mobile', 'cimb clicks'
];

//  Preprocessing gambar: resize + grayscale + kontras + sharpen 
// Menggunakan canvas (sudah di-import di atas). Toleran untuk resolusi HP besar maupun kecil.
async function preprocessImageForOCR(imageBuffer) {
    try {
        const img = await loadImage(imageBuffer);

        // Skala ke lebar 1400px max (optimal Tesseract), gambar kecil tidak diperbesar
        const TW    = 1400;
        const scale = img.width > TW ? TW / img.width : 1;
        const W     = Math.round(img.width  * scale);
        const H     = Math.round(img.height * scale);

        const c   = createCanvas(W, H);
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0, W, H);

        // Grayscale + tingkatkan kontras
        const id = ctx.getImageData(0, 0, W, H);
        const p  = id.data;
        for (let i = 0; i < p.length; i += 4) {
            const g = 0.299 * p[i] + 0.587 * p[i + 1] + 0.114 * p[i + 2];
            let   v = 1.6 * (g - 128) + 128 + 10;
            p[i] = p[i + 1] = p[i + 2] = Math.max(0, Math.min(255, v));
        }
        ctx.putImageData(id, 0, 0);

        // Sharpen: unsharp mask via scale down + scale up
        const BSCALE = 0.15;
        const bw = Math.max(1, Math.round(W * BSCALE));
        const bh = Math.max(1, Math.round(H * BSCALE));
        const tmp = createCanvas(bw, bh);
        tmp.getContext('2d').drawImage(c, 0, 0, bw, bh);
        const cb  = createCanvas(W, H);
        const xb  = cb.getContext('2d');
        xb.drawImage(tmp, 0, 0, W, H);

        const orig = ctx.getImageData(0, 0, W, H);
        const blr  = xb.getImageData(0, 0, W, H);
        for (let i = 0; i < orig.data.length; i += 4) {
            for (let k = 0; k < 3; k++) {
                const v = orig.data[i + k] + 2 * (orig.data[i + k] - blr.data[i + k]);
                orig.data[i + k] = Math.max(0, Math.min(255, v));
            }
        }
        ctx.putImageData(orig, 0, 0);

        return c.toBuffer('image/png');
    } catch(e) {
        console.warn('[ValidasiBukti] preprocessing gagal, pakai buffer asli:', e.message);
        return imageBuffer;
    }
}

//  Jalankan satu pass OCR 
async function runOCRPass(tess, buffer, psm) {
    try {
        const { data: { text } } = await tess.recognize(buffer, 'ind+eng', {
            logger: () => {},
            tessedit_pageseg_mode: psm,
            preserve_interword_spaces: '1'
        });
        return text || '';
    } catch(e) {
        return '';
    }
}

//  Bersihkan teks OCR: ganti karakter mirip angka 
// Kunci untuk HP resolusi tinggi: O→0, em-dash, non-breaking space, dll.
function ocr_bersihkan(teks) {
    return teks
        .replace(/(?<=[\d.,\s])O(?=[\d.,\s])/g, '0')
        .replace(/(?<=[\d])O\b/g, '0')
        .replace(/\bO(?=[\d])/g, '0')
        .replace(/[–—]/g, '-')
        .replace(/\u00A0/g, ' ');
}

//  Konversi satu token angka → integer, toleran noise OCR 
function ocr_parseAngkaTunggal(s) {
    s = s.replace(/O/g, '0').replace(/o/g, '0')
         .replace(/[lI]/g, '1').replace(/S/g, '5')
         .replace(/\s/g, '');

    const dots   = (s.match(/\./g) || []).length;
    const commas = (s.match(/,/g)  || []).length;

    if (dots > 1) {
        s = s.replace(/\./g, '');                           // 1.000.000 → 1000000
    } else if (commas > 1) {
        s = s.replace(/,/g, '');                            // 1,000,000 → 1000000
    } else if (dots === 1 && commas === 0) {
        const [a, b] = s.split('.');
        s = (b && b.length === 3) ? s.replace('.', '') : a; // 1.000→1000 / 1.50→1
    } else if (commas === 1 && dots === 0) {
        const [a, b] = s.split(',');
        s = (b && b.length === 3) ? s.replace(',', '') : a;
    } else if (dots === 1 && commas === 1) {
        s = s.replace('.', '').replace(/,\d+$/, '');         // 1.000,00 format Eropa
    }

    const n = parseInt(s, 10);
    return isNaN(n) ? null : n;
}

//  Ekstrak SEMUA angka yang masuk akal sebagai nominal (1.000 – 999.999.999) 
function ocr_semuaAngka(teks) {
    const hasil = [];
    const re = /\b(\d[\d.,\s]{0,15}\d|\d{4,})\b/g;
    let m;
    while ((m = re.exec(teks)) !== null) {
        const n = ocr_parseAngkaTunggal(m[1].trim());
        if (n !== null && n >= 1000 && n <= 999999999) hasil.push(n);
    }
    return hasil;
}

/**
 * Ekstrak nominal: prioritas Rp/IDR → kata kunci → fallback angka terbesar.
 * Tidak bergantung konteks kata kunci agar tetap bekerja di semua layout bukti.
 */
function parseJumlahOCR(teks) {
    const t     = ocr_bersihkan(teks);
    const semua = ocr_semuaAngka(t);
    if (semua.length === 0) return null;

    // Prioritas 1: ada konteks Rp/IDR langsung sebelum angka
    const reRp   = /(?:Rp\.?|IDR)\s*([0-9][0-9.,\s]{1,14})/gi;
    const dariRp = [];
    let m;
    while ((m = reRp.exec(t)) !== null) {
        const n = ocr_parseAngkaTunggal(m[1].trim());
        if (n && n >= 1000) dariRp.push(n);
    }
    if (dariRp.length > 0) return Math.max(...dariRp);

    // Prioritas 2: konteks kata kunci nominal
    const reKata   = /(?:nominal|jumlah|total|amount|dikirim|ditransfer|disetor)[^\d]{0,10}([0-9][0-9.,\s]{1,14})/gi;
    const dariKata = [];
    while ((m = reKata.exec(t)) !== null) {
        const n = ocr_parseAngkaTunggal(m[1].trim());
        if (n && n >= 1000) dariKata.push(n);
    }
    if (dariKata.length > 0) return Math.max(...dariKata);

    // Prioritas 3: angka terbesar di seluruh teks
    return Math.max(...semua);
}

/**
 * Parse tanggal dari teks OCR.
 * Mendukung: DD/MM/YYYY, YYYY-MM-DD, DD MMM YYYY, MMM DD YYYY,
 * DD/MM/YY, DD.MM.YYYY, format kompak ddmmyyyy & yyyymmdd.
 * Mengembalikan Date object atau null.
 */
function parseTanggalOCR(teks) {
    const t = ocr_bersihkan(teks);

    const bulanMap = {
        jan:0, feb:1, mar:2, apr:3, mei:4, may:4,
        jun:5, jul:6, agu:7, aug:7, sep:8, okt:9, oct:9, nov:10, des:11, dec:11
    };

    const pola = [
        // DD/MM/YYYY  DD-MM-YYYY  DD.MM.YYYY
        { re: /\b(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](20\d{2})\b/g,
          fn: m => new Date(+m[3], +m[2]-1, +m[1]) },
        // YYYY/MM/DD  YYYY-MM-DD
        { re: /\b(20\d{2})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})\b/g,
          fn: m => new Date(+m[1], +m[2]-1, +m[3]) },
        // "15 Mei 2025"  "15 May 2025"
        { re: /\b(\d{1,2})\s+([A-Za-z]{3,9})\s+(20\d{2})\b/g,
          fn: m => { const b = bulanMap[m[2].toLowerCase().slice(0,3)]; return b != null ? new Date(+m[3], b, +m[1]) : null; } },
        // "Mei 15 2025"  "May 15, 2025"
        { re: /\b([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/g,
          fn: m => { const b = bulanMap[m[1].toLowerCase().slice(0,3)]; return b != null ? new Date(+m[3], b, +m[2]) : null; } },
        // DD/MM/YY  (2 digit tahun)
        { re: /\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2})\b/g,
          fn: m => new Date(2000 + +m[3], +m[2]-1, +m[1]) },
        // Format kompak ddmmyyyy (8 digit)
        { re: /\b(\d{2})(\d{2})(20\d{2})\b/g,
          fn: m => new Date(+m[3], +m[2]-1, +m[1]) },
        // Format kompak yyyymmdd (8 digit)
        { re: /\b(20\d{2})(\d{2})(\d{2})\b/g,
          fn: m => new Date(+m[1], +m[2]-1, +m[3]) },
    ];

    const hasil = [];
    for (const { re, fn } of pola) {
        let m;
        re.lastIndex = 0;
        while ((m = re.exec(t)) !== null) {
            try {
                const d = fn(m);
                if (d && !isNaN(d) && d.getFullYear() >= 2020 && d.getFullYear() <= 2030
                    && d.getMonth() >= 0 && d.getDate() >= 1 && d.getDate() <= 31) {
                    hasil.push(d);
                }
            } catch(e) {}
        }
    }

    if (hasil.length === 0) return null;
    const now = Date.now();
    hasil.sort((a, b) => Math.abs(a - now) - Math.abs(b - now));
    return hasil[0];
}

/**
 * Deteksi nama bank/e-wallet dari teks OCR.
 */
function parseBankOCR(teks) {
    const lower = teks.toLowerCase();
    for (const nama of NAMA_BANK) {
        if (lower.includes(nama)) return nama.toUpperCase();
    }
    return null;
}

/**
 * Cek apakah ada kata kunci "berhasil/sukses" di teks.
 */
function cekKataBerhasil(teks) {
    const lower = teks.toLowerCase();
    return KEYWORD_BERHASIL.some(k => lower.includes(k));
}

/**
 * Validasi bukti transfer menggunakan OCR lokal (Tesseract.js).
 * Menggunakan preprocessing gambar + multi-pass OCR agar akurat
 * untuk screenshot dari layar HP kecil maupun besar/resolusi tinggi.
 *
 * @param {Buffer} imageBuffer - Buffer gambar
 * @returns {Promise<{
 *   isValid: boolean,
 *   reason: string,
 *   tanggalTransfer: string|null,
 *   jumlahTransfer: number|null,
 *   namaBank: string|null
 * }>}
 */
async function validateBuktiTransfer(imageBuffer) {
    const tess = getTesseract();
    if (!tess) {
        console.warn('[ValidasiBukti] tesseract.js tidak tersedia, validasi dilewati.');
        return { isValid: true, reason: 'OCR tidak tersedia, validasi dilewati', tanggalTransfer: null, jumlahTransfer: null, namaBank: null };
    }

    let ocrTeks = '';
    try {
        // Preprocessing: resize + grayscale + kontras + sharpen
        const processedBuffer = await preprocessImageForOCR(imageBuffer);

        // Pass 1: gambar preprocessed, PSM 6 (uniform block) — terbaik untuk kebanyakan bukti
        ocrTeks = await runOCRPass(tess, processedBuffer, '6');
        console.log(`[ValidasiBukti] Pass1 (PSM6) panjang=${ocrTeks.length}: ${ocrTeks.replace(/\n/g,' ').substring(0,200)}`);

        // Pass 2 fallback: gambar asli, PSM 3 (fully automatic)
        if (ocrTeks.trim().length < 40) {
            const t2 = await runOCRPass(tess, imageBuffer, '3');
            if (t2.trim().length > ocrTeks.trim().length) {
                ocrTeks = t2;
                console.log(`[ValidasiBukti] Pass2 (PSM3) panjang=${ocrTeks.length}: ${ocrTeks.replace(/\n/g,' ').substring(0,200)}`);
            }
        }

        // Pass 3 fallback: gambar preprocessed, PSM 11 (sparse text) — layout tidak standar
        if (ocrTeks.trim().length < 40) {
            const t3 = await runOCRPass(tess, processedBuffer, '11');
            if (t3.trim().length > ocrTeks.trim().length) {
                ocrTeks = t3;
                console.log(`[ValidasiBukti] Pass3 (PSM11) panjang=${ocrTeks.length}: ${ocrTeks.replace(/\n/g,' ').substring(0,200)}`);
            }
        }

    } catch(e) {
        console.error('[ValidasiBukti] OCR gagal:', e.message);
        return { isValid: true, reason: 'OCR gagal dijalankan, validasi dilewati', tanggalTransfer: null, jumlahTransfer: null, namaBank: null };
    }

    //  Cek 1: Tanggal ada & = hari ini (WIB) 
    const jumlahTransfer = parseJumlahOCR(ocrTeks);
    const tglDate    = parseTanggalOCR(ocrTeks);
    const nowWIB     = new Date(Date.now() + 7 * 3600 * 1000);
    const hariIni    = { d: nowWIB.getUTCDate(), m: nowWIB.getUTCMonth(), y: nowWIB.getUTCFullYear() };
    console.log(`[ValidasiBukti] Tanggal ditemukan: ${tglDate} | Jumlah: ${jumlahTransfer}`);

    if (!tglDate) {
        return {
            isValid: false,
            reason: ' Gambar tidak valid',
            tanggalTransfer: null, jumlahTransfer, namaBank: parseBankOCR(ocrTeks)
        };
    }

    const samaTanggal = (
        tglDate.getDate()     === hariIni.d &&
        tglDate.getMonth()    === hariIni.m &&
        tglDate.getFullYear() === hariIni.y
    );
    const tglStr = `${String(tglDate.getDate()).padStart(2,'0')}/${String(tglDate.getMonth()+1).padStart(2,'0')}/${tglDate.getFullYear()}`;

    if (!samaTanggal) {
        return {
            isValid: false,
            reason: ' Gambar tidak valid',
            tanggalTransfer: tglStr, jumlahTransfer, namaBank: parseBankOCR(ocrTeks)
        };
    }

    //  Cek 2: Nama Merchant 
    const merchantName = (CONFIG.MERCHANT_NAME || '').toLowerCase().trim();
    const ocrLower     = ocrTeks.toLowerCase();
    if (merchantName && !ocrLower.includes(merchantName)) {
        console.log(`[ValidasiBukti] Merchant tidak ditemukan: "${merchantName}"`);
        return {
            isValid: false,
            reason: ' Gambar tidak valid',
            tanggalTransfer: tglStr, jumlahTransfer, namaBank: parseBankOCR(ocrTeks)
        };
    }

    //  Semua cek lolos 
    return {
        isValid: true,
        reason: 'Valid',
        tanggalTransfer: tglStr,
        jumlahTransfer,
        namaBank: parseBankOCR(ocrTeks)
    };
}
// ==================== END VALIDASI BUKTI TRANSFER ====================

// Map untuk anti double-process (lock per user)
const processingPayment = new Map(); // userId -> true jika sedang diproses

// ==================== TRACKING MESSAGE ====================
async function trackMessage(ctx, messageId, type = 'menu', options = {}) {
    const userId = ctx.from.id.toString();
    if (!messageHistory.has(userId)) {
        messageHistory.set(userId, { menu: null, temp: [], results: [] });
    }
    
    const userHistory = messageHistory.get(userId);
    
    if (type === 'menu') {
        // Hapus pesan menu lama di background (tidak di-await) — pesan menu BARU
        // sudah terkirim & terlihat user duluan, jadi proses hapus yang lama
        // tidak perlu menahan/nunda apapun. Ini yang bikin transisi antar-menu
        // (apalagi yang bertukar dari/ke pesan foto: main menu <-> panel VPN, dst)
        // kerasa 1 round-trip instan, bukan 2 round-trip berurutan.
        if (userHistory.menu) {
            const oldMenuId = userHistory.menu;
            ctx.telegram.deleteMessage(ctx.chat.id, oldMenuId).catch(() => {});
        }
        userHistory.menu = messageId;
    } else if (type === 'temp') {
        userHistory.temp.push(messageId);
        // Kalau persist=true (mis. pesan prompt yang menunggu input user,
        // seperti "Ketik password manual"), JANGAN auto-hapus dalam 5 detik —
        // biarkan tetap ada sampai user selesai input. Pesan ini tetap akan
        // dibersihkan lewat clearTempMessages() saat menu berikutnya tampil.
        if (!options.persist) {
            setTimeout(async () => {
                try {
                    await ctx.telegram.deleteMessage(ctx.chat.id, messageId);
                    const index = userHistory.temp.indexOf(messageId);
                    if (index > -1) userHistory.temp.splice(index, 1);
                } catch(e) {}
            }, 5000);
        }
    } else if (type === 'result') {
        userHistory.results.push(messageId);
        if (userHistory.results.length > 30) userHistory.results.shift();
    }
}

async function clearTempMessages(ctx) {
    const userId = ctx.from.id.toString();
    const userHistory = messageHistory.get(userId);
    if (userHistory && userHistory.temp.length > 0) {
        const idsToDelete = userHistory.temp;
        userHistory.temp = [];
        // Hapus semua pesan temp secara paralel (bukan satu-satu/sequential)
        // supaya tidak menambah latency ke caller yang menunggu ini.
        await Promise.all(idsToDelete.map(msgId =>
            ctx.telegram.deleteMessage(ctx.chat.id, msgId).catch(() => {})
        ));
    }
}

async function clearPreviewMessages(ctx) {
    const userId = ctx.from.id.toString();
    const userHistory = messageHistory.get(userId);
    if (userHistory && userHistory.preview && userHistory.preview.length > 0) {
        const idsToDelete = userHistory.preview;
        userHistory.preview = [];
        // Hapus semua pesan preview secara paralel (bukan satu-satu/sequential),
        // sama seperti clearTempMessages — supaya tidak nambah latency ke caller.
        await Promise.all(idsToDelete.map(msgId =>
            ctx.telegram.deleteMessage(ctx.chat.id, msgId).catch(() => {})
        ));
    }
}

// ==================== AUTO BUTTON COLOR (Bot API 9.4+) ====================
// Telegram Bot API 9.4 menambahkan field `style` pada inline button:
// 'primary' = biru, 'success' = hijau, 'danger' = merah.
// Fungsi di bawah otomatis mewarnai SEMUA inline button di seluruh bot
// berdasarkan kata kunci pada teksnya, jadi tidak perlu edit satu-satu
// di setiap menu. Dipasang di sendMenu/sendMenuWithCachedPhoto/dll
// supaya berlaku global.

// Konversi Mathematical Bold Unicode (𝘼𝙗𝙘...) balik ke huruf biasa,
// karena hampir semua teks tombol di bot ini pakai gaya bold unicode.
function normalizeButtonText(text) {
    if (!text) return '';
    let out = '';
    for (const ch of text) {
        const cp = ch.codePointAt(0);
        if (cp >= 0x1D400 && cp <= 0x1D419) out += String.fromCharCode(65 + (cp - 0x1D400)); // A-Z bold
        else if (cp >= 0x1D41A && cp <= 0x1D433) out += String.fromCharCode(97 + (cp - 0x1D41A)); // a-z bold
        else if (cp >= 0x1D7CE && cp <= 0x1D7D7) out += String.fromCharCode(48 + (cp - 0x1D7CE)); // 0-9 bold
        else out += ch;
    }
    return out.toLowerCase();
}

// Urutan dicek dari atas ke bawah — kecocokan pertama yang menang.
// Tambah/ubah kata kunci di sini kalau ada tombol yang warnanya kurang pas.
const BUTTON_STYLE_RULES = [
    { style: 'danger', keywords: [
        'batal', 'hapus', 'tolak', 'reject', 'cancel', 'delete', 'nonaktif',
        'blokir', 'ban', 'stop', 'reset', 'kembali', 'menu utama',
    ]},
    { style: 'success', keywords: [
        'top up', 'topup', 'riwayat', 'upgrade', 'trial', 'generate',
        'ringkasan', 'reseller', 'dashboard', 'create', 'akun saya',
        'renew', 'perpanjang', 'daftar', 'preview', 'konfirmasi',
        'approve', 'terima', 'refresh', 'saldo', 'admin',
    ]},
];

function getButtonStyle(btn) {
    if (!btn || !btn.text) return undefined;
    if (btn.style) return btn.style; // sudah diset manual, jangan ditimpa
    const t = normalizeButtonText(btn.text);
    for (const rule of BUTTON_STYLE_RULES) {
        if (rule.keywords.some(k => t.includes(k))) return rule.style;
    }
    return 'primary'; // default biru untuk sisanya (termasuk tombol url/web_app/pay)
}

function applyButtonStyles(keyboardObj) {
    try {
        const rows = keyboardObj?.reply_markup?.inline_keyboard;
        if (!Array.isArray(rows)) return keyboardObj;
        for (const row of rows) {
            for (const btn of row) {
                const s = getButtonStyle(btn);
                if (s) btn.style = s;
            }
        }
    } catch(e) {}
    return keyboardObj;
}

// ==================== SEND FUNCTIONS ====================
async function sendMainMenuWithHeader(ctx, text, keyboard) {
    applyButtonStyles(keyboard);
    return sendMenuWithCachedPhoto(
        ctx, text, keyboard,
        HEADER_IMAGE_PATH,
        () => headerFileId,
        (fid) => { headerFileId = fid; }
    );
}

async function sendMenu(ctx, text, keyboard, forceNew = false) {
    applyButtonStyles(keyboard);
    // Jangan di-await: penghapusan pesan temp lama tidak perlu menahan
    // proses edit menu. Biarkan berjalan di background (paralel).
    clearTempMessages(ctx).catch(() => {});

    // Kalau dipanggil dari callback query (tekan tombol), edit pesan yang ada
    // (kecuali forceNew=true, mis. tombol "Refresh Bot" yang sengaja mau kirim pesan baru)
    if (ctx.callbackQuery && !forceNew) {
        const msg = ctx.callbackQuery.message;
        const userIdForHistory = ctx.from.id.toString();
        const existingHistory = messageHistory.get(userIdForHistory);
        // Jangan pernah edit pesan yang berstatus "result" (mis. hasil ganti bug xray/link).
        // Kalau di-edit, isi hasil (link yang sudah diganti) akan tertimpa oleh teks menu
        // dan hilang saat user menekan tombol "Kembali". Pesan result harus tetap utuh.
        const isResultMessage = !!(existingHistory && existingHistory.results && existingHistory.results.includes(msg.message_id));
        // Hanya edit jika pesan sebelumnya teks biasa (bukan foto/caption) DAN bukan pesan result
        if (msg && !msg.photo && !msg.document && !isResultMessage) {
            try {
                const edited = await ctx.telegram.editMessageText(
                    msg.chat.id,
                    msg.message_id,
                    null,
                    text,
                    { parse_mode: 'HTML', ...keyboard }
                );
                // Catat message_id di history agar tetap terlacak
                const userId = ctx.from.id.toString();
                if (!messageHistory.has(userId)) messageHistory.set(userId, { menu: null, temp: [], results: [] });
                messageHistory.get(userId).menu = msg.message_id;
                return edited;
            } catch(e) {
                // Konten sama (MessageNotModified) — abaikan, tidak perlu kirim baru
                if (e.description && e.description.includes('message is not modified')) return;
                // Error lain (misal pesan sudah dihapus) — fallback kirim baru
            }
        }
    }

    // Fallback: kirim pesan baru (dari command /menu atau pesan sebelumnya adalah foto)
    const sentMessage = await ctx.reply(text, { parse_mode: 'HTML', ...keyboard });
    if (sentMessage && sentMessage.message_id) {
        await trackMessage(ctx, sentMessage.message_id, 'menu');
    }
    return sentMessage;
}

// Helper umum: kirim menu dengan gambar header + file_id cache
async function sendMenuWithCachedPhoto(ctx, text, keyboard, headerPath, fileIdRef, setFileId) {
    applyButtonStyles(keyboard);
    clearTempMessages(ctx).catch(() => {});
    let sentMessage;
    const currentFileId = fileIdRef();
    if (currentFileId) {
        sentMessage = await ctx.replyWithPhoto(currentFileId, {
            caption: text, parse_mode: 'HTML', ...keyboard
        });
    } else if (fs.existsSync(headerPath)) {
        sentMessage = await ctx.replyWithPhoto(
            { source: fs.readFileSync(headerPath) },
            { caption: text, parse_mode: 'HTML', ...keyboard }
        );
        if (sentMessage?.photo?.length) {
            const fid = sentMessage.photo[sentMessage.photo.length - 1].file_id;
            setFileId(fid);
            console.log('[HeaderCache] file_id cached:', headerPath.split(/[\/]/).pop(), fid.substring(0, 20) + '...');
        }
    } else {
        sentMessage = await ctx.reply(text, { parse_mode: 'HTML', ...keyboard });
    }
    if (sentMessage?.message_id) await trackMessage(ctx, sentMessage.message_id, 'menu');
    return sentMessage;
}

// Tombol "❌ Batal" universal untuk mengganti teks "Ketik cancel untuk batal".
// callback_data-nya 'cancel_input' ditangani secara global di callback_query
// handler: menghapus userStates lalu kembali ke menu utama (sama seperti
// perilaku mengetik teks "cancel").
function cancelButtonRow() {
    return [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'cancel_input', style: 'danger' }];
}

function cancelKeyboard() {
    return Markup.inlineKeyboard([cancelButtonRow()]);
}

// Menambahkan baris tombol Batal ke keyboard inline yang sudah ada (kalau ada),
// atau membuat keyboard baru yang cuma berisi tombol Batal (kalau belum ada keyboard).
function withCancelButton(extra) {
    const opts = extra && typeof extra === 'object' ? { ...extra } : {};
    const existingRows = opts?.reply_markup?.inline_keyboard || [];
    opts.reply_markup = { inline_keyboard: [...existingRows, cancelButtonRow()] };
    return opts;
}

async function sendTempMessage(ctx, text, extraOptions = {}, persist = false) {
    applyButtonStyles(extraOptions);
    let sentMessage;
    
    if (extraOptions.photo) {
        sentMessage = await ctx.replyWithPhoto(extraOptions.photo, {
            caption: text,
            parse_mode: 'HTML',
            ...extraOptions
        });
    } else {
        sentMessage = await ctx.reply(text, { parse_mode: 'HTML', ...extraOptions });
    }
    
    if (sentMessage && sentMessage.message_id) {
        // persist=true → pesan TIDAK auto-terhapus 5 detik, dipakai untuk
        // prompt yang menunggu balasan/input user (mis. "Ketik password manual").
        await trackMessage(ctx, sentMessage.message_id, 'temp', { persist });
    }
    
    return sentMessage;
}

async function sendResultMessage(ctx, text, extraOptions = {}) {
    applyButtonStyles(extraOptions);
    let sentMessage;
    
    if (extraOptions.photo) {
        sentMessage = await ctx.replyWithPhoto(extraOptions.photo, {
            caption: text,
            parse_mode: 'HTML',
            ...extraOptions
        });
    } else {
        sentMessage = await ctx.reply(text, { parse_mode: 'HTML', ...extraOptions });
    }
    
    if (sentMessage && sentMessage.message_id) {
        await trackMessage(ctx, sentMessage.message_id, 'result');
    }
    
    return sentMessage;
}

// ==================== LOAD HEADER IMAGE ====================
async function loadHeaderImage() {
    try {
        if (fs.existsSync(HEADER_IMAGE_PATH)) {
            const imageBuffer = fs.readFileSync(HEADER_IMAGE_PATH);
            headerMedia = { source: imageBuffer };
            console.log(' Header image loaded successfully');
            return true;
        } else {
            console.log(' Header image not found at:', HEADER_IMAGE_PATH);
            return false;
        }
    } catch (err) {
        console.log(' Failed to load header image:', err.message);
        return false;
    }
}

// ==================== FUNGSI PEMBANTU ====================
function formatRp(amount) {
    return 'Rp ' + amount.toLocaleString('id-ID');
}

function formatTimestamp() {
    return new Date().toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// ==================== HARGA IP LIMIT ====================
// IP ke-2 dst dikenakan biaya tambahan terpisah
// Nilai diambil dari CONFIG agar bisa diedit via admin tanpa restart

// Tambahkan ke CONFIG di atas (jika belum ada):
if (!CONFIG.HARGA_TAMBAH_IP_PER_BULAN) {
    CONFIG.HARGA_TAMBAH_IP_PER_BULAN = parseInt(process.env.HARGA_TAMBAH_IP_PER_BULAN) || 3000;
}

function getHargaTambahIpPerHari() {
    return Math.ceil(CONFIG.HARGA_TAMBAH_IP_PER_BULAN / 30);
}
function getHargaTambahIpPerJam() {
    return Math.ceil(CONFIG.HARGA_TAMBAH_IP_PER_BULAN / 30 / 24);
}

function hitungHarga(days, iplimit) {
    const hargaBase     = CONFIG.HARGA_PER_HARI_PER_IP * days;
    const hargaTambahIp = iplimit > 1 ? (iplimit - 1) * getHargaTambahIpPerHari() * days : 0;
    return hargaBase + hargaTambahIp;
}

function hitungPerJamPayg(iplimit, server) {
    const hargaPerHari = server ? getHargaServer(server) : CONFIG.HARGA_PER_HARI_PER_IP;
    const perJamBase   = Math.ceil(hargaPerHari / 24);
    const tambahIpJam  = iplimit > 1 ? (iplimit - 1) * getHargaTambahIpPerJam() : 0;
    return perJamBase + tambahIpJam;
}

function formatHarga() {
    return `${formatRp(CONFIG.HARGA_PER_HARI_PER_IP)}/hari/IP`;
}

// Helper: format label harga untuk tampilan di menu create/renew, sudah memperhitungkan reseller
function formatHargaServerLabel(server, userId) {
    const hargaNormal = getHargaServer(server);
    const customMark = server && server.hargaPerHari != null ? ' ' : '';
    if (isReseller(userId)) {
        const hargaReseller = hitungHargaReseller(hargaNormal);
        return `~~${formatRp(hargaNormal)}~~ → ${formatRp(hargaReseller)}/hari/IP${customMark} <b>· Reseller</b>`;
    }
    return `${formatRp(hargaNormal)}/hari/IP${customMark}`;
}

/**
 * Helper: Buat baris daftar SEMUA layanan & harga, layout per-server (mirip panel
 * "Nama Server / Kuota / Default Login / Harga"), dipisah garis horizontal.
 * Mode 'hari' menampilkan Harga Bulanan & Harga Harian, mode 'jam' (PAYG) hanya Harga Per Jam.
 * @param {string} userId  - Telegram user ID
 * @param {'hari'|'jam'}  mode   - 'hari' untuk Create/Renew, 'jam' untuk PAYG
 * @param {string[]} excludeTypes - tipe server yang tidak ditampilkan (mis. ['zivpn'])
 * @returns {string}  teks multi-baris HTML siap embed di dalam <blockquote>
 */
function buildHargaLayananLines(userId, mode = 'hari', excludeTypes = [], options = {}) {
    const { extraPerHari = 0, includeTypes = null, accountTypeLabel = null } = options;
    let srvList = Object.values(SERVERS).filter(s => !excludeTypes.includes(s.type || 'xray'));
    if (includeTypes) {
        srvList = srvList.filter(s => includeTypes.includes(s.type || 'xray'));
    }
    const isResellerUser = isReseller(userId);
    // Pertahankan urutan: ssh → xray → zivpn
    const typeMap = { ssh: [], xray: [], zivpn: [] };
    for (const s of srvList) {
        const t = s.type || 'xray';
        if (!typeMap[t]) typeMap[t] = [];
        typeMap[t].push(s);
    }
    const lines = [];
    const allServers = [];
    for (const [t, servers] of Object.entries(typeMap)) {
        if (servers.length) allServers.push(...servers);
    }

    allServers.forEach((s, idx) => {
        const defaultIpLogin = CONFIG.DEFAULT_IP_LIMIT || 1;
        const jenisLabel = accountTypeLabel ? ` - ${accountTypeLabel}` : '';
        const serverQuota = getEffectiveQuota(s);
        const quotaStr = serverQuota === 0 ? 'Unlimited' : `${serverQuota}GB`;

        lines.push(`<b>· Server:</b> ${s.name}${jenisLabel}`);
        lines.push(`<b>· Bandwidth:</b> ${quotaStr}`);
        lines.push(`<b>· Default Login:</b> ${defaultIpLogin} IP`);
        lines.push(formatSlotLine(s));

        if (mode === 'jam') {
            const perJamNormal = Math.ceil(getHargaServer(s) / 24);
            const perJamFinal  = isResellerUser ? hitungHargaReseller(perJamNormal) : perJamNormal;
            const hargaPerJamLine = isResellerUser
                ? `<s>${formatRp(perJamNormal)}</s> → ${formatRp(perJamFinal)}/jam (Reseller)`
                : `${formatRp(perJamFinal)}/jam`;
            lines.push(`<b>· Harga Per Jam:</b> ${hargaPerJamLine}`);
        } else {
            const hargaNormal   = getHargaServer(s) + extraPerHari;
            const hargaFinal    = isResellerUser ? hitungHargaReseller(hargaNormal) : hargaNormal;
            const perBulanFinal = hargaFinal * 30;
            const hargaHarianLine = isResellerUser
                ? `<s>${formatRp(hargaNormal)}</s> → ${formatRp(hargaFinal)} (Reseller)`
                : formatRp(hargaFinal);
            lines.push(`<b>· Harga Bulanan:</b> ${formatRp(perBulanFinal)}`);
            lines.push(`<b>· Harga Harian:</b> ${hargaHarianLine}`);
        }

        if (idx < allServers.length - 1) {
            lines.push(`──────────────────────`);
        }
    });

    lines.push(`──────────────────────`);
    if (mode === 'jam') {
        lines.push(`<b>· Tambah IP:</b> +Rp ${getHargaTambahIpPerJam()}/jam`);
    } else {
        lines.push(`<b>· Tambah IP:</b> +Rp ${getHargaTambahIpPerHari()}/hari`);
    }
    return lines.join('\n');
}

// Tampilkan menu pilih IP limit sebagai inline keyboard
async function showIpLimitMenu(ctx, callbackPrefix, days = null, isPayg = false, server = null, isEdurc = false, showCustom = false) {
    const userId = ctx.from.id.toString();
    const saldo  = getSaldo(userId);
    const maxIp  = CONFIG.MAX_IP_LIMIT;

    let infoText;
    if (isPayg) {
        const pj1Normal = hitungPerJamPayg(1, server);
        const pj2Normal = hitungPerJamPayg(2, server);
        const isResellerUser = isReseller(userId);
        const pj1 = isResellerUser ? hitungHargaReseller(pj1Normal) : pj1Normal;
        const pj2 = isResellerUser ? hitungHargaReseller(pj2Normal) : pj2Normal;
        const hargaServerLabel = server && server.hargaPerHari != null
            ? `${formatRp(getHargaServer(server))}/hari/IP `
            : `${formatRp(CONFIG.HARGA_PER_HARI_PER_IP)}/hari/IP`;
        const resellerNote = isResellerUser ? `\n<b>· Reseller (Diskon ${getDiskonResellerPersen()}%)</b>` : '';
        infoText =
`${getHeader('𝙋𝙄𝙇𝙄𝙃 𝙅𝙐𝙈𝙇𝘼𝙃 𝙄𝙋 / 𝘿𝙀𝙑𝙄𝘾𝙀')}
<blockquote>💡 <b>Harga:</b> ${hargaServerLabel}${resellerNote}

📱 <b>1 IP</b> — ${formatRp(pj1)}/jam
📱📱 <b>2 IP</b> — ${formatRp(pj2)}/jam${showCustom ? `
✏️ <b>Custom</b> — masukkan jumlah sendiri` : ''}</blockquote>
ℹ️ IP ke-2 dikenakan biaya: +Rp ${getHargaTambahIpPerJam()}/jam per IP`;
    } else {
        const d  = days || 30;
        const h1Normal = isEdurc
            ? hitungHargaEdurc(server, d, 1)
            : (server ? hitungHargaServer(server, d, 1) : hitungHarga(d, 1));
        const h2Normal = isEdurc
            ? hitungHargaEdurc(server, d, 2)
            : (server ? hitungHargaServer(server, d, 2) : hitungHarga(d, 2));
        const isResellerUser = isReseller(userId);
        const h1 = isResellerUser ? hitungHargaReseller(h1Normal) : h1Normal;
        const h2 = isResellerUser ? hitungHargaReseller(h2Normal) : h2Normal;
        const hargaLabel = isEdurc
            ? formatHargaEdurcLabel(server, userId)
            : (server
                ? formatHargaServerLabel(server, userId)
                : `${formatRp(CONFIG.HARGA_PER_HARI_PER_IP)}/hari/IP`);
        infoText =
`${getHeader('𝙋𝙄𝙇𝙄𝙃 𝙅𝙐𝙈𝙇𝘼𝙃 𝙄𝙋 / 𝘿𝙀𝙑𝙄𝘾𝙀')}
<blockquote>💡 <b>Harga:</b> ${hargaLabel}

📱 <b>1 IP</b> — ${formatRp(h1)} (${d} hari)
📱📱 <b>2 IP</b> — ${formatRp(h2)} (${d} hari)${showCustom ? `
✏️ <b>Custom</b> — masukkan jumlah sendiri` : ''}</blockquote>
ℹ️ IP ke-2 dikenakan biaya: +Rp ${getHargaTambahIpPerHari()}/hari per IP`;
    }

    const keyboardRows = [
        [
            { text: '📱 𝟭 𝙄𝙋', callback_data: `${callbackPrefix}_1` },
            { text: '📱📱 𝟮 𝙄𝙋', callback_data: `${callbackPrefix}_2` }
        ]
    ];
    if (showCustom) {
        keyboardRows.push([{ text: '✏️ 𝘾𝙪𝙨𝙩𝙤𝙢 𝙄𝙋', callback_data: `${callbackPrefix}_custom` }]);
    }
    keyboardRows.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'main_menu', style: 'danger' }]);

    const keyboard = Markup.inlineKeyboard(keyboardRows);

    await sendMenu(ctx, infoText, keyboard);
}

function getGreeting() {
    const now = new Date();
    // Tambah 7 jam untuk Asia/Jakarta (UTC+7)
    const hours = (now.getUTCHours() + 7) % 24;
    
    if (hours >= 3 && hours < 11) return "🌤 Selamat Pagi";
    else if (hours >= 11 && hours < 15) return "☀️ Selamat Siang";
    else if (hours >= 15 && hours < 18) return "🌇 Selamat Sore";
    else return "🌙 Selamat Malam";
}

function getHeader(title) {
    return `<blockquote>✦ <b>${title.trim()}</b> ✦</blockquote>`;
}

function isAdmin(userId) {
    return ADMIN_IDS.includes(userId);
}

// Cache nama user (hasil getChat) supaya list-list admin (top saldo, reseller,
// search user, dst) tidak perlu hit Telegram API berkali-kali untuk user yang sama.
const _userNameCache = new Map(); // userId -> { name, ts }
const _USERNAME_CACHE_TTL = 10 * 60 * 1000; // 10 menit

async function getUserName(userId, ctx) {
    const uid = String(userId);
    const cached = _userNameCache.get(uid);
    if (cached && (Date.now() - cached.ts) < _USERNAME_CACHE_TTL) {
        return cached.name;
    }
    try {
        const chat = await ctx.telegram.getChat(parseInt(userId));
        const name = chat.first_name || chat.username || 'User';
        _userNameCache.set(uid, { name, ts: Date.now() });
        return name;
    } catch (e) {
        // Jangan cache hasil gagal — supaya percobaan berikutnya masih coba fetch ulang
        return 'User';
    }
}

// ==================== SALDO MANAGEMENT ====================
function loadSaldo() {
    return _cacheGet('saldo', SALDO_FILE, {});
}

function saveSaldo(data) {
    _cacheSet('saldo', SALDO_FILE, data);
}

function getSaldo(userId) {
    const data = loadSaldo();
    return data[userId] || 0;
}

function setSaldo(userId, amount) {
    const data = loadSaldo();
    data[userId] = Math.max(0, amount);
    saveSaldo(data);
    return true;
}

function tambahSaldo(userId, amount) {
    const cur = getSaldo(userId);
    const newAmount = cur + amount;
    setSaldo(userId, newAmount);
    return newAmount;
}

function kurangiSaldo(userId, amount) {
    const cur = getSaldo(userId);
    if (cur < amount) return false;
    setSaldo(userId, cur - amount);
    return true;
}

// ==================== DISKON / BONUS TOPUP (PER PERSEN) ====================
// Admin bisa atur tier bonus topup berbasis RANGE (rentang), misal:
// Topup 10K - 50K dapat bonus +5%, Topup 50K - 100K dapat bonus +10%, dst.
// Tier tertinggi bisa dibuat tanpa batas atas (maxAmount = null).
// Bonus dihitung dari tier yang rentang min-max nya cocok dengan nominal topup user.
function loadTopupBonus() {
    return _cacheGet('topupBonus', TOPUP_BONUS_FILE, { aktif: false, tiers: [] });
}

function saveTopupBonus(data) {
    _cacheSet('topupBonus', TOPUP_BONUS_FILE, data);
}

function isTopupBonusAktif() {
    return !!loadTopupBonus().aktif;
}

function setTopupBonusAktif(aktif) {
    const data = loadTopupBonus();
    data.aktif = !!aktif;
    saveTopupBonus(data);
    return data.aktif;
}

// Selalu dikembalikan terurut ASC berdasarkan minAmount
function getTopupBonusTiers() {
    const data = loadTopupBonus();
    return [...(data.tiers || [])].sort((a, b) => a.minAmount - b.minAmount);
}

// Tambah tier baru (berbasis RANGE min-max), atau update jika minAmount sudah ada.
// maxAmount = null artinya tier tanpa batas atas (biasanya dipakai untuk tier tertinggi).
function setTopupBonusTier(minAmount, maxAmount, persen) {
    const data = loadTopupBonus();
    if (!Array.isArray(data.tiers)) data.tiers = [];
    const existing = data.tiers.find(t => t.minAmount === minAmount);
    if (existing) {
        existing.maxAmount = maxAmount;
        existing.persen = persen;
    } else {
        data.tiers.push({ minAmount, maxAmount, persen });
    }
    data.tiers.sort((a, b) => a.minAmount - b.minAmount);
    saveTopupBonus(data);
    return data.tiers;
}

function removeTopupBonusTier(minAmount) {
    const data = loadTopupBonus();
    const before = (data.tiers || []).length;
    data.tiers = (data.tiers || []).filter(t => t.minAmount !== minAmount);
    saveTopupBonus(data);
    return data.tiers.length < before;
}

// Hitung bonus untuk nominal topup tertentu. Setiap tier sekarang berupa RANGE
// (minAmount - maxAmount). Bonus dipakai dari tier yang rentangnya cocok dengan
// nominal topup. maxAmount = null artinya tier tanpa batas atas.
function hitungBonusTopup(amount) {
    if (!isTopupBonusAktif()) return { persen: 0, bonus: 0 };
    const tiers = getTopupBonusTiers().filter(t =>
        amount >= t.minAmount && (t.maxAmount == null || amount <= t.maxAmount)
    );
    if (tiers.length === 0) return { persen: 0, bonus: 0 };
    const tierTerbaik = tiers[tiers.length - 1]; // jika ada overlap, ambil minAmount tertinggi
    const bonus = Math.floor(amount * tierTerbaik.persen / 100);
    return { persen: tierTerbaik.persen, bonus };
}

// Format nominal singkat untuk ditampilkan di list diskon, contoh: 10000 -> "10K", 1500000 -> "1.5JT"
function formatRibuanSingkat(n) {
    if (n >= 1000000) {
        const v = n / 1000000;
        return `${Number.isInteger(v) ? v : v.toFixed(1)}JT`;
    }
    if (n >= 1000) {
        const v = n / 1000;
        return `${Number.isInteger(v) ? v : v.toFixed(1)}K`;
    }
    return n.toString();
}

// Teks list diskon topup untuk ditampilkan di deskripsi menu utama.
// Kembalikan string kosong jika fitur nonaktif / belum ada tier.
function getTopupBonusListText() {
    if (!isTopupBonusAktif()) return '';
    const tiers = getTopupBonusTiers();
    if (tiers.length === 0) return '';
    const lines = tiers.map(t => {
        const rangeLabel = t.maxAmount == null
            ? `${formatRibuanSingkat(t.minAmount)}+`
            : `${formatRibuanSingkat(t.minAmount)} - ${formatRibuanSingkat(t.maxAmount)}`;
        return `🎁 <b>${rangeLabel}</b> → <b>+${t.persen}%</b>`;
    }).join('\n');
    return `\n<blockquote>🎉 <b>— BONUS TOPUP —</b>\n${lines}</blockquote>`;
}


function loadTransaksi() {
    return _cacheGet('transaksi', TRANSAKSI_FILE, []);
}

// ==================== STATS: COUNTER PERMANEN (tidak ikut terpotong) ====================
// transaksi.json sengaja dipangkas ke 1000 record terbaru saja (lihat simpanTransaksi) supaya
// file tetap ringan. Untuk statistik "Total Transaksi" & "Tx Hari Ini" yang akurat walau sudah
// lebih dari 1000 transaksi, dipakai counter terpisah di stats.json yang selalu bertambah.
function loadStats() {
    const stats = _cacheGet('stats', STATS_FILE, null);
    if (stats) return stats;

    // stats.json belum pernah dibuat (fitur baru) → seed baseline dari transaksi.json yang ada
    // sekarang, supaya "Total Transaksi" tidak tiba-tiba balik ke 0. Catatan: baseline ini hanya
    // sebatas record yang masih tersimpan (transaksi.json dipangkas ke 1000 terbaru), jadi angka
    // histori sebelum fix ini tetap tidak bisa dipulihkan 100% — tapi mulai sekarang counter ini
    // akan terus bertambah tanpa batas dan tidak akan mentok lagi.
    const existing = loadTransaksi();
    const seeded = { totalTransaksiAllTime: existing.length, dailyCount: { date: '', count: 0 } };
    saveStats(seeded);
    return seeded;
}

function saveStats(stats) {
    _cacheSet('stats', STATS_FILE, stats);
}

function incrementStatsTransaksi() {
    const stats = loadStats();
    stats.totalTransaksiAllTime = (stats.totalTransaksiAllTime || 0) + 1;

    const todayStr = new Date().toDateString();
    if (stats.dailyCount && stats.dailyCount.date === todayStr) {
        stats.dailyCount.count += 1;
    } else {
        stats.dailyCount = { date: todayStr, count: 1 };
    }

    saveStats(stats);
    return stats;
}

function getTxHariIniBot() {
    const stats = loadStats();
    const todayStr = new Date().toDateString();
    return (stats.dailyCount && stats.dailyCount.date === todayStr) ? stats.dailyCount.count : 0;
}

function getTotalTransaksiBot() {
    return loadStats().totalTransaksiAllTime || 0;
}

function simpanTransaksi(tx) {
    const data = loadTransaksi();
    data.unshift(tx);
    if (data.length > 1000) data.splice(1000);
    _cacheSet('transaksi', TRANSAKSI_FILE, data);
    incrementStatsTransaksi();
}

function generateTxId() {
    return 'TX' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 100).toString().padStart(2, '0');
}

// ==================== CEK RIWAYAT TOPUP & ORDER (untuk gating fitur Ganti Bug) ====================
// Fitur "Ganti Bug Xray" hanya boleh dipakai user yang sudah pernah TOPUP saldo
// DAN sudah pernah ORDER/create akun (bukan cuma "mampir" tanpa transaksi apapun).
const ORDER_TX_TYPES = ['create', 'renew', 'sewa_sc', 'sewa_sc_perpanjang', 'sewa_bot', 'sewa_bot_perpanjang', 'payg_create'];

function cekRiwayatTopupDanOrder(userId) {
    const transaksi = loadTransaksi();
    const txUser = transaksi.filter(t => t.userId === userId && t.status === 'success');
    const sudahTopup = txUser.some(t => t.type === 'topup');
    const sudahOrder = txUser.some(t => ORDER_TX_TYPES.includes(t.type));
    return { sudahTopup, sudahOrder };
}

// ==================== TRIAL MANAGEMENT ====================
function loadTrialData() {
    return _cacheGet('trial', TRIAL_FILE, {});
}

function saveTrialData(data) {
    _cacheSet('trial', TRIAL_FILE, data);
}

function cekBisaTrial(userId) {
    const data = loadTrialData();
    const today = new Date().toDateString();
    const userTrials = data[userId] || [];
    const trialsToday = userTrials.filter(t => new Date(t).toDateString() === today);
    return trialsToday.length < CONFIG.MAX_TRIAL_PER_USER;
}

function catatTrial(userId) {
    const data = loadTrialData();
    if (!data[userId]) data[userId] = [];
    data[userId].push(new Date().toISOString());
    saveTrialData(data);
}

// ==================== GET ALL USERS FROM ALL SOURCES ====================
function getAllUsersFromBot() {
    const usersSet = new Set();
    
    // 0. Dari users.json (semua user yang pernah /start — sumber paling lengkap)
    try {
        const users = loadUsers();
        Object.keys(users).forEach(uid => usersSet.add(uid));
    } catch(e) {}

    // 1. Dari saldo.json (user yang topup)
    try {
        const saldo = loadSaldo();
        Object.keys(saldo).forEach(uid => usersSet.add(uid));
    } catch(e) {}
    
    // 2. Dari akun.json (user yang create akun)
    try {
        const akun = loadAkun();
        Object.keys(akun).forEach(uid => usersSet.add(uid));
    } catch(e) {}
    
    // 3. Dari transaksi.json (user yang transaksi)
    try {
        const transaksi = loadTransaksi();
        transaksi.forEach(tx => {
            if (tx.userId) usersSet.add(tx.userId.toString());
        });
    } catch(e) {}
    
    // 4. Dari trial.json (user yang trial)
    try {
        const trial = loadTrialData();
        Object.keys(trial).forEach(uid => usersSet.add(uid));
    } catch(e) {}
    
    return Array.from(usersSet);
}

// Ambil semua user dengan detail lengkap
function getAllUsersWithDetails() {
    const usersMap = new Map();
    
    // 1. Dari saldo.json
    try {
        const saldo = loadSaldo();
        for (const [uid, saldoAmount] of Object.entries(saldo)) {
            if (!usersMap.has(uid)) {
                usersMap.set(uid, { 
                    userId: uid, 
                    saldo: 0, 
                    akunCount: 0, 
                    transaksiCount: 0,
                    trialCount: 0,
                    lastActivity: null,
                    sources: []
                });
            }
            usersMap.get(uid).saldo = saldoAmount;
            usersMap.get(uid).sources.push('saldo');
        }
    } catch(e) {}
    
    // 2. Dari akun.json
    try {
        const akun = loadAkun();
        for (const [uid, akuns] of Object.entries(akun)) {
            if (!usersMap.has(uid)) {
                usersMap.set(uid, { 
                    userId: uid, 
                    saldo: 0, 
                    akunCount: 0, 
                    transaksiCount: 0,
                    trialCount: 0,
                    lastActivity: null,
                    sources: []
                });
            }
            usersMap.get(uid).akunCount = akuns.length;
            usersMap.get(uid).sources.push('akun');
            
            // Cari last activity dari akun terbaru
            for (const ak of akuns) {
                if (ak.createdAt) {
                    const createdDate = new Date(ak.createdAt);
                    const currentLast = usersMap.get(uid).lastActivity;
                    if (!currentLast || createdDate > currentLast) {
                        usersMap.get(uid).lastActivity = createdDate;
                    }
                }
            }
        }
    } catch(e) {}
    
    // 3. Dari transaksi.json
    try {
        const transaksi = loadTransaksi();
        for (const tx of transaksi) {
            if (tx.userId) {
                const uid = tx.userId.toString();
                if (!usersMap.has(uid)) {
                    usersMap.set(uid, { 
                        userId: uid, 
                        saldo: 0, 
                        akunCount: 0, 
                        transaksiCount: 0,
                        trialCount: 0,
                        lastActivity: null,
                        sources: []
                    });
                }
                usersMap.get(uid).transaksiCount++;
                if (!usersMap.get(uid).sources.includes('transaksi')) {
                    usersMap.get(uid).sources.push('transaksi');
                }
                
                // Update last activity dari transaksi
                if (tx.waktu) {
                    const txDate = new Date(tx.waktu);
                    const currentLast = usersMap.get(uid).lastActivity;
                    if (!currentLast || txDate > currentLast) {
                        usersMap.get(uid).lastActivity = txDate;
                    }
                }
            }
        }
    } catch(e) {}
    
    // 4. Dari trial.json
    try {
        const trial = loadTrialData();
        for (const [uid, trials] of Object.entries(trial)) {
            if (!usersMap.has(uid)) {
                usersMap.set(uid, { 
                    userId: uid, 
                    saldo: 0, 
                    akunCount: 0, 
                    transaksiCount: 0,
                    trialCount: 0,
                    lastActivity: null,
                    sources: []
                });
            }
            usersMap.get(uid).trialCount = trials.length;
            usersMap.get(uid).sources.push('trial');
            
            // Update last activity dari trial
            for (const t of trials) {
                const trialDate = new Date(t);
                const currentLast = usersMap.get(uid).lastActivity;
                if (!currentLast || trialDate > currentLast) {
                    usersMap.get(uid).lastActivity = trialDate;
                }
            }
        }
    } catch(e) {}
    
    // Konversi Map ke Array
    const users = Array.from(usersMap.values());
    
    // Urutkan berdasarkan last activity (terbaru ke terlama)
    users.sort((a, b) => {
        if (!a.lastActivity && !b.lastActivity) return b.saldo - a.saldo;
        if (!a.lastActivity) return 1;
        if (!b.lastActivity) return -1;
        return b.lastActivity - a.lastActivity;
    });
    
    return users;
}

// Ambil statistik lengkap user
function getUserStatsAll() {
    const users = getAllUsersWithDetails();
    const saldo = loadSaldo();
    
    let totalSaldo = 0;
    let totalAkun = 0;
    let totalTransaksi = 0;
    let totalTrial = 0;
    let usersWithSaldo = 0;
    let usersWithAkun = 0;
    let usersWithTransaksi = 0;
    let usersWithTrial = 0;
    
    for (const user of users) {
        totalSaldo += user.saldo;
        totalAkun += user.akunCount;
        totalTransaksi += user.transaksiCount;
        totalTrial += user.trialCount;
        if (user.saldo > 0) usersWithSaldo++;
        if (user.akunCount > 0) usersWithAkun++;
        if (user.transaksiCount > 0) usersWithTransaksi++;
        if (user.trialCount > 0) usersWithTrial++;
    }
    
    return {
        totalUsers: users.length,
        totalSaldo,
        totalAkun,
        totalTransaksi,
        totalTrial,
        usersWithSaldo,
        usersWithAkun,
        usersWithTransaksi,
        usersWithTrial,
        averageSaldo: users.length > 0 ? totalSaldo / users.length : 0,
        averageAkun: users.length > 0 ? totalAkun / users.length : 0
    };
}

// ==================== AKUN MANAGEMENT ====================
function loadAkun() {
    return _cacheGet('akun', AKUN_FILE, {});
}

function saveAkun(data) {
    _cacheSet('akun', AKUN_FILE, data);
    // CATATAN: slot terpakai TIDAK dihitung ulang otomatis dari sini lagi.
    // Naik/turunnya counter slot ditangani langsung di titik create/hapus akun
    // (tambahSlotTerpakai / kurangiSlotTerpakai), bukan scan ulang akun.json.
}

// Parse string tanggal expired (format "18 Jun 2026" dst, termasuk singkatan bulan Indonesia)
// menjadi Unix timestamp (ms), di akhir hari WIB (23:59:59 UTC+7). Return null kalau gagal parse.
function parseExpiredStringToTimestamp(expiredStr) {
    if (!expiredStr || expiredStr === '-' || expiredStr === 'Pay As You Go') return null;
    try {
        const bulanMap = {
            'jan':0,'feb':1,'mar':2,'apr':3,'mei':4,'may':4,
            'jun':5,'jul':6,'agu':7,'aug':7,'sep':8,'okt':9,'oct':9,'nov':10,'des':11,'dec':11
        };
        const parts = expiredStr.trim().split(/\s+/);
        if (parts.length >= 3) {
            const day   = parseInt(parts[0]);
            const month = bulanMap[parts[1].toLowerCase().slice(0,3)];
            const year  = parseInt(parts[2]);
            if (!isNaN(day) && month !== undefined && !isNaN(year)) {
                const d = new Date(year, month, day, 23, 59, 59, 0);
                return d.getTime() - (7 * 60 * 60 * 1000);
            }
        }
        const d = new Date(expiredStr);
        if (!isNaN(d.getTime())) return d.getTime();
    } catch(e) {
        console.log('[parseExpiredStringToTimestamp] Gagal parse:', e.message);
    }
    return null;
}

// Format Unix timestamp (ms) menjadi string display "18 Jun 2026" (sama persis dengan format saat create akun)
function formatExpiredDisplay(timestampMs) {
    return new Date(timestampMs).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}

function tambahAkun(userId, akunInfo) {
    const akun = loadAkun();
    if (!akun[userId]) akun[userId] = [];

    // Hitung expiredTimestamp (Unix ms) untuk akun biasa (non-PAYG, non-trial)
    // Dipakai oleh auto-delete expired checker agar tidak perlu parse string tanggal
    let expiredTimestamp = akunInfo.expiredTimestamp || null;
    if (!expiredTimestamp && !akunInfo.payAsYouGo && !akunInfo.isTrial) {
        expiredTimestamp = parseExpiredStringToTimestamp(akunInfo.expired);
    }

    akun[userId].push({
        ...akunInfo,
        ...(expiredTimestamp ? { expiredTimestamp } : {}),
        createdAt: new Date().toISOString(),
        status: 'active'
    });
    saveAkun(akun);

    // Slot terpakai naik 1 untuk akun non-trial yang berhasil dibuat di server ini
    if (!akunInfo.isTrial) {
        const server = akunInfo.serverId ? SERVERS[akunInfo.serverId]
            : (akunInfo.serverName ? Object.values(SERVERS).find(s => s.name === akunInfo.serverName) : null);
        if (server) tambahSlotTerpakai(server);
    }
}

// Update tanggal expired di akun.json untuk akun yang baru saja di-renew, supaya
// akun.json tetap sinkron dengan masa aktif yang sebenarnya di server (dan tidak
// dihapus duluan oleh auto-delete checker meski sudah diperpanjang).
// Mengembalikan { oldExpired, newExpired, expiredTimestamp } kalau ketemu, atau null kalau tidak ketemu.
function updateAkunExpiredAfterRenew(userId, serviceType, server, target, days) {
    const akun = loadAkun();
    const list = akun[userId];
    if (!Array.isArray(list)) return null;

    const svcType = (serviceType || '').toLowerCase();
    const entry = list.find(a => {
        if (a.payAsYouGo || a.isTrial) return false;
        if ((a.serviceType || '').toLowerCase() !== svcType) return false;
        // Cocokkan server kalau datanya ada (prioritas serverId, fallback nama server)
        if (server) {
            const sameServer = (a.serverId && server.id && a.serverId === server.id) ||
                                (!a.serverId && a.serverName && server.name && a.serverName === server.name);
            if (a.serverId || a.serverName) {
                if (!sameServer) return false;
            }
        }
        // Cocokkan identifier akun: username (SSH/Trojan/VLess/VMess) atau password/uuid (ZiVPN)
        return a.username === target || a.password === target || a.uuid === target;
    });

    if (!entry) return null;

    const now = Date.now();
    const oldTimestamp  = entry.expiredTimestamp || parseExpiredStringToTimestamp(entry.expired) || now;
    const oldDisplay    = entry.expired || formatExpiredDisplay(oldTimestamp);
    // Kalau akun sudah lewat expired, tambahan hari dihitung mulai dari sekarang (bukan dari tanggal lama)
    const baseTimestamp = Math.max(oldTimestamp, now);
    const newTimestamp  = baseTimestamp + (days * 24 * 60 * 60 * 1000);
    const newDisplay    = formatExpiredDisplay(newTimestamp);

    entry.expiredTimestamp = newTimestamp;
    entry.expired = newDisplay;
    entry.status = 'active'; // reset kalau sebelumnya sempat ditandai expired

    saveAkun(akun);

    return { oldExpired: oldDisplay, newExpired: newDisplay, expiredTimestamp: newTimestamp };
}

// ====== Auto-detect akun & server untuk RENEW (tanpa pilih server manual) ======
// Cari akun milik user di akun.json yang cocok dengan serviceType + mode (reguler/EDURC/CloudFront)
// + identifier (username/password/uuid) yang diketik user. Server otomatis diambil dari data akun.
function findAkunForRenew(userId, serviceType, isEdurc, target, serverId = null) {
    const akun = loadAkun();
    const list = akun[userId];
    if (!Array.isArray(list)) return null;

    const svcType = (serviceType || '').toLowerCase();
    const wantEdurc = !!isEdurc;
    const targetTrim = (target || '').trim();

    // Cocokkan dari yang terbaru duluan (createdAt desc) supaya kalau ada duplikat username lama, ambil yang aktif terbaru
    const sorted = [...list].sort((x, y) => {
        const tx = x.createdAt ? new Date(x.createdAt).getTime() : 0;
        const ty = y.createdAt ? new Date(y.createdAt).getTime() : 0;
        return ty - tx;
    });

    const entry = sorted.find(a => {
        if (a.payAsYouGo || a.isTrial) return false;
        if ((a.serviceType || '').toLowerCase() !== svcType) return false;
        if (!!a.isEdurc !== wantEdurc) return false;
        if (serverId && a.serverId !== serverId) return false;
        return a.username === targetTrim || a.password === targetTrim || a.uuid === targetTrim;
    });

    if (!entry) return null;

    let server = entry.serverId ? SERVERS[entry.serverId] : null;
    if (!server && entry.serverName) {
        server = Object.values(SERVERS).find(s => s.name === entry.serverName) || null;
    }
    if (!server) return null;

    return { entry, server };
}

function getJumlahAkun(userId) {
    const akun = loadAkun();
    return akun[userId] ? akun[userId].length : 0;
}

function getAllAkunCount() {
    const akun = loadAkun();
    let total = 0;
    for (const userId in akun) total += akun[userId].length;
    return total;
}

// ==================== SLOT SERVER (KAPASITAS AKUN PER SERVER) ====================
// server.maxSlot = jumlah maksimum akun AKTIF (non-trial) yang boleh ada di server
// tersebut secara bersamaan. null/undefined = Unlimited (tanpa batas, default).
// Akun trial TIDAK dihitung karena sifatnya sementara (durasi menit) dan akan
// terus berganti-ganti — menghitungnya bisa membuat status "Slot Penuh" palsu.
//
// PENTING: SSH & XRAY (dan tipe lain) yang menunjuk ke apiUrl yang sama adalah
// SATU server fisik yang sama, cuma beda nama/type saja. Jadi slot (terpakai
// maupun total) disatukan/dihitung gabungan lintas semua entri server yang
// apiUrl-nya sama, bukan dihitung terpisah per entri.
function getServerGroupKey(server) {
    return String(server?.apiUrl || '').trim().toLowerCase().replace(/\/+$/, '');
}

function getServersInGroup(server) {
    const key = getServerGroupKey(server);
    if (!server || !key) return server ? [server] : [];
    return Object.values(SERVERS).filter(s => getServerGroupKey(s) === key);
}

function getEffectiveMaxSlot(server) {
    const group = getServersInGroup(server);
    for (const s of group) {
        if (s && s.maxSlot != null) return s.maxSlot;
    }
    return null;
}

// ==================== totalslot.json (COUNTER SLOT TERPAKAI PER SERVER) ====================
// PENTING (revisi): angka "slot terpakai" di sini SEKARANG MURNI COUNTER MANUAL —
// TIDAK PERNAH dihitung/disinkronkan ulang dengan cara scan akun.json. Angka naik
// 1 setiap kali ada akun BARU (non-trial) berhasil dibuat di server tsb, dan turun
// 1 setiap kali akun (non-trial) itu dihapus/expired/di-stop. Kalau angkanya meleset
// (mis. ada penghapusan lewat jalur lain yang belum ke-cover), admin tinggal
// koreksi manual lewat menu "Edit Slot Terpakai" — tidak akan ketiban/ketimpa
// otomatis oleh proses lain.
function loadTotalSlot() {
    return _cacheGet('totalslot', TOTALSLOT_FILE, {});
}

function saveTotalSlot(data) {
    _cacheSet('totalslot', TOTALSLOT_FILE, data);
}

// Naikkan/turunkan counter slot terpakai untuk SEMUA entri server dalam satu
// grup (ssh & xray dkk di server fisik yang sama), tanpa scan akun.json.
function ubahSlotTerpakai(server, delta) {
    if (!server) return null;
    const group = getServersInGroup(server);
    const ids = group.map(s => s.id);
    if (ids.length === 0) return null;
    const data = loadTotalSlot();
    let current = 0;
    for (const id of ids) {
        if (data[id] && typeof data[id].used === 'number') { current = data[id].used; break; }
    }
    const next = Math.max(0, current + delta);
    const updatedAt = new Date().toISOString();
    for (const id of ids) {
        data[id] = { used: next, updatedAt };
    }
    saveTotalSlot(data);
    return data;
}

function tambahSlotTerpakai(server) { return ubahSlotTerpakai(server, 1); }
function kurangiSlotTerpakai(server) { return ubahSlotTerpakai(server, -1); }

// Override manual "slot terpakai" (dipakai saat admin mengoreksi angka lewat menu
// Edit Slot Terpakai). Berlaku untuk SEMUA entri server dalam grup yang sama.
function setTotalSlotUsedManual(server, usedCount) {
    if (!server) return null;
    const group = getServersInGroup(server);
    const ids = group.map(s => s.id);
    const data = loadTotalSlot();
    const updatedAt = new Date().toISOString();
    for (const id of ids) {
        data[id] = { used: usedCount, updatedAt };
    }
    saveTotalSlot(data);
    return data;
}

// Jumlah akun aktif (non-trial) digabung untuk SEMUA entri server dalam satu grup.
// MURNI baca counter dari totalslot.json — kalau belum pernah ada data sama
// sekali, dianggap 0 (BUKAN scan akun.json).
function getJumlahAkunAktifPerServerGroup(server) {
    if (!server) return 0;
    const cached = loadTotalSlot();
    const entry = cached[server.id];
    return entry ? entry.used : 0;
}

// Dipertahankan untuk kompatibilitas (hitung per-id saja, tanpa gabungan grup)
function getJumlahAkunAktifPerServer(serverId) {
    const akun = loadAkun();
    const server = SERVERS[serverId];
    let total = 0;
    for (const uid in akun) {
        const list = akun[uid] || [];
        for (const a of list) {
            if (a.status !== 'active' || a.isTrial) continue;
            const sameServer = (a.serverId && a.serverId === serverId) ||
                                (!a.serverId && a.serverName && server && a.serverName === server.name);
            if (sameServer) total++;
        }
    }
    return total;
}

function getSlotInfo(server) {
    if (!server) return { unlimited: true, used: 0, max: null, sisa: null, penuh: false };
    const max = getEffectiveMaxSlot(server);
    // Slot Terpakai SELALU dihitung/ditampilkan apa adanya, terlepas dari Slot
    // Total sudah diset atau belum — keduanya adalah 2 nilai independen.
    const used = getJumlahAkunAktifPerServerGroup(server);
    if (max == null) {
        return { unlimited: true, used, max: null, sisa: null, penuh: false };
    }
    const sisa = Math.max(0, max - used);
    return { unlimited: false, used, max, sisa, penuh: used >= max };
}

// Baris siap-pakai untuk ditampilkan di blok "LAYANAN & HARGA" — SENGAJA tidak
// menampilkan angka slot ke pelanggan, cukup status tersedia/penuh saja.
function formatSlotLine(server) {
    const info = getSlotInfo(server);
    if (info.penuh) return `<b>· Slot:</b> ❌ Penuh`;
    return `<b>· Slot:</b> ✅ Tersedia`;
}

// ==================== USER REGISTRATION ====================
function loadUsers() {
    return _cacheGet('users', USERS_FILE, {});
}

function saveUsers(data) {
    try {
        _cacheSet('users', USERS_FILE, data);
    } catch (e) {
        console.error('[saveUsers] Error:', e.message);
    }
}

/**
 * Daftarkan / update data user setiap kali berinteraksi dengan bot.
 * Menyimpan: userId, username, firstName, lastName, firstSeen, lastSeen
 */
function registerUser(from) {
    if (!from || !from.id) return;
    const userId = from.id.toString();
    const users = loadUsers();
    const now = new Date().toISOString();
    if (!users[userId]) {
        users[userId] = {
            userId,
            username: from.username || null,
            firstName: from.first_name || null,
            lastName: from.last_name || null,
            firstSeen: now,
            lastSeen: now,
            hasSeenWelcome: false // user baru harus lihat pesan welcome dulu sebelum bisa akses /menu langsung
        };
        console.log(`[registerUser] User baru: ${userId} (${from.first_name || from.username || '-'})`);
    } else {
        // Update info terbaru (nama/username bisa berubah)
        users[userId].username  = from.username  || users[userId].username  || null;
        users[userId].firstName = from.first_name || users[userId].firstName || null;
        users[userId].lastName  = from.last_name  || users[userId].lastName  || null;
        users[userId].lastSeen  = now;
    }
    saveUsers(users);
}

function getTotalRegisteredUsers() {
    return Object.keys(loadUsers()).length;
}

// User lama (sebelum fitur ini ada) tidak punya field hasSeenWelcome sama sekali →
// dianggap SUDAH pernah lihat welcome (bukan false eksplisit), jadi tidak terkunci.
// Hanya user BARU (di-set false saat pertama kali registerUser) yang wajib lihat welcome dulu.
function hasSeenWelcome(userId) {
    const users = loadUsers();
    const u = users[userId?.toString()];
    return !u || u.hasSeenWelcome !== false;
}

function markWelcomeSeen(userId) {
    const users = loadUsers();
    const uid = userId?.toString();
    if (users[uid]) {
        users[uid].hasSeenWelcome = true;
        saveUsers(users);
    }
}

// ==================== SERVER MANAGEMENT ====================
function _parseServers(raw) {
    const servers = (raw || {}).servers || {};
    const formatted = {};
    for (const [id, info] of Object.entries(servers)) {
        formatted[id] = {
            id,
            name: info.name || `Server ${id}`,
            apiUrl: (info.api_url || '').replace(/\/$/, ''),
            authKey: info.auth_key || '',
            type: info.type || 'ssh',
            hargaPerHari: info.harga_per_hari != null ? parseInt(info.harga_per_hari) : null,
            // Quota (GB) per server — HARUS di-parse balik dari disk, kalau
            // tidak, settingan quota hilang (balik ke Unlimited/global) tiap bot restart.
            quotaGb: info.quota_gb != null ? parseInt(info.quota_gb) : null,
            // Slot maksimum akun aktif per server — HARUS di-parse balik dari disk,
            // kalau tidak, settingan slot hilang (balik ke Unlimited) tiap bot restart.
            maxSlot: info.max_slot != null ? parseInt(info.max_slot) : null
        };
    }
    return formatted;
}

function loadServers() {
    // Cache menyimpan raw JSON; parse ke format runtime setiap kali
    const raw = _cacheGet('servers', CONFIG_FILE, { servers: {} });
    return _parseServers(raw);
}

function saveServers(servers) {
    const data = { servers: {} };
    for (const [id, info] of Object.entries(servers)) {
        data.servers[id] = {
            name: info.name,
            api_url: info.apiUrl,
            auth_key: info.authKey,
            type: info.type,
            ...(info.hargaPerHari != null ? { harga_per_hari: info.hargaPerHari } : {}),
            // Simpan quota (GB) supaya tidak hilang saat bot restart
            ...(info.quotaGb != null ? { quota_gb: info.quotaGb } : {}),
            // Simpan slot maksimum supaya tidak hilang saat bot restart
            ...(info.maxSlot != null ? { max_slot: info.maxSlot } : {})
        };
    }
    _cacheSet('servers', CONFIG_FILE, data);
}

// ==================== EDURC: DOMAIN CDN PER SERVER ====================
// edurc.json menyimpan domain CDN yang dipakai untuk menggantikan
// address/host/SNI (xray, mode Direct) atau domain (SSH, mode CloudFront) pada hasil create & trial.
// Struktur: { "servers": { "<serverId>": "cdn.domain.com" } }
function loadEdurcDomains() {
    const raw = _cacheGet('edurc', EDURC_FILE, { servers: {} });
    return (raw && raw.servers) ? raw.servers : {};
}

function saveEdurcDomains(domains) {
    _cacheSet('edurc', EDURC_FILE, { servers: domains });
}

function getEdurcDomain(serverId) {
    const domains = loadEdurcDomains();
    const val = domains[serverId];
    return (val && val.trim()) ? val.trim() : null;
}

function setEdurcDomain(serverId, domain) {
    const domains = loadEdurcDomains();
    domains[serverId] = domain.trim();
    saveEdurcDomains(domains);
}

function deleteEdurcDomain(serverId) {
    const domains = loadEdurcDomains();
    if (domains[serverId] !== undefined) {
        delete domains[serverId];
        saveEdurcDomains(domains);
        return true;
    }
    return false;
}

// ==================== WILDCARD: DAFTAR DOMAIN BUG WILDCARD ====================
// wildcard.json menyimpan daftar domain/prefix wildcard yang bisa dipilih user untuk
// mengganti mode bug pada link Xray (VMess/VLESS/Trojan) miliknya sendiri — BUKAN untuk
// create akun, murni tool ganti bug link. Dikelola admin lewat submenu Mode Wildcard.
//
// Cara kerja Mode Wildcard:
//   - "bug"    = address/host yang akan dipakai bot untuk konek (menggantikan host asli link).
//   - "prefix" = potongan wildcard yang ditempel DI DEPAN host asli, lalu dipakai sebagai
//                SNI & Host header. Kalau prefix kosong, otomatis dianggap sama dengan bug.
//   Contoh: prefix "bug.com." + host asli link "server.example.com"
//           -> SNI/Host baru = "bug.com.server.example.com"
//           -> address baru  = "bug.com" (nilai bug)
//
// Struktur file: { "domains": [ { "id": "wc_ab12cd", "label": "Bug XL", "bug": "bug.xl.co.id", "prefix": "bug.xl.co.id." } ] }
function loadWildcardDomains() {
    const raw = _cacheGet('wildcard', WILDCARD_FILE, { domains: [] });
    return (raw && Array.isArray(raw.domains)) ? raw.domains : [];
}

function saveWildcardDomains(domains) {
    _cacheSet('wildcard', WILDCARD_FILE, { domains });
}

function getWildcardDomain(id) {
    return loadWildcardDomains().find(d => d.id === id) || null;
}

function addWildcardDomain(bug, prefix) {
    const domains = loadWildcardDomains();
    const cleanBug = (bug || '').trim();
    let cleanPrefix = (prefix || '').trim() || cleanBug;
    if (!cleanPrefix.endsWith('.')) cleanPrefix = `${cleanPrefix}.`;

    const entry = {
        id: 'wc_' + require('crypto').randomBytes(4).toString('hex'),
        bug: cleanBug,
        prefix: cleanPrefix
    };
    domains.push(entry);
    saveWildcardDomains(domains);
    return entry;
}

function deleteWildcardDomain(id) {
    const domains = loadWildcardDomains();
    const idx = domains.findIndex(d => d.id === id);
    if (idx === -1) return false;
    domains.splice(idx, 1);
    saveWildcardDomains(domains);
    return true;
}

// Gabungkan prefix wildcard dengan host asli dari link.
// Prefix yang diakhiri "." langsung ditempel, kalau belum disisipkan titik pemisah.
function buildWildcardAddress(prefix, originalHost) {
    if (!prefix) return originalHost;
    return prefix.endsWith('.') ? `${prefix}${originalHost}` : `${prefix}.${originalHost}`;
}

// Deteksi tipe link Xray yang didukung untuk fitur Mode Wildcard.
function detectWildcardLinkType(link) {
    const raw = (link || '').trim();
    if (raw.startsWith('vmess://')) return 'vmess';
    if (raw.startsWith('vless://')) return 'vless';
    if (raw.startsWith('trojan://')) return 'trojan';
    return null;
}

// Terapkan entry wildcard (bug + prefix) ke link vmess/vless/trojan milik user.
// Return { newLink, type, originalHost, wildcardHost, bug }
function applyWildcardToLink(link, entry) {
    const type = detectWildcardLinkType(link);
    if (!type) {
        throw new Error('Link tidak dikenali. Hanya mendukung link vmess://, vless://, atau trojan://');
    }

    if (type === 'vmess') {
        const base64Data = link.trim().split('://')[1];
        let config;
        try {
            config = JSON.parse(Buffer.from(base64Data, 'base64').toString());
        } catch (e) {
            throw new Error('Format link VMess tidak valid (gagal decode base64).');
        }
        const originalHost = config.add || config.address || config.server;
        if (!originalHost) throw new Error('Address pada link VMess tidak ditemukan.');

        const wildcardHost = buildWildcardAddress(entry.prefix, originalHost);
        config.add = entry.bug;
        config.host = wildcardHost;
        config.sni = wildcardHost;

        const newBase64 = Buffer.from(JSON.stringify(config)).toString('base64');
        return { newLink: 'vmess://' + newBase64, type, originalHost, wildcardHost, bug: entry.bug };
    }

    // vless / trojan — sama-sama format URL standar
    let url;
    try {
        url = new URL(link.trim());
    } catch (e) {
        throw new Error(`Format link ${type.toUpperCase()} tidak valid.`);
    }
    const originalHost = url.hostname;
    const wildcardHost = buildWildcardAddress(entry.prefix, originalHost);

    url.hostname = entry.bug;
    url.searchParams.set('sni', wildcardHost);
    url.searchParams.set('host', wildcardHost);

    return { newLink: url.toString(), type, originalHost, wildcardHost, bug: entry.bug };
}

// ==================== BUG XRAY: DAFTAR BUG (TERPISAH DARI WILDCARD) ====================
// bug.json menyimpan daftar bug yang bisa dipilih user untuk mengganti address & SNI/Host
// pada link Xray (VMess/VLESS/Trojan) miliknya sendiri — BUKAN untuk create akun.
// Cara kerja SAMA seperti Mode Wildcard, tapi TIDAK ada konsep prefix yang ditempel di
// depan host asli. Yang diganti hanya address & SNI/Host, keduanya langsung diisi nilai
// bug (host asli dibuang sepenuhnya, tidak digabung seperti wildcard).
//   Contoh: bug "bug.com" -> address baru = "bug.com", SNI/Host baru = "bug.com"
//
// Struktur file: { "domains": [ { "id": "bug_ab12cd", "bug": "bug.xl.co.id" } ] }
function loadBugDomains() {
    const raw = _cacheGet('bug', BUG_FILE, { domains: [] });
    return (raw && Array.isArray(raw.domains)) ? raw.domains : [];
}

function saveBugDomains(domains) {
    _cacheSet('bug', BUG_FILE, { domains });
}

function getBugDomain(id) {
    return loadBugDomains().find(d => d.id === id) || null;
}

function addBugDomain(bug) {
    const domains = loadBugDomains();
    const cleanBug = (bug || '').trim();

    const entry = {
        id: 'bug_' + require('crypto').randomBytes(4).toString('hex'),
        bug: cleanBug
    };
    domains.push(entry);
    saveBugDomains(domains);
    return entry;
}

function deleteBugDomain(id) {
    const domains = loadBugDomains();
    const idx = domains.findIndex(d => d.id === id);
    if (idx === -1) return false;
    domains.splice(idx, 1);
    saveBugDomains(domains);
    return true;
}

// Deteksi tipe link Xray yang didukung untuk fitur Bug Xray (sama seperti wildcard).
function detectBugLinkType(link) {
    const raw = (link || '').trim();
    if (raw.startsWith('vmess://')) return 'vmess';
    if (raw.startsWith('vless://')) return 'vless';
    if (raw.startsWith('trojan://')) return 'trojan';
    return null;
}

// Terapkan entry bug ke link vmess/vless/trojan milik user.
// Beda dengan wildcard: TIDAK ada penggabungan prefix + host asli — bug langsung
// dipakai sebagai nilai baru. Beda dengan versi awal: address & SNI/Host TIDAK
// digabung jadi satu aksi lagi, user pilih salah satu mode:
//   mode 'address' -> HANYA address yang diganti, SNI/Host tetap host asli.
//   mode 'sni'     -> HANYA SNI/Host yang diganti, address tetap host asli.
// Return { newLink, type, originalHost, bug, mode }
function applyBugToLink(link, entry, mode) {
    const type = detectBugLinkType(link);
    if (!type) {
        throw new Error('Link tidak dikenali. Hanya mendukung link vmess://, vless://, atau trojan://');
    }
    if (mode !== 'address' && mode !== 'sni') {
        throw new Error('Mode ganti bug tidak valid.');
    }

    if (type === 'vmess') {
        const base64Data = link.trim().split('://')[1];
        let config;
        try {
            config = JSON.parse(Buffer.from(base64Data, 'base64').toString());
        } catch (e) {
            throw new Error('Format link VMess tidak valid (gagal decode base64).');
        }
        const originalHost = config.add || config.address || config.server;
        if (!originalHost) throw new Error('Address pada link VMess tidak ditemukan.');

        if (mode === 'address') {
            config.add = entry.bug;
        } else {
            config.host = entry.bug;
            config.sni = entry.bug;
        }

        const newBase64 = Buffer.from(JSON.stringify(config)).toString('base64');
        return { newLink: 'vmess://' + newBase64, type, originalHost, bug: entry.bug, mode };
    }

    // vless / trojan — sama-sama format URL standar
    let url;
    try {
        url = new URL(link.trim());
    } catch (e) {
        throw new Error(`Format link ${type.toUpperCase()} tidak valid.`);
    }
    const originalHost = url.hostname;

    if (mode === 'address') {
        url.hostname = entry.bug;
    } else {
        url.searchParams.set('sni', entry.bug);
        url.searchParams.set('host', entry.bug);
    }

    return { newLink: url.toString(), type, originalHost, bug: entry.bug, mode };
}

// Hitung total "Server Tersedia" untuk ditampilkan ke user: jumlah server asli
// (tipe ssh/xray, yang dipakai VPN Reguler), TANPA menghitung ganda server yang
// kebetulan juga punya Domain CDN (EDURC/Cloudfront) — itu server fisik yang sama.
function getServerTersediaCount() {
    // Dihitung berdasarkan nama server (name) unik, BUKAN dari host/apiUrl
    // atau field type.
    const names = new Set();
    Object.values(SERVERS).forEach(s => {
        const key = String(s?.name || '').trim().toLowerCase();
        if (key) names.add(key);
    });
    return names.size;
}

// Rincian jumlah server tersedia per jenis: Reguler, VPN EDURC, dan Cloudfront.
// Reguler  = jumlah semua server (SSH/Trojan/VLess/VMess) yang terdaftar.
// EDURC    = server tipe xray (Trojan/VLess/VMess) yang sudah punya Domain CDN.
// Cloudfront = server tipe ssh yang sudah punya Domain CDN.
function getServerTersediaBreakdown() {
    const servers = Object.values(SERVERS);
    const edurcDomains = loadEdurcDomains();
    const hasDomain = (s) => {
        const d = edurcDomains[s.id];
        return d && d.trim();
    };

    const reguler = servers.length;
    const edurc = servers.filter(s => s.type === 'xray' && hasDomain(s)).length;
    const cloudfront = servers.filter(s => s.type === 'ssh' && hasDomain(s)).length;

    return { reguler, edurc, cloudfront };
}

// Helper: ambil harga per hari untuk server tertentu (fallback ke global)
function getHargaServer(server) {
    if (server && server.hargaPerHari != null && server.hargaPerHari > 0) {
        return server.hargaPerHari;
    }
    return CONFIG.HARGA_PER_HARI_PER_IP;
}

// Hitung harga order dengan harga server spesifik
function hitungHargaServer(server, days, iplimit) {
    const hargaBase = getHargaServer(server) * days;
    const hargaTambahIp = iplimit > 1 ? (iplimit - 1) * getHargaTambahIpPerHari() * days : 0;
    return hargaBase + hargaTambahIp;
}

function getHargaEdurcTambahan() {
    return CONFIG.HARGA_EDURC_PER_HARI;
}

function hitungHargaEdurc(server, days, iplimit) {
    const hargaBase = server
        ? hitungHargaServer(server, days, iplimit)
        : hitungHarga(days, iplimit);
    return hargaBase + getHargaEdurcTambahan() * days;
}

function formatHargaEdurcLabel(server, userId) {
    const hargaNormal = getHargaServer(server) + getHargaEdurcTambahan();
    const customMark = server && server.hargaPerHari != null ? ' ' : '';
    if (isReseller(userId)) {
        const hargaReseller = hitungHargaReseller(hargaNormal);
        return `~~${formatRp(hargaNormal)}~~ → ${formatRp(hargaReseller)}/hari/IP${customMark} <b>· Reseller</b>`;
    }
    return `${formatRp(hargaNormal)}/hari/IP${customMark}`;
}

function buildHargaEdurcLines(userId) {
    return buildHargaLayananLines(userId, 'hari', ['zivpn'], {
        extraPerHari: getHargaEdurcTambahan(),
        includeTypes: ['xray'],
        accountTypeLabel: 'VPN EDURC',
    });
}

function buildHargaCloudfrontLines(userId) {
    return buildHargaLayananLines(userId, 'hari', [], {
        extraPerHari: getHargaEdurcTambahan(),
        includeTypes: ['ssh'],
        accountTypeLabel: 'Cloudfront',
    });
}

function isCloudfrontMode(isEdurc, serviceType) {
    return isEdurc && serviceType === 'ssh';
}

function getTipeAkunLabel(serviceType, isEdurc) {
    if (isCloudfrontMode(isEdurc, serviceType)) return '☁️ Cloudfront';
    return isEdurc ? '🌐 EDURC' : '📡 Reguler';
}

function formatServiceBold(serviceType) {
    const map = {
        ssh: '𝙎𝙎𝙃',
        trojan: '𝙏𝙍𝙊𝙅𝘼𝙉',
        vless: '𝙑𝙇𝙀𝙎𝙎',
        vmess: '𝙑𝙈𝙀𝙎𝙎',
        zivpn: '𝙕𝙄𝙑𝙋𝙉',
    };
    return map[serviceType] || serviceType.toUpperCase();
}

function getCreateModeHeader(isEdurc, serviceType) {
    if (!isEdurc) return `𝘾𝙍𝙀𝘼𝙏𝙀 ${formatServiceBold(serviceType)}`;
    if (isCloudfrontMode(isEdurc, serviceType)) return '☁️ 𝘾𝙍𝙀𝘼𝙏𝙀 𝙎𝙎𝙃 𝘾𝙇𝙊𝙐𝘿𝙁𝙍𝙊𝙉𝙏';
    return `🌐 𝘾𝙍𝙀𝘼𝙏𝙀 𝙀𝘿𝙐𝙍𝘾 ${formatServiceBold(serviceType)}`;
}

function getConfirmModeHeader(isEdurc, serviceType) {
    return '𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙋𝙀𝙈𝘽𝘼𝙔𝘼𝙍𝘼𝙉';
}

function getTrialModeHeader(isEdurc, serviceType) {
    if (!isEdurc) return `𝙏𝙍𝙄𝘼𝙇 ${formatServiceBold(serviceType)}`;
    if (isCloudfrontMode(isEdurc, serviceType)) return '☁️ 𝙏𝙍𝙄𝘼𝙇 𝙎𝙎𝙃 𝘾𝙇𝙊𝙐𝘿𝙁𝙍𝙊𝙉𝙏';
    return `🌐 𝙏𝙍𝙄𝘼𝙇 𝙀𝘿𝙐𝙍𝘾 ${formatServiceBold(serviceType)}`;
}

function getCdnNote(isEdurc, serviceType) {
    if (!isEdurc) return '';
    if (isCloudfrontMode(isEdurc, serviceType)) {
        return '';
    }
    return '';
}

function formatHargaCreateLabel(server, userId, isEdurc = false) {
    return isEdurc ? formatHargaEdurcLabel(server, userId) : formatHargaServerLabel(server, userId);
}

function generateServerId() {
    let num = 1;
    while (Object.keys(SERVERS).includes(`server${num}`)) num++;
    return `server${num}`;
}

SERVERS = loadServers();

// ==================== USER STATS ====================
function getUserStats() {
    const saldo = loadSaldo();
    const transaksi = loadTransaksi();
    const akun = loadAkun();
    const users = loadUsers();
    
    // Gabungkan semua sumber user agar tidak ada yang terlewat
    const allUserIds = new Set([
        ...Object.keys(users),
        ...Object.keys(saldo),
        ...Object.keys(akun),
    ]);
    
    const jumlahUser = allUserIds.size;
    const totalSaldo = Object.values(saldo).reduce((a, b) => a + b, 0);
    const totalAkun = getAllAkunCount();
    const totalTransaksi = transaksi.length;
    
    const today = new Date().toDateString();
    const txHariIni = transaksi.filter(t => new Date(t.waktu).toDateString() === today);
    const totalTxHariIni = txHariIni.reduce((a, t) => a + (t.amount || 0), 0);
    
    return { jumlahUser, totalSaldo, totalAkun, totalTransaksi, txHariIni: txHariIni.length, totalTxHariIni };
}

// ==================== QRIS ====================
async function generateQRISDinamis(amount) {
    if (!QRIS_STATIS) throw new Error('QRIS_STATIS belum dikonfigurasi di .env');
    const url = `${QRIS_API_URL}?qris=${encodeURIComponent(QRIS_STATIS)}&nominal=${amount}`;
    const res = await axios.get(url, { timeout: 15000 });
    const qrString = res.data.QR || res.data.qr || res.data.qris;
    if (!qrString) throw new Error('API QRIS tidak mengembalikan data');
    return qrString;
}

// ==================== PAKASIR PAYMENT ====================
/**
 * Buat transaksi QRIS via Pakasir API.
 * POST https://app.pakasir.com/api/transactioncreate/qris
 * Body: { project, order_id, amount, api_key }
 * Response: { payment: { payment_number (QR string), expired_at, ... } }
 */
async function createPakasirTransaction(amount, orderId) {
    if (!PAKASIR_SLUG || !PAKASIR_API_KEY) {
        throw new Error('Konfigurasi Pakasir (Slug / API Key) belum lengkap di dashboard admin.');
    }
    const payload = {
        project:  PAKASIR_SLUG,
        order_id: orderId,
        amount:   amount,
        api_key:  PAKASIR_API_KEY,
    };
    const res = await axios.post(
        'https://app.pakasir.com/api/transactioncreate/qris',
        payload,
        { timeout: 15000 }
    );
    const payment = res.data?.payment;
    if (!payment || !payment.payment_number) {
        throw new Error(res.data?.message || 'Pakasir tidak mengembalikan QR string');
    }
    return payment; // { project, order_id, amount, fee, total_payment, payment_number, expired_at }
}

async function cekStatusPakasir(orderId, amount) {
    if (!PAKASIR_SLUG || !PAKASIR_API_KEY) return null;
    const url = `https://app.pakasir.com/api/transactiondetail` +
        `?project=${encodeURIComponent(PAKASIR_SLUG)}` +
        `&amount=${amount}` +
        `&order_id=${encodeURIComponent(orderId)}` +
        `&api_key=${encodeURIComponent(PAKASIR_API_KEY)}`;
    const res = await axios.get(url, { timeout: 15000 });
    return res.data?.transaction || null;
}

// ==================== SIMPAN QRIS STRING ====================
async function simpanQrisStatis(ctx, qrisString) {
    const userId = ctx.from.id.toString();
    try {
        QRIS_STATIS = qrisString;
        updateEnvValue('QRIS_STATIS', qrisString);

        const preview = qrisString.substring(0, 50) + (qrisString.length > 50 ? '...' : '');
        await sendResultMessage(ctx,
            ` <b>QRIS Statis berhasil diupdate!</b>\n\n` +
            ` <b>Preview:</b>\n<code>${preview}</code>\n\n` +
            ` Panjang string: ${qrisString.length} karakter\n` +
            ` Perubahan langsung berlaku tanpa restart.`
        );
        console.log(` QRIS_STATIS updated (${qrisString.length} chars)`);
    } catch (err) {
        await sendTempMessage(ctx, ` Gagal menyimpan QRIS: ${err.message}`);
    }
    userStates.delete(userId);
    await showAdminEditData(ctx);
}

// Ganti fungsi generateQRCodeWithCenterIcon dengan yang ini
async function generateQRCodeWithCenterIcon(qrString, iconPath) {
    try {
        // Generate QR code buffer
        const qrBuffer = await QRCode.toBuffer(qrString, {
            type: 'png',
            width: 500,
            margin: 2,
            color: { dark: '#000000', light: '#FFFFFF' }
        });
        
        // Jika tidak ada icon atau icon tidak bisa diload, return QR polos
        if (!iconPath || !fs.existsSync(iconPath)) {
            console.log(' Icon not found, sending plain QR code');
            return qrBuffer;
        }
        
        try {
            // Load QR image dan icon
            const qrImage = await loadImage(qrBuffer);
            const iconImage = await loadImage(iconPath);
            
            const qrSize = qrImage.width;
            const iconSize = Math.floor(qrSize * 0.2);
            const canvas = createCanvas(qrSize, qrSize);
            const ctx = canvas.getContext('2d');
            
            // Gambar QR code
            ctx.drawImage(qrImage, 0, 0, qrSize, qrSize);
            
            // Gambar icon di tengah dengan background putih
            const x = (qrSize - iconSize) / 2;
            const y = (qrSize - iconSize) / 2;
            
            // Background putih untuk icon
            ctx.beginPath();
            ctx.arc(qrSize / 2, qrSize / 2, iconSize / 2 + 5, 0, 2 * Math.PI);
            ctx.fillStyle = '#FFFFFF';
            ctx.fill();
            
            // Gambar icon
            ctx.drawImage(iconImage, x, y, iconSize, iconSize);
            
            return canvas.toBuffer('image/png');
        } catch (iconErr) {
            console.log(' Failed to add icon:', iconErr.message);
            return qrBuffer;
        }
    } catch (err) {
        console.error(' Failed to generate QR code:', err.message);
        throw err;
    }
}

// ==================== FORMAT MESSAGES ====================
// ==================== EDURC: RESOLVE DOMAIN UNTUK RESULT LINK ====================
// Jika akun dibuat/trial via menu "VPN EDURC" (data.isEdurc = true) DAN server tersebut
// memiliki domain CDN tersimpan di edurc.json, maka domain yang dipakai pada result
// message (address/host/sni untuk xray, atau domain untuk SSH) diganti dengan domain CDN.
// API call ke server tetap memakai domain/apiUrl asli — hanya tampilan link yang berubah.
function resolveEdurcDomain(data, fallbackDomain) {
    if (data && data.isEdurc && data.serverId) {
        const cdnDomain = getEdurcDomain(data.serverId);
        if (cdnDomain) return cdnDomain;
    }
    return fallbackDomain;
}

function formatCreateMessage(service, data, serverName) {
    const domain = resolveEdurcDomain(data, data.domain || serverName);
    const timestamp = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    const tipeLabel = getTipeAkunLabel(service, data.isEdurc);
    
    if (service === 'ssh') {
        const payloadWS = "GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]";
        const payloadTLS = `GET wss://${domain}/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`;
        
        return `${getHeader('✅ 𝙎𝙎𝙃 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝘾𝙍𝙀𝘼𝙏𝙀𝘿')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>Username:</b> <code>${data.username}</code>
🔑 <b>Password:</b> <code>${data.password}</code>
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🔌 <b>SSH WebSocket:</b>
<blockquote><code>${domain}:80@${data.username}:${data.password}</code></blockquote>

🔐 <b>SSH SSL:</b>
<blockquote><code>${domain}:443@${data.username}:${data.password}</code></blockquote>

📦 <b>Payload WS:</b>
<pre><code>${payloadWS}</code></pre>

📦 <b>Payload TLS:</b>
<pre><code>${payloadTLS}</code></pre>

🕐 <b>Waktu:</b> ${timestamp}
✅ <b>Status:</b> Berhasil dibuat`;
    }
    else if (service === 'trojan') {
        const trojanTLS = `trojan://${data.password}@${domain}:443?security=tls&type=ws&path=/trojan&host=${domain}&sni=${domain}#${data.username}`;
        const trojanHTTP = `trojan://${data.password}@${domain}:80?security=none&type=ws&path=/trojan&host=${domain}#${data.username}`;
        const trojanGRPC = `trojan://${data.password}@${domain}:443?security=tls&type=grpc&serviceName=trojan-grpc&host=${domain}&sni=${domain}#${data.username}`;
        
        return `${getHeader('✅ 𝙏𝙍𝙊𝙅𝘼𝙉 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝘾𝙍𝙀𝘼𝙏𝙀𝘿')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>Username:</b> <code>${data.username}</code>
🔑 <b>Password:</b> <code>${data.password}</code>
📊 <b>Quota:</b> ${data.quota || 0} GB
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🔐 <b>TLS (443):</b>
<pre><code>${trojanTLS}</code></pre>

🌐 <b>HTTP (80):</b>
<pre><code>${trojanHTTP}</code></pre>

⚡ <b>gRPC:</b>
<pre><code>${trojanGRPC}</code></pre>

🕐 <b>Waktu:</b> ${timestamp}
✅ <b>Status:</b> Berhasil dibuat`;
    }
    else if (service === 'vless') {
        const vlessTLS = `vless://${data.uuid || data.password}@${domain}:443?encryption=none&security=tls&type=ws&host=${domain}&path=/vless&sni=${domain}#${data.username}`;
        const vlessHTTP = `vless://${data.uuid || data.password}@${domain}:80?encryption=none&security=none&type=ws&host=${domain}&path=/vless#${data.username}`;
        const vlessGRPC = `vless://${data.uuid || data.password}@${domain}:443?encryption=none&security=tls&type=grpc&serviceName=vless-grpc&sni=${domain}#${data.username}`;
        
        return `${getHeader('✅ 𝙑𝙇𝙀𝙎𝙎 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝘾𝙍𝙀𝘼𝙏𝙀𝘿')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>Username:</b> <code>${data.username}</code>
🔑 <b>UUID:</b> <code>${data.uuid || data.password}</code>
📊 <b>Quota:</b> ${data.quota || 0} GB
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🔐 <b>TLS (443):</b>
<pre><code>${vlessTLS}</code></pre>

🌐 <b>HTTP (80):</b>
<pre><code>${vlessHTTP}</code></pre>

⚡ <b>gRPC:</b>
<pre><code>${vlessGRPC}</code></pre>

🕐 <b>Waktu:</b> ${timestamp}
✅ <b>Status:</b> Berhasil dibuat`;
    }
    else if (service === 'vmess') {
        const vmessTLS = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "443",
            id: data.uuid || data.password, aid: "0", net: "ws", path: "/vmess",
            host: domain, tls: "tls"
        })).toString('base64')}`;
        
        const vmessHTTP = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "80",
            id: data.uuid || data.password, aid: "0", net: "ws", path: "/vmess",
            host: domain, tls: "none"
        })).toString('base64')}`;
        
        const vmessGRPC = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "443",
            id: data.uuid || data.password, aid: "0", net: "grpc", path: "vmess-grpc",
            host: domain, tls: "tls"
        })).toString('base64')}`;
        
        return `${getHeader('✅ 𝙑𝙈𝙀𝙎𝙎 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝘾𝙍𝙀𝘼𝙏𝙀𝘿')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>Username:</b> <code>${data.username}</code>
🔑 <b>UUID:</b> <code>${data.uuid || data.password}</code>
📊 <b>Quota:</b> ${data.quota || 0} GB
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🔐 <b>TLS (443):</b>
<pre><code>${vmessTLS}</code></pre>

🌐 <b>HTTP (80):</b>
<pre><code>${vmessHTTP}</code></pre>

⚡ <b>gRPC:</b>
<pre><code>${vmessGRPC}</code></pre>

🕐 <b>Waktu:</b> ${timestamp}
✅ <b>Status:</b> Berhasil dibuat`;
    }
    else if (service === 'zivpn') {
        return `${getHeader('✅ 𝙕𝙄𝙑𝙋𝙉 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝘾𝙍𝙀𝘼𝙏𝙀𝘿')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
🔑 <b>Password:</b> <code>${data.password}</code>
📅 <b>Expired:</b> ${data.expired}
🖥 <b>IP Limit:</b> ${data.iplimit}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🕐 <b>Waktu:</b> ${timestamp}
✅ <b>Status:</b> Berhasil dibuat`;
    }
    return '';
}

function formatTrialMessage(service, data, serverName) {
    const domain = resolveEdurcDomain(data, data.domain || serverName);
    const timestamp = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    const tipeLabel = getTipeAkunLabel(service, data.isEdurc);
    
    if (service === 'ssh') {
        const payloadWS = "GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]";
        const payloadTLS = `GET wss://${domain}/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`;
        
        return `${getHeader('🧪 𝙏𝙍𝙄𝘼𝙇 𝙎𝙎𝙃 𝘼𝘾𝘾𝙊𝙐𝙉𝙏')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>Username:</b> <code>${data.username}</code>
🔑 <b>Password:</b> <code>${data.password}</code>
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🔌 <b>SSH WebSocket:</b>
<blockquote><code>${domain}:80@${data.username}:${data.password}</code></blockquote>

🔐 <b>SSH SSL:</b>
<blockquote><code>${domain}:443@${data.username}:${data.password}</code></blockquote>

📦 <b>Payload WS:</b>
<pre><code>${payloadWS}</code></pre>

📦 <b>Payload TLS:</b>
<pre><code>${payloadTLS}</code></pre>

🕐 <b>Waktu:</b> ${timestamp}
⏳ <b>Status:</b> Trial aktif ${data.duration_minutes} menit`;
    }
    else if (service === 'trojan') {
        const trojanTLS = `trojan://${data.password}@${domain}:443?security=tls&type=ws&path=/trojan&host=${domain}&sni=${domain}#${data.username}`;
        const trojanHTTP = `trojan://${data.password}@${domain}:80?security=none&type=ws&path=/trojan&host=${domain}#${data.username}`;
        const trojanGRPC = `trojan://${data.password}@${domain}:443?security=tls&type=grpc&serviceName=trojan-grpc&host=${domain}&sni=${domain}#${data.username}`;
        
        return `${getHeader('🧪 𝙏𝙍𝙄𝘼𝙇 𝙏𝙍𝙊𝙅𝘼𝙉 𝘼𝘾𝘾𝙊𝙐𝙉𝙏')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>Username:</b> <code>${data.username}</code>
🔑 <b>Password:</b> <code>${data.password}</code>
📊 <b>Quota:</b> 1 GB
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🔐 <b>TLS (443):</b>
<pre><code>${trojanTLS}</code></pre>

🌐 <b>HTTP (80):</b>
<pre><code>${trojanHTTP}</code></pre>

⚡ <b>gRPC:</b>
<pre><code>${trojanGRPC}</code></pre>

🕐 <b>Waktu:</b> ${timestamp}
⏳ <b>Status:</b> Trial aktif ${data.duration_minutes} menit`;
    }
    else if (service === 'vless') {
        const vlessTLS = `vless://${data.uuid || data.password}@${domain}:443?encryption=none&security=tls&type=ws&host=${domain}&path=/vless&sni=${domain}#${data.username}`;
        const vlessHTTP = `vless://${data.uuid || data.password}@${domain}:80?encryption=none&security=none&type=ws&host=${domain}&path=/vless#${data.username}`;
        const vlessGRPC = `vless://${data.uuid || data.password}@${domain}:443?encryption=none&security=tls&type=grpc&serviceName=vless-grpc&sni=${domain}#${data.username}`;
        
        return `${getHeader('🧪 𝙏𝙍𝙄𝘼𝙇 𝙑𝙇𝙀𝙎𝙎 𝘼𝘾𝘾𝙊𝙐𝙉𝙏')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>Username:</b> <code>${data.username}</code>
🔑 <b>UUID:</b> <code>${data.uuid || data.password}</code>
📊 <b>Quota:</b> 1 GB
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🔐 <b>TLS (443):</b>
<pre><code>${vlessTLS}</code></pre>

🌐 <b>HTTP (80):</b>
<pre><code>${vlessHTTP}</code></pre>

⚡ <b>gRPC:</b>
<pre><code>${vlessGRPC}</code></pre>

🕐 <b>Waktu:</b> ${timestamp}
⏳ <b>Status:</b> Trial aktif ${data.duration_minutes} menit`;
    }
    else if (service === 'vmess') {
        const vmessTLS = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "443",
            id: data.uuid || data.password, aid: "0", net: "ws", path: "/vmess",
            host: domain, tls: "tls"
        })).toString('base64')}`;
        
        const vmessHTTP = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "80",
            id: data.uuid || data.password, aid: "0", net: "ws", path: "/vmess",
            host: domain, tls: "none"
        })).toString('base64')}`;
        
        const vmessGRPC = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "443",
            id: data.uuid || data.password, aid: "0", net: "grpc", path: "vmess-grpc",
            host: domain, tls: "tls"
        })).toString('base64')}`;
        
        return `${getHeader('🧪 𝙏𝙍𝙄𝘼𝙇 𝙑𝙈𝙀𝙎𝙎 𝘼𝘾𝘾𝙊𝙐𝙉𝙏')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>Username:</b> <code>${data.username}</code>
🔑 <b>UUID:</b> <code>${data.uuid || data.password}</code>
📊 <b>Quota:</b> 1 GB
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🔐 <b>TLS (443):</b>
<pre><code>${vmessTLS}</code></pre>

🌐 <b>HTTP (80):</b>
<pre><code>${vmessHTTP}</code></pre>

⚡ <b>gRPC:</b>
<pre><code>${vmessGRPC}</code></pre>

🕐 <b>Waktu:</b> ${timestamp}
⏳ <b>Status:</b> Trial aktif ${data.duration_minutes} menit`;
    }
    else if (service === 'zivpn') {
        return `${getHeader('🧪 𝙏𝙍𝙄𝘼𝙇 𝙕𝙄𝙑𝙋𝙉 𝘼𝘾𝘾𝙊𝙐𝙉𝙏')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
🔑 <b>Password:</b> <code>${data.password}</code>
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired:</b> ${data.expired}
🌐 <b>Domain:</b> <code>${domain}</code></blockquote>

🕐 <b>Waktu:</b> ${timestamp}
⏳ <b>Status:</b> Trial aktif ${data.duration_minutes} menit`;
    }
    return '';
}

function formatRenewMessage(service, data) {
    const timestamp = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    const tipeLabel = getTipeAkunLabel(service, data.isEdurc);
    
    return `${getHeader('🔁 ' + formatServiceBold(service) + ' 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝙍𝙀𝙉𝙀𝙒𝙀𝘿')}

<blockquote>🏷 <b>Tipe:</b> ${tipeLabel}
👤 <b>${service === 'zivpn' ? 'Password' : 'Username'}:</b> <code>${data.target}</code>
🖥 <b>IP Limit:</b> ${data.iplimit}
📅 <b>Expired Lama:</b> ${data.old_expired || '-'}
📅 <b>Expired Baru:</b> ${data.new_expired || '-'}
➕ <b>Durasi Tambahan:</b> ${data.days_added} hari</blockquote>

🕐 <b>Waktu:</b> ${timestamp}
✅ <b>Status:</b> Berhasil diperpanjang`;
}

// ==================== API CALLS ====================
async function callApi(server, endpoint, payload = null, method = 'POST') {
    try {
        const url = `${server.apiUrl}${endpoint}`;
        const headers = { 'x-api-key': server.authKey, 'Content-Type': 'application/json' };
        let response;
        if (method === 'POST') response = await axios.post(url, payload, { headers, timeout: 30000 });
        else response = await axios.get(url, { headers, timeout: 30000 });
        return response.data;
    } catch(error) {
        if (error.response) return { success: false, message: error.response.data?.message || `HTTP ${error.response.status}` };
        return { success: false, message: error.message };
    }
}

function getModule(serviceType) {
    const map = { ssh: sshModule, trojan: trojanModule, vless: vlessModule, vmess: vmessModule, zivpn: zivpnModule };
    return map[serviceType] || sshModule;
}

// ==================== GET SERVER LIST ====================
async function getServerList(serviceType) {
    if (serviceType === 'zivpn') {
        return Object.values(SERVERS).filter(s => s.type === 'zivpn');
    }
    if (serviceType === 'ssh') {
        // SSH hanya di server tipe 'ssh' (bukan xray/zivpn)
        return Object.values(SERVERS).filter(s => s.type === 'ssh');
    }
    // trojan, vless, vmess → server tipe 'xray'
    return Object.values(SERVERS).filter(s => s.type === 'xray');
}

function getServerKeyboard(servers, action) {
    const buttons = [];
    // Susun 2 tombol server per baris (bukan 1 tombol per baris),
    // supaya daftar server lebih ringkas dan tidak kepanjangan ke bawah.
    for (let i = 0; i < servers.length; i += 2) {
        const row = [{ text: servers[i].name, callback_data: `${action}_${servers[i].id}` }];
        if (servers[i + 1]) {
            row.push({ text: servers[i + 1].name, callback_data: `${action}_${servers[i + 1].id}` });
        }
        buttons.push(row);
    }
    buttons.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'main_menu', style: 'danger' }]);
    return Markup.inlineKeyboard(buttons);
}

// ==================== MAIN MENU ====================
// Pesan awal saat /start: deskripsi singkat store + gambar banner + tombol Menu Utama.
// Menu utama sendiri (showMainMenu) TIDAK lagi pakai banner, biar lebih ringan tiap navigasi.
async function showWelcomeStart(ctx) {
    markWelcomeSeen(ctx.from.id);
    const firstName = ctx.from.first_name || 'User';
    const text = `${getHeader('𝙋𝙓 𝙎𝙏𝙊𝙍𝙀')}
<blockquote>👋 <b>Halo, ${firstName}!</b>

🛡 <b>PX Store</b> adalah layanan VPN & proxy premium terpercaya — SSH, Trojan, VLess, VMess, hingga Sewa SC Tunneling, semua bisa dibuat otomatis lewat bot ini.

⚡ <b>Kenapa PX Store?</b>
· Proses serba otomatis & cepat
· Harga bersaing, ada program Reseller
· Dukungan berbagai tipe server & protokol

🔰 <b>Owner:</b> <i>@PeyxDev</i></blockquote>

Tekan tombol di bawah untuk mulai:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🏠 𝙈𝙚𝙣𝙪 𝙐𝙩𝙖𝙢𝙖', callback_data: 'main_menu', style: 'primary' }]
    ]);

    await sendMainMenuWithHeader(ctx, text, keyboard);
}

async function showMainMenu(ctx, forceNew = false) {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const jumlahAkun = getJumlahAkun(userId);
    const greeting = getGreeting();
    const firstName = ctx.from.first_name || 'User';
    const serverCount = Object.keys(SERVERS).length;
    
    // Hitung total transaksi USER INI SAJA (bukan global)
    const transaksiData = loadTransaksi();
    let totalTransaksiUser = 0;
    let totalNominalTransaksi = 0;
    let lastTransaction = null;
    let firstTransactionDate = null;

    // Statistik bot GLOBAL (semua user) — pakai counter permanen di stats.json,
    // BUKAN transaksiData.length, karena transaksi.json sengaja dipangkas ke 1000 record terbaru.
    const totalTransaksiBot = getTotalTransaksiBot();
    const txHariIniBot = getTxHariIniBot();
    
    for (const tx of transaksiData) {
        // Filter hanya untuk user yang sedang login
        if (tx.userId && tx.userId.toString() === userId) {
            totalTransaksiUser++;
            totalNominalTransaksi += tx.amount || 0;
            
            if (tx.waktu) {
                const txDate = new Date(tx.waktu);
                if (!lastTransaction || txDate > new Date(lastTransaction)) {
                    lastTransaction = tx.waktu;
                }
                if (!firstTransactionDate || txDate < new Date(firstTransactionDate)) {
                    firstTransactionDate = tx.waktu;
                }
            }
        }
    }
    
    // Hitung total create (pengeluaran) dari akun milik USER INI
    const akunData = loadAkun();
    let totalAkunDibuat = 0;
    let akunAktif = 0;
    let totalIPDigunakan = 0;
    let totalPengeluaranCreate = 0;
    
    if (akunData[userId]) {
        totalAkunDibuat = akunData[userId].length;
        for (const akun of akunData[userId]) {
            totalIPDigunakan += akun.iplimit || 0;
            
            // Hitung estimasi biaya per akun (harga * hari * IP)
            if (akun.days && akun.iplimit) {
                totalPengeluaranCreate += CONFIG.HARGA_PER_HARI_PER_IP * akun.days * akun.iplimit;
            }
            
            if (akun.expired) {
                try {
                    const expiredDate = new Date(akun.expired);
                    if (expiredDate > new Date()) {
                        akunAktif++;
                    }
                } catch(e) {}
            } else {
                akunAktif++;
            }
        }
    }
    
    // Cek sisa trial USER INI hari ini
    const trialData = loadTrialData();
    const trialHariIni = (trialData[userId] || []).filter(t => {
        try {
            return new Date(t).toDateString() === new Date().toDateString();
        } catch(e) { return false; }
    }).length;
    const sisaTrial = Math.max(0, CONFIG.MAX_TRIAL_PER_USER - trialHariIni);
    
    // Format terakhir transaksi
    let lastTxText = 'Belum pernah';
    if (lastTransaction) {
        try {
            const lastDate = new Date(lastTransaction);
            lastTxText = lastDate.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
        } catch(e) {}
    }
    
    // Format pertama kali transaksi
    let firstTxText = 'Belum pernah';
    if (firstTransactionDate) {
        try {
            const firstDate = new Date(firstTransactionDate);
            firstTxText = firstDate.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
        } catch(e) {}
    }
    
    // Hitung rata-rata pengeluaran per hari (berdasarkan data USER INI)
    let avgSpending = 0;
    let memberSince = '-';
    if (totalTransaksiUser > 0 && firstTransactionDate) {
        try {
            const daysDiff = Math.max(1, Math.ceil((new Date() - new Date(firstTransactionDate)) / (1000 * 60 * 60 * 24)));
            avgSpending = totalNominalTransaksi / daysDiff;
            memberSince = `${daysDiff} hari lalu`;
        } catch(e) {}
    }
    
    // Info reseller (jika aktif)
    const labelStatus = getLabelStatus(userId);
    const resellerInfo = formatInfoReseller(userId);
    const resellerLine = resellerInfo
        ? `<b> · Status:</b> ${labelStatus}\n<b> · Diskon:</b> 🎁 ${resellerInfo.diskonPersen}% (Reseller)\n<b> · Transaksi Bulan Ini:</b> 📦 ${resellerInfo.jumlahTransaksiPeriode}/${resellerInfo.minimalTransaksiPeriode} akun\n<b> · Sisa Periode:</b> ⏳ ${resellerInfo.sisaHariSebelumExpire} hari lagi`
        : `<b> · Status:</b> ${labelStatus}`;

    const text = `${getHeader('𝙈𝙀𝙉𝙐 𝙐𝙏𝘼𝙈𝘼')}
<blockquote>👤 <b>${greeting}, ${firstName}!</b>
🆔 <b>User ID:</b> <code>${userId}</code>
🏷 <b>Role:</b> ${labelStatus}

📊 <b>— STATISTIK ANDA —</b>
💰 <b>Saldo:</b> ${formatRp(saldo)}
📦 <b>Akun Dibuat:</b> ${totalAkunDibuat}
🔄 <b>Total Transaksi:</b> ${totalTransaksiUser}
💳 <b>Total Topup:</b> ${formatRp(totalNominalTransaksi)}
🕐 <b>Transaksi Terakhir:</b> ${lastTxText}

🤖 <b>— STATISTIK BOT —</b>
📅 <b>Tx Hari Ini:</b> ${txHariIniBot}
🧾 <b>Total Transaksi:</b> ${totalTransaksiBot}

⏱ <b>Runtime Bot:</b> ${formatRuntime()}</blockquote>${getTopupBonusListText()}
<blockquote>🔰 <b>Owner:</b> <i>@PeyxDev</i></blockquote>`;

    const resellerBtn = isReseller(userId)
        ? { text: '⭐ 𝙎𝙩𝙖𝙩𝙪𝙨 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧', callback_data: 'reseller_info' }
        : { text: '🤝 𝘿𝙖𝙛𝙩𝙖𝙧 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧', callback_data: 'join_reseller' };

    const keyboard = Markup.inlineKeyboard([
    [{ text: '🛡 𝙋𝙖𝙣𝙚𝙡 𝙑𝙋𝙉', callback_data: 'panel_vpn' }],
    ...(isSewaScAktif()
        ? [[{ text: '📜 𝙎𝙚𝙬𝙖 𝙎𝘾', callback_data: 'sewa_sc_menu' }, { text: '🔧 𝙏𝙤𝙤𝙡𝙨', url: 'https://t.me/izinip_bot' }]]
        : [[{ text: '🔧 𝙏𝙤𝙤𝙡𝙨', url: 'https://t.me/izinip_bot' }]]),
    [{ text: '💳 𝙏𝙤𝙥 𝙐𝙥', callback_data: 'topup' }, { text: '📋 𝙍𝙞𝙬𝙖𝙮𝙖𝙩', callback_data: 'my_transaksi' }],
    [resellerBtn],
]);

keyboard.reply_markup.inline_keyboard.push([{ text: '🔄 𝙍𝙚𝙛𝙧𝙚𝙨𝙝 𝘽𝙤𝙩', callback_data: 'refresh_bot' }]);

if (isAdmin(ctx.from.id)) {
    keyboard.reply_markup.inline_keyboard.push([{ text: '⚙️ 𝘼𝙙𝙢𝙞𝙣 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard' }]);
}

await sendMenu(ctx, text, keyboard, forceNew);
}


// ==================== SEWA SC TUNNELING ====================

async function showSewaScMenu(ctx) {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const sewaMilik = getSewaByUser(userId);
    const aktif = sewaMilik.filter(s => new Date(s.masaAktif) >= new Date());
    const paketList = getPaketList();

    let hargaLines = '';
    paketList.forEach(p => {
        const harga = hitungHargaSC(1, p.jumlahHari);
        hargaLines += `<b>  📦 ${p.label}  → ${formatRp(harga)}</b>\n`;
    });

    const text = `${getHeader('𝙎𝙀𝙒𝘼 𝙎𝘾 𝙏𝙐𝙉𝙉𝙀𝙇𝙄𝙉𝙂')}
<blockquote>🔒 <b>Layanan izin IP untuk SC Tunneling</b>

💰 <b>Paket Harga (1 IP):</b>
${hargaLines.trimEnd()}
➕ <b>Tambah IP:</b> ${formatRp(getHargaSCExtraIp())} per IP
♾️ <b>Paket Lifetime:</b> bebas ganti IP & Nama

📡 <b>IP Aktif Anda:</b> ${aktif.length} IP

📝 <b>Catatan:</b> Fasilitas ganti IP hanya berlaku untuk paket Lifetime. Untuk paket selain Lifetime, IP yang telah didaftarkan bersifat tetap selama masa aktif berlangsung.</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [
            { text: '🆕 𝘿𝙖𝙛𝙩𝙖𝙧𝙠𝙖𝙣 𝙄𝙋', callback_data: 'sewa_sc_pilih_paket' },
            { text: '🔁 𝙋𝙚𝙧𝙥𝙖𝙣𝙟𝙖𝙣𝙜', callback_data: 'sewa_sc_perpanjang' },
        ],
        [{ text: '📋 𝙄𝙋 𝘼𝙠𝙩𝙞𝙛 𝙎𝙖𝙮𝙖', callback_data: 'sewa_sc_list' }],
        [{ text: '🖼 𝙋𝙧𝙚𝙫𝙞𝙚𝙬 𝙎𝘾', callback_data: 'sewa_sc_preview' }],
        ...(isSewaBotAktif()
            ? [[{ text: '🤖 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩 𝙎𝙚𝙡𝙡𝙚𝙧', callback_data: 'sewa_bot_menu' }]]
            : []),
        [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙚𝙣𝙪', callback_data: 'main_menu', style: 'danger' }],
    ]);

    await sendMenu(ctx, text, keyboard);
}

// Preview SC — tampil gambar preview saat user klik "Preview SC"
async function showSewaScPreview(ctx) {
    const previewPaths = [
        path.join(__dirname, 'assets', 'preview-sc1.png'),
        path.join(__dirname, 'assets', 'preview-sc2.png'),
    ];

    const existingPreviews = previewPaths.filter(p => fs.existsSync(p));

    if (existingPreviews.length === 0) {
        try { await ctx.answerCbQuery('Gambar preview belum tersedia.', { show_alert: true }); } catch(e) {}
        return;
    }

    try { await ctx.answerCbQuery(); } catch(e) {}

    // Inisialisasi preview tracker di messageHistory
    const userId = ctx.from.id.toString();
    if (!messageHistory.has(userId)) {
        messageHistory.set(userId, { menu: null, temp: [], results: [] });
    }
    messageHistory.get(userId).preview = [];

    const caption = `${getHeader(' 𝙋𝙍𝙀𝙑𝙄𝙀𝙒 𝙎𝘾 𝙋𝙀𝙔𝙓 𝙏𝙐𝙉𝙉𝙀𝙇𝙄𝙉𝙂')}\n<blockquote><b>Tampilan panel SC Tunneling yang akan Anda dapatkan setelah install.</b></blockquote>`;

    const backKeyboard = Markup.inlineKeyboard([
        [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙚𝙣𝙪 𝙎𝙚𝙬𝙖 𝙎𝘾', callback_data: 'sewa_sc_menu', style: 'danger' }],
    ]);
    applyButtonStyles(backKeyboard);

    if (existingPreviews.length === 1) {
        // Kirim 1 gambar saja dengan caption
        const sent = await ctx.replyWithPhoto(
            { source: fs.createReadStream(existingPreviews[0]) },
            { caption, parse_mode: 'HTML', ...backKeyboard }
        );
        if (sent?.message_id) messageHistory.get(userId).preview.push(sent.message_id);
    } else {
        // Kirim sebagai media group (album) — caption di foto pertama
        const mediaGroup = existingPreviews.map((p, i) => ({
            type: 'photo',
            media: { source: fs.createReadStream(p) },
            ...(i === 0 ? { caption, parse_mode: 'HTML' } : {}),
        }));
        const sentGroup = await ctx.replyWithMediaGroup(mediaGroup);
        if (Array.isArray(sentGroup)) {
            for (const msg of sentGroup) {
                if (msg?.message_id) messageHistory.get(userId).preview.push(msg.message_id);
            }
        }
        // Kirim tombol kembali terpisah setelah album
        const sentBack = await ctx.reply('Pilih aksi:', backKeyboard);
        if (sentBack?.message_id) messageHistory.get(userId).preview.push(sentBack.message_id);
    }
}

// Halaman pilih paket — tampil setelah user klik "Sewa SC"
async function showSewaScPilihPaket(ctx) {
    const paketList = getPaketList();
    const paketButtons = paketList.map(p => {
        const harga = hitungHargaSC(1, p.jumlahHari);
        return [{ text: `${p.icon} ${p.label} – ${formatRp(harga)}`, callback_data: `sewa_sc_paket_${p.id}` }];
    });

    const keyboard = Markup.inlineKeyboard([
        ...paketButtons,
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_sc_menu', style: 'danger' }],
    ]);

    await sendMenu(ctx, `${getHeader(' 𝙋𝙄𝙇𝙄𝙃 𝙋𝘼𝙆𝙀𝙏 𝙎𝙀𝙒𝘼 𝙎𝘾')}\n<blockquote><b>Pilih durasi sewa:</b>\n<b></b>\n<b> Paket Lifetime: bebas ganti IP & Nama kapan saja gratis.</b>\n\n📝 <b>Catatan:</b> Selain paket Lifetime, IP tidak dapat diganti selama masa aktif berlangsung.</blockquote>`, keyboard);
}


async function showSewaScList(ctx, page = 0) {
    const userId = ctx.from.id.toString();
    const sewaMilik = getSewaByUser(userId);

    if (sewaMilik.length === 0) {
        await sendTempMessage(ctx, 'Belum ada sewa SC aktif.\n\nGunakan menu <b>Sewa SC</b> untuk mendaftar IP.');
        await showSewaScMenu(ctx);
        return;
    }

    const itemsPerPage = 5;
    const totalPages = Math.ceil(sewaMilik.length / itemsPerPage);
    page = Math.max(0, Math.min(page, totalPages - 1));
    const start = page * itemsPerPage;
    const end = start + itemsPerPage;
    const pageSewa = sewaMilik.slice(start, end);

    const now = new Date();
    let text = `${getHeader('𝙄𝙋 𝙎𝘾 𝘼𝙆𝙏𝙄𝙁')}
`;
    const buttons = [];
    pageSewa.forEach((s, idx) => {
        const i = start + idx;
        const expired = new Date(s.masaAktif) < now;
        const statusIcon = expired ? '⛔' : '✅';
        const status = expired ? 'Expired' : 'Aktif';
        const isLifetime = s.jumlahHari === null || s.masaAktif === '2099-12-31';
        text += `<blockquote><b>🛰 IP:</b> <code>${s.ip}</code>
🏷 <b>Nama:</b> ${s.nama}
📅 <b>Exp:</b> ${s.masaAktif}${isLifetime ? ' ♾️' : ''}
${statusIcon} <b>Status:</b> ${status}</blockquote>\n`;
        if (isLifetime && s.txId) {
            buttons.push([{ text: `🔄 𝙂𝙖𝙣𝙩𝙞 𝙄𝙋/𝙉𝙖𝙢𝙖 – ${s.nama}`, callback_data: `sewa_sc_ganti_${s.txId}` }]);
        }
    });

    text += `
<blockquote>🌐 <b>Total IP:</b> ${sewaMilik.length}</blockquote>
<b>· Halaman ${page + 1} dari ${totalPages}</b>`;

    const navButtons = [];
    if (page > 0) {
        navButtons.push({ text: '◀ 𝙎𝙚𝙗𝙚𝙡𝙪𝙢𝙣𝙮𝙖', callback_data: `sewa_sc_list_page_${page - 1}` });
    }
    if (page < totalPages - 1) {
        navButtons.push({ text: '𝙎𝙚𝙡𝙖𝙣𝙟𝙪𝙩𝙣𝙮𝙖 ▶', callback_data: `sewa_sc_list_page_${page + 1}` });
    }
    if (navButtons.length > 0) {
        buttons.push(navButtons);
    }

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        ...buttons,
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_sc_menu', style: 'danger' }],
    ]));
}

// ── GANTI IP & NAMA (khusus Lifetime) ──

async function startSewaScGanti(ctx, txId) {
    const userId = ctx.from.id.toString();
    const sewaMilik = getSewaByUser(userId);
    const rec = sewaMilik.find(s => s.txId === txId);

    if (!rec) {
        await sendTempMessage(ctx, ' Data sewa tidak ditemukan.');
        await showSewaScList(ctx);
        return;
    }

    const isLifetime = rec.jumlahHari === null || rec.masaAktif === '2099-12-31';
    if (!isLifetime) {
        await sendTempMessage(ctx, ' Ganti IP & Nama hanya untuk paket Lifetime.');
        await showSewaScList(ctx);
        return;
    }

    userStates.set(userId, {
        action: 'sewa_sc_ganti',
        step: 'input_nama',
        txId,
        namaLama: rec.nama,
        ipLama: rec.ip,
    });

    const text = `${getHeader(' 𝙂𝘼𝙉𝙏𝙄 𝙄𝙋 & 𝙉𝘼𝙈𝘼 𝙎𝘾')}
<blockquote><b>· Nama Saat Ini:</b> ${rec.nama}
<b>· IP Saat Ini:</b> <code>${rec.ip}</code>
<b></b>
<b>Langkah 1/2 — Nama Baru</b>
Ketik nama baru untuk label ini:
<i>(contoh: Server-SG, NodeBaru, dll)</i>
</blockquote>`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_list', style: 'danger' }],
    ]));
}

async function processSewaScGantiInput(ctx, message, state) {
    const userId = ctx.from.id.toString();

    // ── step input_nama ──
    if (state.step === 'input_nama') {
        const nama = message.trim();
        if (!nama || nama.length < 2) {
            await sendTempMessage(ctx, ' Nama terlalu pendek (minimal 2 karakter).');
            return;
        }
        userStates.set(userId, { ...state, step: 'input_ip', namaBaru: nama });

        const text = `${getHeader(' 𝙂𝘼𝙉𝙏𝙄 𝙄𝙋 & 𝙉𝘼𝙈𝘼 𝙎𝘾')}
<blockquote><b>· Nama Baru: ${nama} </b>
<b></b>
<b>Langkah 2/2 — IP Baru</b>
Ketik IP server baru:
<i>(contoh: 103.12.34.56)</i>
</blockquote>`;

        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_list', style: 'danger' }],
        ]));
        return;
    }

    // ── step input_ip ──
    if (state.step === 'input_ip') {
        const ip = message.trim();
        if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) {
            await sendTempMessage(ctx, ' Format IP tidak valid!\n\nContoh: <code>103.12.34.56</code>');
            return;
        }

        userStates.set(userId, {
            action: 'sewa_sc_ganti_confirm',
            txId: state.txId,
            namaLama: state.namaLama,
            ipLama: state.ipLama,
            namaBaru: state.namaBaru,
            ipBaru: ip,
        });

        const text = `${getHeader(' 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙂𝘼𝙉𝙏𝙄')}
<blockquote><b>· Sebelum:</b>
  Nama: ${state.namaLama}
  IP: <code>${state.ipLama}</code>
<b></b>
<b>· Sesudah:</b>
  Nama: ${state.namaBaru}
  IP: <code>${ip}</code>
<b></b>
⚠️ IP lama akan dihapus dari repo dan diganti IP baru.</blockquote>`;

        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '✅ 𝙔𝙖, 𝙂𝙖𝙣𝙩𝙞 𝙎𝙚𝙠𝙖𝙧𝙖𝙣𝙜', callback_data: 'sewa_sc_ganti_confirm' }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_list', style: 'danger' }],
        ]));
        return;
    }
}

async function processSewaScGantiKonfirmasi(ctx) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);

    if (!state || state.action !== 'sewa_sc_ganti_confirm') {
        await showSewaScList(ctx);
        return;
    }

    const { txId, namaLama, ipLama, namaBaru, ipBaru } = state;
    userStates.delete(userId);

    // Loading
    const loadingMsg = await ctx.reply(
        ` <b>Memproses penggantian IP...</b>\n\n` +
        `<blockquote>· Hapus IP lama: <code>${ipLama}</code>\n` +
        `· Push IP baru: <code>${ipBaru}</code>\n` +
        `· Mohon tunggu sebentar...</blockquote>`,
        { parse_mode: 'HTML' }
    );

    // Update record di JSON
    const rekamLama = updateSewaIpNama(userId, txId, namaBaru, ipBaru);

    let repoOk = false;
    let repoErr = '';
    try {
        const token = getScGithubToken();
        if (!token) throw new Error('SC_GITHUB_TOKEN belum diset');
        await removeIpFromRepo(ipLama);
        // Push IP baru (masa aktif lifetime = 2099-12-31)
        await addIpToRepo(namaBaru, '2099-12-31', ipBaru);
        repoOk = true;
    } catch(e) {
        repoErr = e.message || String(e);
        console.error('[SewaSC] Gagal ganti IP repo:', repoErr);
    }

    // Hapus loading
    try { await ctx.deleteMessage(loadingMsg.message_id); } catch(e) {}

    // Notif admin
    if (ADMIN_IDS.length > 0) {
        for (const adminId of ADMIN_IDS) {
            try {
                await notifBot.telegram.sendMessage(adminId,
                    `<b>GANTI IP SC (Lifetime)</b>\n\n` +
                    `<b>· User:</b> ${ctx.from.first_name || 'User'} (<code>${userId}</code>)\n` +
                    `<b>· Nama:</b> ${namaLama} → ${namaBaru}\n` +
                    `<b>· IP:</b> <code>${ipLama}</code> → <code>${ipBaru}</code>\n` +
                    `<b>· Repo:</b> ${repoOk ? 'OK' : `GAGAL: ${repoErr}`}`,
                    { parse_mode: 'HTML' }
                );
            } catch(e) {}
        }
    }

    const resultText = repoOk
        ? `${getHeader(' 𝙂𝘼𝙉𝙏𝙄 𝙄𝙋 𝘽𝙀𝙍𝙃𝘼𝙎𝙄𝙇')}
<blockquote><b>· Nama:</b> ${namaBaru}
<b>· IP Baru:</b> <code>${ipBaru}</code>
<b>· IP Lama:</b> <code>${ipLama}</code> (dihapus)
<b>· Repo:</b> Tersinkron</blockquote>`
        : `${getHeader(' 𝙂𝘼𝙉𝙏𝙄 𝙄𝙋 𝙋𝘼𝙍𝙎𝙄𝘼𝙇')}
<blockquote><b>· Nama & IP diperbarui di data lokal.</b>
<b>· IP Baru:</b> <code>${ipBaru}</code>
<b>· Repo:</b> Gagal — <code>${repoErr}</code>
⚠️ Hubungi admin untuk sinkronisasi manual.</blockquote>`;

    await sendMenu(ctx, resultText, Markup.inlineKeyboard([
        [{ text: '📋 𝙄𝙋 𝘼𝙠𝙩𝙞𝙛 𝙎𝙖𝙮𝙖', callback_data: 'sewa_sc_list' }],
        [{ text: '🏠 𝙈𝙚𝙣𝙪 𝙎𝙚𝙬𝙖 𝙎𝘾', callback_data: 'sewa_sc_menu' }],
    ]));
}


async function showSewaScPerpanjang(ctx) {
    const userId = ctx.from.id.toString();
    const sewaMilik = getSewaByUser(userId);

    if (sewaMilik.length === 0) {
        await sendTempMessage(ctx, 'Belum ada sewa SC aktif.\n\nGunakan menu <b>Sewa SC</b> untuk mendaftar IP.');
        await showSewaScMenu(ctx);
        return;
    }

    const now = new Date();
    let text = `${getHeader('𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂 𝙎𝘾')}\n<blockquote><b>Pilih IP yang akan diperpanjang:</b></blockquote>\n`;
    const renewButtons = [];
    sewaMilik.forEach((s, i) => {
        const expired = new Date(s.masaAktif) < now;
        const status = expired ? '' : '';
        text += `<blockquote><b>${i + 1}. ${s.ip}</b>\n<b>· Exp:</b> ${s.masaAktif} ${status}</blockquote>\n`;
        if (s.txId) {
            renewButtons.push([{ text: `${s.nama} – ${s.ip}`, callback_data: `sewa_sc_renew_${s.txId}` }]);
        }
    });

    const keyboard = Markup.inlineKeyboard([
        ...renewButtons,
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_sc_menu', style: 'danger' }],
    ]);
    await sendMenu(ctx, text, keyboard);
}

// ── PERPANJANG IP ──
// Step 1: pilih paket durasi perpanjangan untuk txId tertentu
async function startSewaScRenew(ctx, txId) {
    const userId = ctx.from.id.toString();
    const sewaMilik = getSewaByUser(userId);
    const rec = sewaMilik.find(s => s.txId === txId);

    if (!rec) {
        await sendTempMessage(ctx, ' Data sewa tidak ditemukan.');
        await showSewaScList(ctx);
        return;
    }

    const paketList = getPaketList();
    if (paketList.length === 0) {
        await sendTempMessage(ctx, ' Belum ada paket yang tersedia.');
        await showSewaScList(ctx);
        return;
    }

    const expiredLabel = rec.masaAktif;
    const text = `${getHeader('𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂 𝙄𝙋')}
<blockquote><b>· IP:</b> <code>${rec.ip}</code>
<b>· Nama:</b> ${rec.nama}
<b>· Exp Saat Ini:</b> ${expiredLabel}
<b></b>
🔄 Pilih paket perpanjangan:</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        ...paketList.map(p => [{
            text: `${p.icon} ${p.label} – ${formatRp(hitungHargaSatuIp(p.jumlahHari))}`,
            callback_data: `sewa_sc_renew_paket_${txId}_${p.id}`,
        }]),
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_list', style: 'danger' }],
    ]);
    await sendMenu(ctx, text, keyboard);
}

// Step 2: konfirmasi harga & tanggal baru, lalu minta konfirmasi bayar
async function startSewaScRenewKonfirmasi(ctx, txId, paketId) {
    const userId = ctx.from.id.toString();
    const sewaMilik = getSewaByUser(userId);
    const rec = sewaMilik.find(s => s.txId === txId);
    const paket = getPaketById(paketId);

    if (!rec || !paket) {
        await sendTempMessage(ctx, ' Data sewa atau paket tidak ditemukan.');
        await showSewaScList(ctx);
        return;
    }

    const harga = hitungHargaSatuIp(paket.jumlahHari);
    const masaAktifBaru = hitungTanggalPerpanjangan(rec.masaAktif, paket.jumlahHari);
    const saldo = getSaldo(userId);

    userStates.set(userId, {
        action: 'sewa_sc_renew_confirm',
        txId, paketId,
        jumlahHari: paket.jumlahHari,
        harga, masaAktifBaru,
    });

    const text = `${getHeader('𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂𝘼𝙉')}
<blockquote><b>· IP:</b> <code>${rec.ip}</code>
<b>· Nama:</b> ${rec.nama}
<b>· Paket:</b> ${paket.label}
<b>· Exp Sekarang:</b> ${rec.masaAktif}
<b>· Exp Setelah Perpanjang:</b> ${masaAktifBaru}
<b>· Harga:</b> ${formatRp(harga)}
<b>· Saldo Sekarang:</b> ${formatRp(saldo)}
<b>· Saldo Setelah:</b> ${formatRp(saldo - harga)}</blockquote>`;

    if (saldo < harga) {
        await sendTempMessage(ctx, ` Saldo tidak cukup!\n\n<b>· Harga:</b> ${formatRp(harga)}\n<b>· Saldo:</b> ${formatRp(saldo)}\n<b>· Kurang:</b> ${formatRp(harga - saldo)}\n\nTopup saldo terlebih dahulu.`);
        userStates.delete(userId);
        await showSewaScList(ctx);
        return;
    }

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '💳 𝘽𝙖𝙮𝙖𝙧 & 𝙋𝙚𝙧𝙥𝙖𝙣𝙟𝙖𝙣𝙜', callback_data: 'sewa_sc_renew_pay' }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_list', style: 'danger' }],
    ]));
}

// Step 3: eksekusi pembayaran perpanjangan
async function processSewaScRenewPay(ctx) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);

    if (!state || state.action !== 'sewa_sc_renew_confirm') {
        await showSewaScList(ctx);
        return;
    }

    const { txId, jumlahHari, harga, masaAktifBaru } = state;
    const sewaMilik = getSewaByUser(userId);
    const rec = sewaMilik.find(s => s.txId === txId);

    if (!rec) {
        await sendTempMessage(ctx, ' Data sewa tidak ditemukan / sudah dihapus.');
        userStates.delete(userId);
        await showSewaScList(ctx);
        return;
    }

    const saldo = getSaldo(userId);
    if (saldo < harga) {
        await sendTempMessage(ctx, ` Saldo tidak cukup! Topup dulu.`);
        userStates.delete(userId);
        await showSewaScList(ctx);
        return;
    }

    // Potong saldo
    kurangiSaldo(userId, harga);
    const renewTxId = generateTxId();

    simpanTransaksi({
        txId: renewTxId, userId,
        userName: ctx.from.first_name || ctx.from.username || 'User',
        type: 'sewa_sc_perpanjang',
        amount: harga,
        keterangan: `Perpanjang SC: ${rec.ip} | ${jumlahHari === null ? 'Lifetime' : jumlahHari + ' hari'} | exp baru ${masaAktifBaru}`,
        waktu: new Date().toISOString(),
        status: 'success',
    });

    perpanjangSewaRecord(userId, txId, masaAktifBaru, harga, jumlahHari);
    userStates.delete(userId);

    // Update tanggal expired di repo GitHub
    let githubOk = false;
    let githubErr = '';
    let usedFallback = false;
    try {
        const token = getScGithubToken();
        if (!token) throw new Error('SC_GITHUB_TOKEN belum diset');
        const result = await updateIpExpiryInRepo(rec.ip, rec.nama, masaAktifBaru);
        if (!result || !result.updated) throw new Error('Gagal memperbarui IP di repo');
        usedFallback = !!result.fallback;
        githubOk = true;
    } catch(e) {
        githubErr = e.message || String(e);
        console.error('[SewaSC] Gagal update expiry repo:', githubErr);
    }

    let resultText = `${getHeader('𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂𝘼𝙉 𝘽𝙀𝙍𝙃𝘼𝙎𝙄𝙇')}
<blockquote><b>· IP:</b> <code>${rec.ip}</code>
<b>· Nama:</b> ${rec.nama}
<b>· Exp Baru:</b> ${masaAktifBaru}
<b>· Bayar:</b> ${formatRp(harga)}</blockquote>`;

    if (!githubOk) {
        resultText += `\n\n Tanggal expired di repo <b>belum tersinkron</b>:\n<code>${githubErr}</code>\nHubungi admin dengan TxID: <code>${renewTxId}</code>`;
    } else if (usedFallback) {
        resultText += `\n\nℹ IP didaftarkan ulang ke repo (entry sebelumnya tidak ditemukan, kemungkinan belum tersinkron).`;
    }

    // Notif admin
    if (ADMIN_IDS.length > 0) {
        for (const adminId of ADMIN_IDS) {
            try {
                await notifBot.telegram.sendMessage(adminId,
                    `<b>PERPANJANG SC</b>\n\n<b>· User:</b> ${ctx.from.first_name || 'User'} (<code>${userId}</code>)\n<b>· Nama:</b> ${rec.nama}\n<b>· IP:</b> <code>${rec.ip}</code>\n<b>· Exp Baru:</b> ${masaAktifBaru}\n<b>· Bayar:</b> ${formatRp(harga)}\n<b>· Repo:</b> ${githubOk ? 'OK' : `GAGAL: ${githubErr}`}`,
                    { parse_mode: 'HTML' }
                );
            } catch(e) {}
        }
    }

    await sendMenu(ctx, resultText, Markup.inlineKeyboard([
        [{ text: '📋 𝙄𝙋 𝘼𝙠𝙩𝙞𝙛 𝙎𝙖𝙮𝙖', callback_data: 'sewa_sc_list' }],
        [{ text: '🏠 𝙈𝙚𝙣𝙪 𝙎𝙚𝙬𝙖 𝙎𝘾', callback_data: 'sewa_sc_menu' }],
    ]));
}


// SC_INSTALL_SCRIPTS — URL script instalasi per OS
const SC_INSTALL_SCRIPTS = {
    ubuntu: 'https://pxstore.web.id/install/install-sc-ubuntu.sh',
    debian: 'https://pxstore.web.id/install/install-sc-debian.sh',
};

// Step 1: mulai sewa paket (30/60/90/lifetime) — langsung minta jumlah IP lalu nama
// paket: { id, label, jumlahHari, icon } — jumlahHari null = lifetime
async function startSewaScPaket(ctx, paket) {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const jumlahHari = paket.jumlahHari;
    const isLifetime = jumlahHari === null;
    const labelHari  = paket.label;
    const harga1Ip   = hitungHargaSC(1, jumlahHari);
    const icon       = paket.icon || (isLifetime ? '' : '');

    userStates.set(userId, {
        action: 'sewa_sc_input',
        step: 'input_ip_count',
        mode: 'paket',
        jumlahHari,   // null = lifetime
        labelHari,
        jumlahIp: 1,
    });

    const lifetimeNote = isLifetime
        ? `\n<b> Paket ini bebas ganti IP & Nama kapan saja.</b>`
        : '';

    const text = `${getHeader(`${icon} 𝙎𝙀𝙒𝘼 𝙎𝘾 – ${labelHari.toUpperCase()}`)}
<blockquote><b>· Paket: ${labelHari}</b>
<b>· Harga IP ke-1: ${formatRp(harga1Ip)}</b>
<b>· IP ke-2 dst: ${formatRp(getHargaSCExtraIp())} / IP</b>
<b>· Saldo: ${formatRp(saldo)}</b>${lifetimeNote}
<b></b>
<b>Langkah 1/3 — Jumlah IP</b>
Ketik berapa jumlah IP yang disewa:
<i>(contoh: 1, 2, 3)</i>
</blockquote>`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_menu', style: 'danger' }],
    ]));
}

async function processSewaScInput(ctx, message, state) {
    const userId = ctx.from.id.toString();
    const isLifetime = state.jumlahHari === null;
    const labelHari  = state.labelHari || (isLifetime ? 'Lifetime' : `${state.jumlahHari} Hari`);

    // ── step input_ip_count ──
    if (state.step === 'input_ip_count') {
        const jumlahIp = parseInt(message.replace(/\D/g, ''));
        if (isNaN(jumlahIp) || jumlahIp < 1) {
            await sendTempMessage(ctx, ' Jumlah IP tidak valid (minimal 1).');
            return;
        }
        const bd = breakdownHargaSC(jumlahIp, state.jumlahHari);
        const rincianExtra = bd.jumlahExtra > 0
            ? `\n<b>· IP ke-1:</b> ${formatRp(bd.hargaIpPertama)}\n<b>· IP Tambahan (${bd.jumlahExtra}x):</b> ${formatRp(bd.totalExtra)}`
            : '';

        // langsung mulai loop: minta nama IP ke-1
        userStates.set(userId, {
            ...state,
            step: 'input_nama_loop',
            jumlahIp,
            harga: bd.total,
            currentIdx: 0,       // index IP yang sedang diinput (0-based)
            entries: [],          // [{nama, ip}, ...]
        });

        const totalStep = jumlahIp * 2 + 1; // ip_count + nama*n + ip*n
        const text = `${getHeader('𝙎𝙀𝙒𝘼 𝙎𝘾')}
<blockquote><b>· Paket: ${labelHari} </b>
<b>· Jumlah IP: ${jumlahIp} </b>${rincianExtra}
<b>· Total Harga: ${formatRp(bd.total)}</b>
<b></b>
<b>Langkah 2/${totalStep} — Nama IP ke-1</b>
Ketik nama/label untuk IP ke-1:
<i>(contoh: Server-1, Node-SG, dll)</i>
</blockquote>`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_menu', style: 'danger' }],
        ]));
        return;
    }

    // ── step input_nama_loop ──  (minta nama ke-(currentIdx+1))
    if (state.step === 'input_nama_loop') {
        const nama = message.trim();
        if (!nama || nama.length < 2) {
            await sendTempMessage(ctx, ' Nama terlalu pendek (minimal 2 karakter).');
            return;
        }
        const idx = state.currentIdx;
        const totalStep = state.jumlahIp * 2 + 1;
        const stepNow   = 2 + idx * 2 + 1; // step saat ini (input IP ke-(idx+1))

        // simpan nama sementara, lanjut minta IP
        userStates.set(userId, { ...state, step: 'input_ip_loop', currentNama: nama });

        const text = `${getHeader('𝙎𝙀𝙒𝘼 𝙎𝘾')}
<blockquote><b>· Nama ke-${idx + 1}: ${nama} </b>
<b></b>
<b>Langkah ${stepNow}/${totalStep} — IP Server ke-${idx + 1}</b>
Ketik IP server ke-${idx + 1}:
<i>(contoh: 103.12.34.56)</i>
</blockquote>`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_menu', style: 'danger' }],
        ]));
        return;
    }

    // ── step input_ip_loop ──  (minta IP ke-(currentIdx+1))
    if (state.step === 'input_ip_loop') {
        const ip = message.trim();
        if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) {
            await sendTempMessage(ctx, ' Format IP tidak valid!\n\nContoh: <code>103.12.34.56</code>');
            return;
        }

        const idx     = state.currentIdx;
        const entries = [...(state.entries || []), { nama: state.currentNama, ip }];
        const jumlahIp = state.jumlahIp;
        const totalStep = jumlahIp * 2 + 1;

        // masih ada IP berikutnya?
        if (idx + 1 < jumlahIp) {
            const nextIdx   = idx + 1;
            const stepNow   = 2 + nextIdx * 2; // step input nama berikutnya
            userStates.set(userId, {
                ...state,
                step: 'input_nama_loop',
                currentIdx: nextIdx,
                currentNama: null,
                entries,
            });

            // ringkasan progress
            const progressLines = entries.map((e, i) =>
                `<b>· IP ke-${i + 1}:</b> ${e.nama} — <code>${e.ip}</code>`
            ).join('\n');

            const text = `${getHeader('𝙎𝙀𝙒𝘼 𝙎𝘾')}
<blockquote>${progressLines}
<b></b>
<b>Langkah ${stepNow}/${totalStep} — Nama IP ke-${nextIdx + 1}</b>
Ketik nama/label untuk IP ke-${nextIdx + 1}:
<i>(contoh: Server-${nextIdx + 1})</i>
</blockquote>`;
            await sendMenu(ctx, text, Markup.inlineKeyboard([
                [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_menu', style: 'danger' }],
            ]));
            return;
        }

        // semua IP sudah diinput — tampilkan konfirmasi
        const { jumlahHari, harga } = state;
        const masaAktif   = formatTanggalExpiry(jumlahHari);
        const saldo       = getSaldo(userId);
        const durasiLabel = isLifetime ? `${labelHari} ` : labelHari;
        const bd          = breakdownHargaSC(jumlahIp, jumlahHari);
        const rincianExtra = bd.jumlahExtra > 0
            ? `\n<b>· IP ke-1:</b> ${formatRp(bd.hargaIpPertama)}\n<b>· IP Tambahan (${bd.jumlahExtra}x @ ${formatRp(bd.hargaExtraPerIp)}):</b> ${formatRp(bd.totalExtra)}`
            : '';

        const entriesLines = entries.map((e, i) =>
            `<b>· IP ke-${i + 1}:</b> ${e.nama} — <code>${e.ip}</code>`
        ).join('\n');

        userStates.set(userId, {
            action: 'sewa_sc_confirm',
            entries,          // array [{nama, ip}]
            jumlahIp, jumlahHari, harga, masaAktif,
            // backward compat (ambil IP/nama pertama untuk tampilan & record)
            nama: entries[0].nama,
            ip:   entries[0].ip,
        });

        const konfText = `${getHeader(' 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙎𝙀𝙒𝘼 𝙎𝘾')}
<blockquote>${entriesLines}
<b>· Jumlah IP:</b> ${jumlahIp}
<b>· Durasi:</b> ${durasiLabel}
<b>· Masa Aktif s/d:</b> ${masaAktif}${rincianExtra}
<b>· Total Harga:</b> ${formatRp(harga)}
<b>· Saldo Sekarang:</b> ${formatRp(saldo)}
<b>· Saldo Setelah:</b> ${formatRp(saldo - harga)}</blockquote>`;

        if (saldo < harga) {
            await sendTempMessage(ctx, ` Saldo tidak cukup!\n\n<b>· Harga:</b> ${formatRp(harga)}\n<b>· Saldo:</b> ${formatRp(saldo)}\n<b>· Kurang:</b> ${formatRp(harga - saldo)}\n\nTopup saldo terlebih dahulu.`);
            userStates.delete(userId);
            await showSewaScMenu(ctx);
            return;
        }

        await sendMenu(ctx, konfText, Markup.inlineKeyboard([
            [{ text: '💳 𝘽𝙖𝙮𝙖𝙧 & 𝘿𝙖𝙛𝙩𝙖𝙧𝙠𝙖𝙣 𝙄𝙋', callback_data: 'sewa_sc_pay' }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_sc_menu', style: 'danger' }],
        ]));
        return;
    }
}

// Setelah bayar sukses — pilih OS dulu, push IP terjadi setelah OS dipilih
async function showSewaScPilihOs(ctx, txData) {
    const userId = ctx.from.id.toString();
    userStates.set(userId, {
        action: 'sewa_sc_pilih_os',
        txData,
    });

    const ipEntries = (txData.entries && txData.entries.length > 0) ? txData.entries : [{ nama: txData.nama || '-', ip: txData.ip || '-' }];
    const ipLines = ipEntries.map((e, i) =>
        `<b>· IP ke-${i + 1}:</b> ${e.nama} — <code>${e.ip}</code>`
    ).join('\n');

    const text = `${getHeader(' 𝙋𝙄𝙇𝙄𝙃 𝙊𝙎 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b> Pembayaran berhasil!</b>
<b></b>
${ipLines}
<b></b>
<b>Pilih OS server untuk mendapatkan</b>
<b>script instalasi SC Tunneling:</b></blockquote>`;
    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '🐧 𝙐𝙗𝙪𝙣𝙩𝙪', callback_data: 'sewa_sc_os_ubuntu' }],
        [{ text: '🍥 𝘿𝙚𝙗𝙞𝙖𝙣', callback_data: 'sewa_sc_os_debian' }],
    ]));
}
async function showSewaScInstallScript(ctx, os) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    const txData = state?.txData || {};
    userStates.delete(userId);

    const ipEntries = (txData.entries && txData.entries.length > 0) ? txData.entries : [{ nama: txData.nama || '-', ip: txData.ip || '-' }];

    // ── Loading: push IP ke repo ──
    const ipLoadingLines = ipEntries.map((e, i) =>
        `· IP ke-${i + 1}: <code>${e.ip}</code> (${e.nama})`
    ).join('\n');
    const loadingMsg = await ctx.reply(
        ` <b>Mendaftarkan IP ke repo...</b>\n\n` +
        `<blockquote>${ipLoadingLines}\n` +
        `· Mohon tunggu sebentar...</blockquote>`,
        { parse_mode: 'HTML' }
    );

    // ── Push semua IP ke GitHub repo (loop) ──
    const repoResults = [];
    let anyFail = false;
    const token = getScGithubToken();
    for (const entry of ipEntries) {
        let ok = false;
        let err = '';
        try {
            if (!token) throw new Error('SC_GITHUB_TOKEN belum diset');
            await addIpToRepo(entry.nama, txData.masaAktif, entry.ip);
            ok = true;
        } catch(e) {
            err = e.message || String(e);
            anyFail = true;
            console.error(`[SewaSC] Gagal push repo ${entry.ip}:`, err);
        }
        repoResults.push({ ...entry, ok, err });
    }

    // ── Hapus pesan loading ──
    try { await ctx.deleteMessage(loadingMsg.message_id); } catch(e) {}

    // ── Notif admin (dengan hasil repo per-IP) ──
    if (ADMIN_IDS.length > 0) {
        const repoLines = repoResults.map(r =>
            `  · ${r.nama} <code>${r.ip}</code>: ${r.ok ? ' OK' : ` ${r.err}`}`
        ).join('\n');
        for (const adminId of ADMIN_IDS) {
            try {
                await notifBot.telegram.sendMessage(adminId,
                    `<b>SEWA SC BARU</b>\n\n` +
                    `<b>· User:</b> ${ctx.from.first_name || 'User'} (<code>${userId}</code>)\n` +
                    `<b>· Jumlah IP:</b> ${txData.jumlahIp || 1}\n` +
                    `<b>· Exp:</b> ${txData.masaAktif || '-'}\n` +
                    `<b>· Bayar:</b> ${formatRp(txData.harga || 0)}\n` +
                    `<b>· Repo:</b>\n${repoLines}`,
                    { parse_mode: 'HTML' }
                );
            } catch(e) {}
        }
    }

    // ── Pesan gagal push (jika ada) ──
    if (anyFail) {
        const gagalList = repoResults.filter(r => !r.ok).map(r => `• ${r.nama} (${r.ip}): ${r.err}`).join('\n');
        await sendTempMessage(ctx,
            ` Sebagian IP gagal didaftarkan ke repo:\n<code>${gagalList}</code>\n\nHubungi admin dengan TxID: <code>${txData.txId || '-'}</code>`
        );
    }

    // ── Tampilkan result + script instalasi ──
    const scriptUrl = SC_INSTALL_SCRIPTS[os] || SC_INSTALL_SCRIPTS.ubuntu;
    const osLabel   = os === 'debian' ? ' Debian' : ' Ubuntu';
    const curlCmd   = `bash &lt;(wget -qO- ${scriptUrl})`;
    const isLifetime  = txData.jumlahHari === null;
    const durasiLabel = isLifetime ? 'Lifetime ' : `${txData.jumlahHari || '-'} hari`;

    const ipLines = repoResults.map((r, i) =>
        `<b>· IP ke-${i + 1}:</b> ${r.nama} — <code>${r.ip}</code> ${r.ok ? '' : ''}`
    ).join('\n');

    const resultText = `${getHeader('𝙎𝙀𝙒𝘼 𝙎𝘾 𝘽𝙀𝙍𝙃𝘼𝙎𝙄𝙇')}
<blockquote><b>· TxID:</b> <code>${txData.txId || '-'}</code>
${ipLines}
<b>· Jumlah IP:</b> ${txData.jumlahIp || 1}
<b>· Durasi:</b> ${durasiLabel}
<b>· Masa Aktif:</b> ${txData.masaAktif || '-'}
<b>· Bayar:</b> ${formatRp(txData.harga || 0)}
<b>· Sisa Saldo:</b> ${formatRp(getSaldo(userId))}</blockquote>

<blockquote><b> Script Instalasi ${osLabel}</b>
<b>Jalankan di server sebagai root:</b>

<code>${curlCmd}</code></blockquote>`;

    await sendResultMessage(ctx, resultText, {
        reply_markup: Markup.inlineKeyboard([
            [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙚𝙣𝙪 𝙎𝘾', callback_data: 'sewa_sc_menu', style: 'danger' }],
        ]).reply_markup,
    });
}

async function processSewaScPay(ctx) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);

    if (!state || state.action !== 'sewa_sc_confirm') {
        await showSewaScMenu(ctx);
        return;
    }

    const { entries, nama, ip, jumlahIp, jumlahHari, harga, masaAktif } = state;
    // entries = [{nama, ip}, ...] untuk multi-IP; fallback single
    const ipEntries = (entries && entries.length > 0) ? entries : [{ nama: nama || '-', ip: ip || '-' }];
    const saldo = getSaldo(userId);

    if (saldo < harga) {
        await sendTempMessage(ctx, ` Saldo tidak cukup! Topup dulu.`);
        userStates.delete(userId);
        await showSewaScMenu(ctx);
        return;
    }

    // Potong saldo
    kurangiSaldo(userId, harga);
    const txId = generateTxId();

    const ipListStr = ipEntries.map(e => `${e.nama}:${e.ip}`).join(', ');
    simpanTransaksi({
        txId, userId,
        userName: ctx.from.first_name || ctx.from.username || 'User',
        type: 'sewa_sc',
        amount: harga,
        keterangan: `Sewa SC: ${ipListStr} | ${jumlahIp} IP | ${jumlahHari} hari`,
        waktu: new Date().toISOString(),
        status: 'success',
    });

    // Simpan record sewa (gunakan nama & ip pertama sebagai primary, simpan semua di entries)
    tambahSewaRecord(userId, ipEntries[0].nama, ipEntries[0].ip, masaAktif, jumlahHari, harga, txId, ipEntries);

    userStates.delete(userId);

    // Lanjut pilih OS — push IP dilakukan setelah OS dipilih
    await showSewaScPilihOs(ctx, { txId, nama: ipEntries[0].nama, ip: ipEntries[0].ip, jumlahIp, jumlahHari, masaAktif, harga, entries: ipEntries });
}

// ==================== SEWA BOT SELLER ====================

async function showSewaBotMenu(ctx) {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const milikSaya = getSewaBotByUser(userId);
    const aktif = milikSaya.filter(s => new Date(s.masaAktif) >= new Date());
    const paketList = getBotPaketList();

    let hargaLines = '';
    paketList.forEach(p => {
        const harga = hitungHargaBotSeller(p.jumlahHari);
        hargaLines += `${p.icon || '💰'} <b>${p.label}</b> → ${formatRp(harga)}\n`;
    });

    const text = `${getHeader('🤖 𝙎𝙀𝙒𝘼 𝘽𝙊𝙏 𝙎𝙀𝙇𝙇𝙀𝙍')}
<blockquote>Lisensi token untuk install Bot Seller PEYX TUNNELING

⚠️ Bot ini khusus untuk Anda yang sudah install SC PEYX TUNNELING. Bot Seller ini berjalan di dalam SC PEYX TUNNELING Anda — pastikan SC sudah terinstall sebelum sewa.</blockquote>

<blockquote>💵 <b>Paket Harga</b>
${hargaLines.trimEnd()}</blockquote>

<blockquote>🔑 <b>Lisensi Aktif Anda:</b> ${aktif.length}</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🆕 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩 𝘽𝙖𝙧𝙪', callback_data: 'sewa_bot_pilih_paket' }, { text: '🔁 𝙋𝙚𝙧𝙥𝙖𝙣𝙟𝙖𝙣𝙜 𝙇𝙞𝙨𝙚𝙣𝙨𝙞', callback_data: 'sewa_bot_perpanjang' }],
        [{ text: '📋 𝙇𝙞𝙨𝙚𝙣𝙨𝙞 𝙎𝙖𝙮𝙖', callback_data: 'sewa_bot_list' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙎𝙚𝙬𝙖 𝙎𝘾', callback_data: 'sewa_sc_menu', style: 'danger' }],
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showSewaBotPilihPaket(ctx) {
    const paketList = getBotPaketList();
    const paketButtons = paketList.map(p => {
        const harga = hitungHargaBotSeller(p.jumlahHari);
        return [{ text: `${p.icon} ${p.label} – ${formatRp(harga)}`, callback_data: `sewa_bot_paket_${p.id}` }];
    });

    const keyboard = Markup.inlineKeyboard([
        ...paketButtons,
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_bot_menu', style: 'danger' }],
    ]);

    await sendMenu(ctx, `${getHeader(' 𝙋𝙄𝙇𝙄𝙃 𝙋𝘼𝙆𝙀𝙏 𝘽𝙊𝙏 𝙎𝙀𝙇𝙇𝙀𝙍')}\n<blockquote><b>Pilih masa aktif lisensi bot:</b></blockquote>`, keyboard);
}

async function startSewaBotPaket(ctx, paket) {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const jumlahHari = paket.jumlahHari;
    const isLifetime = jumlahHari === null;
    const harga = hitungHargaBotSeller(jumlahHari);

    userStates.set(userId, {
        action: 'sewa_bot_input',
        step: 'input_nama',
        jumlahHari,
        labelHari: paket.label,
        harga,
    });

    const text = `${getHeader(`🤖 𝙎𝙀𝙒𝘼 𝘽𝙊𝙏 – ${paket.label.toUpperCase()}`)}
<blockquote><b>· Paket: ${paket.label}</b>
<b>· Harga: ${formatRp(harga)}</b>
<b>· Saldo: ${formatRp(saldo)}</b>
<b></b>
<b>Langkah 1/2 — Nama Bot/Toko</b>
Ketik nama bot/toko Anda:
<i>(contoh: PEYX STORE)</i>
</blockquote>`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_bot_menu', style: 'danger' }],
    ]));
}

async function processSewaBotInput(ctx, message, state) {
    const userId = ctx.from.id.toString();

    if (state.step === 'input_nama') {
        const nama = message.trim();
        if (!nama || nama.length < 2) {
            await sendTempMessage(ctx, ' Nama terlalu pendek (minimal 2 karakter).');
            return;
        }
        userStates.set(userId, { ...state, step: 'input_ip', nama });

        const text = `${getHeader('𝙎𝙀𝙒𝘼 𝘽𝙊𝙏')}
<blockquote><b>· Nama: ${nama}</b>
<b></b>
<b>Langkah 2/2 — IP Server</b>
Ketik IP VPS tempat bot akan diinstall:
<i>(contoh: 103.12.34.56)</i>
</blockquote>`;
        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_bot_menu', style: 'danger' }],
        ]));
        return;
    }

    if (state.step === 'input_ip') {
        const ip = message.trim();
        if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) {
            await sendTempMessage(ctx, ' Format IP tidak valid!\n\nContoh: <code>103.12.34.56</code>');
            return;
        }

        const { jumlahHari, labelHari, harga, nama } = state;
        const isLifetime = jumlahHari === null;
        const masaAktif  = formatTanggalExpiryBot(jumlahHari);
        const saldo      = getSaldo(userId);

        userStates.set(userId, {
            action: 'sewa_bot_confirm',
            nama, ip, jumlahHari, labelHari, harga, masaAktif,
        });

        const konfText = `${getHeader(' 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙎𝙀𝙒𝘼 𝘽𝙊𝙏')}
<blockquote><b>· Nama:</b> ${nama}
<b>· IP Server:</b> <code>${ip}</code>
<b>· Paket:</b> ${labelHari}
<b>· Masa Aktif s/d:</b> ${masaAktif}
<b>· Total Harga:</b> ${formatRp(harga)}
<b>· Saldo Sekarang:</b> ${formatRp(saldo)}
<b>· Saldo Setelah:</b> ${formatRp(saldo - harga)}</blockquote>`;

        if (saldo < harga) {
            await sendTempMessage(ctx, ` Saldo tidak cukup!\n\n<b>· Harga:</b> ${formatRp(harga)}\n<b>· Saldo:</b> ${formatRp(saldo)}\n<b>· Kurang:</b> ${formatRp(harga - saldo)}\n\nTopup saldo terlebih dahulu.`);
            userStates.delete(userId);
            await showSewaBotMenu(ctx);
            return;
        }

        await sendMenu(ctx, konfText, Markup.inlineKeyboard([
            [{ text: '💳 𝘽𝙖𝙮𝙖𝙧 & 𝙂𝙚𝙣𝙚𝙧𝙖𝙩𝙚 𝙏𝙤𝙠𝙚𝙣', callback_data: 'sewa_bot_pay' }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'sewa_bot_menu', style: 'danger' }],
        ]));
        return;
    }
}

async function processSewaBotPay(ctx) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);

    if (!state || state.action !== 'sewa_bot_confirm') {
        await showSewaBotMenu(ctx);
        return;
    }

    const { nama, ip, jumlahHari, harga, masaAktif } = state;
    const saldo = getSaldo(userId);

    if (saldo < harga) {
        await sendTempMessage(ctx, ' Saldo tidak cukup! Topup dulu.');
        userStates.delete(userId);
        await showSewaBotMenu(ctx);
        return;
    }

    // Potong saldo
    kurangiSaldo(userId, harga);
    const txId  = generateTxId();
    const token = generateLisensiToken(masaAktif);

    simpanTransaksi({
        txId, userId,
        userName: ctx.from.first_name || ctx.from.username || 'User',
        type: 'sewa_bot',
        amount: harga,
        keterangan: `Sewa Bot Seller: ${nama} | ${ip} | exp ${masaAktif}`,
        waktu: new Date().toISOString(),
        status: 'success',
    });

    tambahSewaBotRecord(userId, { txId, token, nama, ip, masaAktif, jumlahHari, harga });
    userStates.delete(userId);

    await sendTempMessage(ctx, '⏳ Membuat token lisensi & menyimpan ke lisensi.json...');

    try {
        await tambahLisensiDanUpload({ token, nama, ip, masaAktif, jumlahHari, userId });

        const text = `${getHeader('✅ 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏 𝙎𝙄𝘼𝙋')}
<blockquote><b>· Nama:</b> ${nama}
<b>· IP Server:</b> <code>${ip}</code>
<b>· Masa Aktif s/d:</b> ${masaAktif}
<b>· Token Lisensi:</b>
<code>${token}</code></blockquote>

<blockquote>📖 <b>Cara Install Bot Seller Telegram:</b>
1. SSH ke VPS Anda (IP di atas)
2. Di menu utama PEYX TUNNELING, pilih angka <b>7. Bot Manager</b>
3. Lalu pilih angka <b>9. Bot Seller Telegram</b>
4. Tunggu proses install berjalan & ikuti arahan di layar
5. Saat diminta token lisensi, masukkan token di atas

Masukkan token ini saat diminta script install. Token akan divalidasi otomatis lewat server lisensi.</blockquote>`;

        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '📋 𝙇𝙞𝙨𝙚𝙣𝙨𝙞 𝙎𝙖𝙮𝙖', callback_data: 'sewa_bot_list' }],
            [{ text: '🏠 𝙈𝙚𝙣𝙪 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩', callback_data: 'sewa_bot_menu' }],
        ]));
    } catch (e) {
        await sendMenu(ctx,
            `${getHeader(' 𝙂𝘼𝙂𝘼𝙇 𝙈𝙀𝙉𝙔𝙄𝙈𝙋𝘼𝙉 𝙇𝙄𝙎𝙀𝙉𝙎𝙄')}\n<blockquote>Token <code>${token}</code> sudah dibuat & saldo terpotong, namun gagal menulis ke lisensi.json:\n<code>${(e.message || e).toString().slice(0, 300)}</code>\n\nKemungkinan bot tidak punya izin tulis ke folder tujuan. Cek permission folder <code>${getLisensiFilePath ? getLisensiFilePath() : ''}</code> atau hubungi admin server.</blockquote>`,
            Markup.inlineKeyboard([[{ text: '🏠 𝙈𝙚𝙣𝙪 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩', callback_data: 'sewa_bot_menu' }]])
        );
    }
}

async function showSewaBotList(ctx) {
    const userId = ctx.from.id.toString();
    const list = getSewaBotByUser(userId);

    if (list.length === 0) {
        await sendMenu(ctx, `${getHeader('📋 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏 𝙎𝘼𝙔𝘼')}\n<blockquote>ℹ️ Anda belum punya lisensi Bot Seller.</blockquote>`,
            Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_bot_menu', style: 'danger' }]]));
        return;
    }

    const aktifCount = list.filter(s => new Date(s.masaAktif) >= new Date()).length;
    let text = `${getHeader('📋 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏 𝙎𝘼𝙔𝘼')}
<blockquote>📄 <b>Total:</b> ${list.length}  ✅ <b>Aktif:</b> ${aktifCount}  ❌ <b>Expired:</b> ${list.length - aktifCount}</blockquote>\n`;

    list.forEach((s, i) => {
        const aktif = new Date(s.masaAktif) >= new Date();
        text += `\n🪪 <b>${i + 1}. ${s.nama}</b>
<blockquote>🌐 <code>${s.ip}</code>
🔑 <b>Token:</b> <code>${s.token}</code>
📅 <b>Exp:</b> ${s.masaAktif} ${aktif ? '✅' : '❌ Expired'}</blockquote>\n`;
    });

    await sendMenu(ctx, text,
        Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_bot_menu', style: 'danger' }]]));
}

// ==================== PERPANJANG LISENSI BOT SELLER ====================

async function showSewaBotPerpanjangPilihToken(ctx) {
    const userId = ctx.from.id.toString();
    const list = getSewaBotByUser(userId);

    if (list.length === 0) {
        await sendMenu(ctx, `${getHeader('🔁 𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏')}\n<blockquote>ℹ️ Anda belum punya lisensi Bot Seller untuk diperpanjang.</blockquote>`,
            Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_bot_menu', style: 'danger' }]]));
        return;
    }

    const buttons = list
        .filter(s => s.jumlahHari !== null) // lifetime tidak perlu diperpanjang
        .map((s) => {
            const aktif = new Date(s.masaAktif) >= new Date();
            const label = `${aktif ? '✅' : '❌'} ${s.nama} (${s.ip}) — exp ${s.masaAktif}`;
            return [{ text: label, callback_data: `sewa_bot_perpanjang_token_${s.token}` }];
        });

    if (buttons.length === 0) {
        await sendMenu(ctx, `${getHeader('🔁 𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏')}\n<blockquote>♾ Semua lisensi Anda sudah Lifetime, tidak perlu diperpanjang.</blockquote>`,
            Markup.inlineKeyboard([[{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_bot_menu', style: 'danger' }]]));
        return;
    }

    buttons.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_bot_menu', style: 'danger' }]);

    await sendMenu(ctx,
        `${getHeader('🔁 𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏')}\n<blockquote>🪪 <b>Pilih lisensi (token) yang ingin diperpanjang:</b></blockquote>`,
        Markup.inlineKeyboard(buttons));
}

async function showSewaBotPerpanjangPilihPaket(ctx, token) {
    const userId = ctx.from.id.toString();
    const record = getSewaBotByToken(userId, token);
    if (!record) {
        await sendTempMessage(ctx, ' Lisensi tidak ditemukan.');
        await showSewaBotMenu(ctx);
        return;
    }

    const paketList = getBotPaketList();
    const paketButtons = paketList.map(p => {
        const harga = hitungHargaBotSeller(p.jumlahHari);
        return [{ text: `${p.icon} +${p.label} – ${formatRp(harga)}`, callback_data: `sewa_bot_perpanjang_paket_${p.id}_${token}` }];
    });

    const aktif = new Date(record.masaAktif) >= new Date();
    const text = `${getHeader('🔁 𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏')}
<blockquote>🪪 <b>Nama:</b> ${record.nama}
🌐 <b>IP Server:</b> <code>${record.ip}</code>
🔑 <b>Token:</b> <code>${record.token}</code>
📅 <b>Masa Aktif Saat Ini:</b> ${record.masaAktif} ${aktif ? '✅' : '❌ Expired'}</blockquote>

💵 <b>Pilih tambahan masa aktif:</b>`;

    paketButtons.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'sewa_bot_perpanjang', style: 'danger' }]);
    await sendMenu(ctx, text, Markup.inlineKeyboard(paketButtons));
}

async function processSewaBotPerpanjangPay(ctx, token, paket) {
    const userId = ctx.from.id.toString();
    const record = getSewaBotByToken(userId, token);
    if (!record) {
        await sendTempMessage(ctx, ' Lisensi tidak ditemukan.');
        await showSewaBotMenu(ctx);
        return;
    }

    const jumlahHari = paket.jumlahHari;
    const harga = hitungHargaBotSeller(jumlahHari);
    const saldo = getSaldo(userId);

    if (saldo < harga) {
        await sendTempMessage(ctx, ` Saldo tidak cukup!\n\n<b>· Harga:</b> ${formatRp(harga)}\n<b>· Saldo:</b> ${formatRp(saldo)}\n<b>· Kurang:</b> ${formatRp(harga - saldo)}\n\nTopup saldo terlebih dahulu.`);
        await showSewaBotMenu(ctx);
        return;
    }

    try {
        const hasil = await perpanjangLisensiDanUpload(token, jumlahHari);
        if (!hasil) {
            await sendTempMessage(ctx, ' Token tidak ditemukan di lisensi.json (mungkin sudah direvoke admin).');
            await showSewaBotMenu(ctx);
            return;
        }

        kurangiSaldo(userId, harga);
        perpanjangSewaBotRecord(userId, token, hasil.masaAktifBaru, hasil.jumlahHariBaru, harga);

        const txId = generateTxId();
        simpanTransaksi({
            txId, userId,
            userName: ctx.from.first_name || ctx.from.username || 'User',
            type: 'sewa_bot_perpanjang',
            amount: harga,
            keterangan: `Perpanjang Lisensi Bot: ${record.nama} | ${record.ip} | token ${token} | exp baru ${hasil.masaAktifBaru}`,
            waktu: new Date().toISOString(),
            status: 'success',
        });

        const text = `${getHeader('✅ 𝙇𝙄𝙎𝙀𝙉𝙎𝙄 𝘽𝙊𝙏 𝘿𝙄𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂')}
<blockquote><b>· Nama:</b> ${record.nama}
<b>· IP Server:</b> <code>${record.ip}</code>
<b>· Token:</b> <code>${token}</code>
<b>· Masa Aktif Baru s/d:</b> ${hasil.jumlahHariBaru === null ? 'Lifetime ♾️' : hasil.masaAktifBaru}
<b>· Biaya:</b> ${formatRp(harga)}
<b>· Status:</b> Berhasil diperpanjang</blockquote>`;

        await sendMenu(ctx, text, Markup.inlineKeyboard([
            [{ text: '📋 𝙇𝙞𝙨𝙚𝙣𝙨𝙞 𝙎𝙖𝙮𝙖', callback_data: 'sewa_bot_list' }],
            [{ text: '🏠 𝙈𝙚𝙣𝙪 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩', callback_data: 'sewa_bot_menu' }],
        ]));
    } catch (e) {
        await sendMenu(ctx,
            `${getHeader(' 𝙂𝘼𝙂𝘼𝙇 𝙋𝙀𝙍𝙋𝘼𝙉𝙅𝘼𝙉𝙂 𝙇𝙄𝙎𝙀𝙉𝙎𝙄')}\n<blockquote>Token <code>${token}</code> gagal diperpanjang:\n<code>${(e.message || e).toString().slice(0, 300)}</code></blockquote>`,
            Markup.inlineKeyboard([[{ text: '🏠 𝙈𝙚𝙣𝙪 𝙎𝙚𝙬𝙖 𝘽𝙤𝙩', callback_data: 'sewa_bot_menu' }]])
        );
    }
}

// ==================== ADMIN SEWA BOT SELLER ====================

// [DIPINDAH KE admin.js] function showAdminSewaBotMenu() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminSewaBotList() -- lihat admin.js

// [DIPINDAH KE admin.js] function startAdminBotRevoke() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminBotRevokeInput() -- lihat admin.js





// [DIPINDAH KE admin.js] function showAdminSewaScMenu() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminScList() -- lihat admin.js

// [DIPINDAH KE admin.js] function startAdminScAdd() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminScAddInput() -- lihat admin.js

// [DIPINDAH KE admin.js] function startAdminScRemove() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminScRemoveInput() -- lihat admin.js

// ── Tambah Button Paket (dinamis) ──
// [DIPINDAH KE admin.js] function startAdminScPaketAdd() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminScPaketAddInput() -- lihat admin.js

// ── Hapus Button Paket (dinamis) ──
// [DIPINDAH KE admin.js] function startAdminScPaketRemove() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminScPaketRemove() -- lihat admin.js


// ==================== PANEL VPN MENU ====================
async function showPanelVPN(ctx) {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const jumlahAkun = getJumlahAkun(userId);
    const trialData = loadTrialData();
    const trialHariIni = (trialData[userId] || []).filter(t => {
        try { return new Date(t).toDateString() === new Date().toDateString(); } catch(e) { return false; }
    }).length;
    const sisaTrial = Math.max(0, CONFIG.MAX_TRIAL_PER_USER - trialHariIni);
    const sisaTrialLabel = (isAdmin(ctx.from.id) || isReseller(userId)) ? 'Unlimited ♾️' : `${sisaTrial}/${CONFIG.MAX_TRIAL_PER_USER}`;
    const text = `${getHeader(" 𝙋𝘼𝙉𝙀𝙇 𝙑𝙋𝙉")}
<blockquote><b>ℹ️ Perbedaan Jenis Akun</b>
📡 <b>Reguler</b> — Layanan VPN utama (SSH/Trojan/VLess/VMess) dengan masa aktif harian/bulanan, dibayar di awal sebelum akun dibuat.
⚡ <b>PAYG</b> — Akun aktif selama saldo mencukupi, dipotong otomatis per jam dari saldo Anda.</blockquote>

<blockquote>💰 <b>Saldo:</b> Rp${getSaldo(userId).toLocaleString('id-ID')}
🔑 <b>Akun Aktif:</b> ${jumlahAkun}
🧪 <b>Sisa Trial Hari Ini:</b> ${sisaTrialLabel}
🖥 <b>Server Tersedia:</b> ${getServerTersediaCount()}</blockquote>`;
    const keyboard = Markup.inlineKeyboard([
        [{ text: "📡 𝙑𝙋𝙉 𝙍𝙀𝙂𝙐𝙇𝙀𝙍", callback_data: "reguler_menu" }, { text: "⚡ 𝙋𝘼𝙔𝙂", callback_data: "payg_menu" }],
        [{ text: "📂 𝘼𝙆𝙐𝙉 𝙎𝘼𝙔𝘼", callback_data: "akun_saya" }],
        [{ text: "🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙚𝙣𝙪", callback_data: "main_menu", style: 'danger' }],
    ]);

    await sendMenu(ctx, text, keyboard);
}

// ==================== MENU VPN REGULER ====================
async function showRegulerMenu(ctx) {
    const text = `${getHeader('📡 𝙑𝙋𝙉 𝙍𝙀𝙂𝙐𝙇𝙀𝙍')}
<blockquote>📡 <b>VPN Reguler</b> adalah layanan utama kami berbasis <b>SSH / Trojan / VLess / VMess</b>, dirancang untuk performa stabil dan kebutuhan pemakaian sehari-hari.</blockquote>

🔧 Pilih mode:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '➕ 𝘾𝙧𝙚𝙖𝙩𝙚 𝘼𝙠𝙪𝙣', callback_data: 'create_menu' }, { text: '🧪 𝙏𝙧𝙞𝙖𝙡 𝘼𝙠𝙪𝙣', callback_data: 'trial_menu' }],
        [{ text: '🔁 𝙍𝙚𝙣𝙚𝙬 𝘼𝙠𝙪𝙣', callback_data: 'renew_menu' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'panel_vpn', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

// ==================== MENU VPN EDURC ====================
// EDURC bukan protokol baru — ini adalah mode create/trial yang sama dengan
// SSH/Trojan/VLess/VMess, tapi domainnya otomatis memakai Domain CDN yang sudah
// didaftarkan admin per server (lihat edurc.json):
//   - SSH               → mode CloudFront (domain hasil diganti)
//   - Trojan/VLess/VMess → mode Direct (address/host/SNI hasil diganti)
async function showEdurcMenu(ctx) {
    const text = `${getHeader('🌐 𝙑𝙋𝙉 𝙀𝘿𝙐𝙍𝘾')}
<blockquote><b>Apa itu VPN EDURC?</b>
VPN EDURC adalah layanan VPN berbasis <b>Trojan / VLess / VMess</b> yang menggunakan <b>Domain CDN</b> sebagai alamat koneksi, sehingga traffic internet dapat melewati jaringan edukasi operator.

<b>Support untuk inject paket:</b>
📶 <b>Telkomsel Ilmupedia</b> — paket data edukasi Telkomsel
📶 <b>ByU Ilmupedia</b> — paket data edukasi ByU (Telkomsel)</blockquote>

🔧 Pilih mode:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '➕ 𝘾𝙧𝙚𝙖𝙩𝙚 𝙀𝘿𝙐𝙍𝘾', callback_data: 'edurc_create_menu' }, { text: '🧪 𝙏𝙧𝙞𝙖𝙡 𝙀𝘿𝙐𝙍𝘾', callback_data: 'edurc_trial_menu' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'panel_vpn', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showEdurcCreateMenu(ctx) {
    const serverCount = Object.keys(SERVERS).length;

    if (serverCount === 0) {
        await sendTempMessage(ctx, ` Belum ada server. Silakan tambah server lewat /dashboard terlebih dahulu.`);
        return;
    }

    const text = `${getHeader('🌐 𝘾𝙍𝙀𝘼𝙏𝙀 𝙀𝘿𝙐𝙍𝘾')}
<blockquote>🔧 Pilih protokol yang ingin digunakan. Detail <b>layanan &amp; harga</b> akan ditampilkan setelah Anda memilih protokol.</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: 'edurc_create_trojan' }],
        [{ text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: 'edurc_create_vless' }, { text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: 'edurc_create_vmess' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'edurc_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showEdurcTrialMenu(ctx) {
    const text = `${getHeader('🌐 𝙏𝙍𝙄𝘼𝙇 𝙀𝘿𝙐𝙍𝘾')}
<blockquote><b>Pilih layanan untuk TRIAL VPN EDURC (${CONFIG.MAX_TRIAL_MENIT} menit):</b></blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: 'edurc_trial_trojan' }],
        [{ text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: 'edurc_trial_vless' }, { text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: 'edurc_trial_vmess' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'edurc_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

// ==================== MENU CLOUDFRONT ====================
// CLOUDFRONT adalah mode SSH yang menggunakan Domain CDN CloudFront
// Sama seperti VPN EDURC namun hanya untuk layanan SSH (mode CloudFront).
async function showCloudfrontMenu(ctx) {
    const text = `${getHeader('☁️ 𝘾𝙇𝙊𝙐𝘿𝙁𝙍𝙊𝙉𝙏')}
<blockquote>☁️ <b>SSH CloudFront</b> adalah layanan SSH yang memanfaatkan jaringan <b>CDN Amazon CloudFront</b> sebagai jalur koneksi, cocok untuk paket operator yang mengizinkan akses ke CDN tersebut.</blockquote>

🔧 Pilih mode:`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '➕ 𝘾𝙧𝙚𝙖𝙩𝙚 𝙎𝙎𝙃 𝘾𝙁', callback_data: 'cloudfront_create_menu' }, { text: '🧪 𝙏𝙧𝙞𝙖𝙡 𝙎𝙎𝙃 𝘾𝙁', callback_data: 'cloudfront_trial_menu' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'panel_vpn', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showCloudfrontCreateMenu(ctx) {
    const serverCount = Object.keys(SERVERS).length;

    if (serverCount === 0) {
        await sendTempMessage(ctx, ` Belum ada server. Silakan tambah server lewat /dashboard terlebih dahulu.`);
        return;
    }

    const text = `${getHeader('☁️ 𝘾𝙍𝙀𝘼𝙏𝙀 𝙎𝙎𝙃 𝘾𝙇𝙊𝙐𝘿𝙁𝙍𝙊𝙉𝙏')}
<blockquote>🔧 Pilih protokol yang ingin digunakan. Detail <b>layanan &amp; harga</b> akan ditampilkan setelah Anda memilih protokol.</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔑 𝙎𝙎𝙃 𝘾𝙡𝙤𝙪𝙙𝙁𝙧𝙤𝙣𝙩', callback_data: 'cloudfront_create_ssh' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'cloudfront_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showCloudfrontTrialMenu(ctx) {
    const text = `<blockquote><b>☁️ Pilih layanan untuk TRIAL SSH CloudFront (${CONFIG.MAX_TRIAL_MENIT} menit):</b></blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔑 𝙎𝙎𝙃 𝘾𝙡𝙤𝙪𝙙𝙁𝙧𝙤𝙣𝙩', callback_data: 'cloudfront_trial_ssh' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'cloudfront_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

// ==================== MENU MODE WILDCARD (GANTI BUG LINK) ====================
// Tool untuk user: pilih domain wildcard yang sudah disiapkan admin, lalu kirim link
// Xray (VMess/VLESS/Trojan) milik sendiri — bot otomatis mengganti bug link tersebut
// memakai mode wildcard (address diganti ke bug, SNI/Host diganti ke prefix+host asli).
async function showWildcardMenu(ctx) {
    const domains = loadWildcardDomains();
    const admin = isAdmin(ctx.from.id);

    const text = `${getHeader('✨ 𝙒𝙄𝙇𝘿𝘾𝘼𝙍𝘿')}
<blockquote>✨ <b>Wildcard</b> adalah tool untuk mengganti <b>bug</b> pada link Xray (VMess/VLESS/Trojan) milik Anda sendiri — bukan create akun baru.</blockquote>

<blockquote><b>⚙️ Cara Kerja</b>
1️⃣ Pilih address wildcard di bawah
2️⃣ Kirim link <code>vmess://</code>, <code>vless://</code>, atau <code>trojan://</code> milik Anda
3️⃣ Bot ganti <b>address</b> ke bug, lalu <b>SNI &amp; Host</b> ke <code>prefix.hostAsli</code>
4️⃣ Terima link baru siap pakai — server tujuan tetap sama, cuma bug/SNI yang berubah</blockquote>
<blockquote>ℹ️ Silahkan pilih bug sesuai paket yang Anda inject, dan pastikan TKP support memakai bug yang dipilih.</blockquote>
${domains.length === 0 ? '\n⚠️ Belum ada address wildcard yang tersedia. Hubungi admin untuk menambahkan.' : '\n🌐 Pilih address wildcard:'}`;

    const rows = domains.map(d => ([{ text: `✨ ${d.bug}`, callback_data: `wildcard_select_${d.id}` }]));

    if (admin) {
        rows.push([{ text: '🛠 𝙆𝙚𝙡𝙤𝙡𝙖 𝘼𝙙𝙙𝙧𝙚𝙨𝙨 (𝘼𝙙𝙢𝙞𝙣)', callback_data: 'wildcard_admin_list' }]);
    }
    rows.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'bug_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(rows));
}

// User memilih salah satu domain wildcard -> minta kirim link
async function promptWildcardLinkInput(ctx, entryId) {
    const userId = ctx.from.id.toString();
    const entry = getWildcardDomain(entryId);
    if (!entry) {
        await sendTempMessage(ctx, ' Domain wildcard tidak ditemukan / sudah dihapus admin.');
        await showWildcardMenu(ctx);
        return;
    }

    userStates.set(userId, { action: 'wildcard_input_link', entryId });

    const text = `${getHeader('✏️ 𝙆𝙄𝙍𝙄𝙈 𝙇𝙄𝙉𝙆')}
<blockquote>🔧 <b>Bug:</b> <code>${entry.bug}</code>
🔧 <b>Prefix:</b> <code>${entry.prefix}</code></blockquote>

Kirim link <code>vmess://</code>, <code>vless://</code>, atau <code>trojan://</code> yang ingin diganti mode wildcard-nya.`;

    await sendMenu(ctx, text, cancelKeyboard());
}

// Proses link yang dikirim user -> terapkan wildcard -> kirim hasil
async function processWildcardLinkInput(ctx, message, entryId) {
    const userId = ctx.from.id.toString();
    const entry = getWildcardDomain(entryId);
    if (!entry) {
        userStates.delete(userId);
        await sendTempMessage(ctx, ' Domain wildcard tidak ditemukan / sudah dihapus admin.');
        await showWildcardMenu(ctx);
        return;
    }

    const link = message.trim();
    let result;
    try {
        result = applyWildcardToLink(link, entry);
    } catch (err) {
        await sendTempMessage(ctx, ` ${err.message}\n\nKirim ulang link yang valid.`);
        return;
    }

    userStates.delete(userId);

    const text = `${getHeader('✅ 𝘽𝙐𝙂 𝘽𝙀𝙍𝙃𝘼𝙎𝙄𝙇 𝘿𝙄𝙂𝘼𝙉𝙏𝙄')}
<blockquote>🌐 <b>Host Asli:</b> <code>${result.originalHost}</code>
🔧 <b>Address Baru (Bug):</b> <code>${result.bug}</code>
🔒 <b>SNI / Host Baru:</b> <code>${result.wildcardHost}</code></blockquote>

<b>🔗 Link Hasil:</b>
<code>${result.newLink}</code>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '✨ 𝙂𝙖𝙣𝙩𝙞 𝙇𝙞𝙣𝙠 𝙇𝙖𝙞𝙣', callback_data: `wildcard_select_${entry.id}` }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'wildcard_menu', style: 'danger' }]
    ]);

    await sendResultMessage(ctx, text, keyboard);
}

// ==================== ADMIN: KELOLA ADDRESS WILDCARD ====================
async function showWildcardAdminList(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    const domains = loadWildcardDomains();

    let text = `${getHeader('🛠 𝙆𝙀𝙇𝙊𝙇𝘼 𝘼𝘿𝘿𝙍𝙀𝙎𝙎 𝙒𝙄𝙇𝘿𝘾𝘼𝙍𝘿')}\n`;
    if (domains.length === 0) {
        text += `\n⚠️ Belum ada address wildcard. Tekan tombol ➕ untuk menambahkan.`;
    } else {
        text += `\n<blockquote>${domains.map((d, i) =>
            `${i + 1}. <code>${d.bug}</code>\n   Prefix: <code>${d.prefix}</code>`
        ).join('\n')}</blockquote>`;
    }

    const rows = domains.map(d => ([{ text: `🗑 Hapus: ${d.bug}`, callback_data: `wildcard_admin_del_${d.id}` }]));
    rows.push([{ text: '➕ 𝙏𝙖𝙢𝙗𝙖𝙝 𝘼𝙙𝙙𝙧𝙚𝙨𝙨', callback_data: 'wildcard_admin_add' }]);
    rows.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'wildcard_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(rows));
}

async function startWildcardAdminAdd(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'wildcard_admin_add', step: 'input_bug', data: {} });

    const text = `${getHeader('➕ 𝙏𝘼𝙈𝘽𝘼𝙃 𝘼𝘿𝘿𝙍𝙀𝙎𝙎 𝙒𝙄𝙇𝘿𝘾𝘼𝙍𝘿')}
<blockquote>Langkah 1/2 — Masukkan <b>bug/address</b> tujuan koneksi (contoh: <code>bug.xl.co.id</code>)</blockquote>`;

    await sendMenu(ctx, text, cancelKeyboard());
}

async function processWildcardAdminAddInput(ctx, message, state) {
    const userId = ctx.from.id.toString();
    const value = message.trim();

    if (state.step === 'input_bug') {
        state.data.bug = value;
        state.step = 'input_prefix';
        userStates.set(userId, state);
        await sendMenu(ctx, `${getHeader('➕ 𝙏𝘼𝙈𝘽𝘼𝙃 𝘼𝘿𝘿𝙍𝙀𝙎𝙎 𝙒𝙄𝙇𝘿𝘾𝘼𝙍𝘿')}
<blockquote>Langkah 2/2 — Masukkan <b>prefix wildcard</b> untuk SNI/Host (contoh: <code>bug.xl.co.id.</code>)
Kosongkan / ketik <code>-</code> untuk memakai nilai bug sebagai prefix.</blockquote>`, cancelKeyboard());
        return;
    }

    if (state.step === 'input_prefix') {
        const prefix = (value === '-' || value === '') ? '' : value;
        const entry = addWildcardDomain(state.data.bug, prefix);
        userStates.delete(userId);

        await sendTempMessage(ctx, ` Address wildcard <b>${entry.bug}</b> berhasil ditambahkan.`);
        await showWildcardAdminList(ctx);
        return;
    }
}

async function confirmWildcardAdminDelete(ctx, id) {
    if (!isAdmin(ctx.from.id)) return;
    const entry = getWildcardDomain(id);
    if (!entry) {
        await sendTempMessage(ctx, ' Address wildcard tidak ditemukan / sudah dihapus.');
        await showWildcardAdminList(ctx);
        return;
    }

    const text = `${getHeader('🗑 𝙃𝘼𝙋𝙐𝙎 𝘼𝘿𝘿𝙍𝙀𝙎𝙎 𝙒𝙄𝙇𝘿𝘾𝘼𝙍𝘿')}
<blockquote>Yakin hapus address wildcard berikut?

✨ <code>${entry.bug}</code>
Prefix: <code>${entry.prefix}</code></blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝙃𝙖𝙥𝙪𝙨', callback_data: `wildcard_admin_del_confirm_${id}` }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'wildcard_admin_list', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function processWildcardAdminDelete(ctx, id) {
    if (!isAdmin(ctx.from.id)) return;
    const removed = deleteWildcardDomain(id);
    await sendTempMessage(ctx, removed
        ? ' Address wildcard berhasil dihapus.'
        : ' Address wildcard tidak ditemukan / sudah dihapus.');
    await showWildcardAdminList(ctx);
}

// ==================== MENU BUG XRAY (GANTI ADDRESS & SNI SAJA) ====================
// Sama seperti Mode Wildcard, tapi list bug-nya terpisah (bug.json) dan user WAJIB
// pilih dulu mau ganti ADDRESS SAJA atau SNI SAJA — dua aksi ini tidak digabung.
async function showBugMenu(ctx) {
    const text = `${getHeader('🐛 𝙂𝘼𝙉𝙏𝙄 𝘽𝙐𝙂 𝙓𝙍𝘼𝙔')}
<blockquote>🐛 <b>Ganti Bug Xray</b> adalah tool untuk mengganti <b>bug</b> pada link Xray (VMess/VLESS/Trojan) milik Anda sendiri — bukan create akun baru.</blockquote>

<blockquote><b>⚙️ Cara Kerja</b>
1️⃣ Pilih mode: <b>Wildcard</b>, <b>Address</b> saja, atau <b>SNI</b> saja
2️⃣ Pilih bug yang ingin dipakai
3️⃣ Kirim link <code>vmess://</code>, <code>vless://</code>, atau <code>trojan://</code> milik Anda
4️⃣ Terima link baru — hanya bagian yang dipilih yang berubah, sisanya tetap asli</blockquote>
🔧 Pilih mode ganti bug:`;

    const admin = isAdmin(ctx.from.id);
    const rows = [
        [{ text: '✨ 𝙒𝙞𝙡𝙙𝙘𝙖𝙧𝙙', callback_data: 'bug_mode_wildcard' }],
        [{ text: '🔧 𝙂𝙖𝙣𝙩𝙞 𝘼𝙙𝙙𝙧𝙚𝙨𝙨 𝙎𝙖𝙟𝙖', callback_data: 'bug_mode_address' }],
        [{ text: '🔒 𝙂𝙖𝙣𝙩𝙞 𝙎𝙉𝙄 𝙎𝙖𝙟𝙖', callback_data: 'bug_mode_sni' }],
    ];
    if (admin) {
        rows.push([{ text: '🛠 𝙆𝙚𝙡𝙤𝙡𝙖 𝘽𝙪𝙜 (𝘼𝙙𝙢𝙞𝙣)', callback_data: 'bug_admin_list' }]);
    }
    rows.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'panel_vpn', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(rows));
}

const BUG_MODE_LABEL = { address: 'Address', sni: 'SNI' };

// User sudah pilih mode (address/sni) -> tampilkan daftar bug untuk mode tsb
async function showBugListByMode(ctx, mode) {
    if (mode !== 'address' && mode !== 'sni') {
        await showBugMenu(ctx);
        return;
    }
    const domains = loadBugDomains();
    const modeLabel = BUG_MODE_LABEL[mode];

    const text = `${getHeader('🐛 𝘽𝙐𝙂 𝙓𝙍𝘼𝙔')}
<blockquote>🔧 <b>Mode:</b> Ganti ${modeLabel} Saja</blockquote>
<blockquote>ℹ️ Silahkan pilih bug sesuai paket yang Anda inject, dan pastikan TKP support memakai bug yang dipilih.</blockquote>
${domains.length === 0 ? '\n⚠️ Belum ada bug yang tersedia. Hubungi admin untuk menambahkan.' : '\n🐛 Pilih bug:'}`;

    const rows = domains.map(d => ([{ text: `🐛 ${d.bug}`, callback_data: `bug_select_${mode}_${d.id}` }]));
    rows.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'bug_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(rows));
}

// User memilih salah satu bug -> minta kirim link
async function promptBugLinkInput(ctx, entryId, mode) {
    const userId = ctx.from.id.toString();
    const entry = getBugDomain(entryId);
    if (!entry) {
        await sendTempMessage(ctx, ' Bug tidak ditemukan / sudah dihapus admin.');
        await showBugMenu(ctx);
        return;
    }

    userStates.set(userId, { action: 'bug_input_link', entryId, mode });
    const modeLabel = BUG_MODE_LABEL[mode] || mode;

    const text = `${getHeader('✏️ 𝙆𝙄𝙍𝙄𝙈 𝙇𝙄𝙉𝙆')}
<blockquote>🐛 <b>Bug:</b> <code>${entry.bug}</code>
🔧 <b>Mode:</b> Ganti ${modeLabel} Saja</blockquote>

Kirim link <code>vmess://</code>, <code>vless://</code>, atau <code>trojan://</code> yang ingin diganti bug-nya.`;

    await sendMenu(ctx, text, cancelKeyboard());
}

// Proses link yang dikirim user -> terapkan bug (address saja / sni saja) -> kirim hasil
async function processBugLinkInput(ctx, message, entryId, mode) {
    const userId = ctx.from.id.toString();
    const entry = getBugDomain(entryId);
    if (!entry) {
        userStates.delete(userId);
        await sendTempMessage(ctx, ' Bug tidak ditemukan / sudah dihapus admin.');
        await showBugMenu(ctx);
        return;
    }

    const link = message.trim();
    let result;
    try {
        result = applyBugToLink(link, entry, mode);
    } catch (err) {
        await sendTempMessage(ctx, ` ${err.message}\n\nKirim ulang link yang valid.`);
        return;
    }

    userStates.delete(userId);
    const modeLabel = BUG_MODE_LABEL[mode] || mode;
    const fieldLabel = mode === 'address' ? 'Address Baru' : 'SNI / Host Baru';

    const text = `${getHeader('✅ 𝘽𝙐𝙂 𝘽𝙀𝙍𝙃𝘼𝙎𝙄𝙇 𝘿𝙄𝙂𝘼𝙉𝙏𝙄')}
<blockquote>🔧 <b>Mode:</b> Ganti ${modeLabel} Saja
🌐 <b>Host Asli:</b> <code>${result.originalHost}</code>
🐛 <b>${fieldLabel}:</b> <code>${result.bug}</code></blockquote>

<b>🔗 Link Hasil:</b>
<code>${result.newLink}</code>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🐛 𝙂𝙖𝙣𝙩𝙞 𝙇𝙞𝙣𝙠 𝙇𝙖𝙞𝙣', callback_data: `bug_select_${mode}_${entry.id}` }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'bug_menu', style: 'danger' }]
    ]);

    await sendResultMessage(ctx, text, keyboard);
}

// ==================== ADMIN: KELOLA BUG XRAY ====================
async function showBugAdminList(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    const domains = loadBugDomains();

    let text = `${getHeader('🛠 𝙆𝙀𝙇𝙊𝙇𝘼 𝘽𝙐𝙂 𝙓𝙍𝘼𝙔')}\n`;
    if (domains.length === 0) {
        text += `\n⚠️ Belum ada bug. Tekan tombol ➕ untuk menambahkan.`;
    } else {
        text += `\n<blockquote>${domains.map((d, i) =>
            `${i + 1}. <code>${d.bug}</code>`
        ).join('\n')}</blockquote>`;
    }

    const rows = domains.map(d => ([{ text: `🗑 Hapus: ${d.bug}`, callback_data: `bug_admin_del_${d.id}` }]));
    rows.push([{ text: '➕ 𝙏𝙖𝙢𝙗𝙖𝙝 𝘽𝙪𝙜', callback_data: 'bug_admin_add' }]);
    rows.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'bug_menu', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(rows));
}

async function startBugAdminAdd(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'bug_admin_add', step: 'input_bug', data: {} });

    const text = `${getHeader('➕ 𝙏𝘼𝙈𝘽𝘼𝙃 𝘽𝙐𝙂 𝙓𝙍𝘼𝙔')}
<blockquote>Masukkan <b>bug/address</b> tujuan koneksi (contoh: <code>bug.xl.co.id</code>)</blockquote>`;

    await sendMenu(ctx, text, cancelKeyboard());
}

async function processBugAdminAddInput(ctx, message, state) {
    const userId = ctx.from.id.toString();
    const value = message.trim();

    if (state.step === 'input_bug') {
        const entry = addBugDomain(value);
        userStates.delete(userId);

        await sendTempMessage(ctx, ` Bug <b>${entry.bug}</b> berhasil ditambahkan.`);
        await showBugAdminList(ctx);
        return;
    }
}

async function confirmBugAdminDelete(ctx, id) {
    if (!isAdmin(ctx.from.id)) return;
    const entry = getBugDomain(id);
    if (!entry) {
        await sendTempMessage(ctx, ' Bug tidak ditemukan / sudah dihapus.');
        await showBugAdminList(ctx);
        return;
    }

    const text = `${getHeader('🗑 𝙃𝘼𝙋𝙐𝙎 𝘽𝙐𝙂 𝙓𝙍𝘼𝙔')}
<blockquote>Yakin hapus bug berikut?

🐛 <code>${entry.bug}</code></blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝙃𝙖𝙥𝙪𝙨', callback_data: `bug_admin_del_confirm_${id}` }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'bug_admin_list', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function processBugAdminDelete(ctx, id) {
    if (!isAdmin(ctx.from.id)) return;
    const removed = deleteBugDomain(id);
    await sendTempMessage(ctx, removed
        ? ' Bug berhasil dihapus.'
        : ' Bug tidak ditemukan / sudah dihapus.');
    await showBugAdminList(ctx);
}

// ==================== RIWAYAT TRANSAKSI PER USER ====================
async function showUserTransaksi(ctx, page = 0) {
    const userId = ctx.from.id.toString();
    const transaksiData = loadTransaksi();
    
    // Filter hanya transaksi milik user ini
    const userTransaksi = transaksiData.filter(tx => tx.userId && tx.userId.toString() === userId)
        .sort((a, b) => new Date(b.waktu) - new Date(a.waktu));
    
    if (userTransaksi.length === 0) {
        await sendTempMessage(ctx, '📭 Belum ada riwayat transaksi untuk akun Anda.');
        return;
    }
    
    // Hitung statistik ringkasan
    const totalTopup = userTransaksi.filter(tx => tx.type === 'topup').reduce((sum, tx) => sum + (tx.amount || 0), 0);
    const totalCreate = userTransaksi.filter(tx => tx.type === 'create').reduce((sum, tx) => sum + (tx.amount || 0), 0);
    const totalRenew = userTransaksi.filter(tx => tx.type === 'renew').reduce((sum, tx) => sum + (tx.amount || 0), 0);
    const totalPayg = userTransaksi.filter(tx => ['payg_create','payg_deduct'].includes(tx.type)).reduce((sum, tx) => sum + (tx.amount || 0), 0);
    
    const itemsPerPage = 5;
    const totalPages = Math.ceil(userTransaksi.length / itemsPerPage);
    page = Math.max(0, Math.min(page, totalPages - 1));
    const start = page * itemsPerPage;
    const end = start + itemsPerPage;
    const pageTransaksi = userTransaksi.slice(start, end);

    const typeIconMap = {
        topup: '💳', create: '➕', renew: '🔁',
        payg_create: '⚡', payg_deduct: '⏱', payg_stop: '⏹', payg_delete: '🗑',
        reseller_join: '🤝', admin_add: '📥', admin_reduce: '📤',
        sewa_sc: '📜', sewa_sc_perpanjang: '🔁', sewa_bot: '🤖', sewa_bot_perpanjang: '🔁'
    };
    const typeNameMap = {
        topup: 'Topup Saldo', create: 'Create Akun', renew: 'Renew Akun',
        payg_create: 'PAYG Aktif', payg_deduct: 'PAYG / Jam', payg_stop: 'PAYG Stop', payg_delete: 'PAYG Hapus',
        reseller_join: 'Daftar Reseller', admin_add: 'Saldo Masuk', admin_reduce: 'Saldo Kurang',
        sewa_sc: 'Sewa SC', sewa_sc_perpanjang: 'Perpanjang SC', sewa_bot: 'Sewa Bot', sewa_bot_perpanjang: 'Perpanjang Bot'
    };

    let text = `${getHeader(' 𝙍𝙄𝙒𝘼𝙔𝘼𝙏 𝙏𝙍𝘼𝙉𝙎𝘼𝙆𝙎𝙄')}
`;

    for (let i = 0; i < pageTransaksi.length; i++) {
        const tx = pageTransaksi[i];
        const txDate = tx.waktu ? new Date(tx.waktu).toLocaleDateString('id-ID', { 
            day: 'numeric', 
            month: 'short', 
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }) : '-';
        
        const typeIcon = typeIconMap[tx.type] || '📄';
        const typeName = typeNameMap[tx.type] || (tx.type || 'Lainnya');
        const statusIcon = tx.status === 'success' ? '✅' : '⏳';
        const statusLabel = tx.status === 'success' ? 'Sukses' : 'Pending';
        const ket = (tx.keterangan || '-').substring(0, 35) + ((tx.keterangan || '').length > 35 ? '...' : '');
        
        text += `
<blockquote><b>${typeIcon} ${typeName}</b>
🧾 <code>${tx.txId || '-'}</code>
💰 <b>Nominal:</b> ${formatRp(tx.amount || 0)}
📝 ${ket}
🕒 ${txDate}
${statusIcon} <b>Status:</b> ${statusLabel}</blockquote>`;
    }
    
    text += `
<b>· Halaman ${page + 1} dari ${totalPages}</b>`;

    const keyboardButtons = [];
    
    if (page > 0) {
        keyboardButtons.push({ text: '◀ 𝙎𝙚𝙗𝙚𝙡𝙪𝙢𝙣𝙮𝙖', callback_data: `my_transaksi_page_${page - 1}` });
    }
    if (page < totalPages - 1) {
        keyboardButtons.push({ text: '𝙎𝙚𝙡𝙖𝙣𝙟𝙪𝙩𝙣𝙮𝙖 ▶', callback_data: `my_transaksi_page_${page + 1}` });
    }
    
    const keyboard = Markup.inlineKeyboard([
        keyboardButtons,
        [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙚𝙣𝙪', callback_data: 'main_menu', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

// ==================== MENU CREATE ====================
async function showCreateMenu(ctx) {
    const serverCount = Object.keys(SERVERS).length;
    
    if (serverCount === 0) {
        const text = `${getHeader(' 𝘽𝙀𝙇𝙐𝙈 𝘼𝘿𝘼 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b>· Anda belum menambahkan server.</b>
<b>· Silakan tambah server terlebih dahulu.</b>
<b></b>
<b>· Cara menambah server:</b>
<b>· 1. Kirim /dashboard</b>
<b>· 2. Pilih "Server Management"</b>
<b>· 3. Pilih "Tambah Server"</b>
<b>· 4. Ikuti petunjuk step by step</b></blockquote>`;
        
        const keyboard = Markup.inlineKeyboard([
            [{ text: '🛡 𝘼𝙙𝙢𝙞𝙣 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard' }],
            [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'main_menu', style: 'danger' }]
        ]);
        
        await sendMenu(ctx, text, keyboard);
        return;
    }

    const text = `${getHeader(' 𝘾𝙍𝙀𝘼𝙏𝙀 𝘼𝙆𝙐𝙉')}
<blockquote>🔧 Pilih protokol yang ingin digunakan. Detail <b>layanan &amp; harga</b> akan ditampilkan setelah Anda memilih protokol.</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔑 𝙎𝙎𝙃', callback_data: 'create_ssh' }, { text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: 'create_trojan' }],
        [{ text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: 'create_vless' }, { text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: 'create_vmess' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'reguler_menu', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

// ==================== CREATE ACCOUNT HANDLERS ====================
// ==================== CREATE ACCOUNT HANDLERS (STEP BY STEP) ====================
async function handleCreateService(ctx, serviceType, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const servers = await getServerList(serviceType);
    
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server untuk ${serviceType.toUpperCase()}`);
        return;
    }
    
    userStates.set(userId, {
        action: 'create_select_server',
        serviceType,
        isEdurc,
        step: 'select_server',
        data: {}
    });

    const isResellerUser = isReseller(userId);

    const _hargaLines = isEdurc
        ? (isCloudfrontMode(isEdurc, serviceType) ? buildHargaCloudfrontLines(userId) : buildHargaEdurcLines(userId))
        : buildHargaLayananLines(userId, 'hari', [], { includeTypes: serviceType === 'ssh' ? ['ssh'] : ['xray'], accountTypeLabel: serviceType === 'ssh' ? 'SSH' : 'XRAY' });

    const modeLabel = isEdurc
        ? (isCloudfrontMode(isEdurc, serviceType) ? '☁️ Cloudfront' : '🌐 VPN EDURC')
        : '📡 Akun Reguler';

    const text = `${getHeader(getCreateModeHeader(isEdurc, serviceType))}
<blockquote><b>· Jenis Akun:</b> ${modeLabel}
<b>· Protokol:</b> ${formatServiceBold(serviceType)}

<b>LAYANAN &amp; HARGA</b>
${_hargaLines}${isResellerUser ? `\n<b>· Status: Reseller (Diskon ${getDiskonResellerPersen()}%)</b>` : ''}</blockquote>
<b>· LANGKAH 1/${getTotalSteps(serviceType)} - Pilih Server</b>
Silakan pilih server yang akan digunakan:`;

    const keyboard = getServerKeyboard(servers, `create_server`);
    await sendMenu(ctx, text, keyboard);
}

function getTotalSteps(serviceType) {
    if (serviceType === 'zivpn') {
        return 3;
    }
    return 4;
}

function getStepsOrder(serviceType) {
    if (serviceType === 'zivpn') {
        return ['input_password', 'input_days'];
    }
    return ['input_username', 'input_password', 'input_days'];
}

function getFirstStep(serviceType) {
    if (serviceType === 'zivpn') return 'input_password';
    return 'input_username';
}

function getStepNumber(serviceType, currentStep) {
    const steps = getStepsOrder(serviceType);
    const index = steps.indexOf(currentStep);
    return index + 2;
}

function getInputInstruction(serviceType, field) {
    const instructions = {
        username: ' Masukkan USERNAME untuk akun\n• Huruf/angka/underscore\n• Minimal 3 karakter, maksimal 20\nContoh: <code>user123</code>',
        password: ' Masukkan PASSWORD:\n• Ketik <code>random</code> untuk password/UUID acak otomatis\n• Atau ketik password manual (min 4 karakter)',
        days: ' Masukkan DURASI dalam HARI\n• Minimal 1 hari\nContoh: <code>30</code>'
    };
    return instructions[field] || `Masukkan ${field}`;
}

async function processCreateSelectServer(ctx, serverId, serviceType, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const server = SERVERS[serverId];
    
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        await showCreateMenu(ctx);
        return;
    }

    const slotInfo = getSlotInfo(server);
    if (slotInfo.penuh) {
        await sendMenu(ctx,
            `${getHeader(' 𝙎𝙇𝙊𝙏 𝙋𝙀𝙉𝙐𝙃')}\n\n❌ <b>Slot server "${server.name}" PENUH</b>.\n\nSilakan pilih server lain.`,
            Markup.inlineKeyboard([
                [{ text: '🔙 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙛𝙩𝙖𝙧 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: `create_back_server_list_${serviceType}_${isEdurc ? 1 : 0}`, style: 'danger' }]
            ])
        );
        return;
    }
    
    const saldoUser = getSaldo(userId);
    
    userStates.set(userId, { 
        action: 'create_input', 
        serviceType, 
        server, 
        isEdurc,
        step: getFirstStep(serviceType),
        data: {} 
    });
    
    const currentStep = getFirstStep(serviceType);
    const field = currentStep.replace('input_', '');
    
    const text = `${getHeader(getCreateModeHeader(isEdurc, serviceType))}
<blockquote><b>· Server :</b> ${server.name}
<b>· Harga:</b> ${formatHargaCreateLabel(server, userId, isEdurc)}${isReseller(userId) ? `\n<b>· Status: Reseller (Diskon ${getDiskonResellerPersen()}%)</b>` : ''}</blockquote>

<b>· LANGKAH 2/${getTotalSteps(serviceType)} - Masukkan ${field.toUpperCase()}</b>

${getInputInstruction(serviceType, field)}`;

    await sendMenu(ctx, text, cancelKeyboard());
}

async function processCreateInput(ctx, input, serviceType, server, currentStep, data, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const saldoUser = getSaldo(userId);
    
    let validated = false;
    let errorMsg = '';
    let finalValue = input.trim();
    
    if (currentStep === 'input_username') {
        if (!finalValue.match(/^[a-zA-Z0-9_]+$/)) {
            errorMsg = ' Username hanya boleh huruf, angka, dan underscore (_)';
        } else if (finalValue.length < 3 || finalValue.length > 20) {
            errorMsg = ' Username harus 3-20 karakter';
        } else {
            data.username = finalValue;
            validated = true;
        }
    }
    else if (currentStep === 'input_password') {
        if (finalValue.toLowerCase() === 'random') {
            const isXray = ['trojan','vless','vmess'].includes(serviceType);
            data.password = isXray ? require('crypto').randomUUID() : Math.random().toString(36).substring(2, 12);
            validated = true;
        } else if (finalValue.length < 4) {
            errorMsg = ' Password minimal 4 karakter';
        } else {
            data.password = finalValue;
            validated = true;
        }
    }
    else if (currentStep === 'input_days') {
        const days = parseInt(finalValue);
        if (isNaN(days) || days < 1) {
            errorMsg = ' Durasi harus angka positif (minimal 1 hari)';
        } else {
            data.days = days;
            validated = true;
        }
    }
    
    if (!validated) {
        await sendTempMessage(ctx, errorMsg + '\n\nSilakan coba lagi:');
        return false;
    }
    
    const steps = getStepsOrder(serviceType);
    const currentIndex = steps.indexOf(currentStep);
    
    if (currentIndex < steps.length - 1) {
        const nextStep = steps[currentIndex + 1];
        const nextField = nextStep.replace('input_', '');
        
        userStates.set(userId, { 
            action: 'create_input', 
            serviceType, 
            server, 
            isEdurc,
            step: nextStep,
            data: data 
        });
        
        const text = `${getHeader(getCreateModeHeader(isEdurc, serviceType))}
<blockquote><b>· Server :</b> ${server.name}
<b>· Harga:</b> ${formatHargaCreateLabel(server, userId, isEdurc)}${isReseller(userId) ? `\n<b>· Status: Reseller (Diskon ${getDiskonResellerPersen()}%)</b>` : ''}</blockquote>

<b>· LANGKAH ${getStepNumber(serviceType, nextStep)}/${getTotalSteps(serviceType)} - Masukkan ${nextField.toUpperCase()}</b>

${getInputInstruction(serviceType, nextField)}`;

        await sendMenu(ctx, text, cancelKeyboard());
        return true;
    }
    
    // ============ INI STEP TERAKHIR (input_days) → tampilkan pilih IP ============
    data.quota = getEffectiveQuota(server);

    // Simpan state tunggu pilihan IP
    userStates.set(userId, {
        action: 'create_select_ip',
        serviceType,
        server,
        isEdurc,
        data
    });

    await showIpLimitMenu(ctx, 'create_ip', data.days, false, server, isEdurc);
    return true;
}

// ====== Helper: lanjut setelah IP limit dipilih di Create ======
async function processCreateAfterIpSelect(ctx, iplimit) {
    const userId    = ctx.from.id.toString();
    const state     = userStates.get(userId);
    if (!state || state.action !== 'create_select_ip') return;

    const { serviceType, server, data, isEdurc } = state;
    const saldoUser = getSaldo(userId);

    data.iplimit = iplimit;
    const totalHargaNormal = isEdurc
        ? hitungHargaEdurc(server, data.days, iplimit)
        : hitungHargaServer(server, data.days, iplimit);
    const totalHarga = isReseller(userId) ? hitungHargaReseller(totalHargaNormal) : totalHargaNormal;
    const diskonLabel = isReseller(userId) ? `\n<b>· Harga Reseller (${getDiskonResellerPersen()}% off):</b> ${formatRp(totalHarga)}` : '';

    if (saldoUser < totalHarga) {
        const text = ` Saldo tidak cukup!

<b>· Harga :</b> ${formatRp(totalHarga)} (${data.days} hari × ${iplimit} IP)
<b>· Saldo :</b> ${formatRp(saldoUser)}
<b>· Kurang :</b> ${formatRp(totalHarga - saldoUser)}

Gunakan menu <b>Topup Saldo</b> untuk mengisi saldo.`;
        await sendTempMessage(ctx, text);
        userStates.delete(userId);
        return;
    }

    userStates.set(userId, {
        action: 'create_confirm',
        serviceType,
        server,
        data,
        isEdurc,
        totalHarga,
        step: 'confirm'
    });

    let summary = '';
    if (serviceType === 'zivpn') {
        summary = ` <b>Password:</b> <code>${data.password}</code>\n <b>Hari:</b> ${data.days}\n <b>IP Limit:</b> ${iplimit} IP`;
    } else if (serviceType === 'ssh') {
        summary = ` <b>Username:</b> <code>${data.username}</code>\n <b>Password:</b> <code>${data.password}</code>\n <b>Hari:</b> ${data.days}\n <b>IP Limit:</b> ${iplimit} IP`;
    } else {
        summary = ` <b>Username:</b> <code>${data.username}</code>\n <b>Password:</b> <code>${data.password}</code>\n <b>Hari:</b> ${data.days}\n <b>IP Limit:</b> ${iplimit} IP\n <b>Quota:</b> ${data.quota} GB`;
    }

    const confText = `${getHeader(getConfirmModeHeader(isEdurc, serviceType))}
<blockquote>${summary}

<b>· Server  : ${server.name}</b>
<b>· Harga   : ${formatHargaCreateLabel(server, userId, isEdurc)}</b>
<b>· Total Normal: ${formatRp(totalHargaNormal)}</b>${diskonLabel}
${getCdnNote(isEdurc, serviceType)}
❓ Apakah Anda yakin ingin melanjutkan?</blockquote>`;

    const confKeyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝙇𝙖𝙣𝙟𝙪𝙩𝙠𝙖𝙣', callback_data: 'create_confirm_yes' }],
        [{ text: '❌ 𝙏𝙞𝙙𝙖𝙠, 𝘽𝙖𝙩𝙖𝙡',   callback_data: 'main_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, confText, confKeyboard);
}

async function eksekusiCreate(ctx, serviceType, server, data, totalHarga, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const userName = ctx.from.first_name || ctx.from.username || 'User';
    
    if (!kurangiSaldo(userId, totalHarga)) {
        await sendTempMessage(ctx, ` Saldo tidak cukup!`);
        return;
    }
    
    // Update aktivitas reseller jika user adalah reseller
    if (isReseller(userId)) updateResellerActivity(userId);
    
    simpanTransaksi({
        txId: generateTxId(),
        userId,
        userName,
        type: 'create',
        amount: totalHarga,
        keterangan: `Create ${isEdurc ? (isCloudfrontMode(isEdurc, serviceType) ? 'CloudFront ' : 'EDURC ') : ''}${serviceType.toUpperCase()} ${data.username || data.password} ${data.days}hr`,
        waktu: new Date().toISOString(),
        status: 'success'
    });
    
    await sendTempMessage(ctx, ` Memproses...`);
    
    const module = getModule(serviceType);
    const domain = server.apiUrl.split('/')[2]?.split(':')[0] || server.name;
    
    try {
        const expiredDate = new Date();
        expiredDate.setDate(expiredDate.getDate() + data.days);
        const expiredDisplay = expiredDate.toLocaleDateString('id-ID', { day:'numeric', month:'short', year:'numeric' });
        
        let result;
        if (serviceType === 'zivpn') {
            result = await module.zivpnCreate(server, data.password, data.days, data.iplimit);
        } else if (serviceType === 'ssh') {
            result = await module.createSSH(server, data.username, data.password, data.days, data.iplimit);
        } else if (serviceType === 'trojan') {
            result = await module.createTrojan(server, data.username, data.password, data.days, data.iplimit, data.quota || 0);
        } else if (serviceType === 'vless') {
            result = await module.createVless(server, data.username, data.password, data.days, data.iplimit, data.quota || 0);
        } else if (serviceType === 'vmess') {
            result = await module.createVmess(server, data.username, data.password, data.days, data.iplimit, data.quota || 0);
        }
        
        if (result && result.success) {
            // Prioritas username dari response API agar sesuai dengan yang tersimpan di server
            const usernameFromAPI = result.data?.username || result.username;
            const akunData = {
                username: usernameFromAPI || data.username || data.password,
                password: data.password,
                uuid: result.data?.uuid || data.password,
                expired: expiredDisplay,
                iplimit: data.iplimit,
                quota: data.quota || 0,
                domain: domain,
                serviceType: serviceType,
                serverName: server.name,
                serverId: server.id,
                isEdurc: isEdurc
            };
            console.log(`[Create] ${serviceType} username saved: "${akunData.username}" (API: "${usernameFromAPI||'none'}", input: "${data.username||data.password}")`);
            
            tambahAkun(userId, akunData);

            // Notif ke grup & admin
            try {
                const kodeOrder = getKodeAkun(userId, false, false, serviceType, data.days);
                await kirimNotifikasiCreateAkun({
                    userId, userName,
                    serviceType,
                    username: akunData.username,
                    password: akunData.password,
                    serverName: server.name,
                    harga: totalHarga,
                    sisaSaldo: getSaldo(userId),
                    days: data.days,
                    iplimit: data.iplimit,
                    kode: kodeOrder,
                    isEdurc
                });
            } catch(e) {}
            
            const msg = formatCreateMessage(serviceType, akunData, server.name);
            await sendResultMessage(ctx, msg);
        } else {
            tambahSaldo(userId, totalHarga);
            await sendTempMessage(ctx, ` Gagal: ${result?.message || 'Unknown'}\n Saldo dikembalikan.`);
        }
    } catch(err) {
        tambahSaldo(userId, totalHarga);
        await sendTempMessage(ctx, ` Error: ${err.message}\n Saldo dikembalikan.`);
    }
    
    userStates.delete(userId);
}

// ==================== TRIAL ACCOUNT HANDLERS (UPDATED) ====================
async function handleTrialService(ctx, serviceType, isEdurc = false) {
    const userId = ctx.from.id.toString();
    
    // Admin & Reseller mendapatkan trial unlimited — skip pengecekan limit
    const adminTrial = isAdmin(ctx.from.id);
    const resellerTrial = isReseller(userId);
    
    if (!adminTrial && !resellerTrial && !cekBisaTrial(userId)) {
        await sendTempMessage(ctx, ` Batas trial hari ini sudah habis (max ${CONFIG.MAX_TRIAL_PER_USER}x/hari)`);
        return;
    }
    
    const servers = await getServerList(serviceType);
    
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server untuk ${serviceType.toUpperCase()}`);
        return;
    }
    
    // Langsung simpan state untuk pilih server
    userStates.set(userId, { action: 'trial_select_server', serviceType, isEdurc, step: 'select_server' });

    const isResellerUser = isReseller(userId);

    const _hargaLines = isEdurc
        ? (isCloudfrontMode(isEdurc, serviceType) ? buildHargaCloudfrontLines(userId) : buildHargaEdurcLines(userId))
        : buildHargaLayananLines(userId, 'hari', [], { includeTypes: serviceType === 'ssh' ? ['ssh'] : ['xray'], accountTypeLabel: serviceType === 'ssh' ? 'SSH' : 'XRAY' });

    const modeLabel = isEdurc
        ? (isCloudfrontMode(isEdurc, serviceType) ? '☁️ Cloudfront' : '🌐 VPN EDURC')
        : '📡 Akun Reguler';

    const text = `${getHeader(getTrialModeHeader(isEdurc, serviceType))}
<blockquote><b>· Jenis Akun:</b> ${modeLabel}
<b>· Protokol:</b> ${formatServiceBold(serviceType)}

<b>LAYANAN &amp; HARGA</b>
${_hargaLines}${isResellerUser ? `\n<b>· Status: Reseller (Diskon ${getDiskonResellerPersen()}%)</b>` : ''}</blockquote>
<b>· Pilih Server</b>

Durasi trial: <b>${CONFIG.MAX_TRIAL_MENIT} menit</b>
${getCdnNote(isEdurc, serviceType)}
Silakan pilih server yang akan digunakan:`;
    
    const keyboard = getServerKeyboard(servers, `trial_server`);
    await sendMenu(ctx, text, keyboard);
}

async function processTrialSelectServer(ctx, serverId, serviceType, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const server = SERVERS[serverId];
    
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        await showTrialMenu(ctx);
        return;
    }

    // Trial TIDAK dihitung ke slot terpakai (sifatnya sementara), TAPI kalau
    // server sudah PENUH oleh akun reguler, tetap harus ditolak — server fisik
    // memang sudah tidak ada kapasitas riil, trial pun akan gagal/numpuk di sana.
    const slotInfo = getSlotInfo(server);
    if (slotInfo.penuh) {
        await sendMenu(ctx,
            `${getHeader(' 𝙎𝙇𝙊𝙏 𝙋𝙀𝙉𝙐𝙃')}\n\n❌ <b>Slot server "${server.name}" PENUH</b>.\n\nSilakan pilih server lain untuk trial.`,
            Markup.inlineKeyboard([
                [{ text: '🔙 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙛𝙩𝙖𝙧 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: `trial_back_server_list_${serviceType}_${isEdurc ? 1 : 0}`, style: 'danger' }]
            ])
        );
        return;
    }
    
    // Langsung eksekusi trial tanpa konfirmasi dan pilihan durasi
    await eksekusiTrial(ctx, CONFIG.MAX_TRIAL_MENIT, serviceType, server, isEdurc);
}

async function eksekusiTrial(ctx, duration, serviceType, server, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const module = getModule(serviceType);
    const timestamp = Date.now().toString().slice(-6);
    const username = `trial${timestamp}`;
    const domain = server.apiUrl.split('/')[2]?.split(':')[0] || server.name;
    
    await sendTempMessage(ctx, ` Membuat trial account ${duration} menit...`);
    
    try {
        let result;
        if (serviceType === 'ssh') {
            result = await module.trialSSH(server, username, duration);
        } 
        else if (serviceType === 'trojan') {
            result = await module.trialTrojan(server, username, duration);
        } 
        else if (serviceType === 'vless') {
            // Module trialVless seharusnya sudah generate UUID sendiri
            result = await module.trialVless(server, username, duration);
        } 
        else if (serviceType === 'vmess') {
            // Module trialVmess seharusnya sudah generate UUID sendiri
            result = await module.trialVmess(server, username, duration);
        } 
        else if (serviceType === 'zivpn') {
            const pw = `trial${Math.random().toString(36).substring(2, 10)}`;
            result = await module.zivpnCreate(server, pw, 1, 1);
            if (result?.success) result.data = { password: pw, username: pw };
        }
        
        if (result && result.success) {
            // Admin & Reseller tidak dicatat di counter trial (unlimited)
            if (!isAdmin(parseInt(userId)) && !isReseller(userId)) catatTrial(userId);
            const expiredDate = new Date();
            expiredDate.setMinutes(expiredDate.getMinutes() + duration);
            const expiredDisplay = expiredDate.toLocaleString('id-ID', { timeZone:'Asia/Jakarta', day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
            
            //  PERBAIKAN DI SINI 
            // Untuk VLESS dan VMESS, UUID harus dari response API, bukan dari password
            let uuid = result.data?.uuid || result.uuid;
            let password = result.data?.password || username;
            
            // Jika UUID tidak ada di response, generate sendiri
            if ((serviceType === 'vless' || serviceType === 'vmess') && !uuid) {
                const { randomUUID } = require('crypto');
                uuid = randomUUID();
                console.log(` UUID not in response, generated: ${uuid}`);
            }
            
            // Prioritas username dari response API
            const usernameFromAPI = result.data?.username || result.username;
            const finalUsername = usernameFromAPI || username;

            const akunData = {
                username: finalUsername,
                password: password,
                uuid: uuid,
                expired: expiredDisplay,
                iplimit: 1,
                quota: 1,
                duration_minutes: duration,
                domain: domain,
                serviceType: serviceType,
                serverName: server.name,
                serverId: server.id,
                isEdurc: isEdurc
            };
            
            if (serviceType === 'zivpn') {
                akunData.username = password;
                akunData.password = password;
                akunData.uuid = password;
            }
            
            // Debug log
            console.log(` Trial ${serviceType} created:`);
            console.log(`   Username (input) : ${username}`);
            console.log(`   Username (API)   : ${usernameFromAPI || 'none'}`);
            console.log(`   Username (saved) : ${finalUsername}`);
            console.log(`   UUID             : ${uuid}`);
            console.log(`   Password         : ${password}`);
            
            tambahAkun(userId, { ...akunData, isTrial: true });

            // Notif ke grup & admin
            try {
                const kodeTrial = getKodeAkun(userId, false, true, serviceType);
                await kirimNotifikasiTrial({
                    userId,
                    userName: ctx.from.first_name || ctx.from.username || 'User',
                    serviceType,
                    identifier: akunData.username || akunData.password,
                    serverName: server.name,
                    durasi: duration,
                    kode: kodeTrial,
                    isEdurc
                });
            } catch(e) {}
            
            const msg = formatTrialMessage(serviceType, akunData, server.name);
            await sendResultMessage(ctx, msg);
        } else {
            await sendTempMessage(ctx, ` Gagal trial: ${result?.message || 'Unknown'}`);
        }
    } catch(err) {
        console.error(`Trial error: ${err.message}`);
        await sendTempMessage(ctx, ` Error: ${err.message}`);
    }
    
    userStates.delete(userId);
}

async function showTrialMenu(ctx) {
    const serverCount = Object.keys(SERVERS).length;
    
    if (serverCount === 0) {
        const text = `${getHeader(' 𝘽𝙀𝙇𝙐𝙈 𝘼𝘿𝘼 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b>· Anda belum menambahkan server.</b>
<b>· Silakan tambah server terlebih dahulu.</b>
<b></b>
<b>· Cara menambah server:</b>
<b>· 1. Kirim /dashboard</b>
<b>· 2. Pilih "Server Management"</b>
<b>· 3. Pilih "Tambah Server"</b>
<b>· 4. Ikuti petunjuk step by step</b></blockquote>`;
        
        const keyboard = Markup.inlineKeyboard([
            [{ text: '🛡 𝘼𝙙𝙢𝙞𝙣 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard' }],
            [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'main_menu', style: 'danger' }]
        ]);
        
        await sendMenu(ctx, text, keyboard);
        return;
    }
    
    const text = `<b> Pilih layanan untuk TRIAL (${CONFIG.MAX_TRIAL_MENIT} menit):</b>`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔑 𝙎𝙎𝙃', callback_data: 'trial_ssh' }, { text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: 'trial_trojan' }],
        [{ text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: 'trial_vless' }, { text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: 'trial_vmess' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'reguler_menu', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

// ==================== RENEW ACCOUNT HANDLERS ====================
// ==================== RENEW ACCOUNT HANDLERS (STEP BY STEP, AUTO-DETECT SERVER) ====================
// Catatan: Renew TIDAK lagi minta user pilih server secara manual. User cukup pilih
// mode akun (Reguler/Cloudfront untuk SSH, Reguler/EDURC untuk Trojan/VLess/VMess),
// lalu masukkan username — server & data akun otomatis dideteksi dari akun.json
// (lihat findAkunForRenew). Ini juga otomatis membedakan harga reguler vs EDURC/Cloudfront.

// Label tampilan untuk tiap mode, per serviceType
function getRenewModeLabel(serviceType, isEdurc) {
    if (serviceType === 'ssh') return isEdurc ? '☁️ Cloudfront' : '🔑 Akun Reguler';
    return isEdurc ? '🌐 VPN EDURC' : '📡 Reguler';
}

// Menu pilihan mode akun sebelum input target (langkah baru, menggantikan pilih server)
async function showRenewModeMenu(ctx, serviceType) {
    const userId = ctx.from.id.toString();
    const isResellerUser = isReseller(userId);
    const _hargaLines = buildHargaLayananLines(userId, 'hari', [], { includeTypes: serviceType === 'ssh' ? ['ssh'] : ['xray'], accountTypeLabel: serviceType === 'ssh' ? 'SSH' : 'XRAY' });
    const _hargaLinesAlt = serviceType === 'ssh' ? buildHargaCloudfrontLines(userId) : buildHargaEdurcLines(userId);

    // Hilangkan baris separator + "Tambah IP" di akhir masing-masing blok agar tidak duplikat
    const stripTail = (str) => str.replace(/\n──────────────────────\n<b>· Tambah IP:<\/b>.*$/s, '');
    const hargaUtama = stripTail(_hargaLines);
    const hargaAlt = stripTail(_hargaLinesAlt);
    const tambahIpLine = `<b>· Tambah IP:</b> +Rp ${getHargaTambahIpPerHari()}/hari`;

    const text = `${getHeader(` 𝙍𝙀𝙉𝙀𝙒 ${formatServiceBold(serviceType)}`)}
<blockquote><b>LAYANAN &amp; HARGA</b>
${hargaUtama}
──────────────────────
${hargaAlt}
──────────────────────
${tambahIpLine}${isResellerUser ? `\n<b>· Status: Reseller (Diskon ${getDiskonResellerPersen()}%)</b>` : ''}</blockquote>
<b>· Pilih jenis akun yang akan diperpanjang:</b>`;

    const keyboard = serviceType === 'ssh'
        ? Markup.inlineKeyboard([
            [{ text: '🔑 𝘼𝙠𝙪𝙣 𝙍𝙚𝙜𝙪𝙡𝙚𝙧', callback_data: `renew_mode_${serviceType}_reg` }],
            [{ text: '☁️ 𝘾𝙡𝙤𝙪𝙙𝙛𝙧𝙤𝙣𝙩', callback_data: `renew_mode_${serviceType}_edu` }],
            [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'renew_menu', style: 'danger' }]
        ])
        : Markup.inlineKeyboard([
            [{ text: '📡 𝙍𝙚𝙜𝙪𝙡𝙚𝙧', callback_data: `renew_mode_${serviceType}_reg` }],
            [{ text: '🌐 𝙑𝙋𝙉 𝙀𝘿𝙐𝙍𝘾', callback_data: `renew_mode_${serviceType}_edu` }],
            [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'renew_menu', style: 'danger' }]
        ]);

    await sendMenu(ctx, text, keyboard);
}

async function handleRenewService(ctx, serviceType, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const servers = await getServerList(serviceType);

    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server untuk ${serviceType.toUpperCase()}`);
        return;
    }

    userStates.set(userId, {
        action: 'renew_select_server',
        serviceType,
        isEdurc,
        step: 'select_server',
        data: {}
    });

    let hargaBlock = '';
    if (serviceType !== 'zivpn') {
        const isResellerUser = isReseller(userId);
        const _hargaLines = buildHargaLayananLines(userId, 'hari', [], { includeTypes: serviceType === 'ssh' ? ['ssh'] : ['xray'], accountTypeLabel: serviceType === 'ssh' ? 'SSH' : 'XRAY' });
        const stripTail = (str) => str.replace(/\n──────────────────────\n<b>· Tambah IP:<\/b>.*$/s, '');
        const hargaUtama = stripTail(_hargaLines);
        const tambahIpLine = `<b>· Tambah IP:</b> +Rp ${getHargaTambahIpPerHari()}/hari`;
        hargaBlock = `<blockquote><b>LAYANAN &amp; HARGA</b>
${hargaUtama}
──────────────────────
${tambahIpLine}${isResellerUser ? `\n<b>· Status: Reseller (Diskon ${getDiskonResellerPersen()}%)</b>` : ''}</blockquote>
`;
    }

    const text = `${getHeader(` 𝙍𝙀𝙉𝙀𝙒 ${formatServiceBold(serviceType)}`)}
${hargaBlock}<b>· LANGKAH 1/3 - Pilih Server</b>
Silakan pilih server tempat akun Anda berada:`;

    const keyboard = getServerKeyboard(servers, 'renew_server');
    await sendMenu(ctx, text, keyboard);
}

async function processRenewSelectServer(ctx, serverId, serviceType, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const server = SERVERS[serverId];

    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan!`);
        await showRenewMenu(ctx);
        return;
    }

    userStates.set(userId, {
        action: 'renew_input',
        serviceType,
        isEdurc,
        server,
        step: 'input_target',
        data: {}
    });

    const modeLabel = getRenewModeLabel(serviceType, isEdurc);

    const text = `${getHeader(` 𝙍𝙀𝙉𝙀𝙒 ${formatServiceBold(serviceType)}`)}
<blockquote><b>· Server :</b> ${server.name}
<b>· Jenis Akun :</b> ${modeLabel}</blockquote>

<b>· LANGKAH 2/3 - Masukkan TARGET AKUN</b>

${getRenewInstruction(serviceType, 'target')}`;

    await sendMenu(ctx, text, cancelKeyboard());
}

function getRenewInstruction(serviceType, field) {
    if (field === 'target') {
        if (serviceType === 'zivpn') {
            return ' Masukkan PASSWORD akun yang akan diperpanjang\nContoh: <code>mypass123</code>';
        }
        return ' Masukkan USERNAME akun yang akan diperpanjang\nContoh: <code>user123</code>';
    }
    if (field === 'days') {
        return ' Masukkan TAMBAHAN HARI\n• Minimal 1 hari\nContoh: <code>30</code>';
    }
    return `Masukkan ${field}`;
}

async function processRenewInput(ctx, input, serviceType, isEdurc, currentStep, data, server) {
    const userId = ctx.from.id.toString();

    let validated = false;
    let errorMsg = '';
    let finalValue = input.trim();

    if (currentStep === 'input_target') {
        if (finalValue.length < 3) {
            errorMsg = ' Target akun terlalu pendek (minimal 3 karakter)';
        } else {
            data.target = finalValue;
            validated = true;
        }
    }
    else if (currentStep === 'input_days') {
        const days = parseInt(finalValue);
        if (isNaN(days) || days < 1) {
            errorMsg = ' Durasi harus angka positif (minimal 1 hari)';
        } else {
            data.days = days;
            validated = true;
        }
    }

    if (!validated) {
        await sendTempMessage(ctx, errorMsg + '\n\nSilakan coba lagi:');
        return false;
    }

    const modeLabel = getRenewModeLabel(serviceType, isEdurc);

    if (currentStep === 'input_target') {
        // Cari akun yang cocok DI SERVER yang sudah dipilih user secara manual
        const found = findAkunForRenew(userId, serviceType, isEdurc, data.target, server ? server.id : null);

        if (!found) {
            await sendTempMessage(ctx,
                ` Akun <code>${data.target}</code> dengan jenis "${modeLabel}" tidak ditemukan di server <b>${server ? server.name : '-'}</b>.\n\n` +
                `Pastikan username &amp; server yang dipilih sudah benar.`);
            userStates.delete(userId);
            return false;
        }

        data.server = server || found.server;

        userStates.set(userId, {
            action: 'renew_input',
            serviceType,
            isEdurc,
            server: data.server,
            step: 'input_days',
            data
        });

        const hargaLabel = formatHargaCreateLabel(data.server, userId, isEdurc);

        const text = `${getHeader(` 𝙍𝙀𝙉𝙀𝙒 ${formatServiceBold(serviceType)}`)}
<blockquote><b>· Jenis Akun :</b> ${modeLabel}
<b>· Akun :</b> <code>${data.target}</code>
<b>· Server :</b> ${data.server.name}
<b>· Harga:</b> ${hargaLabel}${isReseller(userId) ? `\n<b>· Status: Reseller (Diskon ${getDiskonResellerPersen()}%)</b>` : ''}</blockquote>

<b>· LANGKAH 3/3 - Masukkan TAMBAHAN HARI</b>

${getRenewInstruction(serviceType, 'days')}`;

        await sendMenu(ctx, text, cancelKeyboard());
        return true;
    }

    // Step terakhir (days) → tampilkan pilih IP
    userStates.set(userId, {
        action: 'renew_select_ip',
        serviceType,
        isEdurc,
        server: data.server,
        data
    });

    await showIpLimitMenu(ctx, 'renew_ip', data.days, false, data.server, isEdurc);
    return true;
}

// ====== Helper: lanjut setelah IP limit dipilih di Renew ======
async function processRenewAfterIpSelect(ctx, iplimit) {
    const userId    = ctx.from.id.toString();
    const state     = userStates.get(userId);
    if (!state || state.action !== 'renew_select_ip') return;

    const { serviceType, server, data, isEdurc } = state;
    const saldoUser = getSaldo(userId);

    const totalHargaNormalRenew = isEdurc
        ? hitungHargaEdurc(server, data.days, iplimit)
        : hitungHargaServer(server, data.days, iplimit);
    const totalHarga = isReseller(userId) ? hitungHargaReseller(totalHargaNormalRenew) : totalHargaNormalRenew;
    const diskonLabelRenew = isReseller(userId) ? `\n<b>· Harga Reseller (${getDiskonResellerPersen()}% off):</b> ${formatRp(totalHarga)}` : '';
    const modeLabel = getRenewModeLabel(serviceType, isEdurc);

    if (saldoUser < totalHarga) {
        await sendTempMessage(ctx, ` Saldo tidak cukup!\n\n<b>· Harga:</b> ${formatRp(totalHarga)} (${data.days} hari × ${iplimit} IP)\n<b>· Saldo:</b> ${formatRp(saldoUser)}\n<b>· Kurang:</b> ${formatRp(totalHarga - saldoUser)}`);
        userStates.delete(userId);
        return;
    }

    userStates.set(userId, {
        action: 'renew_confirm',
        serviceType,
        isEdurc,
        server,
        data,
        totalHarga,
        iplimit,
        step: 'confirm'
    });

    const text = `${getHeader(' 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙍𝙀𝙉𝙀𝙒')}
${serviceType.toUpperCase()} – ${modeLabel}

Target: <code>${data.target}</code>
 Tambah Hari: ${data.days}
 IP Limit: ${iplimit} IP

<b>· Server terdeteksi : ${server.name}</b>
<b>· Harga   : ${formatHargaCreateLabel(server, userId, isEdurc)}</b>
<b>· Total Normal: ${formatRp(totalHargaNormalRenew)}</b>${diskonLabelRenew}

Apakah Anda yakin ingin melanjutkan?`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝙇𝙖𝙣𝙟𝙪𝙩𝙠𝙖𝙣', callback_data: 'renew_confirm_yes' }],
        [{ text: '❌ 𝙏𝙞𝙙𝙖𝙠, 𝘽𝙖𝙩𝙖𝙡',   callback_data: 'main_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function eksekusiRenew(ctx, serviceType, server, data, totalHarga, isEdurc = false) {
    const userId = ctx.from.id.toString();
    const userName = ctx.from.first_name || ctx.from.username || 'User';
    
    if (!kurangiSaldo(userId, totalHarga)) {
        await sendTempMessage(ctx, ` Saldo tidak cukup!`);
        return;
    }
    
    // Update aktivitas reseller jika user adalah reseller
    if (isReseller(userId)) updateResellerActivity(userId);
    
    simpanTransaksi({
        txId: generateTxId(), 
        userId, 
        userName: userName,
        type: 'renew', 
        amount: totalHarga,
        keterangan: `Renew ${isEdurc ? (isCloudfrontMode(isEdurc, serviceType) ? 'Cloudfront ' : 'EDURC ') : ''}${serviceType.toUpperCase()} ${data.target} +${data.days}hr`,
        waktu: new Date().toISOString(), 
        status: 'success'
    });
    
    await sendTempMessage(ctx, ` Memproses renew...`);
    const module = getModule(serviceType);
    
    try {
        let result;
        if (serviceType === 'ssh') result = await module.renewSSH(server, data.target, data.days);
        else if (serviceType === 'trojan') result = await module.renewTrojan(server, data.target, data.days);
        else if (serviceType === 'vless') result = await module.renewVless(server, data.target, data.days);
        else if (serviceType === 'vmess') result = await module.renewVmess(server, data.target, data.days);
        else if (serviceType === 'zivpn') result = await module.zivpnRenew(server, data.target, data.days);
        
        if (result && result.success) {
            // Update tanggal expired di akun.json agar sinkron dengan masa aktif yang baru.
            // Kalau akun ketemu di akun.json, pakai hasil hitungan lokal ini (lebih bisa diandalkan
            // daripada format old_expired/new_expired dari API yang berbeda-beda tiap modul).
            const updatedAkun = updateAkunExpiredAfterRenew(userId, serviceType, server, data.target, data.days);

            const oldExpired = updatedAkun?.oldExpired || result.data?.old_expired || '-';
            const newExpired = updatedAkun?.newExpired || result.data?.new_expired || data.days + ' days added';

            // Notif ke grup & admin
            try {
                const kodeRenew = getKodeRenew(userId);
                await kirimNotifikasiRenew({
                    userId, userName,
                    serviceType,
                    identifier: data.target,
                    serverName: server.name,
                    harga: totalHarga,
                    sisaSaldo: getSaldo(userId),
                    days: data.days,
                    iplimit: CONFIG.DEFAULT_IP_LIMIT,
                    kode: kodeRenew,
                    isEdurc
                });
            } catch(e) {}
            
            const msg = formatRenewMessage(serviceType, {
                target: data.target,
                iplimit: CONFIG.DEFAULT_IP_LIMIT,
                old_expired: oldExpired,
                new_expired: newExpired,
                days_added: data.days,
                isEdurc
            });
            
            await sendResultMessage(ctx, msg);
        } else {
            tambahSaldo(userId, totalHarga);
            await sendTempMessage(ctx, ` Gagal: ${result?.message || 'Unknown'}\n Saldo dikembalikan.`);
        }
    } catch(err) {
        tambahSaldo(userId, totalHarga);
        await sendTempMessage(ctx, ` Error: ${err.message}\n Saldo dikembalikan.`);
    }
    
    userStates.delete(userId);
}

async function showRenewMenu(ctx) {
    const serverCount = Object.keys(SERVERS).length;
    
    if (serverCount === 0) {
        const text = `${getHeader(' 𝘽𝙀𝙇𝙐𝙈 𝘼𝘿𝘼 𝙎𝙀𝙍𝙑𝙀𝙍')}
<blockquote><b>· Anda belum menambahkan server.</b>
<b>· Silakan tambah server terlebih dahulu.</b>
<b></b>
<b>· Cara menambah server:</b>
<b>· 1. Kirim /dashboard</b>
<b>· 2. Pilih "Server Management"</b>
<b>· 3. Pilih "Tambah Server"</b>
<b>· 4. Ikuti petunjuk step by step</b></blockquote>`;
        
        const keyboard = Markup.inlineKeyboard([
            [{ text: '🛡 𝘼𝙙𝙢𝙞𝙣 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard' }],
            [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'main_menu', style: 'danger' }]
        ]);
        
        await sendMenu(ctx, text, keyboard);
        return;
    }
    
    const text = `${getHeader(' 𝙍𝙀𝙉𝙀𝙒 𝘼𝙆𝙐𝙉')}
<blockquote>🔧 Pilih protokol akun yang ingin diperpanjang. Detail <b>layanan &amp; harga</b> akan ditampilkan setelah Anda memilih protokol.</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔑 𝙎𝙎𝙃', callback_data: 'renew_ssh' }, { text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: 'renew_trojan' }],
        [{ text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: 'renew_vless' }, { text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: 'renew_vmess' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'reguler_menu', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, text, keyboard);
}

// ==================== TOPUP SALDO ====================
async function handleTopup(ctx) {
    const userId = ctx.from.id.toString();
    
    const qrisAktif    = !!QRIS_STATIS && QRIS_DINAMIS_AKTIF;
    const pakasirBisa  = PAKASIR_AKTIF && !!PAKASIR_API_KEY && !!PAKASIR_SLUG;
    const danaBisa     = DANA_AKTIF && !!DANA_NOMOR && !!DANA_NAMA;
    const gopayBisa    = GOPAY_AKTIF && !!GOPAY_NOMOR && !!GOPAY_NAMA;

    const jumlahMetode = [qrisAktif, pakasirBisa, danaBisa, gopayBisa].filter(Boolean).length;

    // Jika lebih dari satu metode aktif → tampilkan pilihan
    if (jumlahMetode > 1) {
        const firstName = ctx.from.first_name || 'User';
        const text = `${getHeader(' 𝙏𝙊𝙋𝙐𝙋 𝙎𝘼𝙇𝘿𝙊')}
<blockquote><b>· User :</b> ${firstName}
<b>· Min. Topup :</b> ${formatRp(CONFIG.MIN_TOPUP)}</blockquote>

Pilih metode pembayaran:`;
        const buttons = [];
        if (qrisAktif)   buttons.push([{ text: '💵 𝙌𝙍𝙄𝙎',      callback_data: 'topup_via_qris' }]);
        if (pakasirBisa) buttons.push([{ text: '💵 𝙌𝙍𝙄𝙎 𝙋𝙖𝙠𝙖𝙨𝙞𝙧',      callback_data: 'topup_via_pakasir' }]);
        if (danaBisa)    buttons.push([{ text: '💵 𝘿𝘼𝙉𝘼',              callback_data: 'topup_via_dana' }]);
        if (gopayBisa)   buttons.push([{ text: '💵 𝙂𝙊𝙋𝘼𝙔',             callback_data: 'topup_via_gopay' }]);
        buttons.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'main_menu', style: 'danger' }]);
        const keyboard = Markup.inlineKeyboard(buttons);
        await sendMenu(ctx, text, keyboard);
        return;
    }

    // Hanya Pakasir yang aktif
    if (pakasirBisa && !qrisAktif && !danaBisa && !gopayBisa) {
        await handleTopupInput(ctx, 'pakasir');
        return;
    }
    // Hanya DANA yang aktif
    if (danaBisa && !qrisAktif && !pakasirBisa && !gopayBisa) {
        await handleTopupInput(ctx, 'dana');
        return;
    }
    // Hanya GoPay yang aktif
    if (gopayBisa && !qrisAktif && !pakasirBisa && !danaBisa) {
        await handleTopupInput(ctx, 'gopay');
        return;
    }

    // Default: QRIS saja (atau tidak ada keduanya)
    await handleTopupInput(ctx, 'qris');
}

// Preset nominal cepat untuk topup (bisa disesuaikan)
const TOPUP_PRESET_AMOUNTS = [5000, 10000, 20000, 50000, 100000, 200000];

async function handleTopupInput(ctx, metode = 'qris') {
    const userId = ctx.from.id.toString();
    
    userStates.set(userId, { action: 'topup', step: 'input_amount', metode, input: '' });
    
    await renderTopupNumpad(ctx);
}

function metodeLabelTopup(metode) {
    if (metode === 'pakasir') return ' Pakasir';
    if (metode === 'dana')    return ' DANA';
    if (metode === 'gopay')   return ' GOPAY';
    return ' QRIS';
}

// Keyboard tombol "Menu Utama" untuk pesan hasil topup (berhasil / dibatalkan)
function mainMenuKeyboard() {
    return Markup.inlineKeyboard([
        [{ text: '🏠 𝙈𝙚𝙣𝙪 𝙐𝙩𝙖𝙢𝙖', callback_data: 'main_menu' }]
    ]);
}

// Render UI kalkulator nominal topup (numpad + preset + batal/lanjut)
async function renderTopupNumpad(ctx) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'topup' || state.step !== 'input_amount') return;

    const firstName = ctx.from.first_name || 'User';
    const input = state.input || '';
    const amount = input ? parseInt(input) : 0;
    const preview = input ? formatRp(amount) : 'Rp 0';

    const text = `${getHeader(' 𝙏𝙊𝙋𝙐𝙋 𝙎𝘼𝙇𝘿𝙊')}
<blockquote><b>· User :</b> ${firstName}
<b>· Min. Topup :</b> ${formatRp(CONFIG.MIN_TOPUP)}
<b>· Metode :</b> ${metodeLabelTopup(state.metode)}</blockquote>

Masukkan nominal topup:
<b>${preview}</b>

Gunakan tombol angka di bawah, atau pilih nominal cepat.`;

    const presetButtons = [];
    for (let i = 0; i < TOPUP_PRESET_AMOUNTS.length; i += 3) {
        presetButtons.push(
            TOPUP_PRESET_AMOUNTS.slice(i, i + 3).map(amt => ({
                text: formatRp(amt).replace('Rp', '').trim(),
                callback_data: `topup_preset_${amt}`
            }))
        );
    }

    const keyboard = Markup.inlineKeyboard([
        ...presetButtons,
        [{ text: '1', callback_data: 'topup_num_1' }, { text: '2', callback_data: 'topup_num_2' }, { text: '3', callback_data: 'topup_num_3' }],
        [{ text: '4', callback_data: 'topup_num_4' }, { text: '5', callback_data: 'topup_num_5' }, { text: '6', callback_data: 'topup_num_6' }],
        [{ text: '7', callback_data: 'topup_num_7' }, { text: '8', callback_data: 'topup_num_8' }, { text: '9', callback_data: 'topup_num_9' }],
        [{ text: '000', callback_data: 'topup_num_000' }, { text: '0', callback_data: 'topup_num_0' }, { text: '⌫', callback_data: 'topup_num_del' }],
        [{ text: '🗑 𝙃𝙖𝙥𝙪𝙨', callback_data: 'topup_num_clear' }, { text: '✅ 𝙇𝙖𝙣𝙟𝙪𝙩', callback_data: 'topup_num_confirm' }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'topup_num_cancel', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function processTopupAmount(ctx, amount) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    const metode = (state && state.metode) || 'qris';
    
    if (amount < CONFIG.MIN_TOPUP) {
        await sendTempMessage(ctx, ` Minimal topup ${formatRp(CONFIG.MIN_TOPUP)}`);
        return false;
    }
    
    userStates.delete(userId);

    if (metode === 'pakasir') {
        await processTopupPakasir(ctx, amount);
    } else if (metode === 'dana') {
        await processTopupDana(ctx, amount);
    } else if (metode === 'gopay') {
        await processTopupGopay(ctx, amount);
    } else {
        await processTopupPayment(ctx, amount);
    }
    return true;
}

async function processTopupPayment(ctx, amount) {
    const userId = ctx.from.id.toString();
    const txId = generateTxId();
    const expiresAt = Date.now() + 5 * 60 * 1000;
    const firstName = ctx.from.first_name || 'User';
    const chatId = ctx.chat.id;
    
    // Hitung fee QRIS jika dikonfigurasi
    const feeQris     = CONFIG.QRIS_FEE_PERSEN > 0 ? Math.ceil(amount * CONFIG.QRIS_FEE_PERSEN / 100) : 0;
    const totalQris   = amount + feeQris;

    pendingQRIS.set(userId, { amount, txId, expiresAt, chatId, userName: firstName, qrisMessageId: null, createdAt: Date.now(), totalBayar: totalQris });
    
    const waitingMsg = await sendTempMessage(ctx, `⏳ Proses...`);
    
    try {
        const qrString = await generateQRISDinamis(totalQris);
        console.log(' QRIS string received, length:', qrString.length);
        
        const qrBuffer = await generateQRCodeWithCenterIcon(qrString, QRIS_CENTER_ICON);

        const feeRowQris = feeQris > 0
            ? `\n<b>· Fee QRIS :</b> ${formatRp(feeQris)}`
            : '';

        const langkahQris = CEK_PEMBAYARAN_MODE === 'button'
            ? `<b>Langkah:</b>
1. Scan QR code di atas
2. Lakukan pembayaran sebesar ${formatRp(totalQris)}
3. Setelah bayar, tekan tombol <b>🔍 Cek Status Pembayaran</b> di bawah

✅ Saldo akan masuk setelah pembayaran dikonfirmasi`
            : `<b>Langkah:</b>
1. Scan QR code di atas
2. Lakukan pembayaran sebesar ${formatRp(totalQris)}
3. Kirim screenshot bukti pembayaran KE CHAT INI

✅ Saldo akan otomatis masuk setelah bukti dikirim`;
        
        const caption = `${getHeader(' 𝙋𝙀𝙈𝘽𝘼𝙔𝘼𝙍𝘼𝙉 𝙌𝙍𝙄𝙎')}
<blockquote><b>· Merchant :</b> ${CONFIG.MERCHANT_NAME}
<b>· Nominal Topup :</b> ${formatRp(amount)}${feeRowQris}
<b>· Total Bayar :</b> ${formatRp(totalQris)}
<b>· Kode TX :</b> ${txId}
<b>· Berlaku :</b> 5 menit

${langkahQris}</blockquote>`;

        const qrisPhotoOptions = { caption: caption, parse_mode: 'HTML' };
        if (CEK_PEMBAYARAN_MODE === 'button') {
            qrisPhotoOptions.reply_markup = {
                inline_keyboard: [
                    [{ text: '🔍 Cek Status Pembayaran', callback_data: `cekbayar_qris_${txId}` }],
                    [{ text: '❌ Batal', callback_data: `batalbayar_qris_${txId}` }]
                ]
            };
            applyButtonStyles(qrisPhotoOptions);
        }

        // Kirim QR code sebagai photo dan simpan message_id-nya
        const qrisMsg = await ctx.replyWithPhoto({ source: qrBuffer }, qrisPhotoOptions);
        
        // Hapus pesan loading
        try {
            await ctx.telegram.deleteMessage(chatId, waitingMsg.message_id);
        } catch(e) {}

        // Simpan message_id pesan QRIS agar bisa dihapus nanti
        const pending = pendingQRIS.get(userId);
        if (pending) pending.qrisMessageId = qrisMsg.message_id;
        
        // Auto-expired: hapus pesan QRIS + kirim notif
        setTimeout(async () => {
            const pending = pendingQRIS.get(userId);
            if (pending && pending.txId === txId) {
                pendingQRIS.delete(userId);

                // Hapus pesan QRIS (foto + caption)
                if (pending.qrisMessageId) {
                    try {
                        await ctx.telegram.deleteMessage(chatId, pending.qrisMessageId);
                        console.log(` Deleted expired QRIS message for TX: ${txId}`);
                    } catch(e) {
                        console.log(`[Expiry] Gagal hapus pesan QRIS: ${e.message}`);
                    }
                }

                await sendTempMessage(ctx,
                    ` <b>Waktu pembayaran telah habis!</b>\n\n` +
                    `Kode TX: <code>${txId}</code>\n` +
                    `Nominal: ${formatRp(amount)}\n\n` +
                    `Silakan lakukan topup ulang melalui menu <b>Topup Saldo</b>.`
                );
            }
        }, 5 * 60 * 1000);
        
    } catch(err) {
        pendingQRIS.delete(userId);
        console.error('QRIS Error:', err);
        await sendTempMessage(ctx, ` Gagal membuat QRIS: ${err.message}\n\nSilakan coba lagi nanti.`);
    }
}

// ==================== DANA TOPUP HANDLER ====================
async function processTopupDana(ctx, amount) {
    const userId    = ctx.from.id.toString();
    const txId      = generateTxId();
    const firstName = ctx.from.first_name || 'User';
    const chatId    = ctx.chat.id;
    const expiresAt = Date.now() + 5 * 60 * 1000;

    // Simpan sesi pending DANA
    pendingDANA.set(userId, { amount, txId, expiresAt, chatId, userName: firstName, messageId: null, createdAt: Date.now() });

    const langkahDana = CEK_PEMBAYARAN_MODE === 'button'
        ? `<b>Langkah:</b>
1. Buka aplikasi DANA
2. Transfer sebesar ${formatRp(amount)} ke nomor di atas
3. Setelah transfer berhasil, tekan tombol <b>🔍 Cek Status Pembayaran</b> di bawah

✅ Saldo akan masuk setelah pembayaran dikonfirmasi`
        : `<b>Langkah:</b>
1. Buka aplikasi DANA
2. Transfer sebesar ${formatRp(amount)} ke nomor di atas
3. Screenshot bukti transfer
4. Kirim screenshot ke chat ini

✅ Saldo akan masuk setelah bukti diverifikasi`;

    const caption = `${getHeader(' 𝙋𝙀𝙈𝘽𝘼𝙔𝘼𝙍𝘼𝙉 𝘿𝘼𝙉𝘼')}
<blockquote><b>· Nominal :</b> ${formatRp(amount)}
<b>· Kode TX :</b> <code>${txId}</code>
<b>· Berlaku :</b> 5 menit

<b>Transfer DANA ke:</b>
 <b>· No. DANA :</b> <code>${DANA_NOMOR}</code>
 <b>· Nama :</b> ${DANA_NAMA}
 <b>· Nominal :</b> <b>${formatRp(amount)}</b>

${langkahDana}</blockquote>`;

    const replyOptions = { parse_mode: 'HTML' };
    if (CEK_PEMBAYARAN_MODE === 'button') {
        replyOptions.reply_markup = {
            inline_keyboard: [
                [{ text: '🔍 Cek Status Pembayaran', callback_data: `cekbayar_dana_${txId}` }],
                [{ text: '❌ Batal', callback_data: `batalbayar_dana_${txId}` }]
            ]
        };
        applyButtonStyles(replyOptions);
    }
    const msg = await ctx.reply(caption, replyOptions);
    const pending = pendingDANA.get(userId);
    if (pending) pending.messageId = msg.message_id;

    // Auto-expired 15 menit
    setTimeout(async () => {
        const p = pendingDANA.get(userId);
        if (p && p.txId === txId) {
            pendingDANA.delete(userId);
            if (p.messageId) {
                try { await ctx.telegram.deleteMessage(chatId, p.messageId); } catch(e) {}
            }
            await sendTempMessage(ctx,
                ` <b>Waktu pembayaran DANA habis!</b>\n\n` +
                `Kode TX: <code>${txId}</code>\nNominal: ${formatRp(amount)}\n\n` +
                `Silakan topup ulang melalui menu <b>Topup Saldo</b>.`
            );
        }
    }, 5 * 60 * 1000);
}

// ==================== GOPAY TOPUP HANDLER ====================
async function processTopupGopay(ctx, amount) {
    const userId    = ctx.from.id.toString();
    const txId      = generateTxId();
    const firstName = ctx.from.first_name || 'User';
    const chatId    = ctx.chat.id;
    const expiresAt = Date.now() + 5 * 60 * 1000;

    // Simpan sesi pending GoPay
    pendingGOPAY.set(userId, { amount, txId, expiresAt, chatId, userName: firstName, messageId: null, createdAt: Date.now() });

    const langkahGopay = CEK_PEMBAYARAN_MODE === 'button'
        ? `<b>Langkah:</b>
1. Buka aplikasi Gojek / GoPay
2. Transfer sebesar ${formatRp(amount)} ke nomor di atas
3. Setelah transfer berhasil, tekan tombol <b>🔍 Cek Status Pembayaran</b> di bawah

✅ Saldo akan masuk setelah pembayaran dikonfirmasi`
        : `<b>Langkah:</b>
1. Buka aplikasi Gojek / GoPay
2. Transfer sebesar ${formatRp(amount)} ke nomor di atas
3. Screenshot bukti transfer
4. Kirim screenshot ke chat ini

✅ Saldo akan masuk setelah bukti diverifikasi`;

    const caption = `${getHeader(' 𝙋𝙀𝙈𝘽𝘼𝙔𝘼𝙍𝘼𝙉 𝙂𝙊𝙋𝘼𝙔')}
<blockquote><b>· Nominal :</b> ${formatRp(amount)}
<b>· Kode TX :</b> <code>${txId}</code>
<b>· Berlaku :</b> 5 menit

<b>Transfer GoPay ke:</b>
 <b>· No. GoPay :</b> <code>${GOPAY_NOMOR}</code>
 <b>· Nama :</b> ${GOPAY_NAMA}
 <b>· Nominal :</b> <b>${formatRp(amount)}</b>

${langkahGopay}</blockquote>`;

    const replyOptions = { parse_mode: 'HTML' };
    if (CEK_PEMBAYARAN_MODE === 'button') {
        replyOptions.reply_markup = {
            inline_keyboard: [
                [{ text: '🔍 Cek Status Pembayaran', callback_data: `cekbayar_gopay_${txId}` }],
                [{ text: '❌ Batal', callback_data: `batalbayar_gopay_${txId}` }]
            ]
        };
        applyButtonStyles(replyOptions);
    }
    const msg = await ctx.reply(caption, replyOptions);
    const pending = pendingGOPAY.get(userId);
    if (pending) pending.messageId = msg.message_id;

    // Auto-expired 15 menit
    setTimeout(async () => {
        const p = pendingGOPAY.get(userId);
        if (p && p.txId === txId) {
            pendingGOPAY.delete(userId);
            if (p.messageId) {
                try { await ctx.telegram.deleteMessage(chatId, p.messageId); } catch(e) {}
            }
            await sendTempMessage(ctx,
                ` <b>Waktu pembayaran GoPay habis!</b>\n\n` +
                `Kode TX: <code>${txId}</code>\nNominal: ${formatRp(amount)}\n\n` +
                `Silakan topup ulang melalui menu <b>Topup Saldo</b>.`
            );
        }
    }, 5 * 60 * 1000);
}

// ==================== HANDLER BUKTI FOTO DANA / GOPAY ====================
async function handlePaymentProofDana(ctx) {
    const userId    = ctx.from.id.toString();
    const pending   = pendingDANA.get(userId);
    if (!pending) return;

    const { amount, txId, expiresAt, chatId, userName } = pending;
    const firstName = ctx.from.first_name || userName || 'User';

    // Cek expired
    if (Date.now() > expiresAt) {
        pendingDANA.delete(userId);
        await sendTempMessage(ctx, ` Sesi pembayaran DANA sudah kadaluarsa. Silakan topup ulang.`);
        return;
    }

    // Download gambar
    const photos = ctx.message.photo;
    const fileId  = photos[photos.length - 1].file_id;
    let imageBuffer;
    try {
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const response = await axios.get(fileLink.href, { responseType: 'arraybuffer' });
        imageBuffer = Buffer.from(response.data);
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal mengunduh gambar: ${e.message}`);
        return;
    }

    // Cek keunikan hash gambar
    const base64Data  = imageBuffer.toString('base64');
    const uniqueCheck = validateImageUniqueness(base64Data);
    if (!uniqueCheck.isValid) {
        try { await ctx.telegram.deleteMessage(chatId, ctx.message.message_id); } catch(e) {}
        await sendTempMessage(ctx, uniqueCheck.message);
        return;
    }

    // OCR validasi (sama dengan QRIS)
    let ocrBank = 'DANA', ocrTgl = null, ocrJumlah = null;
    try {
        const result = await validateBuktiTransfer(imageBuffer, amount);
        if (!result.isValid) {
            try { await ctx.telegram.deleteMessage(chatId, ctx.message.message_id); } catch(e) {}
            await sendTempMessage(ctx, ` Gambar tidak valid\n\nSilakan kirim ulang screenshot bukti pembayaran yang sesuai.`);
            return;
        }
        ocrBank   = result.bank   || 'DANA';
        ocrTgl    = result.tanggal;
        ocrJumlah = result.jumlah;
    } catch(e) {
        console.log('[DANA Bukti] OCR error (lanjut approve):', e.message);
    }

    // Sukses — proses saldo
    pendingDANA.delete(userId);
    markImageHashUsed(uniqueCheck.hash);

    // Hapus pesan instruksi DANA
    if (pending.messageId) {
        try { await ctx.telegram.deleteMessage(chatId, pending.messageId); } catch(e) {}
    }

    const bonusInfo = hitungBonusTopup(amount);
    const newSaldo = tambahSaldo(userId, amount + bonusInfo.bonus);
    simpanTransaksi({
        txId: generateTxId(), userId, userName: firstName,
        type: 'topup', amount,
        keterangan: `Topup via DANA oleh ${firstName}${bonusInfo.bonus > 0 ? ` (+bonus ${bonusInfo.persen}% = ${formatRp(bonusInfo.bonus)})` : ''}`,
        waktu: new Date().toISOString(), status: 'success'
    });

    await sendMenu(ctx,
        `<b>· TOPUP DANA BERHASIL!</b>\n\n` +
        ` Nominal: ${formatRp(amount)}\n` +
        (bonusInfo.bonus > 0 ? ` Bonus: 🎁 +${bonusInfo.persen}% (${formatRp(bonusInfo.bonus)})\n` : '') +
        ` Saldo Baru: ${formatRp(newSaldo)}\n` +
        ` Kode TX: <code>${txId}</code>\n\n` +
        `Silakan gunakan menu <b>Create Akun</b> untuk membuat VPN.`,
        mainMenuKeyboard()
    );

    try {
        await kirimNotifikasiTopup({
            userId, userName: firstName, amount,
            sisaSaldo: newSaldo, txId,
            ocrBank, ocrTgl, ocrJumlah, imageBuffer
        });
    } catch(e) {}

}

async function handlePaymentProofGopay(ctx) {
    const userId    = ctx.from.id.toString();
    const pending   = pendingGOPAY.get(userId);
    if (!pending) return;

    const { amount, txId, expiresAt, chatId, userName } = pending;
    const firstName = ctx.from.first_name || userName || 'User';

    // Cek expired
    if (Date.now() > expiresAt) {
        pendingGOPAY.delete(userId);
        await sendTempMessage(ctx, ` Sesi pembayaran GoPay sudah kadaluarsa. Silakan topup ulang.`);
        return;
    }

    // Download gambar
    const photos = ctx.message.photo;
    const fileId  = photos[photos.length - 1].file_id;
    let imageBuffer;
    try {
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const response = await axios.get(fileLink.href, { responseType: 'arraybuffer' });
        imageBuffer = Buffer.from(response.data);
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal mengunduh gambar: ${e.message}`);
        return;
    }

    // Cek keunikan hash gambar
    const base64Data  = imageBuffer.toString('base64');
    const uniqueCheck = validateImageUniqueness(base64Data);
    if (!uniqueCheck.isValid) {
        try { await ctx.telegram.deleteMessage(chatId, ctx.message.message_id); } catch(e) {}
        await sendTempMessage(ctx, uniqueCheck.message);
        return;
    }

    // OCR validasi
    let ocrBank = 'GoPay', ocrTgl = null, ocrJumlah = null;
    try {
        const result = await validateBuktiTransfer(imageBuffer, amount);
        if (!result.isValid) {
            try { await ctx.telegram.deleteMessage(chatId, ctx.message.message_id); } catch(e) {}
            await sendTempMessage(ctx, ` Gambar tidak valid\n\nSilakan kirim ulang screenshot bukti pembayaran yang sesuai.`);
            return;
        }
        ocrBank   = result.bank   || 'GoPay';
        ocrTgl    = result.tanggal;
        ocrJumlah = result.jumlah;
    } catch(e) {
        console.log('[GoPay Bukti] OCR error (lanjut approve):', e.message);
    }

    // Sukses — proses saldo
    pendingGOPAY.delete(userId);
    markImageHashUsed(uniqueCheck.hash);

    // Hapus pesan instruksi GoPay
    if (pending.messageId) {
        try { await ctx.telegram.deleteMessage(chatId, pending.messageId); } catch(e) {}
    }

    const bonusInfo = hitungBonusTopup(amount);
    const newSaldo = tambahSaldo(userId, amount + bonusInfo.bonus);
    simpanTransaksi({
        txId: generateTxId(), userId, userName: firstName,
        type: 'topup', amount,
        keterangan: `Topup via GoPay oleh ${firstName}${bonusInfo.bonus > 0 ? ` (+bonus ${bonusInfo.persen}% = ${formatRp(bonusInfo.bonus)})` : ''}`,
        waktu: new Date().toISOString(), status: 'success'
    });

    await sendMenu(ctx,
        `<b>· TOPUP GOPAY BERHASIL!</b>\n\n` +
        ` Nominal: ${formatRp(amount)}\n` +
        (bonusInfo.bonus > 0 ? ` Bonus: 🎁 +${bonusInfo.persen}% (${formatRp(bonusInfo.bonus)})\n` : '') +
        ` Saldo Baru: ${formatRp(newSaldo)}\n` +
        ` Kode TX: <code>${txId}</code>\n\n` +
        `Silakan gunakan menu <b>Create Akun</b> untuk membuat VPN.`,
        mainMenuKeyboard()
    );

    try {
        await kirimNotifikasiTopup({
            userId, userName: firstName, amount,
            sisaSaldo: newSaldo, txId,
            ocrBank, ocrTgl, ocrJumlah, imageBuffer
        });
    } catch(e) {}

}

// ==================== HANDLER TOMBOL "CEK PEMBAYARAN" (mode CEK_PEMBAYARAN_MODE = 'button') ====================
// Dipakai sebagai pengganti webhook otomatis untuk metode manual (DANA/GoPay/QRIS manual).
// TIDAK ada verifikasi pembayaran nyata ke bank/e-wallet — hanya jeda waktu minimal
// (CEK_PEMBAYARAN_DELAY detik) sebelum tombol ini diizinkan mencairkan saldo, supaya user
// tidak bisa langsung klik sesaat setelah membuat topup tanpa transfer terlebih dahulu.
async function handleCekPembayaranButton(ctx, metode, txId) {
    const userId = ctx.from.id.toString();

    const pendingMap  = metode === 'dana' ? pendingDANA : metode === 'gopay' ? pendingGOPAY : pendingQRIS;
    const metodeLabel = metode === 'dana' ? 'DANA' : metode === 'gopay' ? 'GoPay' : 'QRIS';
    const pending = pendingMap.get(userId);

    if (!pending || pending.txId !== txId) {
        try { await ctx.answerCbQuery(' Sesi topup tidak ditemukan / sudah selesai.', { show_alert: true }); } catch(e) {}
        return;
    }

    if (Date.now() > pending.expiresAt) {
        pendingMap.delete(userId);
        try { await ctx.answerCbQuery(' Sesi pembayaran sudah kadaluarsa. Silakan topup ulang.', { show_alert: true }); } catch(e) {}
        return;
    }

    // Jeda minimal supaya user benar-benar sempat transfer dulu sebelum tombol bisa menyetujui
    const elapsedMs = Date.now() - (pending.createdAt || 0);
    const delayMs   = CEK_PEMBAYARAN_DELAY * 1000;
    if (elapsedMs < delayMs) {
        const sisaDetik = Math.ceil((delayMs - elapsedMs) / 1000);
        try {
            await ctx.answerCbQuery(
                `⚠️ Belum bisa diverifikasi.\n\nPastikan kamu sudah transfer ${formatRp(pending.totalBayar || pending.amount)}, lalu coba lagi dalam ${sisaDetik} detik.`,
                { show_alert: true }
            );
        } catch(e) {}
        return;
    }

    // Lolos jeda -> cairkan saldo (TANPA bukti/OCR, murni berdasar klik tombol)
    pendingMap.delete(userId);
    const { amount, chatId, userName } = pending;
    const firstName = ctx.from.first_name || userName || 'User';

    if (pending.messageId) {
        try { await ctx.telegram.deleteMessage(chatId, pending.messageId); } catch(e) {}
    }
    if (pending.qrisMessageId) {
        try { await ctx.telegram.deleteMessage(chatId, pending.qrisMessageId); } catch(e) {}
    }

    const bonusInfo = hitungBonusTopup(amount);
    const newSaldo  = tambahSaldo(userId, amount + bonusInfo.bonus);
    const newTxId   = generateTxId();

    simpanTransaksi({
        txId: newTxId, userId, userName: firstName,
        type: 'topup', amount,
        keterangan: `Topup via ${metodeLabel} oleh ${firstName} (verifikasi tombol Cek Pembayaran, tanpa bukti)${bonusInfo.bonus > 0 ? ` (+bonus ${bonusInfo.persen}% = ${formatRp(bonusInfo.bonus)})` : ''}`,
        waktu: new Date().toISOString(), status: 'success'
    });

    try { await ctx.answerCbQuery(' Pembayaran dikonfirmasi! Saldo sudah masuk.'); } catch(e) {}

    await sendMenu(ctx,
        `<b>· TOPUP ${metodeLabel} BERHASIL!</b>\n\n` +
        ` User: ${firstName}\n` +
        ` Nominal: ${formatRp(amount)}\n` +
        (bonusInfo.bonus > 0 ? ` Bonus: 🎁 +${bonusInfo.persen}% (${formatRp(bonusInfo.bonus)})\n` : '') +
        ` Saldo Baru: ${formatRp(newSaldo)}\n` +
        ` Kode TX: <code>${newTxId}</code>\n\n` +
        `Silakan gunakan menu <b>Create Akun</b> untuk membuat VPN.`,
        mainMenuKeyboard()
    );

    try {
        await kirimNotifikasiTopup({
            userId, userName: firstName, amount,
            sisaSaldo: newSaldo, txId: newTxId,
            ocrBank: `${metodeLabel} (Cek Pembayaran)`, ocrTgl: null, ocrJumlah: null, imageBuffer: null
        });
    } catch(e) {}
}

// Membatalkan sesi topup pending (dipanggil dari tombol "❌ Batal" di bawah tombol Cek Status Pembayaran)
async function handleBatalPembayaranButton(ctx, metode, txId) {
    const userId = ctx.from.id.toString();

    const pendingMap  = metode === 'dana' ? pendingDANA : metode === 'gopay' ? pendingGOPAY : pendingQRIS;
    const metodeLabel = metode === 'dana' ? 'DANA' : metode === 'gopay' ? 'GoPay' : 'QRIS';
    const pending = pendingMap.get(userId);

    if (!pending || pending.txId !== txId) {
        try { await ctx.answerCbQuery(' Sesi topup ini sudah tidak berlaku.', { show_alert: true }); } catch(e) {}
        return;
    }

    pendingMap.delete(userId);
    const { chatId } = pending;

    if (pending.messageId) {
        try { await ctx.telegram.deleteMessage(chatId, pending.messageId); } catch(e) {}
    }
    if (pending.qrisMessageId) {
        try { await ctx.telegram.deleteMessage(chatId, pending.qrisMessageId); } catch(e) {}
    }

    try { await ctx.answerCbQuery(' Topup dibatalkan.'); } catch(e) {}

    await sendMenu(ctx,
        ` <b>Topup ${metodeLabel} dibatalkan.</b>\n\n` +
        `Kode TX: <code>${txId}</code>\n\n` +
        `Silakan lakukan topup ulang melalui menu <b>Topup Saldo</b> jika ingin melanjutkan.`,
        mainMenuKeyboard()
    );
}


async function showAdminSettingsCekPembayaran(ctx) {
    const modeLabel = CEK_PEMBAYARAN_MODE === 'button' ? '🔍 Tombol Cek Pembayaran' : '📤 Upload Bukti';
    const text = `${getHeader(' 𝙋𝙀𝙉𝙂𝘼𝙏𝙐𝙍𝘼𝙉 𝘾𝙀𝙆 𝙋𝙀𝙈𝘽𝘼𝙔𝘼𝙍𝘼𝙉')}
<blockquote>Pengaturan ini berlaku untuk topup manual (DANA / GoPay / QRIS manual). Pakasir tidak terpengaruh karena sudah pakai payment gateway asli.

<b>· Mode Aktif :</b> ${modeLabel}
<b>· Jeda Tombol :</b> ${CEK_PEMBAYARAN_DELAY} detik

<b>📤 Upload Bukti</b> — user wajib kirim screenshot bukti transfer, divalidasi OCR sebelum saldo masuk. Lebih aman, direkomendasikan.

<b>🔍 Tombol Cek Pembayaran</b> — user klik tombol setelah transfer, saldo masuk otomatis tanpa upload bukti/OCR. Hanya ada jeda waktu sebagai pencegah, BUKAN verifikasi pembayaran nyata. Gunakan dengan pengawasan aktif terhadap notifikasi topup di grup/admin.</blockquote>`;

    await sendMenu(ctx, text, Markup.inlineKeyboard([
        [{ text: `🔁 Ganti Mode (saat ini: ${modeLabel})`, callback_data: 'admin_cekbayar_mode_toggle' }],
        [{ text: `⏱ Edit Jeda Tombol (${CEK_PEMBAYARAN_DELAY}s)`, callback_data: 'admin_cekbayar_delay_edit' }],
        [{ text: '⬅️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'admin_dashboard', style: 'danger' }]
    ]));
}

async function processTopupPakasir(ctx, amount) {
    const userId    = ctx.from.id.toString();
    const txId      = generateTxId();
    const firstName = ctx.from.first_name || 'User';
    const chatId    = ctx.chat.id;

    const waitingMsg = await sendTempMessage(ctx, `⏳ Proses...`);

    // Pre-kalkulasi fee Pakasir sebelum hit API
    const feePakasir  = CONFIG.QRIS_FEE_PERSEN > 0 ? Math.ceil(amount * CONFIG.QRIS_FEE_PERSEN / 100) : 0;
    const totalBayar  = amount + feePakasir;

    try {
        // Hit Pakasir API dengan nominal total (amount + fee)
        const payment = await createPakasirTransaction(totalBayar, txId);
        const qrString = payment.payment_number;

        // Generate QR code image (pakai fungsi yang sama seperti QRIS biasa)
        const qrBuffer = await generateQRCodeWithCenterIcon(qrString, QRIS_CENTER_ICON);

        // Hapus pesan loading
        try { await ctx.telegram.deleteMessage(chatId, waitingMsg.message_id); } catch(e) {}

        // Format expired Pakasir (dari API) atau 15 menit fallback
        let expiredLabel = '15 menit';
        if (payment.expired_at) {
            try {
                const expDate = new Date(payment.expired_at);
                expiredLabel = expDate.toLocaleTimeString('id-ID', {
                    timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit'
                }) + ' WIB';
            } catch(e) {}
        }

        const captionFeeRow = feePakasir > 0
            ? `\n<b>· Fee QRIS :</b> ${formatRp(feePakasir)}`
            : '';

        const caption = `${getHeader(' 𝙋𝙀𝙈𝘽𝘼𝙔𝘼𝙍𝘼𝙉 𝙌𝙍𝙄𝙎 (𝙋𝘼𝙆𝘼𝙎𝙄𝙍)')}
<blockquote><b>· Merchant :</b> ${PAKASIR_MERCHANT_NAME || CONFIG.MERCHANT_NAME}
<b>· Nominal Topup :</b> ${formatRp(amount)}${captionFeeRow}
<b>· Total Bayar :</b> ${formatRp(totalBayar)}
<b>· Order ID :</b> <code>${txId}</code>
<b>· Berlaku s/d :</b> ${expiredLabel}

<b>Langkah:</b>
1. Scan QR code di atas
2. Lakukan pembayaran sebesar ${formatRp(totalBayar)}
3. Tunggu konfirmasi otomatis dari bot

Saldo akan <b>otomatis masuk</b> setelah pembayaran terdeteksi</blockquote>`;

        const qrisMsg = await ctx.replyWithPhoto({ source: qrBuffer }, {
            caption,
            parse_mode: 'HTML'
        });

        // Simpan pending — amount disimpan sebagai nominal topup (bukan total_payment)
        const expiresMs = payment.expired_at
            ? new Date(payment.expired_at).getTime()
            : Date.now() + 15 * 60 * 1000;

        pendingQRIS.set(userId, {
            amount,           // nominal topup yang akan dikreditkan ke saldo
            totalBayar,       // total yang dibayar user (termasuk fee)
            txId,
            expiresAt: expiresMs,
            chatId, userName: firstName,
            qrisMessageId: qrisMsg.message_id,
            metode: 'pakasir'
        });

        // Auto-expired: hapus pesan QR + notif
        const ttl = expiresMs - Date.now();
        setTimeout(async () => {
            const p = pendingQRIS.get(userId);
            if (p && p.txId === txId) {
                pendingQRIS.delete(userId);
                try { await ctx.telegram.deleteMessage(chatId, p.qrisMessageId); } catch(e) {}
                await sendTempMessage(ctx,
                    ` <b>Waktu pembayaran Pakasir telah habis!</b>\n\n` +
                    `Order ID: <code>${txId}</code>\nNominal: ${formatRp(amount)}\n\n` +
                    `Silakan topup ulang melalui menu <b>Topup Saldo</b>.`
                );
            }
        }, ttl > 0 ? ttl : 15 * 60 * 1000);

        //  Polling otomatis status pembayaran Pakasir (tiap 5 detik) 
        const pollInterval = setInterval(async () => {
            try {
                const p = pendingQRIS.get(userId);
                // Hentikan polling jika sesi sudah tidak ada (expired/cancelled/selesai)
                if (!p || p.txId !== txId) {
                    clearInterval(pollInterval);
                    return;
                }

                const transaksi = await cekStatusPakasir(txId, p.totalBayar || amount);
                if (!transaksi) return;

                const status = (transaksi.status || '').toLowerCase();
                console.log(`[Pakasir Poll] TX: ${txId} | Status: ${status}`);

                if (status === 'paid' || status === 'success' || status === 'settlement') {
                    clearInterval(pollInterval);
                    pendingQRIS.delete(userId);

                    // Hapus pesan QR
                    if (p.qrisMessageId) {
                        try { await ctx.telegram.deleteMessage(chatId, p.qrisMessageId); } catch(e) {}
                    }

                    // Proses saldo
                    const bonusInfo = hitungBonusTopup(amount);
                    const newSaldo = tambahSaldo(userId, amount + bonusInfo.bonus);
                    simpanTransaksi({
                        txId: generateTxId(),
                        userId,
                        userName: firstName,
                        type: 'topup',
                        amount,
                        keterangan: `Topup via Pakasir (auto-detect) oleh ${firstName}${bonusInfo.bonus > 0 ? ` (+bonus ${bonusInfo.persen}% = ${formatRp(bonusInfo.bonus)})` : ''}`,
                        waktu: new Date().toISOString(),
                        status: 'success'
                    });

                    await sendMenu(ctx,
                        `<b>· PEMBAYARAN PAKASIR BERHASIL!</b>\n\n` +
                        ` User: ${firstName}\n` +
                        ` Nominal: ${formatRp(amount)}\n` +
                        (bonusInfo.bonus > 0 ? ` Bonus: 🎁 +${bonusInfo.persen}% (${formatRp(bonusInfo.bonus)})\n` : '') +
                        ` Saldo Baru: ${formatRp(newSaldo)}\n` +
                        ` Order ID: <code>${txId}</code>\n\n` +
                        `Silakan gunakan menu <b>Create Akun</b> untuk membuat VPN.`,
                        mainMenuKeyboard()
                    );

                    // Notif admin & grup
                    try {
                        await kirimNotifikasiTopup({
                            userId, userName: firstName,
                            amount,
                            sisaSaldo: newSaldo,
                            txId,
                            ocrBank: 'Pakasir',
                            ocrTgl: new Date().toLocaleDateString('id-ID'),
                            ocrJumlah: p.totalBayar || amount,
                            imageBuffer: null
                        });
                    } catch(e) {}

                }
            } catch(e) {
                console.log(`[Pakasir Poll] Error cek status TX ${txId}: ${e.message}`);
            }
        }, 5000); // cek setiap 5 detik

    } catch(err) {
        try { await ctx.telegram.deleteMessage(chatId, waitingMsg.message_id); } catch(e) {}
        console.error('[Pakasir] Error:', err.message);
        await sendTempMessage(ctx,
            ` Gagal membuat QRIS Pakasir: ${err.message}\n\nSilakan coba lagi atau gunakan metode QRIS biasa.`
        );
    }
}

async function handlePaymentProof(ctx) {
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;
    const proofMessageId = ctx.message.message_id;

    //  PROTEKSI 1: Lock — cegah dua foto diproses bersamaan 
    if (processingPayment.get(userId)) {
        try { await ctx.telegram.deleteMessage(chatId, proofMessageId); } catch(e) {}
        await sendTempMessage(ctx, ` Bukti sedang diproses, harap tunggu...`);
        return;
    }

    const pending = pendingQRIS.get(userId);

    //  PROTEKSI 2: Tidak ada sesi topup aktif 
    if (!pending) {
        try { await ctx.telegram.deleteMessage(chatId, proofMessageId); } catch(e) {}
        await sendTempMessage(ctx, ` Tidak ada topup yang sedang berjalan.\n\nGunakan menu <b>Topup Saldo</b> untuk memulai.`);
        return;
    }

    //  PROTEKSI 3: Sesi sudah expired 
    if (Date.now() > pending.expiresAt) {
        pendingQRIS.delete(userId);
        if (pending.qrisMessageId) {
            try { await ctx.telegram.deleteMessage(chatId, pending.qrisMessageId); } catch(e) {}
        }
        try { await ctx.telegram.deleteMessage(chatId, proofMessageId); } catch(e) {}
        await sendTempMessage(ctx, ` Waktu pembayaran sudah habis. Silakan topup ulang.`);
        return;
    }

    //  SET LOCK & ambil data sebelum hapus pendingQRIS 
    processingPayment.set(userId, true);
    const amount = pending.amount;
    const txId = pending.txId;
    const userName = pending.userName;
    const qrisMessageId = pending.qrisMessageId;

    // Hapus pendingQRIS SEGERA agar tidak bisa trigger lagi
    pendingQRIS.delete(userId);

    try {
        //  PROTEKSI 4: Download gambar & validasi hash konten (seperti beranda.js) 
        const photos = ctx.message.photo;
        const bestPhoto = photos[photos.length - 1]; // ambil resolusi terbesar
        const fileLink = await ctx.telegram.getFileLink(bestPhoto.file_id);
        const response = await axios.get(fileLink.href, { responseType: 'arraybuffer' });
        const base64Data = Buffer.from(response.data).toString('base64');

        //  Cek 1: Hash — cegah gambar yang sama dipakai ulang 
        const hashValidation = validateImageUniqueness(base64Data);
        if (!hashValidation.isValid) {
            try { await ctx.telegram.deleteMessage(chatId, proofMessageId); } catch(e) {}
            processingPayment.delete(userId);
            pendingQRIS.set(userId, { amount, txId, userName, qrisMessageId: null, expiresAt: pending.expiresAt, chatId });
            await sendTempMessage(ctx, hashValidation.message + '\n\nSilakan kirim ulang screenshot bukti pembayaran yang berbeda.');
            return;
        }

        //  Cek 2: OCR — validasi gambar adalah bukti transfer hari ini 
        const imageBuffer = Buffer.from(response.data);

        // Tampilkan loading sebelum OCR (bisa memakan beberapa detik)
        const loadingMsg = await sendTempMessage(ctx, ` <b>Memverifikasi bukti transaksi...</b>`);

        const ocrValidasi = await validateBuktiTransfer(imageBuffer);
        console.log(`[handlePaymentProof] OCR: isValid=${ocrValidasi.isValid} bank=${ocrValidasi.namaBank} tgl=${ocrValidasi.tanggalTransfer} jml=${ocrValidasi.jumlahTransfer}`);

        // Hapus pesan loading setelah OCR selesai
        if (loadingMsg) {
            try { await ctx.telegram.deleteMessage(chatId, loadingMsg.message_id); } catch(e) {}
        }

        if (!ocrValidasi.isValid) {
            try { await ctx.telegram.deleteMessage(chatId, proofMessageId); } catch(e) {}
            processingPayment.delete(userId);
            pendingQRIS.set(userId, { amount, txId, userName, qrisMessageId: null, expiresAt: pending.expiresAt, chatId });
            await sendTempMessage(ctx,
                ` Gambar tidak valid\n\nSilakan kirim ulang screenshot bukti pembayaran yang sesuai.`
            );
            return;
        }

        // Simpan data OCR untuk notifikasi
        const ocrBank   = ocrValidasi.namaBank        || null;
        const ocrTgl    = ocrValidasi.tanggalTransfer  || null;
        const ocrJumlah = ocrValidasi.jumlahTransfer   || null;
        console.log(`[handlePaymentProof]  Bukti valid | Bank: ${ocrBank} | Tanggal: ${ocrTgl} | Jumlah: Rp${ocrJumlah}`);

        //  Hapus pesan QRIS 
        if (qrisMessageId) {
            try {
                await ctx.telegram.deleteMessage(chatId, qrisMessageId);
                console.log(` Deleted QRIS message after proof received: TX ${txId}`);
            } catch(e) {
                console.log(`[Proof] Gagal hapus pesan QRIS: ${e.message}`);
            }
        }

        //  Hapus foto bukti pembayaran user 
        try {
            await ctx.telegram.deleteMessage(chatId, proofMessageId);
            console.log(` Deleted proof photo from user: ${userId}`);
        } catch(e) {
            console.log(`[Proof] Gagal hapus foto bukti: ${e.message}`);
        }

        //  Proses saldo & transaksi 
        const bonusInfo = hitungBonusTopup(amount);
        const newSaldo = tambahSaldo(userId, amount + bonusInfo.bonus);

        simpanTransaksi({
            txId: generateTxId(),
            userId,
            userName: userName,
            type: 'topup',
            amount,
            keterangan: `Topup Saldo oleh ${userName}${bonusInfo.bonus > 0 ? ` (+bonus ${bonusInfo.persen}% = ${formatRp(bonusInfo.bonus)})` : ''}`,
            waktu: new Date().toISOString(),
            status: 'success'
        });

        //  Simpan hash gambar agar tidak bisa dipakai lagi 
        markImageHashUsed(hashValidation.hash);

        const text = `<b>· PEMBAYARAN BERHASIL!</b>

 User: ${userName}
 Nominal: ${formatRp(amount)}${bonusInfo.bonus > 0 ? `\n Bonus: 🎁 +${bonusInfo.persen}% (${formatRp(bonusInfo.bonus)})` : ''}
 Saldo Baru: ${formatRp(newSaldo)}
 Kode TX: ${txId}

Silakan gunakan menu <b>Create Akun</b> untuk membuat VPN.`;

        await sendMenu(ctx, text, mainMenuKeyboard());

        // Notif ke grup & admin
        try {
            await kirimNotifikasiTopup({
                userId, userName,
                amount,
                sisaSaldo: newSaldo,
                txId,
                ocrBank,
                ocrTgl,
                ocrJumlah,
                imageBuffer
            });
        } catch(e) {}


    } catch(err) {
        console.error('[handlePaymentProof] Error:', err.message);
        // Kembalikan pendingQRIS agar user bisa coba lagi
        pendingQRIS.set(userId, { amount, txId, userName, qrisMessageId: null, expiresAt: pending.expiresAt, chatId });
        await sendTempMessage(ctx, ` Gagal memproses bukti: ${err.message}\n\nSilakan kirim ulang bukti pembayaran.`);
    } finally {
        // Selalu lepas lock
        processingPayment.delete(userId);
    }
}

// ==================== RESTART BOT FUNCTION ====================
async function restartBot(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const serviceName = 'bot-seller-tele'; // Nama service sesuai permintaan
    
    try {
        // Kirim pesan konfirmasi
        const confirmText = `${getHeader(' 𝙍𝙀𝙎𝙏𝘼𝙍𝙏 𝘽𝙊𝙏')}
<b>· PERINGATAN:</b>
Bot akan direstart dalam beberapa detik.
Bot akan offline selama beberapa saat.

<b>Service:</b> ${serviceName}

Apakah Anda yakin ingin merestart bot?`;

        const keyboard = Markup.inlineKeyboard([
            [{ text: '🔄 𝙔𝙖, 𝙍𝙚𝙨𝙩𝙖𝙧𝙩 𝙎𝙚𝙠𝙖𝙧𝙖𝙣𝙜', callback_data: 'admin_restart_confirm' }],
            [{ text: '❌ 𝙏𝙞𝙙𝙖𝙠, 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_dashboard', style: 'danger' }]
        ]);
        
        await sendMenu(ctx, confirmText, keyboard);
        
    } catch (err) {
        await sendTempMessage(ctx, ` Gagal memproses restart: ${err.message}`);
    }
}

async function executeRestart(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const serviceName = 'bot-seller-tele';
    
    try {
        // Kirim pesan bahwa bot akan direstart
        await sendResultMessage(ctx, ` <b>Merestart bot...</b>\n\nService: ${serviceName}\nBot akan online kembali dalam beberapa saat.`);
        
        // Eksekusi command restart menggunakan exec
        const { exec } = require('child_process');
        
        // Gunakan sudo jika perlu, atau langsung systemctl
        const command = `sudo systemctl restart ${serviceName}`;
        
        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`Restart error: ${error.message}`);
                // Coba tanpa sudo
                const command2 = `systemctl restart ${serviceName}`;
                exec(command2, (error2, stdout2, stderr2) => {
                    if (error2) {
                        bot.telegram.sendMessage(userId, ` Gagal merestart bot: ${error2.message}\n\nCoba manual: systemctl restart ${serviceName}`);
                    } else {
                        bot.telegram.sendMessage(userId, ` Bot berhasil direstart!\n\nService: ${serviceName}\nBot akan segera online kembali.`);
                    }
                });
            } else {
                bot.telegram.sendMessage(userId, ` Bot berhasil direstart!\n\nService: ${serviceName}\nBot akan segera online kembali.`);
            }
        });
        
        // Stop bot setelah 2 detik
        setTimeout(() => {
            process.exit(0);
        }, 2000);
        
    } catch (err) {
        await sendTempMessage(ctx, ` Gagal merestart bot: ${err.message}`);
    }
}

// ==================== BACKUP & RESTORE (GitHub Integration) ====================
const BACKUP_DIR = path.join(__dirname, 'backups');
const BACKUP_INDEX_FILE = path.join(__dirname, 'backup_index.json');
const BACKUP_CONFIG_FILE = path.join(__dirname, 'backup_config.json');
let autoBackupInterval = null;
let autoBackupEnabled = false;
let autoBackupIntervalMinutes = 60;

/** Simpan setting auto backup ke file agar persist setelah restart */
function saveAutoBackupConfig() {
    try {
        fs.writeFileSync(BACKUP_CONFIG_FILE, JSON.stringify({
            autoBackupEnabled,
            autoBackupIntervalMinutes
        }, null, 2), 'utf8');
    } catch(e) {
        console.error('[AutoBackup] Gagal simpan config:', e.message);
    }
}

/** Load setting auto backup dari file, lalu jalankan jika sebelumnya aktif */
function loadAndRestoreAutoBackup() {
    try {
        if (!fs.existsSync(BACKUP_CONFIG_FILE)) return;
        const cfg = JSON.parse(fs.readFileSync(BACKUP_CONFIG_FILE, 'utf8'));
        if (cfg.autoBackupEnabled && cfg.autoBackupIntervalMinutes > 0) {
            // runImmediately = false -> saat bot start TIDAK langsung backup,
            // cukup jadwalkan interval-nya dan biarkan jalan di latar belakang.
            startAutoBackup(cfg.autoBackupIntervalMinutes, false);
            console.log(` [AutoBackup] Restored (background): setiap ${cfg.autoBackupIntervalMinutes} menit`);
        }
    } catch(e) {
        console.error('[AutoBackup] Gagal load config:', e.message);
    }
}

// GitHub config — isi di .env
let GITHUB_TOKEN  = process.env.GITHUB_TOKEN  || '';
let GITHUB_OWNER  = process.env.GITHUB_OWNER  || 'peyxdev';
let GITHUB_REPO   = process.env.GITHUB_REPO   || 'backup';
let GITHUB_BRANCH = process.env.GITHUB_BRANCH || 'main';

if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

//  Helpers 

/** Generate random ID: 8 hex chars */
function generateBackupId() {
    const ts = Date.now().toString(36);
    const rnd = require('crypto').randomBytes(3).toString('hex');
    return `tele_${ts}_${rnd}`;
}

/** Load local backup index {id -> {id, label, createdAt, filename, githubSha}} */
function loadBackupIndex() {
    try {
        if (fs.existsSync(BACKUP_INDEX_FILE)) return JSON.parse(fs.readFileSync(BACKUP_INDEX_FILE, 'utf8'));
    } catch(e) {}
    return {};
}

function saveBackupIndex(index) {
    fs.writeFileSync(BACKUP_INDEX_FILE, JSON.stringify(index, null, 2), 'utf8');
}

/** Upload file ke GitHub, return sha baru */
async function uploadToGitHub(filename, contentBuffer, existingSha = null) {
    if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN belum diset di .env');
    const base64Content = contentBuffer.toString('base64');
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/tele-bot/${filename}`;
    const body = {
        message: `backup: tele-bot/${filename}`,
        content: base64Content,
        branch: GITHUB_BRANCH,
    };
    if (existingSha) body.sha = existingSha; // update existing file

    const resp = await axios.put(url, body, {
        headers: {
            Authorization: `token ${GITHUB_TOKEN}`,
            'Content-Type': 'application/json',
            Accept: 'application/vnd.github+json',
        },
    });
    return resp.data.content.sha;
}

/** Download file dari GitHub by filename, return parsed JSON */
async function downloadFromGitHub(filename) {
    if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN belum diset di .env');
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/tele-bot/${filename}`;
    const resp = await axios.get(url, {
        headers: {
            Authorization: `token ${GITHUB_TOKEN}`,
            Accept: 'application/vnd.github+json',
        },
        params: { ref: GITHUB_BRANCH },
    });
    const content = Buffer.from(resp.data.content, 'base64').toString('utf8');
    return { data: JSON.parse(content), sha: resp.data.sha };
}

// Cache singkat hasil listing file backup dari GitHub — supaya pindah halaman (pagination)
// di menu "Daftar Backup" tidak nge-hit GitHub API tiap klik next/prev (yang notabene
// request jaringan ke luar, bisa kerasa delay). Data backup jarang berubah dalam hitungan
// detik, jadi cache 60 detik aman. Setelah bikin backup baru / restore, cache di-invalidate
// otomatis (lihat pemanggilnya) supaya tidak nampilin data basi.
let _ghBackupListCache = null;
let _ghBackupListCacheTs = 0;
const _GH_BACKUP_CACHE_TTL = 60000;

function invalidateGithubBackupListCache() {
    _ghBackupListCache = null;
    _ghBackupListCacheTs = 0;
}

/** List semua file .json di GitHub repo */
async function listGitHubBackups() {
    if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN belum diset di .env');
    const now = Date.now();
    if (_ghBackupListCache && (now - _ghBackupListCacheTs) < _GH_BACKUP_CACHE_TTL) {
        return _ghBackupListCache;
    }
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/tele-bot/`;
    try {
        const resp = await axios.get(url, {
            headers: {
                Authorization: `token ${GITHUB_TOKEN}`,
                Accept: 'application/vnd.github+json',
            },
            params: { ref: GITHUB_BRANCH },
        });
        const files = resp.data.filter(f => f.name.endsWith('.json'));
        _ghBackupListCache = files;
        _ghBackupListCacheTs = now;
        return files;
    } catch(e) {
        if (e.response && e.response.status === 404) return [];
        throw e;
    }
}

//  Core backup/restore 

async function createBackup(label = 'manual') {
    const backupId  = generateBackupId();
    const filename  = `${backupId}.json`;
    const localPath = path.join(BACKUP_DIR, filename);

    const backupData = {
        meta: { createdAt: new Date().toISOString(), label, version: '2.0', id: backupId },
        servers:  (() => { try { return fs.existsSync(CONFIG_FILE)    ? JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'))    : {}; } catch(e) { return {}; } })(),
        saldo:    (() => { try { return fs.existsSync(SALDO_FILE)     ? JSON.parse(fs.readFileSync(SALDO_FILE, 'utf8'))     : {}; } catch(e) { return {}; } })(),
        akun:     (() => { try { return fs.existsSync(AKUN_FILE)      ? JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'))      : {}; } catch(e) { return {}; } })(),
        transaksi:(() => { try { return fs.existsSync(TRANSAKSI_FILE) ? JSON.parse(fs.readFileSync(TRANSAKSI_FILE, 'utf8')) : []; } catch(e) { return []; } })(),
        trial:    (() => { try { return fs.existsSync(TRIAL_FILE)     ? JSON.parse(fs.readFileSync(TRIAL_FILE, 'utf8'))     : {}; } catch(e) { return {}; } })(),
    };

    const jsonBuffer = Buffer.from(JSON.stringify(backupData, null, 2), 'utf8');

    // Simpan lokal
    fs.writeFileSync(localPath, jsonBuffer);
    console.log(` Backup lokal: ${filename}`);

    // Upload ke GitHub
    let githubSha = null;
    try {
        githubSha = await uploadToGitHub(filename, jsonBuffer);
        console.log(` Upload GitHub OK: ${filename} (sha: ${githubSha.substring(0,7)})`);
        invalidateGithubBackupListCache(); // backup baru diupload → cache list lama basi
    } catch(ghErr) {
        console.error(` Upload GitHub gagal: ${ghErr.message}`);
    }

    // Simpan ke index
    const index = loadBackupIndex();
    index[backupId] = {
        id: backupId,
        label,
        createdAt: backupData.meta.createdAt,
        filename,
        githubSha,
        githubUploaded: !!githubSha,
    };
    saveBackupIndex(index);

    // Hapus backup lokal lama (simpan maks 10)
    const allIds = Object.values(index).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
    if (allIds.length > 10) {
        const toDelete = allIds.slice(10);
        for (const entry of toDelete) {
            try { fs.unlinkSync(path.join(BACKUP_DIR, entry.filename)); } catch(e) {}
            delete index[entry.id];
        }
        saveBackupIndex(index);
    }

    return { backupId, filename, localPath, githubSha };
}

/** Restore dari ID backup — coba lokal dulu, fallback GitHub */
async function restoreBackupById(backupId) {
    const index = loadBackupIndex();
    const entry = index[backupId];

    let data;

    // Coba lokal
    if (entry) {
        const localPath = path.join(BACKUP_DIR, entry.filename);
        if (fs.existsSync(localPath)) {
            data = JSON.parse(fs.readFileSync(localPath, 'utf8'));
        }
    }

    // Fallback GitHub
    if (!data) {
        const filename = entry ? entry.filename : `${backupId}.json`;
        const result = await downloadFromGitHub(filename);
        data = result.data;
        // Simpan lokal untuk cache
        fs.writeFileSync(path.join(BACKUP_DIR, filename), JSON.stringify(data, null, 2), 'utf8');
    }

    if (!data) throw new Error('Data backup tidak ditemukan di lokal maupun GitHub.');

    if (data.servers)   fs.writeFileSync(CONFIG_FILE,    JSON.stringify(data.servers,   null, 2), 'utf8');
    if (data.saldo)     fs.writeFileSync(SALDO_FILE,     JSON.stringify(data.saldo,     null, 2), 'utf8');
    if (data.akun)      fs.writeFileSync(AKUN_FILE,      JSON.stringify(data.akun,      null, 2), 'utf8');
    if (data.transaksi) fs.writeFileSync(TRANSAKSI_FILE, JSON.stringify(data.transaksi, null, 2), 'utf8');
    if (data.trial)     fs.writeFileSync(TRIAL_FILE,     JSON.stringify(data.trial,     null, 2), 'utf8');
    _cacheInvalidate('akun');
    _cacheInvalidate('servers');
    SERVERS = loadServers();
    // CATATAN: totalslot.json (slot terpakai) SENGAJA TIDAK dihitung ulang di
    // sini — itu murni counter manual, tidak pernah disinkronkan dari akun.json.
    // Kalau setelah restore angkanya meleset, koreksi manual lewat menu
    // "Edit Slot Terpakai" di Admin.
    return data.meta || {};
}

/** Ambil daftar backup — gabungkan index lokal + GitHub */
async function getBackupList() {
    const index = loadBackupIndex();
    const list  = Object.values(index).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));

    // Jika ada GitHub token, sinkron juga dari GitHub (backup yang tidak ada di index lokal)
    if (GITHUB_TOKEN) {
        try {
            const ghFiles = await listGitHubBackups();
            for (const f of ghFiles) {
                const id = f.name.replace('.json', '');
                if (!index[id]) {
                    // tambahkan entry minimal dari GitHub
                    // Parse tanggal dari nama file format: tele_<timestamp_base36>_<random>.json
                    let createdAt = null;
                    const nameParts = f.name.replace('.json', '').split('_');
                    if (nameParts.length >= 2) {
                        const tsBase36 = nameParts[1];
                        const tsMs = parseInt(tsBase36, 36);
                        if (!isNaN(tsMs) && tsMs > 1000000000000) {
                            createdAt = new Date(tsMs).toISOString();
                        }
                    }
                    if (!createdAt) createdAt = new Date().toISOString();
                    list.push({ id, label: 'github', createdAt, filename: f.name, githubSha: f.sha, githubUploaded: true, remoteOnly: true });
                }
            }
        } catch(e) { /* silent */ }
    }

    return list;
}

async function notifAutoBackupToAdmin(result, error = null) {
    if (!ADMIN_IDS || ADMIN_IDS.length === 0) return;
    const waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    let text;
    if (error) {
        text = `⚠️ <b>AUTO BACKUP GAGAL</b>\n\n` +
               `<b>· Waktu  :</b> ${waktu}\n` +
               `<b>· Error  :</b> <code>${error}</code>`;
    } else {
        const ghStatus = result.githubSha ? `✅ <code>${GITHUB_OWNER}/${GITHUB_REPO}</code>` : `⚠️ Gagal upload`;
        text = `💾 <b>AUTO BACKUP SELESAI</b>\n\n` +
               `<b>· Waktu    :</b> ${waktu}\n` +
               `<b>· ID       :</b> <code>${result.backupId}</code>\n` +
               `<b>· File     :</b> <code>${result.filename}</code>\n` +
               `<b>· GitHub   :</b> ${ghStatus}\n` +
               `<b>· Interval :</b> setiap ${autoBackupIntervalMinutes} menit`;
    }
    for (const adminId of ADMIN_IDS) {
        try { await notifBot.telegram.sendMessage(adminId, text, { parse_mode: 'HTML' }); } catch(e) {}
    }
}

function startAutoBackup(intervalMinutes, runImmediately = true) {
    if (autoBackupInterval) clearInterval(autoBackupInterval);
    autoBackupEnabled = true;
    autoBackupIntervalMinutes = intervalMinutes;

    if (runImmediately) {
        // Jalankan backup pertama langsung (tidak tunggu interval penuh) — dipakai saat
        // admin AKTIFKAN auto backup secara manual dari dashboard, supaya langsung dapat
        // feedback kalau fiturnya jalan.
        createBackup('auto')
            .then(result => {
                console.log(` [AutoBackup] Backup awal selesai`);
                notifAutoBackupToAdmin(result);
            })
            .catch(e => {
                console.error(` [AutoBackup] Backup awal gagal: ${e.message}`);
                notifAutoBackupToAdmin(null, e.message);
            });
    } else {
        // Tidak backup instan (dipakai saat restore setting di bot start) — cukup jadwalkan
        // interval-nya saja dan biarkan berjalan di latar belakang. Backup pertama akan
        // jalan otomatis setelah 1 interval penuh berlalu.
        console.log(` [AutoBackup] Berjalan di background, backup pertama akan dijalankan setelah ${intervalMinutes} menit`);
    }

    autoBackupInterval = setInterval(async () => {
        console.log(` [AutoBackup] Menjalankan backup... (interval ${intervalMinutes} menit)`);
        try {
            const result = await createBackup('auto');
            console.log(` [AutoBackup] Selesai (${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })})`);
            await notifAutoBackupToAdmin(result);
        } catch(e) {
            console.error(` [AutoBackup] GAGAL: ${e.message}`);
            await notifAutoBackupToAdmin(null, e.message);
        }
    }, intervalMinutes * 60 * 1000);

    saveAutoBackupConfig();
    console.log(` [AutoBackup] Aktif: setiap ${intervalMinutes} menit`);
}

function stopAutoBackup() {
    if (autoBackupInterval) { clearInterval(autoBackupInterval); autoBackupInterval = null; }
    autoBackupEnabled = false;
    saveAutoBackupConfig(); // simpan state nonaktif
    console.log(' Auto backup dinonaktifkan');
}

// [DIPINDAH KE admin.js] function showAdminBackupMenu() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminBackupList() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminBackupRestoreList() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminBackupDeleteList() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminAutoBackupSetup() -- lihat admin.js

// ==================== ADMIN DASHBOARD (BUTTON BASED) ====================
// [DIPINDAH KE admin.js] function showAdminDashboard() -- lihat admin.js

// ==================== ADMIN MANAGE RESELLER (LIST + TOGGLE ON/OFF) ====================
// Admin bisa menjadikan SIAPA SAJA user sebagai reseller (ON) atau mencabutnya (OFF).
// Halaman ini menampilkan user yang pernah punya status reseller (aktif/nonaktif),
// lengkap dengan tombol toggle cepat. Untuk user yang belum pernah jadi reseller,
// admin tinggal cari usernya (tombol "Cari User") lalu aktifkan dari halaman manage user.
// [DIPINDAH KE admin.js] function showAdminManageResellerList() -- lihat admin.js

// ==================== ADMIN LIST USERS ====================
// [DIPINDAH KE admin.js] function showAdminListUsers() -- lihat admin.js

// ==================== ADMIN SEARCH USERS ====================
// [DIPINDAH KE admin.js] function showAdminSearchUsers() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminSearchResults() -- lihat admin.js

// ==================== ADMIN MANAGE USER SALDO ====================
// [DIPINDAH KE admin.js] function showAdminManageUser() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminEditSaldoAmount() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminEditSaldoNominal() -- lihat admin.js

// ==================== ADMIN LIST AKUN ====================
// [DIPINDAH KE admin.js] function showAdminListAkun() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminUserAkun() -- lihat admin.js

// ==================== ADMIN RIWAYAT TRANSAKSI ====================
// [DIPINDAH KE admin.js] function showAdminTransaksi() -- lihat admin.js

// ==================== ADMIN EDIT DATA BOT ====================

//  Menu utama pengaturan (hanya daftar submenu) 
// [DIPINDAH KE admin.js] function showAdminEditData() -- lihat admin.js

// [DIPINDAH KE admin.js] function startAdminEditHeaderMain() -- lihat admin.js
// [DIPINDAH KE admin.js] function showAdminSettingsUmum() -- lihat admin.js

//  Submenu: Pengaturan QRIS Dinamis 
// [DIPINDAH KE admin.js] function showAdminSettingsQris() -- lihat admin.js

//  Submenu: Pengaturan Pakasir 
// [DIPINDAH KE admin.js] function showAdminSettingsPakasir() -- lihat admin.js

//  Submenu: Pengaturan DANA 
// [DIPINDAH KE admin.js] function showAdminSettingsDana() -- lihat admin.js

//  Submenu: Pengaturan GoPay 
// [DIPINDAH KE admin.js] function showAdminSettingsGopay() -- lihat admin.js

//  Submenu: Pengaturan GitHub (menu pilihan kategori repo) 
// [DIPINDAH KE admin.js] function showAdminSettingsGithub() -- lihat admin.js

//  Submenu: Pengaturan GitHub - Repo Backup 
// [DIPINDAH KE admin.js] function showAdminSettingsGithubBackup() -- lihat admin.js

//  Submenu: Pengaturan GitHub - Repo Sewa SC 
// [DIPINDAH KE admin.js] function showAdminSettingsGithubSewaSc() -- lihat admin.js

// [DIPINDAH KE admin.js] function handleAdminEditValue() -- lihat admin.js

// Replace the processAdminEditValue function with this fixed version:

// [DIPINDAH KE admin.js] function processAdminEditValue() -- lihat admin.js

// autoRestartAfterEdit dihapus — edit data sekarang langsung berlaku tanpa restart

function updateEnvValue(key, value) {
    try {
        const envPath = path.join(__dirname, '.env');
        let content = '';
        
        if (fs.existsSync(envPath)) {
            content = fs.readFileSync(envPath, 'utf8');
        }
        
        const regex = new RegExp(`^${key}=.*$`, 'm');
        const newLine = `${key}=${value}`;
        
        if (regex.test(content)) {
            content = content.replace(regex, newLine);
        } else {
            if (content && !content.endsWith('\n')) {
                content += '\n';
            }
            content += newLine;
        }
        
        fs.writeFileSync(envPath, content, 'utf8');
        console.log(` Updated ${key}=${value} in .env`);
        return true;
    } catch(e) {
        console.error(` Failed to update ${key}:`, e.message);
        return false;
    }
}

// ==================== ADMIN SERVER MANAGEMENT (BUTTON BASED) ====================
// [DIPINDAH KE admin.js] function showAdminServerMenu() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminServerList() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminServerAdd() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerAddName() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerAddType() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerAddDomain() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerAddAuthKey() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminServerEdit() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerEditSelect() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerEditField() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerEditValue() -- lihat admin.js

// ==================== ADMIN EDIT HARGA PER SERVER ====================
// [DIPINDAH KE admin.js] function showAdminServerHargaList() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminServerHargaEdit() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerHargaInput() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminServerDelete() -- lihat admin.js

// [DIPINDAH KE admin.js] function processAdminServerDelete() -- lihat admin.js

// ==================== ADMIN LIST AKUN PER SERVER ====================
// [DIPINDAH KE admin.js] function showAdminAkunPerServer() -- lihat admin.js

// Tampilkan pilihan tipe (vmess/vless/trojan) untuk server xray sebelum list
// [DIPINDAH KE admin.js] function showAdminXrayTypeSelect() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminServerAkunList() -- lihat admin.js

// ==================== ADMIN DELETE AKUN PER SERVER ====================
// [DIPINDAH KE admin.js] function showAdminDeleteAkunServer() -- lihat admin.js

// Tampilkan list button username untuk dipilih dihapus
// [DIPINDAH KE admin.js] function showAdminDeleteAkunList() -- lihat admin.js

// [DIPINDAH KE admin.js] function eksekusiAdminDeleteAkunServer() -- lihat admin.js

// ==================== ADMIN DELETE AKUN - PENCARIAN NAMA ====================
// [DIPINDAH KE admin.js] function showAdminDeleteAkunSearch() -- lihat admin.js

// [DIPINDAH KE admin.js] function showAdminDeleteAkunSearchResult() -- lihat admin.js


broadcastModule.initBroadcast({
    getHeader: getHeader,
    sendMenu: sendMenu,
    sendTempMessage: sendTempMessage,
    sendResultMessage: sendResultMessage,
    isAdmin: isAdmin,
    loadSaldo: loadSaldo,
    loadAkun: loadAkun,
    loadTransaksi: loadTransaksi,
    loadTrialData: loadTrialData,
    formatTimestamp: formatTimestamp,
    bot: bot
});

// ==================== HELPER NOTIFIKASI PAYG ====================
function sensorUsername(str) {
    if (!str || str.length <= 2) return str;
    const v = 2;
    return str.substring(0, v) + 'xxxx' + str.substring(str.length - v);
}

function getNamaLayananPayg(serviceType) {
    const map = { ssh:'SSH', trojan:'TROJAN', vless:'VLESS', vmess:'VMESS', zivpn:'ZIVPN' };
    return (map[serviceType] || serviceType.toUpperCase()) + ' HP Pay as You Go';
}

// Sama persis dengan WA bot — mendukung isPayg & isTrial
function getNamaLayanan(serviceType, isPayg, isTrial) {
    const map = { ssh:'SSH', trojan:'TROJAN', vless:'VLESS', vmess:'VMESS', zivpn:'ZIVPN' };
    const base = (map[serviceType] || serviceType.toUpperCase());
    if (isTrial) return base + ' Trial';
    if (isPayg)  return base + ' Pay as You Go';
    return base;
}

function getKodeAkun(userId, isPayg, isTrial, serviceType, days) {
    const produkMap = { ssh: 'SSH', trojan: 'TROJAN', vless: 'VLESS', vmess: 'VMESS', zivpn: 'ZIVPN' };
    const produkPrefix = serviceType ? (produkMap[serviceType] || serviceType.toUpperCase()) : 'ORDER';
    if (isPayg) return `${produkPrefix}-PAYG`;
    if (isTrial) return `${produkPrefix}-TRIAL`;
    const daysSuffix = days ? `${days}H` : '';
    return `${produkPrefix}-${daysSuffix}`;
}

function getKodeRenew(userId) {
    const tx = loadTransaksi();
    const n = tx.filter(t => t.userId === userId && t.type === 'renew').length;
    return `RENEW${n}D`;
}

// Kirim notif ke semua admin Telegram (via notifBot)
async function sendToAdmins(text) {
    for (const adminId of ADMIN_IDS) {
        try {
            await notifBot.telegram.sendMessage(adminId, text, { parse_mode: 'HTML' });
        } catch(e) {}
    }
}

// Kirim notif ke grup Telegram (via notifBot)
async function sendToGroup(text) {
    if (!TELEGRAM_GROUP_ID) {
        console.log('[sendToGroup] TELEGRAM_GROUP_ID tidak di-set, notif grup dilewati');
        return;
    }
    try {
        const groupId = typeof TELEGRAM_GROUP_ID === 'string'
            ? parseInt(TELEGRAM_GROUP_ID)
            : TELEGRAM_GROUP_ID;
        await notifBot.telegram.sendMessage(groupId, text, { parse_mode: 'HTML' });
    } catch(e) {
        console.error(`[sendToGroup] Gagal kirim ke grup ${TELEGRAM_GROUP_ID}: ${e.message}`);
    }
}

// Kirim notif ke grup (msgGrup) dan semua admin (msgAdmin)
async function sendNotifAll(msgGrup, msgAdmin) {
    await sendToGroup(msgGrup);
    await sendToAdmins(msgAdmin);
}

// Kirim foto + caption ke semua admin (via notifBot)
async function sendPhotoToAdmins(imageBuffer, caption) {
    for (const adminId of ADMIN_IDS) {
        try {
            await notifBot.telegram.sendPhoto(adminId, { source: imageBuffer }, {
                caption,
                parse_mode: 'HTML'
            });
        } catch(e) {
            console.error(`[sendPhotoToAdmins] Gagal kirim foto ke admin ${adminId}: ${e.message}`);
        }
    }
}

async function kirimNotifikasiStopPayg({ userId, userName, serviceType, identifier, serverName, sisaSaldo }) {
    const waktu = formatTimestamp();
    const statusLabel = isReseller(userId) ? 'Reseller' : 'Member';
    const produk = getNamaLayanan(serviceType, true, false);
    const identifierGrup = sensorUsername(identifier || '-');
    const msgGrup =
`<b>-----------------------------------------</b>
<b>· STOP PAYG</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel}
<b>Produk:</b> ${produk}
<b>Aksi:</b> User hentikan layanan
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifierGrup}</code>
<b>Saldo Sisa:</b> ${formatRp(sisaSaldo)}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    const msgAdmin =
`<b>-----------------------------------------</b>
<b>· STOP PAYG</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel} (${userName})
<b>User ID:</b> ${userId}
<b>Produk:</b> ${produk}
<b>Aksi:</b> User hentikan layanan sendiri
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifier || '-'}</code>
<b>Saldo Sisa:</b> ${formatRp(sisaSaldo)}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    await sendNotifAll(msgGrup, msgAdmin);
}

async function kirimNotifikasiAutoHapusPayg({ userId, userName, serviceType, identifier, serverName, sisaSaldo }) {
    const waktu = formatTimestamp();
    const statusLabel = isReseller(userId) ? 'Reseller' : 'Member';
    const produk = getNamaLayanan(serviceType, true, false);
    const identifierGrup = sensorUsername(identifier || '-');

    const msgGrup =
`<b>-----------------------------------------</b>
<b>· PAYG DIHAPUS OTOMATIS</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel}
<b>Produk:</b> ${produk}
<b>Alasan:</b> Saldo habis
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifierGrup}</code>
<b>Saldo Sisa:</b> ${formatRp(sisaSaldo)}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    const msgAdmin =
`<b>-----------------------------------------</b>
<b>· PAYG DIHAPUS OTOMATIS</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel} (${userName})
<b>User ID:</b> ${userId}
<b>Produk:</b> ${produk}
<b>Alasan:</b> Saldo habis — akun dihapus dari server
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifier || '-'}</code>
<b>Saldo Sisa:</b> ${formatRp(sisaSaldo)}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    await sendNotifAll(msgGrup, msgAdmin);
}

// ==================== NOTIFIKASI PAYG DEDUCT ====================
async function kirimNotifikasiDeductPayg({ userId, userName, serviceType, identifier, serverName, potongan, sisaSaldo }) {
    const waktu = formatTimestamp();
    const statusLabel = isReseller(userId) ? 'Reseller' : 'Member';
    const produk = getNamaLayanan(serviceType, true, false);
    const identifierGrup = sensorUsername(identifier || '-');

    const msgGrup =
`<b>-----------------------------------------</b>
<b> PAYG PEMOTONGAN SALDO</b>
<b>-----------------------------------------</b>
<b>Nama:</b> ${userName}
<b>Status:</b> ${statusLabel}
<b>Produk:</b> ${produk}
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifierGrup}</code>
<b>Dipotong:</b> ${formatRp(potongan)}/jam
<b>Saldo Sisa:</b> ${formatRp(sisaSaldo)}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    await sendToGroup(msgGrup);
}

// ==================== NOTIFIKASI CREATE AKUN ====================
async function kirimNotifikasiCreateAkun({ userId, userName, serviceType, username, password, serverName, harga, sisaSaldo, days, iplimit, kode, isEdurc = false }) {
    const waktu = formatTimestamp();
    const statusLabel = isReseller(userId) ? 'Reseller' : 'Member';
    const usernameDisplay = username || password || '-';
    const masaAktif = `${days} Hari`;

    const isCloudfront = isCloudfrontMode(isEdurc, serviceType);
    let modeProduk, modeHeader;
    if (isCloudfront) {
        modeProduk = `SSH CloudFront`;
        modeHeader = `ORDER BERHASIL`;
    } else if (isEdurc) {
        modeProduk = `${getNamaLayanan(serviceType, false, false)} EDURC`;
        modeHeader = `ORDER BERHASIL`;
    } else {
        modeProduk = getNamaLayanan(serviceType, false, false);
        modeHeader = `ORDER BERHASIL`;
    }

    // Grup: sensor username
    const usernameGrup = sensorUsername(usernameDisplay);
    const msgGrup =
`<b>-----------------------------------------</b>
<b>· ${modeHeader}</b>
<b>-----------------------------------------</b>
<b>Nama:</b> ${userName}
<b>Status:</b> ${statusLabel}
<b>Produk:</b> ${modeProduk}
<b>Masa Aktif:</b> ${masaAktif}
<b>Login:</b> ${iplimit || 1} devices
<b>Metode:</b> saldo
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${usernameGrup}</code>
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    // Admin: full tanpa sensor + password + saldo sisa
    let extraAdmin = '';
    if (serviceType !== 'zivpn' && password && password !== username) {
        extraAdmin = `\n<b>Password:</b> <code>${password}</code>`;
    }
    const msgAdmin =
`<b>-----------------------------------------</b>
<b>· ${modeHeader}</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel} (${userName})
<b>User ID:</b> ${userId}
<b>Produk:</b> ${modeProduk}
<b>Masa Aktif:</b> ${masaAktif}
<b>Login:</b> ${iplimit || 1} devices
<b>Metode:</b> saldo
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${usernameDisplay}</code>${extraAdmin}
<b>Harga:</b> ${formatRp(harga)}
<b>Saldo Sisa:</b> ${formatRp(sisaSaldo)}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    await sendNotifAll(msgGrup, msgAdmin);
}

// ==================== NOTIFIKASI TRIAL ====================
async function kirimNotifikasiTrial({ userId, userName, serviceType, identifier, serverName, durasi, kode, isEdurc = false }) {
    const waktu = formatTimestamp();
    const statusLabel = isReseller(userId) ? 'Reseller' : 'Member';
    const identifierGrup = sensorUsername(identifier || '-');

    const isCloudfront = isCloudfrontMode(isEdurc, serviceType);
    let modeProduk, modeHeader;
    if (isCloudfront) {
        modeProduk = `SSH CloudFront Trial`;
        modeHeader = `TRIAL BERHASIL`;
    } else if (isEdurc) {
        modeProduk = `${getNamaLayanan(serviceType, false, true)} EDURC`;
        modeHeader = `TRIAL BERHASIL`;
    } else {
        modeProduk = getNamaLayanan(serviceType, false, true);
        modeHeader = `TRIAL BERHASIL`;
    }

    const msgGrup =
`<b>-----------------------------------------</b>
<b>· ${modeHeader}</b>
<b>-----------------------------------------</b>
<b>Nama:</b> ${userName}
<b>Status:</b> ${statusLabel}
<b>Produk:</b> ${modeProduk}
<b>Masa Aktif:</b> 0 Hari (${durasi} menit)
<b>Login:</b> 1 devices
<b>Metode:</b> trial gratis
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifierGrup}</code>
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    const msgAdmin =
`<b>-----------------------------------------</b>
<b>· ${modeHeader}</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel} (${userName})
<b>User ID:</b> ${userId}
<b>Produk:</b> ${modeProduk}
<b>Masa Aktif:</b> 0 Hari (${durasi} menit)
<b>Login:</b> 1 devices
<b>Metode:</b> trial gratis
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifier || '-'}</code>
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    await sendNotifAll(msgGrup, msgAdmin);
}

// ==================== NOTIFIKASI RENEW ====================
async function kirimNotifikasiRenew({ userId, userName, serviceType, identifier, serverName, harga, sisaSaldo, days, iplimit, kode, isEdurc = false }) {
    const waktu = formatTimestamp();
    const statusLabel = isReseller(userId) ? 'Reseller' : 'Member';
    const identifierGrup = sensorUsername(identifier || '-');

    const isCloudfront = isCloudfrontMode(isEdurc, serviceType);
    let produk;
    if (isCloudfront) {
        produk = `SSH CloudFront`;
    } else if (isEdurc) {
        produk = `${getNamaLayanan(serviceType, false, false)} EDURC`;
    } else {
        produk = getNamaLayanan(serviceType, false, false);
    }

    const msgGrup =
`<b>-----------------------------------------</b>
<b>· RENEW SUKSES</b>
<b>-----------------------------------------</b>
<b>Nama:</b> ${userName}
<b>Status:</b> ${statusLabel}
<b>Produk:</b> ${produk}
<b>Tambah:</b> +${days} Hari
<b>Login:</b> ${iplimit || 1} devices
<b>Metode:</b> saldo
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifierGrup}</code>
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    const msgAdmin =
`<b>-----------------------------------------</b>
<b>· RENEW SUKSES</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel} (${userName})
<b>User ID:</b> ${userId}
<b>Produk:</b> ${produk}
<b>Tambah:</b> +${days} Hari
<b>Login:</b> ${iplimit || 1} devices
<b>Metode:</b> saldo
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifier || '-'}</code>
<b>Harga:</b> ${formatRp(harga)}
<b>Saldo Sisa:</b> ${formatRp(sisaSaldo)}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    await sendNotifAll(msgGrup, msgAdmin);
}

// ==================== NOTIFIKASI TOPUP ====================
async function kirimNotifikasiTopup({ userId, userName, amount, sisaSaldo, txId, ocrBank, ocrTgl, ocrJumlah, imageBuffer }) {
    const waktu = formatTimestamp();
    const statusLabel = isReseller(userId) ? 'Reseller' : 'Member';

    const infoBank   = ocrBank   ? `\n<b>Bank/E-Wallet:</b> ${ocrBank}` : '';
    const infoTgl    = ocrTgl    ? `\n<b>Tgl Transfer:</b> ${ocrTgl}` : '';
    const infoJumlah = ocrJumlah ? `\n<b>Jumlah di Bukti:</b> ${formatRp(ocrJumlah)}` : '';

    const msgGrup =
`<b>-----------------------------------------</b>
<b>· TOPUP BERHASIL</b>
<b>-----------------------------------------</b>
<b>Nama:</b> ${userName}
<b>Status:</b> ${statusLabel}
<b>Nominal:</b> ${formatRp(amount)}
<b>Saldo Baru:</b> ${formatRp(sisaSaldo)}
<b>Kode TX:</b> ${txId}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    const msgAdmin =
`<b>-----------------------------------------</b>
<b>· TOPUP BERHASIL</b>
<b>-----------------------------------------</b>
<b>Nama:</b> ${userName}
<b>Status:</b> ${statusLabel}
<b>User ID:</b> ${userId}
<b>Nominal:</b> ${formatRp(amount)}
<b>Saldo Baru:</b> ${formatRp(sisaSaldo)}
<b>Kode TX:</b> ${txId}${infoBank}${infoTgl}${infoJumlah}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    // Kirim teks ke grup (tanpa foto)
    await sendToGroup(msgGrup);

    // Kirim foto bukti + caption ke admin (seperti WA bot)
    if (imageBuffer) {
        await sendPhotoToAdmins(imageBuffer, ` <b>BUKTI PEMBAYARAN</b>\n\n${msgAdmin.replace(/<b>-+<\/b>\n/g, '')}`);
    } else {
        await sendToAdmins(msgAdmin);
    }
}

// ==================== NOTIFIKASI PAYG CREATE ====================
async function kirimNotifikasiCreatePayg({ userId, userName, serviceType, identifier, serverName, perJam, sisaSaldo, kode }) {
    const waktu = formatTimestamp();
    const statusLabel = isReseller(userId) ? 'Reseller' : 'Member';
    const produk = getNamaLayanan(serviceType, true, false);
    const identifierGrup = sensorUsername(identifier || '-');

    const msgGrup =
`<b>-----------------------------------------</b>
<b>· ORDER BERHASIL</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel}
<b>Produk:</b> ${produk}
<b>Masa Aktif:</b> 0 Hari (Pay as You Go)
<b>Login:</b> 1 devices
<b>Metode:</b> saldo
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifierGrup}</code>
<b>Tarif:</b> ${formatRp(perJam)}/jam
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    const msgAdmin =
`<b>-----------------------------------------</b>
<b>· ORDER BERHASIL</b>
<b>-----------------------------------------</b>
<b>Status:</b> ${statusLabel} (${userName})
<b>User ID:</b> ${userId}
<b>Produk:</b> ${produk}
<b>Masa Aktif:</b> 0 Hari (Pay as You Go)
<b>Login:</b> 1 devices
<b>Metode:</b> saldo
<b>Server:</b> ${serverName || '-'}
<b>Username:</b> <code>${identifier || '-'}</code>
<b>Tarif:</b> ${formatRp(perJam)}/jam
<b>Saldo Sisa:</b> ${formatRp(sisaSaldo)}
<b>Waktu:</b> ${waktu}
<b>-----------------------------------------</b>`;

    await sendNotifAll(msgGrup, msgAdmin);
}

// ==================== PAYG ENGINE ====================
async function deleteAkunPaygFromServer(server, akun) {
    const svcType = (akun.serviceType || '').toString().trim().toLowerCase();
    const mod = getModule(svcType);

    async function doDelete(identifier) {
        if (svcType === 'ssh')     return await mod.deleteSSH(server, identifier);
        if (svcType === 'trojan')  return await mod.deleteTrojan(server, identifier);
        if (svcType === 'vless')   return await mod.deleteVless(server, identifier);
        if (svcType === 'vmess')   return await mod.deleteVmess(server, identifier);
        if (svcType === 'zivpn')   return await mod.zivpnDelete(server, identifier);
        return { success: false, message: 'Tipe tidak dikenal' };
    }

    try {
        const primaryId = akun.username || akun.password;
        console.log(`[deleteAkunPaygFromServer] type=${svcType} identifier="${primaryId}" server=${server.name}`);
        let result = await doDelete(primaryId);
        console.log(`[deleteAkunPaygFromServer] result: success=${result?.success} msg=${result?.message}`);

        if (!result?.success && akun.password && akun.password !== primaryId) {
            console.log(`[deleteAkunPaygFromServer] Retry dengan password: "${akun.password}"`);
            const retry = await doDelete(akun.password);
            console.log(`[deleteAkunPaygFromServer] Retry: success=${retry?.success} msg=${retry?.message}`);
            if (retry?.success) return retry;
        }
        return result;
    } catch(e) {
        console.log(`[deleteAkunPaygFromServer] EXCEPTION: ${e.message}`);
        return { success: false, message: e.message };
    }
}

async function jalankanPayAsYouGo() {
    const akun = loadAkun();
    const now = new Date();
    let totalPotong = 0, totalHapus = 0;

    for (const [userId, akunList] of Object.entries(akun)) {
        if (!Array.isArray(akunList)) continue;
        const akunToKeep = [];
        const akunDeleted = [];

        // Baca saldo sekali di awal per user, update lokal agar tidak race condition
        let saldoUser = getSaldo(userId);

        for (const a of akunList) {
            if (!a.payAsYouGo || a.status === 'deleted') {
                akunToKeep.push(a);
                continue;
            }

            // ===== SESSION PER AKUN (sama seperti bot WA) =====
            // Migrasi akun lama yang belum punya paygNextDeduct
            if (!a.paygNextDeduct) {
                const base = a.paygLastDeduct || a.createdAt || now.toISOString();
                a.paygNextDeduct = new Date(new Date(base).getTime() + 60 * 60 * 1000).toISOString();
            }

            // Belum waktunya potong? Lewati dulu
            if (now < new Date(a.paygNextDeduct)) {
                akunToKeep.push(a);
                continue;
            }

            console.log(` [PAYG] Jatuh tempo: ${userId} → ${a.username || a.password} (next: ${a.paygNextDeduct})`);

            // Harga per jam: pakai yang tersimpan di akun (sudah dihitung dari harga server saat create)
            // Fallback: hitung dari harga server aktif, atau global jika server tidak ada
            let perJam;
            if (a.hargaPerJam) {
                perJam = a.hargaPerJam;
            } else {
                const serverForPayg = a.serverId ? SERVERS[a.serverId] : Object.values(SERVERS).find(s => s.name === a.serverName);
                perJam = hitungPerJamPayg(a.iplimit || CONFIG.DEFAULT_IP_LIMIT || 1, serverForPayg || null);
            }

            if (saldoUser >= perJam) {
                // Potong saldo
                kurangiSaldo(userId, perJam);
                saldoUser -= perJam; // update lokal agar tidak re-read file

                a.paygLastDeduct = now.toISOString();
                // Set waktu potong berikutnya: 1 jam dari sekarang (sesi individual)
                a.paygNextDeduct = new Date(now.getTime() + 60 * 60 * 1000).toISOString();
                totalPotong++;

                simpanTransaksi({
                    txId: generateTxId(), userId,
                    type: 'payg_deduct', amount: perJam,
                    keterangan: `PAYG/jam: ${a.username || a.password} (${(a.serviceType || '').toUpperCase()})`,
                    waktu: now.toISOString(), status: 'success',
                    userName: a.userName || userId
                });

                akunToKeep.push(a);

                const sisaSaldoDeduct = saldoUser;
                const sisaJam = Math.floor(sisaSaldoDeduct / perJam);

                // Notif pemotongan saldo ke grup & admin
                try {
                    let deductUserName = userId;
                    try { const chat = await bot.telegram.getChat(parseInt(userId)); deductUserName = chat.first_name || chat.username || userId; } catch(e) {}
                    await kirimNotifikasiDeductPayg({
                        userId,
                        userName: deductUserName,
                        serviceType: a.serviceType || '',
                        identifier: a.username || a.password,
                        serverName: a.serverName || '-',
                        potongan: perJam,
                        sisaSaldo: sisaSaldoDeduct
                    });
                } catch(e) { console.error('[PAYG] Notif deduct error:', e.message); }

                // Peringatan saldo ≤ 3 jam → kirim notif ke user
                if (sisaJam <= 3 && sisaJam > 0) {
                    try {
                        await bot.telegram.sendMessage(parseInt(userId),
                            ` <b>PERINGATAN SALDO PAYG!</b>

` +
                            `Akun <b>${a.username || a.password}</b> (${(a.serviceType || '').toUpperCase()})
` +
                            ` Sisa Saldo: ${formatRp(sisaSaldoDeduct)}
` +
                            ` Estimasi habis: <b>${sisaJam} jam lagi</b>

` +
                            `Segera topup agar akun tidak dihapus!
` +
                            `Ketik /menu → Topup Saldo `,
                            { parse_mode: 'HTML' }
                        );
                    } catch(e) {}
                }

            } else {
                // Saldo habis → hapus akun dari server
                console.log(`[PAYG] Saldo habis: ${userId} → hapus ${a.username || a.password}`);
                const server = a.serverId ? SERVERS[a.serverId] : Object.values(SERVERS).find(s => s.name === a.serverName);
                if (server) await deleteAkunPaygFromServer(server, a);
                if (server) kurangiSlotTerpakai(server);

                a.status = 'deleted';
                a.deletedAt = now.toISOString();
                a.deleteReason = 'PAYG saldo habis';
                akunDeleted.push(a);
                totalHapus++;

                simpanTransaksi({
                    txId: generateTxId(), userId,
                    type: 'payg_delete', amount: 0,
                    keterangan: `PAYG auto-hapus: ${a.username || a.password} (saldo habis)`,
                    waktu: now.toISOString(), status: 'success',
                    userName: a.userName || userId
                });

                const sisaSaldoHapus = saldoUser;

                // Notif ke user
                try {
                    await bot.telegram.sendMessage(parseInt(userId),
                        ` <b>AKUN PAYG DIHAPUS OTOMATIS</b>

` +
                        `Akun dihapus karena <b>saldo habis</b>.

` +
                        ` <b>Akun:</b> ${a.username || a.password}
` +
                        ` <b>Tipe:</b> ${(a.serviceType || '').toUpperCase()}
` +
                        ` <b>Server:</b> ${a.serverName || '-'}
` +
                        ` <b>Saldo:</b> ${formatRp(sisaSaldoHapus)}

` +
                        `Topup dan buat akun baru via /menu`,
                        { parse_mode: 'HTML' }
                    );
                } catch(e) {}

                // Notif grup & admin — FIX: tidak pakai ctx (tidak ada di scope ini)
                try {
                    let hapusUserName = userId;
                    try { const chat = await bot.telegram.getChat(parseInt(userId)); hapusUserName = chat.first_name || chat.username || userId; } catch(e) {}
                    await kirimNotifikasiAutoHapusPayg({
                        userId,
                        userName: hapusUserName,
                        serviceType: a.serviceType || '',
                        identifier: a.username || a.password,
                        serverName: a.serverName || '-',
                        sisaSaldo: sisaSaldoHapus
                    });
                } catch(e) { console.error('[PAYG] Notif auto-hapus error:', e.message); }
            }
        }

        akun[userId] = [...akunToKeep, ...akunDeleted];

        // Jeda kecil antar user agar tidak semua diproses serentak
        await new Promise(resolve => setTimeout(resolve, 100));
    }

    saveAkun(akun);
    if (totalPotong > 0 || totalHapus > 0)
        console.log(` [PAYG] Selesai: ${totalPotong} dipotong, ${totalHapus} dihapus`);
}

// Jalankan PAYG engine setiap 1 menit (potong sesuai paygNextDeduct per akun)
setInterval(async () => {
    try { await jalankanPayAsYouGo(); } catch(e) { console.error('[PAYG] Error:', e.message); }
}, 60 * 1000);
console.log(' [PAYG] Interval aktif (cek setiap menit, potong sesuai sesi per akun)');

// ==================== AKUN SAYA ====================
// Ambil timestamp expired yang akurat: pakai expiredTimestamp (Unix ms) kalau ada,
// baru fallback parse dari string display (mis. "18 Mei 2026") supaya tidak salah
// dianggap Expired hanya gara-gara native Date() gagal parse nama bulan Indonesia.
function getExpiredTimestampAkun(a) {
    if (a.expiredTimestamp) return a.expiredTimestamp;
    return parseExpiredStringToTimestamp(a.expired);
}

// Selisih hari berbasis TANGGAL KALENDER (bukan pembulatan ke atas dari selisih ms),
// supaya tidak "lebih 1 hari" akibat sisa jam di hari yang sama dibulatkan ke atas.
// Expired besok pukul berapa pun = 1 hari lagi. Expired hari ini = 0 hari lagi.
function hitungSisaHariKalender(expiredTimestampMs) {
    const now = new Date();
    const exp = new Date(expiredTimestampMs);
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfExpiry = new Date(exp.getFullYear(), exp.getMonth(), exp.getDate());
    return Math.round((startOfExpiry - startOfToday) / (1000 * 60 * 60 * 24));
}

// Render satu blok info akun untuk ditampilkan di "Akun Saya" (dipakai juga oleh fitur pencarian)
function renderAkunSayaEntry(a, displayIndex) {
    const typeIconMap = { ssh: '🔑', trojan: '🛡', vless: '⚡', vmess: '🌀', zivpn: '🌀' };
    const serviceType = (a.serviceType || '').toLowerCase();
    const tipe = serviceType.toUpperCase() || '-';
    const typeIcon = typeIconMap[serviceType] || '📡';
    const identifier = a.username || a.password || '-';
    const server = a.serverName || '-';
    const iplimit = a.iplimit || 1;

    // Label jenis akun (Reguler / EDURC / Cloudfront)
    let modeLabel = '📡 Reguler';
    if (a.isEdurc) {
        modeLabel = serviceType === 'ssh' ? '☁️ Cloudfront' : '🌐 EDURC';
    }

    let statusIcon = '✅';
    let statusLine = 'Aktif';
    if (a.payAsYouGo) {
        statusIcon = '⚡';
        statusLine = 'PAYG';
    } else if (a.isTrial) {
        statusIcon = '🧪';
        statusLine = 'Trial';
    } else {
        const expTs = getExpiredTimestampAkun(a);
        if (expTs) {
            const sisaHari = hitungSisaHariKalender(expTs);
            if (expTs > Date.now()) {
                statusIcon = sisaHari <= 3 ? '⏳' : '✅';
                statusLine = sisaHari <= 0 ? 'Aktif · Expired hari ini' : `Aktif · ${sisaHari} hari lagi`;
            } else {
                statusIcon = '❌';
                statusLine = 'Expired';
            }
        } else {
            statusIcon = '❔';
            statusLine = '-';
        }
    }

    return `
<blockquote><b>${displayIndex}. ${typeIcon} ${tipe}</b> · ${modeLabel}
🆔 <code>${identifier}</code>
🖥 <b>Server:</b> ${server}
🌐 <b>IP Limit:</b> ${iplimit}
${statusIcon} <b>Status:</b> ${statusLine}</blockquote>`;
}

// Urutkan akun dari yang paling baru dibuat (createdAt desc)
function sortAkunTerbaru(list) {
    return [...list].sort((x, y) => {
        const tx = x.createdAt ? new Date(x.createdAt).getTime() : 0;
        const ty = y.createdAt ? new Date(y.createdAt).getTime() : 0;
        return ty - tx;
    });
}

async function showAkunSaya(ctx, page = 0) {
    const userId = ctx.from.id.toString();
    const akunData = loadAkun();
    const akunList = akunData[userId] || [];
    const akunAktif = sortAkunTerbaru(akunList.filter(a => a.status !== 'deleted'));

    if (akunAktif.length === 0) {
        const keyboard = Markup.inlineKeyboard([
            [{ text: '➕ 𝘾𝙧𝙚𝙖𝙩𝙚 𝘼𝙠𝙪𝙣', callback_data: 'create_menu' }, { text: '⚡ 𝙋𝘼𝙔𝙂', callback_data: 'payg_menu' }],
            [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'main_menu', style: 'danger' }]
        ]);
        await sendMenu(ctx,
            `${getHeader(' 𝘼𝙆𝙐𝙉 𝙎𝘼𝙔𝘼')}
<blockquote>📭 Anda belum memiliki akun aktif.

Gunakan <b>Create Akun</b> atau <b>PAYG</b> untuk membuat akun baru.</blockquote>`,
            keyboard
        );
        return;
    }

    const itemsPerPage = 5;
    const totalPages = Math.ceil(akunAktif.length / itemsPerPage);
    page = Math.max(0, Math.min(page, totalPages - 1));
    const start = page * itemsPerPage;
    const end = start + itemsPerPage;
    const pageAkun = akunAktif.slice(start, end);

    let text = `${getHeader(' 𝘼𝙆𝙐𝙉 𝙎𝘼𝙔𝘼')}`;

    pageAkun.forEach((a, idx) => {
        text += renderAkunSayaEntry(a, start + idx + 1);
    });

    text += `

<blockquote>📂 <b>Total Akun:</b> ${akunAktif.length}</blockquote>
<b>· Halaman ${page + 1} dari ${totalPages}</b>`;
    const navButtons = [];
    if (page > 0) {
        navButtons.push({ text: '◀ 𝙎𝙚𝙗𝙚𝙡𝙪𝙢𝙣𝙮𝙖', callback_data: `akun_saya_page_${page - 1}` });
    }
    if (page < totalPages - 1) {
        navButtons.push({ text: '𝙎𝙚𝙡𝙖𝙣𝙟𝙪𝙩𝙣𝙮𝙖 ▶', callback_data: `akun_saya_page_${page + 1}` });
    }

    // Tombol Stop PAYG jika ada akun PAYG
    const akunPayg = akunAktif.filter(a => a.payAsYouGo);
    const buttons = [];
    if (navButtons.length > 0) {
        buttons.push(navButtons);
    }
    buttons.push([{ text: '🔍 𝘾𝙖𝙧𝙞 𝘼𝙠𝙪𝙣', callback_data: 'akun_saya_search' }]);
    if (akunPayg.length > 0) {
        buttons.push([{ text: '⏹ 𝙎𝙩𝙤𝙥 𝙋𝘼𝙔𝙂', callback_data: 'payg_stop_list' }]);
    }
    buttons.push([{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'panel_vpn', style: 'danger' }]);

    await sendMenu(ctx, text, Markup.inlineKeyboard(buttons));
}

// ==================== PENCARIAN AKUN SAYA ====================
async function promptAkunSayaSearch(ctx) {
    const userId = ctx.from.id.toString();
    userStates.set(userId, { action: 'akun_saya_search_input' });

    const text = `${getHeader(' 𝘾𝘼𝙍𝙄 𝘼𝙆𝙐𝙉')}
<blockquote>🔍 Ketik <b>username / password / UUID</b> akun yang ingin dicari (boleh sebagian saja).</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'akun_saya', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function processAkunSayaSearchInput(ctx, message) {
    const userId = ctx.from.id.toString();

    if (message.trim().toLowerCase() === 'cancel') {
        userStates.delete(userId);
        await showAkunSaya(ctx);
        return;
    }

    const keyword = message.trim().toLowerCase();
    if (keyword.length < 2) {
        await sendTempMessage(ctx, ' Kata kunci terlalu pendek (minimal 2 karakter)');
        return;
    }

    userStates.delete(userId);

    const akunData = loadAkun();
    const akunList = akunData[userId] || [];
    const akunAktif = sortAkunTerbaru(akunList.filter(a => a.status !== 'deleted'));

    const hasil = akunAktif.filter(a => {
        const target = [a.username, a.password, a.uuid].filter(Boolean).join(' ').toLowerCase();
        return target.includes(keyword);
    });

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔍 𝘾𝙖𝙧𝙞 𝙇𝙖𝙜𝙞', callback_data: 'akun_saya_search' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘼𝙆𝙐𝙉 𝙎𝘼𝙔𝘼', callback_data: 'akun_saya', style: 'danger' }]
    ]);

    if (hasil.length === 0) {
        await sendMenu(ctx,
            `${getHeader(' 𝙃𝘼𝙎𝙄𝙇 𝙋𝙀𝙉𝘾𝘼𝙍𝙄𝘼𝙉')}
<blockquote>📭 Tidak ada akun yang cocok dengan kata kunci <code>${message.trim()}</code>.</blockquote>`,
            keyboard
        );
        return;
    }

    let text = `${getHeader(' 𝙃𝘼𝙎𝙄𝙇 𝙋𝙀𝙉𝘾𝘼𝙍𝙄𝘼𝙉')}
<blockquote>🔍 Kata kunci: <code>${message.trim()}</code></blockquote>`;

    hasil.slice(0, 10).forEach((a, idx) => {
        text += renderAkunSayaEntry(a, idx + 1);
    });

    if (hasil.length > 10) {
        text += `\n<blockquote>Menampilkan 10 dari ${hasil.length} hasil. Perjelas kata kunci untuk hasil lebih spesifik.</blockquote>`;
    }

    await sendMenu(ctx, text, keyboard);
}

// ==================== PAYG MENU ====================
async function showPaygMenu(ctx) {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const perJam = Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * CONFIG.MAX_IP_LIMIT / 24);
    const isResellerUser = isReseller(userId);

    const text = `${getHeader(' 𝙋𝘼𝙔 𝘼𝙎 𝙔𝙊𝙐 𝙂𝙊 (𝙋𝘼𝙔𝙂)')}
<blockquote>🔧 Pilih protokol yang ingin digunakan. Detail <b>layanan &amp; harga</b> akan ditampilkan setelah Anda memilih protokol.</blockquote>`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '🔑 𝙎𝙎𝙃', callback_data: 'payg_create_ssh' }, { text: '🛡 𝙏𝙍𝙊𝙅𝘼𝙉', callback_data: 'payg_create_trojan' }],
        [{ text: '⚡ 𝙑𝙇𝙀𝙎𝙎', callback_data: 'payg_create_vless' }, { text: '🌀 𝙑𝙈𝙀𝙎𝙎', callback_data: 'payg_create_vmess' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'panel_vpn', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showPaygMyAkun(ctx) {
    const userId = ctx.from.id.toString();
    const akunData = loadAkun();
    const akunPayg = (akunData[userId] || []).filter(a => a.payAsYouGo && a.status !== 'deleted');

    if (akunPayg.length === 0) {
        await sendTempMessage(ctx, ` Anda belum memiliki akun PAYG aktif.\n\nGunakan menu <b>· Pay As You Go</b> untuk membuat akun baru.`);
        await showPaygMenu(ctx);
        return;
    }

    let text = `${getHeader(' 𝘼𝙆𝙐𝙉 𝙋𝘼𝙔𝙂 𝙎𝘼𝙔𝘼')}\n\n`;

    akunPayg.forEach((a, i) => {
        const tipe = (a.serviceType || '').toUpperCase();
        const identifier = a.username || a.password || '-';
        const perJam = a.hargaPerJam || Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * (a.iplimit || 1) / 24);
        text += `<b>${i+1}. [${tipe}]</b> <code>${identifier}</code>\n`;
        text += `<b>Server:</b> ${a.serverName || '-'}\n`;
        text += `<b>Tarif:</b> ${formatRp(perJam)}/jam\n`;
        if (i < akunPayg.length - 1) text += `<b></b>\n`;
    });

    const keyboard = Markup.inlineKeyboard([
        [{ text: '⏹ 𝙎𝙩𝙤𝙥 𝙋𝘼𝙔𝙂', callback_data: 'payg_stop_list' }],
        [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'payg_menu', style: 'danger' }]
    ]);

    await sendMenu(ctx, text, keyboard);
}

async function showPaygStopList(ctx) {
    const userId = ctx.from.id.toString();
    const akunData = loadAkun();
    const akunPayg = (akunData[userId] || []).filter(a => a.payAsYouGo && a.status !== 'deleted');

    if (akunPayg.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada akun PAYG aktif yang bisa dihentikan.`);
        return;
    }

    const buttons = akunPayg.map((a, i) => {
        const tipe = (a.serviceType || '').toUpperCase();
        const identifier = a.username || a.password || '-';
        return [{ text: ` [${tipe}] ${identifier.substring(0, 15)}`, callback_data: `payg_stop_confirm_${i}` }];
    });
    buttons.push([{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'payg_my_akun', style: 'danger' }]);

    await sendTempMessage(ctx,
        `${getHeader(' 𝙎𝙏𝙊𝙋 𝙋𝘼𝙔𝙂')}\n\nPilih akun PAYG yang ingin dihentikan:`,
        Markup.inlineKeyboard(buttons)
    );
}

async function handlePaygStopConfirm(ctx, idx) {
    const userId = ctx.from.id.toString();
    const akunData = loadAkun();
    const akunPayg = (akunData[userId] || []).filter(a => a.payAsYouGo && a.status !== 'deleted');

    if (!akunPayg[idx]) {
        await sendTempMessage(ctx, ` Akun PAYG tidak ditemukan.`);
        return;
    }

    const target = akunPayg[idx];
    const identifier = target.username || target.password || '-';
    const tipe = (target.serviceType || '').toUpperCase();
    const perJam = target.hargaPerJam || Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * (target.iplimit || 1) / 24);

    userStates.set(userId, { action: 'payg_stop_exec', paygIdx: idx });

    const text = `${getHeader(' 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙎𝙏𝙊𝙋 𝙋𝘼𝙔𝙂')}
<blockquote><b>· Konfirmasi Stop PAYG</b>
<b></b>
<b>Akun:</b> <code>${identifier}</code>
<b>Tipe:</b> ${tipe}
<b>Server:</b> ${target.serverName || '-'}
<b>Tarif:</b> ${formatRp(perJam)}/jam</blockquote>

 Akun akan <b>DIHAPUS PERMANEN</b> dari server. Lanjutkan?`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '⛔ 𝙔𝙖, 𝘽𝙚𝙧𝙝𝙚𝙣𝙩𝙞 & 𝙃𝙖𝙥𝙪𝙨', callback_data: `payg_stop_exec_${idx}` }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'payg_my_akun', style: 'danger' }]
    ]);

    await sendTempMessage(ctx, text, keyboard);
}

async function eksekusiStopPayg(ctx, idx) {
    const userId = ctx.from.id.toString();
    const firstName = ctx.from.first_name || userId;
    const akunData = loadAkun();
    const akunList = akunData[userId] || [];

    // Cari ulang akun PAYG aktif
    const akunPaygAktif = akunList.filter(a => a.payAsYouGo && a.status !== 'deleted');
    const target = akunPaygAktif[idx];

    if (!target) {
        await sendTempMessage(ctx, ` Akun PAYG tidak ditemukan atau sudah dihapus.`);
        return;
    }

    const identifier = target.username || target.password || '-';
    const loadingMsg = await ctx.reply(` Menghapus akun PAYG <b>${identifier}</b>...`, { parse_mode: 'HTML' });

    try {
        // Hapus dari server
        let deleteResult = { success: false, message: 'Server tidak ditemukan' };
        const server = target.serverId ? SERVERS[target.serverId] : Object.values(SERVERS).find(s => s.name === target.serverName);
        if (server) deleteResult = await deleteAkunPaygFromServer(server, target);

        // Hapus dari lokal
        akunData[userId] = akunList.filter(a =>
            !(a.payAsYouGo && (a.username === identifier || a.password === identifier))
        );
        saveAkun(akunData);
        if (server) kurangiSlotTerpakai(server);

        try { await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id); } catch(e) {}

        const sisaSaldo = getSaldo(userId);

        simpanTransaksi({
            txId: generateTxId(), userId,
            userName: firstName,
            type: 'payg_stop', amount: 0,
            keterangan: `User stop PAYG: ${identifier} (${(target.serviceType || '').toUpperCase()})`,
            waktu: new Date().toISOString(), status: 'success'
        });

        if (deleteResult && deleteResult.success) {
            await sendResultMessage(ctx,
                ` <b>PAYG BERHASIL DIHENTIKAN!</b>\n\n` +
                ` <b>Akun:</b> <code>${identifier}</code>\n` +
                ` <b>Tipe:</b> ${(target.serviceType || '').toUpperCase()}\n` +
                ` <b>Server:</b> ${target.serverName || '-'}\n` +
                ` <b>Status:</b> Akun telah dihapus dari server`
            );
        } else {
            await sendResultMessage(ctx,
                ` <b>PAYG dihentikan (data lokal dihapus)</b>\n\n` +
                ` <b>Akun:</b> <code>${identifier}</code>\n` +
                ` Gagal hapus dari server: ${deleteResult?.message || 'Unknown'}\n\n` +
                `Silakan hapus manual dari dashboard server jika diperlukan.`
            );
        }

        // Notif admin
        try {
            await kirimNotifikasiStopPayg({
                userId, userName: firstName,
                serviceType: target.serviceType || '',
                identifier, serverName: target.serverName || '-',
                sisaSaldo
            });
        } catch(e) {}

    } catch(err) {
        try { await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id); } catch(e) {}
        await sendTempMessage(ctx, ` Error: ${err.message}`);
    }

    userStates.delete(userId);
}

// ==================== PAYG CREATE FLOW ====================
async function handlePaygCreate(ctx, serviceType) {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const perJam = hitungPerJamPayg(1); // pakai 1 IP untuk cek minimum saldo

    if (saldo < perJam) {
        const keyboard = Markup.inlineKeyboard([
            [{ text: '💳 𝙏𝙤𝙥𝙪𝙥 𝙎𝙖𝙡𝙙𝙤', callback_data: 'topup' }],
            [{ text: '↩️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'payg_menu', style: 'danger' }]
        ]);
        await sendTempMessage(ctx,
            ` <b>Saldo tidak cukup untuk PAYG!</b>\n\n` +
            ` Saldo Kamu: ${formatRp(saldo)}\n\n` +
            `Silakan topup terlebih dahulu.`,
            keyboard
        );
        return;
    }

    const servers = await getServerList(serviceType);
    if (servers.length === 0) {
        await sendTempMessage(ctx, ` Tidak ada server tersedia untuk layanan ${serviceType.toUpperCase()}.`);
        return;
    }

    userStates.set(userId, { action: 'payg_select_server', serviceType, step: 'select_server' });

    const hargaLines = buildHargaLayananLines(userId, 'jam', [], { includeTypes: serviceType === 'ssh' ? ['ssh'] : ['xray'], accountTypeLabel: 'Pay As You Go' });
    const isResellerUser = isReseller(userId);
    const resellerStatusLine = isResellerUser
        ? `\n<b>· Status: Reseller (Diskon ${getDiskonResellerPersen()}%)</b>`
        : '';
    const keyboard = getServerKeyboard(servers, `payg_server`);
    await sendMenu(ctx,
        `${getHeader(` 𝘾𝙍𝙀𝘼𝙏𝙀 𝙋𝘼𝙔𝙂 ${formatServiceBold(serviceType)}`)}
<blockquote><b>· Protokol:</b> ${formatServiceBold(serviceType)}

<b>LAYANAN &amp; HARGA</b>
${hargaLines}${resellerStatusLine}</blockquote>

<b>· Pilih server yang akan digunakan:</b>`,
        keyboard
    );
}

async function processPaygSelectServer(ctx, serverId) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state) return;

    const server = SERVERS[serverId];
    if (!server) {
        await sendTempMessage(ctx, ` Server tidak ditemukan.`);
        return;
    }

    const slotInfo = getSlotInfo(server);
    if (slotInfo.penuh) {
        await sendMenu(ctx,
            `${getHeader(' 𝙎𝙇𝙊𝙏 𝙋𝙀𝙉𝙐𝙃')}\n\n❌ <b>Slot server "${server.name}" PENUH</b>.\n\nSilakan pilih server lain.`,
            Markup.inlineKeyboard([
                [{ text: '🔙 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙛𝙩𝙖𝙧 𝙎𝙚𝙧𝙫𝙚𝙧', callback_data: `payg_create_${state.serviceType}`, style: 'danger' }]
            ])
        );
        return;
    }

    const serviceType = state.serviceType;
    userStates.set(userId, { action: 'payg_input', serviceType, server, step: 'username', data: {} });

    if (serviceType === 'zivpn') {
        userStates.get(userId).step = 'password';
        const promptText = `${getHeader(` 𝘾𝙍𝙀𝘼𝙏𝙀 𝙋𝘼𝙔𝙂 𝙕𝙄𝙑𝙋𝙉`)}\n\n <b>Pilih atau buat PASSWORD</b> untuk akun ZiVPN PAYG:`;
        await sendMenu(ctx, promptText, Markup.inlineKeyboard([
            [{ text: '🎲 𝙍𝙖𝙣𝙙𝙤𝙢 𝙋𝙖𝙨𝙨𝙬𝙤𝙧𝙙', callback_data: 'payg_pw_random' }, { text: '⌨️ 𝘾𝙪𝙨𝙩𝙤𝙢 𝙋𝙖𝙨𝙨𝙬𝙤𝙧𝙙', callback_data: 'payg_pw_custom' }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'payg_menu', style: 'danger' }]
        ]));
    } else {
        const prompt = `${getHeader(` 𝘾𝙍𝙀𝘼𝙏𝙀 𝙋𝘼𝙔𝙂 ${formatServiceBold(serviceType)}`)}\n\n Masukkan <b>username</b> untuk akun PAYG Anda.\nContoh: <code>namauser</code>`;
        await sendMenu(ctx, prompt, cancelKeyboard());
    }
}

async function processPaygInput(ctx, message, state) {
    const userId = ctx.from.id.toString();
    const { serviceType, server, step, data } = state;

    if (serviceType === 'zivpn') {
        // ZiVPN hanya butuh password
        data.password = message;
        await showPaygConfirm(ctx, serviceType, server, data);
        return;
    }

    if (step === 'username') {
        data.username = message;
        userStates.set(userId, { action: 'payg_input', serviceType, server, step: 'password', data });

        const isXray = ['trojan', 'vless', 'vmess'].includes(serviceType);
        const randomLabel = isXray ? ' Random UUID' : ' Random Password';
        const promptText = `${getHeader(` 𝘾𝙍𝙀𝘼𝙏𝙀 𝙋𝘼𝙔𝙂 ${formatServiceBold(serviceType)}`)}\n\n <b>Pilih atau buat PASSWORD</b> untuk akun PAYG.`;
        await sendMenu(ctx, promptText, Markup.inlineKeyboard([
            [{ text: randomLabel, callback_data: 'payg_pw_random' }, { text: '⌨️ 𝘾𝙪𝙨𝙩𝙤𝙢 𝙋𝙖𝙨𝙨𝙬𝙤𝙧𝙙', callback_data: 'payg_pw_custom' }],
            [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'payg_menu', style: 'danger' }]
        ]));
        return;
    }

    if (step === 'password' || step === 'password_manual') {
        let pwd = message;
        if (pwd.length < 4) {
            await sendTempMessage(ctx, ` Password minimal 4 karakter. Silakan coba lagi.`);
            return;
        }
        data.password = pwd;
        await showPaygConfirm(ctx, serviceType, server, data);
    }
}

async function showPaygConfirm(ctx, serviceType, server, data) {
    const userId = ctx.from.id.toString();
    // Simpan state dulu, tampilkan pilih IP
    userStates.set(userId, { action: 'payg_select_ip', serviceType, server, data });
    await showIpLimitMenu(ctx, 'payg_ip', null, true, server);
}

// ====== Helper: lanjut setelah IP limit dipilih di PAYG ======
async function processPaygAfterIpSelect(ctx, iplimit) {
    const userId = ctx.from.id.toString();
    const state  = userStates.get(userId);
    if (!state || state.action !== 'payg_select_ip') return;

    const { serviceType, server, data } = state;
    const perJamNormal = hitungPerJamPayg(iplimit, server);
    const perJam  = isReseller(userId) ? hitungHargaReseller(perJamNormal) : perJamNormal;
    const isResellerUser = isReseller(userId);
    const identifier = data.username || data.password || '-';

    userStates.set(userId, { action: 'payg_confirm', serviceType, server, data, iplimit, perJam });

    const diskonLabel = isResellerUser
        ? `\n<b>· Harga Normal:</b> ${formatRp(perJamNormal)}/jam\n<b>· Harga Reseller:</b> ${formatRp(perJam)}/jam`
        : `\n<b>Tarif:</b> ${formatRp(perJam)}/jam`;

    const text = `${getHeader(' 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙋𝘼𝙔𝙂')}
<blockquote><b>Layanan:</b> ${serviceType.toUpperCase()} PAYG
<b>Server:</b> ${server.name}
<b>${serviceType === 'zivpn' ? 'Password' : 'Username'}:</b> <code>${identifier}</code>
<b>IP Limit:</b> ${iplimit} IP${diskonLabel}</blockquote>

Lanjutkan pembuatan akun PAYG?`;

    const keyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝘼𝙠𝙩𝙞𝙛𝙠𝙖𝙣 𝙋𝘼𝙔𝙂', callback_data: 'payg_confirm_yes' }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'payg_menu', style: 'danger' }]
    ]);

    await sendTempMessage(ctx, text, keyboard);
}

async function eksekusiCreatePayg(ctx) {
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    if (!state || state.action !== 'payg_confirm') return;

    const { serviceType, server, data, iplimit, perJam } = state;
    const saldo = getSaldo(userId);

    if (saldo < perJam) {
        await sendTempMessage(ctx, ` Saldo tidak cukup! Topup terlebih dahulu.`);
        userStates.delete(userId);
        return;
    }

    const loadingMsg = await ctx.reply(` Membuat akun PAYG...`);

    try {
        const mod = getModule(serviceType);
        let result;
        const quota = getEffectiveQuota(server) || 0;
        const days = 36500; // berlaku "selamanya", PAYG yang kontrol

        if (serviceType === 'ssh') {
            result = await mod.createSSH(server, data.username, data.password, days, iplimit);
        } else if (serviceType === 'trojan') {
            result = await mod.createTrojan(server, data.username, data.password, days, iplimit, quota);
        } else if (serviceType === 'vless') {
            result = await mod.createVless(server, data.username, data.password, days, iplimit, quota);
        } else if (serviceType === 'vmess') {
            result = await mod.createVmess(server, data.username, data.password, days, iplimit, quota);
        } else if (serviceType === 'zivpn') {
            result = await mod.zivpnCreate(server, data.password, days, iplimit);
        } else {
            result = { success: false, message: 'Tipe tidak dikenal' };
        }

        try { await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id); } catch(e) {}

        if (result && result.success) {
            // Potong saldo 1 jam pertama
            kurangiSaldo(userId, perJam);

            // Hitung sebagai 1 transaksi reseller HANYA saat create PAYG pertama kali.
            // Potongan saldo per-jam berikutnya (PAYG deduct) TIDAK dihitung — lihat jalankanPayAsYouGo().
            if (isReseller(userId)) updateResellerActivity(userId);

            const userName = ctx.from.first_name || ctx.from.username || 'User';

            // Simpan akun PAYG
            const akunData = loadAkun();
            if (!akunData[userId]) akunData[userId] = [];
            akunData[userId].push({
                serviceType, username: data.username, password: data.password,
                serverId: server.id, serverName: server.name,
                iplimit, hargaPerJam: perJam,
                payAsYouGo: true, status: 'active',
                userName,
                createdAt: new Date().toISOString(),
                paygLastDeduct: new Date().toISOString(),
                // Pemotongan pertama: 1 jam dari waktu order (sesi individual per akun)
                paygNextDeduct: new Date(Date.now() + 60 * 60 * 1000).toISOString()
            });
            saveAkun(akunData);
            tambahSlotTerpakai(server); // PAYG bukan trial, jadi ikut hitung slot

            simpanTransaksi({
                txId: generateTxId(), userId,
                userName,
                type: 'payg_create', amount: perJam,
                keterangan: `Aktivasi PAYG ${serviceType.toUpperCase()} ${data.username || data.password} (${formatRp(perJam)}/jam)`,
                waktu: new Date().toISOString(), status: 'success'
            });

            // Format hasil — pakai formatCreateMessage sama seperti akun biasa
            const domain = server.apiUrl.split('/')[2]?.split(':')[0] || server.name;
            const paygAkunData = {
                username: data.username || data.password,
                password: data.password,
                uuid: data.password,
                expired: 'Pay as You Go',
                iplimit,
                quota: getEffectiveQuota(server) || 0,
                domain,
                serviceType,
                serverName: server.name
            };
            const resultText = formatCreateMessage(serviceType, paygAkunData, server.name)
                + `\n\n <b>Tarif:</b> ${formatRp(perJam)}/jam`
                + `\n\nℹ Akun otomatis berhenti jika saldo habis.`;

            // Notif ke grup & admin
            try {
                const kodePayg = getKodeAkun(userId, true, false, serviceType);
                await kirimNotifikasiCreatePayg({
                    userId,
                    userName: ctx.from.first_name || ctx.from.username || 'User',
                    serviceType,
                    identifier: data.username || data.password,
                    serverName: server.name,
                    perJam,
                    sisaSaldo: getSaldo(userId),
                    kode: kodePayg
                });
            } catch(e) {}

            await sendResultMessage(ctx, resultText);
        } else {
            await sendTempMessage(ctx, ` Gagal membuat akun PAYG: ${result?.message || 'Unknown error'}`);
        }

    } catch(err) {
        try { await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id); } catch(e) {}
        await sendTempMessage(ctx, ` Error: ${err.message}`);
    }

    userStates.delete(userId);
}

// ==================== COMMAND HANDLER ====================
// ==================== ADMIN DASHBOARD MODULE ====================
// Seluruh logic dashboard admin (66 fungsi) sudah dipindah ke admin.js.
// Di sini kita tinggal "colokin" semua dependency yang dibutuhkan module itu.
//
// Untuk variable yang nilainya bisa berubah sewaktu-waktu (SERVERS, GITHUB_TOKEN,
// PAKASIR_SLUG, dst), kita kasih dalam bentuk getter/setter FUNGSI (bukan value
// langsung) — supaya admin.js selalu baca/tulis nilai yang PALING BARU dari
// bot.js ini, bukan salinan basi dari saat pertama kali di-require.
function getServers() { return SERVERS; }

function getGithubToken() { return GITHUB_TOKEN; }
function setGithubToken(v) { GITHUB_TOKEN = v; }
function getGithubOwner() { return GITHUB_OWNER; }
function setGithubOwner(v) { GITHUB_OWNER = v; }
function getGithubRepo() { return GITHUB_REPO; }
function setGithubRepo(v) { GITHUB_REPO = v; }
function getGithubBranch() { return GITHUB_BRANCH; }
function setGithubBranch(v) { GITHUB_BRANCH = v; }

function getPakasirAktif() { return PAKASIR_AKTIF; }
function getPakasirApiKey() { return PAKASIR_API_KEY; }
function setPakasirApiKey(v) { PAKASIR_API_KEY = v; }
function getPakasirSlug() { return PAKASIR_SLUG; }
function setPakasirSlug(v) { PAKASIR_SLUG = v; }
function getPakasirMerchantName() { return PAKASIR_MERCHANT_NAME; }
function setPakasirMerchantName(v) { PAKASIR_MERCHANT_NAME = v; }

function getDanaAktif() { return DANA_AKTIF; }
function getDanaNama() { return DANA_NAMA; }
function setDanaNama(v) { DANA_NAMA = v; }
function getDanaNomor() { return DANA_NOMOR; }
function setDanaNomor(v) { DANA_NOMOR = v; }

function getGopayAktif() { return GOPAY_AKTIF; }
function getGopayNama() { return GOPAY_NAMA; }
function setGopayNama(v) { GOPAY_NAMA = v; }
function getGopayNomor() { return GOPAY_NOMOR; }
function setGopayNomor(v) { GOPAY_NOMOR = v; }

function getQrisDinamisAktif() { return QRIS_DINAMIS_AKTIF; }
function getQrisStatis() { return QRIS_STATIS; }

function getAutoBackupEnabled() { return autoBackupEnabled; }
function getAutoBackupIntervalMinutes() { return autoBackupIntervalMinutes; }

const adminModule = require('./admin.js')({
    CONFIG, Markup,
    addIpToRepo, addPaket, formatHarga, formatRp, formatTimestamp,
    generateServerId, generateTxId, getAllAkunCount, getAllResellerList,
    getDiskonReseller, getDiskonResellerPersen, setDiskonReseller,
    getAllSewa, getAllSewaBot, getAllUsersWithDetails, getBackupList,
    getEdurcDomain, getHargaSCExtraIp, getHargaTambahIpPerHari, getHargaTambahIpPerJam,
    getHeader, getLisensiFilePath, getPaketById, getPaketList, getSaldo,
    getScGithubBranch, getScGithubOwner, getScGithubRepo, getScGithubToken,
    getUserName, getUserStats, getUserStatsAll, hapusLisensiDanUpload,
    hitungHargaBotSeller, hitungHargaSC, isAdmin, isReseller, isSewaBotAktif,
    isSewaScAktif, kurangiSaldo, listIpFromRepo, loadAkun, loadBackupIndex,
    loadSaldo, loadTransaksi, removeIpFromRepo, removePaket, saveServers,
    getTotalSlotData: loadTotalSlot, setTotalSlotUsedManual,
    sendMenu, sendResultMessage, sendTempMessage, setEdurcDomain,
    setHargaBotSeller30Hari, setHargaBotSellerLifetime, setHargaSC30Hari,
    setHargaSCExtraIp, setScGithubBranch, setScGithubOwner, setScGithubRepo,
    setScGithubToken, sewaSCModule, simpanTransaksi, sshModule, tambahSaldo,
    tambahSewaRecord,
    isTopupBonusAktif, setTopupBonusAktif, getTopupBonusTiers, setTopupBonusTier,
    removeTopupBonusTier, formatRibuanSingkat,
    trojanModule, updateConfig, updateEnvValue, userStates, vlessModule,
    vmessModule, zivpnModule,
    getAutoBackupEnabled, getAutoBackupIntervalMinutes,
    getServers,
    getGithubToken, setGithubToken, getGithubOwner, setGithubOwner,
    getGithubRepo, setGithubRepo, getGithubBranch, setGithubBranch,
    getPakasirAktif, getPakasirApiKey, setPakasirApiKey, getPakasirSlug, setPakasirSlug,
    getPakasirMerchantName, setPakasirMerchantName,
    getDanaAktif, getDanaNama, setDanaNama, getDanaNomor, setDanaNomor,
    getGopayAktif, getGopayNama, setGopayNama, getGopayNomor, setGopayNomor,
    getQrisDinamisAktif, getQrisStatis,
});

const {
    showAdminSewaBotMenu, showAdminSewaBotList, startAdminBotRevoke, processAdminBotRevokeInput,
    showAdminTopupBonusMenu, startAdminTopupBonusAdd, processAdminTopupBonusAddInput,
    processAdminTopupBonusUnlimited,
    startAdminTopupBonusRemove, processAdminTopupBonusRemove,
    showAdminSewaScMenu, showAdminScList, startAdminScAdd, processAdminScAddInput,
    showAdminScEditList, startAdminScEdit, processAdminScEditInput, processAdminScEditKonfirmasi,
    startAdminScAddUser, processAdminScAddUserInput, processAdminScAddUserKonfirmasi,
    startAdminScRemove, processAdminScRemoveInput, startAdminScPaketAdd, processAdminScPaketAddInput,
    startAdminScPaketRemove, processAdminScPaketRemove, showAdminBackupMenu, showAdminBackupList,
    showAdminBackupRestoreList, showAdminBackupDeleteList, showAdminAutoBackupSetup, showAdminDashboard,
    showAdminStatistikBot,
    showAdminManageResellerList, showAdminListUsers, showAdminSearchUsers, showAdminSearchResults,
    showAdminManageUser, showAdminEditSaldoAmount, processAdminEditSaldoNominal, showAdminListAkun,
    showAdminUserAkun, showAdminTransaksi, showAdminEditData, startAdminEditHeaderMain,
    showAdminSettingsUmum, showAdminSettingsQris, showAdminSettingsPakasir, showAdminSettingsDana,
    showAdminSettingsGopay, showAdminSettingsGithub, showAdminSettingsGithubBackup, showAdminSettingsGithubSewaSc,
    handleAdminEditValue, processAdminEditValue, cancelAdminEditValue, showAdminServerMenu, showAdminServerList,
    showAdminServerAdd, processAdminServerAddName, processAdminServerAddType, processAdminServerAddDomain,
    processAdminServerAddAuthKey, showAdminServerEdit, processAdminServerEditSelect, processAdminServerEditField,
    processAdminServerEditValue, showAdminServerHargaList, showAdminServerHargaEdit, processAdminServerHargaInput,
    showAdminServerQuotaList, showAdminServerQuotaEdit, processAdminServerQuotaInput, getEffectiveQuota,
    showAdminServerSlotList, showAdminServerSlotEdit, showAdminServerSlotTotalEdit, processAdminServerSlotInput,
    showAdminServerSlotTerpakaiEdit, processAdminServerSlotTerpakaiInput,
    showAdminServerDelete, processAdminServerDelete, showAdminAkunPerServer, showAdminXrayTypeSelect,
    showAdminServerAkunList, showAdminDeleteAkunServer, showAdminDeleteAkunList, eksekusiAdminDeleteAkunServer,
    showAdminDeleteAkunSearch, showAdminDeleteAkunSearchResult,
} = adminModule;

bot.start(async (ctx) => {
    registerUser(ctx.from);
    await showWelcomeStart(ctx);
});

bot.command('menu', async (ctx) => {
    registerUser(ctx.from);
    if (!hasSeenWelcome(ctx.from.id)) {
        await showWelcomeStart(ctx);
        return;
    }
    await showMainMenu(ctx);
});

bot.command('start', async (ctx) => {
    registerUser(ctx.from);
    await showWelcomeStart(ctx);
});

bot.command('saldo', async (ctx) => {
    const userId = ctx.from.id.toString();
    const saldo = getSaldo(userId);
    const jumlahAkun = getJumlahAkun(userId);
    const text = `${getHeader(' 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 𝙎𝘼𝙇𝘿𝙊')}
<blockquote><b>· User :</b> ${ctx.from.first_name}
<b>· Saldo :</b> ${formatRp(saldo)}
<b>· Akun :</b> ${jumlahAkun}</blockquote>`;
    await sendTempMessage(ctx, text);
});

bot.command('help', async (ctx) => {
    const text = `${getHeader(' 𝘽𝘼𝙉𝙏𝙐𝘼𝙉')}
<blockquote><b>· /menu   - Menu utama</b>
<b>· /saldo  - Cek saldo</b>
<b>· /help   - Bantuan ini</b></blockquote>

 Harga: ${formatHarga()}
 Trial: ${CONFIG.MAX_TRIAL_MENIT} menit, ${CONFIG.MAX_TRIAL_PER_USER}x/hari

<b>· Format Create (STEP BY STEP):</b>
Setiap field akan ditanyakan satu per satu:
<b>SSH:</b> Username → Password → Durasi → IP Limit
<b>Trojan/VLess/VMess:</b> Username → UUID/Password → Durasi → IP Limit → Quota
<b>ZiVPN:</b> Password → Durasi → IP Limit

<b>· Format Renew (STEP BY STEP):</b>
Target Akun → Tambah Hari → IP Limit Baru

<b>· Catatan:</b>
• Pesan hasil (create/trial/renew) <b>TIDAK akan otomatis terhapus</b>
• Hanya menu dan pesan temporary yang terhapus otomatis
• Header gambar hanya tampil di menu utama`;
    await sendTempMessage(ctx, text);
});

bot.command('dashboard', async (ctx) => {
    if (isAdmin(ctx.from.id)) {
        await showAdminDashboard(ctx);
    } else {
        await sendTempMessage(ctx, ` Anda bukan admin!`);
    }
});

bot.command('servers', async (ctx) => {
    if (isAdmin(ctx.from.id)) {
        await showAdminServerMenu(ctx);
    } else {
        await sendTempMessage(ctx, ` Anda bukan admin!`);
    }
});

// ==================== CALLBACK QUERY HANDLER ====================
bot.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id.toString();
    registerUser(ctx.from);

    // Jawab callback query SEKALI di paling atas, untuk SEMUA jenis tombol,
    // sebelum percabangan apapun. Tidak di-await (biar tidak menahan proses
    // berikutnya) supaya loading spinner di tombol Telegram langsung hilang
    // instan, termasuk untuk tombol pindah halaman/pagination (my_transaksi_page,
    // sewa_sc_list_page, akun_saya_page, dll) yang sebelumnya baru dijawab
    // belakangan (atau malah tidak pernah dijawab kalau branch-nya return lebih
    // dulu), sehingga terasa ada delay tiap pindah halaman.
    //
    // PENGECUALIAN: tombol "Cek Status Pembayaran" & "Batal" (cekbayar_/batalbayar_)
    // TIDAK dijawab blank di sini. Handler-nya (handleCekPembayaranButton /
    // handleBatalPembayaranButton) butuh menjawab callback query dengan
    // show_alert:true supaya muncul sebagai POPUP. Telegram hanya mengizinkan
    // SATU answerCbQuery per callback — kalau baris ini tetap menjawab duluan
    // (tanpa await, jadi timing-nya rebutan/race condition), maka popup alert
    // di handler tsb kadang gagal tampil (kadang tampil kadang tidak).
    const isCekBayarCallback = data && (data.startsWith('cekbayar_') || data.startsWith('batalbayar_'));
    if (!isCekBayarCallback) {
        ctx.answerCbQuery().catch(() => {});
    }

        // ============ BROADCAST CALLBACKS ============
    const broadcastCallbacks = broadcastModule.getBroadcastCallbacks(userStates);
    if (broadcastCallbacks[data]) {
        await broadcastCallbacks[data](ctx);
        return;
    }

    // ============ TOMBOL "❌ BATAL" UNIVERSAL (pengganti teks "ketik cancel") ============
    if (data === 'cancel_input') {
        userStates.delete(userId);
        registerUser(ctx.from);
        if (!hasSeenWelcome(ctx.from.id)) {
            await showWelcomeStart(ctx);
            return;
        }
        await showMainMenu(ctx);
        return;
    }

    // ============ TOMBOL "❌ BATAL" untuk handleAdminEditValue (pengganti teks "ketik cancel") ============
    if (data && data.startsWith('admin_edit_cancel_')) {
        if (!isAdmin(ctx.from.id)) return;
        const field = data.replace('admin_edit_cancel_', '');
        await cancelAdminEditValue(ctx, field);
        return;
    }

    // ============ TOMBOL "CEK PEMBAYARAN" (pengganti webhook manual) ============
    if (data && data.startsWith('cekbayar_')) {
        const rest = data.replace('cekbayar_', '');
        const metode = rest.startsWith('dana_') ? 'dana' : rest.startsWith('gopay_') ? 'gopay' : rest.startsWith('qris_') ? 'qris' : null;
        if (metode) {
            const txId = rest.replace(`${metode}_`, '');
            await handleCekPembayaranButton(ctx, metode, txId);
            return;
        }
    }

    // ============ TOMBOL "BATAL" (membatalkan topup pending sebelum bayar) ============
    if (data && data.startsWith('batalbayar_')) {
        const rest = data.replace('batalbayar_', '');
        const metode = rest.startsWith('dana_') ? 'dana' : rest.startsWith('gopay_') ? 'gopay' : rest.startsWith('qris_') ? 'qris' : null;
        if (metode) {
            const txId = rest.replace(`${metode}_`, '');
            await handleBatalPembayaranButton(ctx, metode, txId);
            return;
        }
    }

    // Jika variable yang digunakan adalah 'data'
if (data === 'my_transaksi') {
    await showUserTransaksi(ctx);
    return;
}
if (data && data.startsWith('my_transaksi_page_')) {
    const page = parseInt(data.replace('my_transaksi_page_', ''));
    await showUserTransaksi(ctx, page);
    return;
}
    
    if (data === 'main_menu') {
        registerUser(ctx.from);
        if (!hasSeenWelcome(ctx.from.id)) {
            await showWelcomeStart(ctx);
            return;
        }
        await showMainMenu(ctx);
        return;
    }

    // Tombol "Refresh Bot": sengaja kirim menu sebagai pesan BARU,
    // bukan edit pesan lama di tempat.
    if (data === 'refresh_bot') {
        registerUser(ctx.from);
        if (!hasSeenWelcome(ctx.from.id)) {
            await showWelcomeStart(ctx);
            return;
        }
        await showMainMenu(ctx, true);
        return;
    }

    if (data === 'panel_vpn') {
        await showPanelVPN(ctx);
        return;
    }

    // ==================== TOOLS MENU ====================
    if (data === 'tools_menu') {
        await sendMenu(ctx,
            `<blockquote><b>𝙏𝙊𝙊𝙇𝙎</b></blockquote>\n<blockquote><b>Pilih tools yang ingin digunakan:</b></blockquote>`,
            {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 𝘾𝙤𝙣𝙫𝙚𝙧𝙩 𝙓𝙧𝙖𝙮 𝙩𝙤 𝙔𝘼𝙈𝙇', callback_data: 'tools_xray_menu' }],
                        [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙚𝙣𝙪',      callback_data: 'main_menu', style: 'danger'       }],
                    ],
                },
            }
        );
        return;
    }

    // Delegasi callback tools_xray_ / xraytool_ ke module convert-xray-yaml
    if (data === 'tools_xray_menu' || data.startsWith('xraytool_')) {
        const xrayHelpers = { sendMenu, sendTempMessage, trackMessage };
        const handled = await xrayYamlModule.handleXrayToolCallback(ctx, data, xrayHelpers);
        if (handled) return;
    }

    // ==================== SEWA SC HANDLERS ====================
    if (data === 'sewa_sc_menu' || data === 'sewa_sc_perpanjang' || data.startsWith('sewa_sc_')) {
        if (!isSewaScAktif() && !isAdmin(ctx.from.id)) {
            await sendTempMessage(ctx, ' Fitur Sewa SC sedang tidak tersedia saat ini.');
            return;
        }
    }
    if (data === 'sewa_bot_menu' || data.startsWith('sewa_bot_')) {
        if (!isSewaBotAktif() && !isAdmin(ctx.from.id)) {
            await sendTempMessage(ctx, ' Fitur Sewa Bot Seller sedang tidak tersedia saat ini.');
            return;
        }
    }
    if (data === 'sewa_sc_menu') {
        // Tidak di-await: hapus preview lama jalan di background,
        // tidak perlu menahan tampilnya menu baru.
        clearPreviewMessages(ctx).catch(() => {});
        await showSewaScMenu(ctx);
        return;
    }
    if (data === 'sewa_sc_pilih_paket') {
        await showSewaScPilihPaket(ctx);
        return;
    }
    if (data === 'sewa_sc_perpanjang') {
        await showSewaScPerpanjang(ctx);
        return;
    }
    if (data.startsWith('sewa_sc_paket_')) {
        const paketId = data.replace('sewa_sc_paket_', '');
        const paket = getPaketById(paketId);
        if (!paket) {
            await sendTempMessage(ctx, ' Paket tidak ditemukan / sudah dihapus.');
            await showSewaScMenu(ctx);
            return;
        }
        await startSewaScPaket(ctx, paket);
        return;
    }
    if (data === 'sewa_sc_list') {
        await showSewaScList(ctx);
        return;
    }
    if (data && data.startsWith('sewa_sc_list_page_')) {
        const page = parseInt(data.replace('sewa_sc_list_page_', ''));
        await showSewaScList(ctx, page);
        return;
    }
    if (data === 'sewa_sc_preview') {
        await showSewaScPreview(ctx);
        return;
    }
    if (data === 'sewa_sc_pay') {
        await processSewaScPay(ctx);
        return;
    }
    if (data === 'sewa_sc_renew_pay') {
        await processSewaScRenewPay(ctx);
        return;
    }
    if (data === 'sewa_sc_ganti_confirm') {
        await processSewaScGantiKonfirmasi(ctx);
        return;
    }
    if (data.startsWith('sewa_sc_ganti_')) {
        const txId = data.replace('sewa_sc_ganti_', '');
        await startSewaScGanti(ctx, txId);
        return;
    }
    if (data.startsWith('sewa_sc_renew_paket_')) {
        // format: sewa_sc_renew_paket_<txId>_<paketId>
        const rest = data.replace('sewa_sc_renew_paket_', '');
        // txId & paketId dipisah underscore terakhir TIDAK reliable jika paketId punya underscore,
        // jadi cari paketId dengan mencocokkan ke daftar paket yang ada.
        const paketList = getPaketList();
        let matched = null;
        for (const p of paketList) {
            if (rest.endsWith(`_${p.id}`)) {
                const txId = rest.slice(0, rest.length - p.id.length - 1);
                matched = { txId, paketId: p.id };
                break;
            }
        }
        if (!matched) {
            await sendTempMessage(ctx, ' Paket tidak valid / sudah dihapus.');
            await showSewaScList(ctx);
            return;
        }
        await startSewaScRenewKonfirmasi(ctx, matched.txId, matched.paketId);
        return;
    }
    if (data.startsWith('sewa_sc_renew_')) {
        const txId = data.replace('sewa_sc_renew_', '');
        await startSewaScRenew(ctx, txId);
        return;
    }
    if (data === 'sewa_sc_os_ubuntu') {
        await showSewaScInstallScript(ctx, 'ubuntu');
        return;
    }
    if (data === 'sewa_sc_os_debian') {
        await showSewaScInstallScript(ctx, 'debian');
        return;
    }

    // ==================== SEWA BOT SELLER ====================
    if (data === 'sewa_bot_menu') {
        await showSewaBotMenu(ctx);
        return;
    }
    if (data === 'sewa_bot_pilih_paket') {
        await showSewaBotPilihPaket(ctx);
        return;
    }
    if (data.startsWith('sewa_bot_paket_')) {
        const paketId = data.replace('sewa_bot_paket_', '');
        const paket = getBotPaketById(paketId);
        if (!paket) {
            await sendTempMessage(ctx, ' Paket tidak ditemukan.');
            await showSewaBotMenu(ctx);
            return;
        }
        await startSewaBotPaket(ctx, paket);
        return;
    }
    if (data === 'sewa_bot_pay') {
        await processSewaBotPay(ctx);
        return;
    }
    if (data === 'sewa_bot_list') {
        await showSewaBotList(ctx);
        return;
    }
    if (data === 'sewa_bot_perpanjang') {
        await showSewaBotPerpanjangPilihToken(ctx);
        return;
    }
    if (data.startsWith('sewa_bot_perpanjang_token_')) {
        const token = data.replace('sewa_bot_perpanjang_token_', '');
        await showSewaBotPerpanjangPilihPaket(ctx, token);
        return;
    }
    if (data.startsWith('sewa_bot_perpanjang_paket_')) {
        const sisa = data.replace('sewa_bot_perpanjang_paket_', '');
        const paketList = getBotPaketList();
        const paket = paketList.find(p => sisa.startsWith(p.id + '_'));
        if (!paket) {
            await sendTempMessage(ctx, ' Paket tidak ditemukan.');
            await showSewaBotMenu(ctx);
            return;
        }
        const token = sisa.slice(paket.id.length + 1);
        await processSewaBotPerpanjangPay(ctx, token, paket);
        return;
    }

    // ==================== ADMIN SEWA SC HANDLERS ====================
    if (data === 'admin_sewa_sc') {
        if (!isAdmin(ctx.from.id)) return;
        await showAdminSewaScMenu(ctx);
        return;
    }
    if (data === 'admin_sc_list') {
        if (!isAdmin(ctx.from.id)) return;
        await showAdminScList(ctx);
        return;
    }
    if (data === 'admin_sc_edit_list') {
        if (!isAdmin(ctx.from.id)) return;
        await showAdminScEditList(ctx);
        return;
    }
    if (data === 'admin_sc_edit_confirm') {
        if (!isAdmin(ctx.from.id)) return;
        await processAdminScEditKonfirmasi(ctx);
        return;
    }
    if (data.startsWith('admin_sc_edit_')) {
        if (!isAdmin(ctx.from.id)) return;
        const ip = data.replace('admin_sc_edit_', '');
        await startAdminScEdit(ctx, ip);
        return;
    }
    if (data === 'admin_sc_adduser') {
        if (!isAdmin(ctx.from.id)) return;
        await startAdminScAddUser(ctx);
        return;
    }
    if (data === 'admin_sc_adduser_confirm') {
        if (!isAdmin(ctx.from.id)) return;
        await processAdminScAddUserKonfirmasi(ctx);
        return;
    }
    if (data === 'admin_sc_add') {
        if (!isAdmin(ctx.from.id)) return;
        await startAdminScAdd(ctx);
        return;
    }
    if (data === 'admin_sc_remove') {
        if (!isAdmin(ctx.from.id)) return;
        await startAdminScRemove(ctx);
        return;
    }
    if (data === 'admin_sc_toggle_visibility') {
        if (!isAdmin(ctx.from.id)) return;
        const statusBaru = !isSewaScAktif();
        setSewaScAktif(statusBaru);
        updateEnvValue('SEWA_SC_AKTIF', statusBaru.toString());
        await sendTempMessage(ctx, statusBaru
            ? ' Button <b>Sewa SC</b> sekarang tampil kembali di menu utama user.'
            : ' Button <b>Sewa SC</b> berhasil disembunyikan dari menu utama user.');
        await showAdminSewaScMenu(ctx);
        return;
    }
    if (data === 'admin_sc_paket_add') {
        if (!isAdmin(ctx.from.id)) return;
        await startAdminScPaketAdd(ctx);
        return;
    }
    if (data === 'admin_sc_paket_remove') {
        if (!isAdmin(ctx.from.id)) return;
        await startAdminScPaketRemove(ctx);
        return;
    }
    if (data.startsWith('admin_sc_paket_del_')) {
        if (!isAdmin(ctx.from.id)) return;
        const paketId = data.replace('admin_sc_paket_del_', '');
        await processAdminScPaketRemove(ctx, paketId);
        return;
    }
    if (data === 'admin_edit_harga_sc_30') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'harga_sc_30', ` <b>Edit Harga Sewa SC – 30 Hari</b>\n\nHarga saat ini: <b>${formatRp(getHargaSC30Hari())}</b> / IP / 30 hari\n(Harga 60 & 90 hari dihitung otomatis dari nilai ini)\n\nKirim harga baru (contoh: 15000):`);
        return;
    }
    if (data === 'admin_edit_harga_sc_lifetime') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'harga_sc_lifetime', ` <b>Edit Harga Sewa SC – Lifetime</b>\n\nHarga saat ini: <b>${formatRp(getHargaSCLifetime())}</b> / IP\n\nKirim harga baru (contoh: 150000):`);
        return;
    }
    if (data === 'admin_edit_harga_sc_extra') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'harga_sc_extra', ` <b>Edit Harga IP Tambahan (ke-2 dst)</b>\n\nHarga saat ini: <b>${formatRp(getHargaSCExtraIp())}</b> / IP\n(Berlaku flat untuk semua paket, tidak dikali jumlah hari)\n\nKirim harga baru (contoh: 25000):`);
        return;
    }

    // ==================== ADMIN DISKON & BONUS TOPUP HANDLERS ====================
    if (data === 'admin_topup_bonus') {
        if (!isAdmin(ctx.from.id)) return;
        await showAdminTopupBonusMenu(ctx);
        return;
    }
    if (data === 'admin_topup_bonus_toggle') {
        if (!isAdmin(ctx.from.id)) return;
        const statusBaru = !isTopupBonusAktif();
        setTopupBonusAktif(statusBaru);
        await sendTempMessage(ctx, statusBaru
            ? ' Bonus Topup sekarang aktif & tampil di menu utama.'
            : ' Bonus Topup berhasil dinonaktifkan.');
        await showAdminTopupBonusMenu(ctx);
        return;
    }
    if (data === 'admin_topup_bonus_add') {
        if (!isAdmin(ctx.from.id)) return;
        await startAdminTopupBonusAdd(ctx);
        return;
    }
    if (data === 'admin_topup_bonus_unlimited') {
        if (!isAdmin(ctx.from.id)) return;
        await processAdminTopupBonusUnlimited(ctx);
        return;
    }
    if (data === 'admin_topup_bonus_remove') {
        if (!isAdmin(ctx.from.id)) return;
        await startAdminTopupBonusRemove(ctx);
        return;
    }
    if (data.startsWith('admin_topup_bonus_del_')) {
        if (!isAdmin(ctx.from.id)) return;
        const minAmount = parseInt(data.replace('admin_topup_bonus_del_', ''));
        await processAdminTopupBonusRemove(ctx, minAmount);
        return;
    }

    // ==================== ADMIN SEWA BOT SELLER HANDLERS ====================
    if (data === 'admin_sewa_bot') {
        if (!isAdmin(ctx.from.id)) return;
        await showAdminSewaBotMenu(ctx);
        return;
    }
    if (data === 'admin_bot_toggle_visibility') {
        if (!isAdmin(ctx.from.id)) return;
        const statusBaru = !isSewaBotAktif();
        setSewaBotAktif(statusBaru);
        updateEnvValue('SEWA_BOT_AKTIF', statusBaru.toString());
        await sendTempMessage(ctx, statusBaru
            ? ' Button <b>Sewa Bot Seller</b> sekarang tampil kembali di menu Sewa SC.'
            : ' Button <b>Sewa Bot Seller</b> berhasil disembunyikan.');
        await showAdminSewaBotMenu(ctx);
        return;
    }
    if (data === 'admin_bot_list') {
        if (!isAdmin(ctx.from.id)) return;
        await showAdminSewaBotList(ctx);
        return;
    }
    if (data === 'admin_bot_revoke') {
        if (!isAdmin(ctx.from.id)) return;
        await startAdminBotRevoke(ctx);
        return;
    }
    if (data === 'admin_edit_harga_bot_30') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'harga_bot_30', ` <b>Edit Harga Sewa Bot – 30 Hari</b>\n\nHarga saat ini: <b>${formatRp(getHargaBotSeller30Hari())}</b> / 30 hari\n(Harga 60 & 90 hari dihitung otomatis dari nilai ini)\n\nKirim harga baru (contoh: 20000):`);
        return;
    }
    if (data === 'admin_edit_harga_bot_lifetime') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'harga_bot_lifetime', ` <b>Edit Harga Sewa Bot – Lifetime</b>\n\nHarga saat ini: <b>${formatRp(getHargaBotSellerLifetime())}</b>\n\nKirim harga baru (contoh: 200000):`);
        return;
    }

    // ==================== RESELLER HANDLERS ====================
    if (data === 'join_reseller') {
        if (isReseller(userId)) {
            await sendTempMessage(ctx, ' Anda sudah terdaftar sebagai Reseller!');
            return;
        }
        const saldo = getSaldo(userId);
        const saldoCukup = saldo >= CONFIG.BIAYA_DAFTAR_RESELLER;
        const kurang = CONFIG.BIAYA_DAFTAR_RESELLER - saldo;
        const statusSaldo = saldoCukup
            ? `<b>· Saldo Cukup! Siap daftar.</b>`
            : `<b>· Saldo Kurang ${formatRp(kurang)} — Topup dulu sebelum daftar.</b>`;
        const text = `${getHeader(' 𝙅𝙊𝙄𝙉 𝙍𝙀𝙎𝙀𝙇𝙇𝙀𝙍')}
<blockquote><b>· PROGRAM RESELLER</b>
<b></b>
<b>· Keuntungan Reseller:</b>
<b>· Diskon ${getDiskonResellerPersen()}% semua harga</b>
<b>· Create & Renew lebih hemat</b>
<b>· Badge Reseller di profil</b>
<b>· Status aktif selama bertransaksi</b>
<b></b>
<b>· Ketentuan:</b>
<b>· Minimal 4 transaksi (Create/Renew)</b>
<b>per bulan (30 hari)</b>
<b>· Jika transaksi kurang dari 4/bulan,</b>
<b>status otomatis DOWNGRADE</b>
<b>menjadi Member (diskon hilang)</b>
<b></b>
<b>· Biaya Daftar: ${formatRp(CONFIG.BIAYA_DAFTAR_RESELLER)}</b>
<b></b>
${statusSaldo}</blockquote>`;

        const keyboard = saldoCukup
            ? Markup.inlineKeyboard([
                [{ text: ` 𝘿𝙖𝙛𝙩𝙖𝙧 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧 (${formatRp(CONFIG.BIAYA_DAFTAR_RESELLER)})`, callback_data: 'join_reseller_confirm' }],
                [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'main_menu', style: 'danger' }]
              ])
            : Markup.inlineKeyboard([
                [{ text: '💳 𝙏𝙤𝙥𝙪𝙥 𝙎𝙖𝙡𝙙𝙤', callback_data: 'topup' }],
                [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'main_menu', style: 'danger' }]
              ]);
        await sendMenu(ctx, text, keyboard);
        return;
    }

    if (data === 'join_reseller_confirm') {
        if (isReseller(userId)) {
            await sendTempMessage(ctx, ' Anda sudah terdaftar sebagai Reseller!');
            return;
        }
        const saldo = getSaldo(userId);
        if (saldo < CONFIG.BIAYA_DAFTAR_RESELLER) {
            await sendTempMessage(ctx,
                ` Saldo tidak cukup!\n\n<b>· Biaya:</b> ${formatRp(CONFIG.BIAYA_DAFTAR_RESELLER)}\n<b>· Saldo:</b> ${formatRp(saldo)}\n<b>· Kurang:</b> ${formatRp(CONFIG.BIAYA_DAFTAR_RESELLER - saldo)}\n\nTopup saldo terlebih dahulu.`
            );
            return;
        }
        // Potong saldo & daftarkan
        kurangiSaldo(userId, CONFIG.BIAYA_DAFTAR_RESELLER);
        const txId = generateTxId();
        daftarReseller(userId, txId);
        simpanTransaksi({
            txId, userId,
            userName: ctx.from.first_name || ctx.from.username || 'User',
            type: 'reseller_join',
            amount: CONFIG.BIAYA_DAFTAR_RESELLER,
            keterangan: 'Daftar Reseller',
            waktu: new Date().toISOString(),
            status: 'success'
        });

        // Notif admin
        if (ADMIN_IDS.length > 0) {
            const namaUser = ctx.from.first_name || ctx.from.username || 'User';
            const usernameTag = ctx.from.username ? `@${ctx.from.username}` : '-';
            for (const adminId of ADMIN_IDS) {
                try {
                    await notifBot.telegram.sendMessage(adminId,
                        `${getHeader(' 𝙍𝙀𝙎𝙀𝙇𝙇𝙀𝙍 𝘽𝘼𝙍𝙐')}
<blockquote>👑 <b>User baru bergabung sebagai Reseller!</b>

👤 <b>Nama:</b> ${namaUser}
🔗 <b>Username:</b> ${usernameTag}
🆔 <b>User ID:</b> <code>${userId}</code>
💰 <b>Biaya Daftar:</b> ${formatRp(CONFIG.BIAYA_DAFTAR_RESELLER)}
🧾 <b>TX ID:</b> <code>${txId}</code>
🕒 <b>Waktu:</b> ${new Date().toLocaleString('id-ID', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</blockquote>`,
                        { parse_mode: 'HTML' }
                    );
                } catch(e) {}
            }
        }

        await sendResultMessage(ctx,
            `${getHeader(' 𝙅𝙊𝙄𝙉 𝙍𝙀𝙎𝙀𝙇𝙇𝙀𝙍')}
<blockquote>🎉 <b>Selamat! Anda kini menjadi Reseller!</b>

👑 <b>Status:</b> Reseller Aktif
🎁 <b>Diskon:</b> ${getDiskonResellerPersen()}% untuk semua transaksi Create &amp; Renew
🧪 <b>Bonus:</b> Trial Akun Unlimited (tanpa batas harian)

ℹ️ Jaga status aktif dengan transaksi minimal <b>4x per bulan (30 hari)</b>. Jika kurang dari itu, status reseller akan otomatis <b>diturunkan (downgrade) menjadi Member</b>.</blockquote>`
        );
        return;
    }

    if (data === 'reseller_info') {
        const info = formatInfoReseller(userId);
        if (!info) {
            await sendTempMessage(ctx, '👤 Anda bukan reseller aktif.');
            return;
        }
        const sisaIcon = info.sisaHariSebelumExpire <= 5 ? '⏳' : '✅';
        const progresIcon = info.jumlahTransaksiPeriode >= info.minimalTransaksiPeriode ? '✅' : '⚠️';
        const text = `${getHeader(' 𝙎𝙏𝘼𝙏𝙐𝙎 𝙍𝙀𝙎𝙀𝙇𝙇𝙀𝙍')}
<blockquote>👑 <b>Status:</b> Reseller Aktif
🎁 <b>Diskon:</b> ${info.diskonPersen}% untuk produk akun VPN
🧪 <b>Trial Akun:</b> Unlimited ♾️</blockquote>

<blockquote>📅 <b>Terdaftar:</b> ${info.daftarAt}
🕒 <b>Transaksi Terakhir:</b> ${info.lastTransaksi}
${progresIcon} <b>Transaksi Bulan Ini:</b> ${info.jumlahTransaksiPeriode}/${info.minimalTransaksiPeriode} akun
${sisaIcon} <b>Sisa Periode:</b> ${info.sisaHariSebelumExpire} hari</blockquote>

<blockquote>ℹ️ Status reseller tetap aktif selama Anda melakukan transaksi (Create/Renew) <b>minimal ${info.minimalTransaksiPeriode} akun setiap bulan (30 hari)</b>. Jika kurang dari itu, status reseller akan <b>otomatis turun (downgrade) menjadi Member</b>.</blockquote>`;
        const keyboard = Markup.inlineKeyboard([
            [{ text: '🏠 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝙈𝙚𝙣𝙪', callback_data: 'main_menu', style: 'danger' }]
        ]);
        await sendMenu(ctx, text, keyboard);
        return;
    }
    // ==================== END RESELLER HANDLERS ====================
    
    if (data === 'reguler_menu') {
        await showRegulerMenu(ctx);
        return;
    }
    if (data === 'create_menu') {
        await showCreateMenu(ctx);
        return;
    }
    if (data === 'trial_menu') {
        await showTrialMenu(ctx);
        return;
    }
    if (data === 'renew_menu') {
        await showRenewMenu(ctx);
        return;
    }

    // ==================== VPN EDURC ====================
    if (data === 'edurc_menu') {
        await showEdurcMenu(ctx);
        return;
    }
    if (data === 'edurc_create_menu') {
        await showEdurcCreateMenu(ctx);
        return;
    }
    if (data === 'edurc_trial_menu') {
        await showEdurcTrialMenu(ctx);
        return;
    }
    if (data === 'edurc_create_trojan' || data === 'edurc_create_vless' ||
        data === 'edurc_create_vmess') {
        const serviceType = data.replace('edurc_create_', '');
        await handleCreateService(ctx, serviceType, true);
        return;
    }
    if (data === 'edurc_trial_trojan' || data === 'edurc_trial_vless' ||
        data === 'edurc_trial_vmess') {
        const serviceType = data.replace('edurc_trial_', '');
        await handleTrialService(ctx, serviceType, true);
        return;
    }

    // ==================== CLOUDFRONT ====================
    if (data === 'cloudfront_menu') {
        await showCloudfrontMenu(ctx);
        return;
    }
    if (data === 'cloudfront_create_menu') {
        await handleCreateService(ctx, 'ssh', true);
        return;
    }
    if (data === 'cloudfront_trial_menu') {
        await handleTrialService(ctx, 'ssh', true);
        return;
    }
    if (data === 'cloudfront_create_ssh') {
        await handleCreateService(ctx, 'ssh', true);
        return;
    }
    if (data === 'cloudfront_trial_ssh') {
        await handleTrialService(ctx, 'ssh', true);
        return;
    }

    // ==================== MODE WILDCARD (GANTI BUG LINK) ====================
    if (data === 'wildcard_menu') {
        await showWildcardMenu(ctx);
        return;
    }
    if (data.startsWith('wildcard_select_')) {
        const entryId = data.replace('wildcard_select_', '');
        await promptWildcardLinkInput(ctx, entryId);
        return;
    }
    if (data === 'wildcard_admin_list') {
        if (!isAdmin(ctx.from.id)) return;
        await showWildcardAdminList(ctx);
        return;
    }
    if (data === 'wildcard_admin_add') {
        if (!isAdmin(ctx.from.id)) return;
        await startWildcardAdminAdd(ctx);
        return;
    }
    if (data.startsWith('wildcard_admin_del_confirm_')) {
        if (!isAdmin(ctx.from.id)) return;
        const id = data.replace('wildcard_admin_del_confirm_', '');
        await processWildcardAdminDelete(ctx, id);
        return;
    }
    if (data.startsWith('wildcard_admin_del_')) {
        if (!isAdmin(ctx.from.id)) return;
        const id = data.replace('wildcard_admin_del_', '');
        await confirmWildcardAdminDelete(ctx, id);
        return;
    }

    // ==================== BUG XRAY (GANTI ADDRESS SAJA / SNI SAJA) ====================
    if (data === 'bug_menu') {
        const userIdBug = ctx.from.id.toString();
        if (!isAdmin(ctx.from.id)) {
            const { sudahTopup, sudahOrder } = cekRiwayatTopupDanOrder(userIdBug);
            if (!sudahTopup || !sudahOrder) {
                const alasan = [];
                if (!sudahTopup) alasan.push('belum pernah <b>Topup</b> saldo');
                if (!sudahOrder) alasan.push('belum pernah <b>Order/Create Akun</b>');
                await sendTempMessage(ctx,
                    ` <b>Akses Ditolak</b>\n\nFitur <b>🐛 Ganti Bug Xray</b> hanya untuk user yang sudah pernah bertransaksi di bot ini, bukan sekadar mampir.\n\n<b>· Alasan:</b> ${alasan.join(' & ')}.\n\nSilakan lakukan topup saldo dan order/buat akun terlebih dahulu, baru fitur ini bisa dipakai.`
                );
                return;
            }
        }
        await showBugMenu(ctx);
        return;
    }
    if (data === 'bug_mode_wildcard') {
        await showWildcardMenu(ctx);
        return;
    }
    if (data === 'bug_mode_address') {
        await showBugListByMode(ctx, 'address');
        return;
    }
    if (data === 'bug_mode_sni') {
        await showBugListByMode(ctx, 'sni');
        return;
    }
    if (data.startsWith('bug_select_address_')) {
        const entryId = data.replace('bug_select_address_', '');
        await promptBugLinkInput(ctx, entryId, 'address');
        return;
    }
    if (data.startsWith('bug_select_sni_')) {
        const entryId = data.replace('bug_select_sni_', '');
        await promptBugLinkInput(ctx, entryId, 'sni');
        return;
    }
    if (data === 'bug_admin_list') {
        if (!isAdmin(ctx.from.id)) return;
        await showBugAdminList(ctx);
        return;
    }
    if (data === 'bug_admin_add') {
        if (!isAdmin(ctx.from.id)) return;
        await startBugAdminAdd(ctx);
        return;
    }
    if (data.startsWith('bug_admin_del_confirm_')) {
        if (!isAdmin(ctx.from.id)) return;
        const id = data.replace('bug_admin_del_confirm_', '');
        await processBugAdminDelete(ctx, id);
        return;
    }
    if (data.startsWith('bug_admin_del_')) {
        if (!isAdmin(ctx.from.id)) return;
        const id = data.replace('bug_admin_del_', '');
        await confirmBugAdminDelete(ctx, id);
        return;
    }

    if (data.startsWith('create_back_server_list_')) {
        const rest = data.replace('create_back_server_list_', '');
        const lastUnderscore = rest.lastIndexOf('_');
        const serviceType = rest.slice(0, lastUnderscore);
        const isEdurcFlag = rest.slice(lastUnderscore + 1) === '1';
        await handleCreateService(ctx, serviceType, isEdurcFlag);
        return;
    }
    if (data === 'create_ssh' || data === 'create_trojan' || data === 'create_vless' || 
        data === 'create_vmess' || data === 'create_zivpn') {
        const serviceType = data.replace('create_', '');
        await handleCreateService(ctx, serviceType);
        return;
    }
    
    // Ganti bagian ini:
if (data.startsWith('create_server_')) {
    const serverId = data.replace('create_server_', '');
    const state = userStates.get(userId);
    if (state && state.action === 'create_select_server') {
        await processCreateSelectServer(ctx, serverId, state.serviceType, state.isEdurc);
    }
    return;
}

if (data === 'create_confirm_yes') {
    const state = userStates.get(userId);
    if (state && state.action === 'create_confirm') {
        await eksekusiCreate(ctx, state.serviceType, state.server, state.data, state.totalHarga, state.isEdurc);
    }
    return;
}
    
    if (data.startsWith('trial_back_server_list_')) {
        const rest = data.replace('trial_back_server_list_', '');
        const lastUnderscore = rest.lastIndexOf('_');
        const serviceType = rest.slice(0, lastUnderscore);
        const isEdurcFlag = rest.slice(lastUnderscore + 1) === '1';
        await handleTrialService(ctx, serviceType, isEdurcFlag);
        return;
    }
    if (data === 'trial_ssh' || data === 'trial_trojan' || data === 'trial_vless' || 
        data === 'trial_vmess' || data === 'trial_zivpn') {
        const serviceType = data.replace('trial_', '');
        await handleTrialService(ctx, serviceType);
        return;
    }
    
    if (data.startsWith('trial_server_')) {
        const serverId = data.replace('trial_server_', '');
        const state = userStates.get(userId);
        if (state && state.action === 'trial_select_server') {
            await processTrialSelectServer(ctx, serverId, state.serviceType, state.isEdurc);
        }
        return;
    }
    
    if (data.startsWith('trial_dur_')) {
        const duration = data.replace('trial_dur_', '');
        const state = userStates.get(userId);
        if (state && state.action === 'trial_select_duration') {
            await eksekusiTrial(ctx, duration, state.serviceType, state.server, state.isEdurc);
        }
        return;
    }
    
    if (data === 'trial_confirm_yes') {
        const state = userStates.get(userId);
        if (state && state.action === 'trial_confirm') {
            await eksekusiTrial(ctx, state.duration, state.serviceType, state.server, state.isEdurc);
        }
        return;
    }
    
    if (data === 'renew_ssh' || data === 'renew_trojan' || data === 'renew_vless' || 
        data === 'renew_vmess' || data === 'renew_zivpn') {
        const serviceType = data.replace('renew_', '');
        await handleRenewService(ctx, serviceType, false);
        return;
    }

    if (data.startsWith('renew_server_')) {
        const serverId = data.replace('renew_server_', '');
        const state = userStates.get(userId);
        if (state && state.action === 'renew_select_server') {
            await processRenewSelectServer(ctx, serverId, state.serviceType, state.isEdurc);
        }
        return;
    }

    if (data.startsWith('renew_mode_')) {
        // format: renew_mode_<serviceType>_reg | renew_mode_<serviceType>_edu
        const rest = data.replace('renew_mode_', '');
        const isEdurc = rest.endsWith('_edu');
        const serviceType = rest.replace(/_reg$|_edu$/, '');
        await handleRenewService(ctx, serviceType, isEdurc);
        return;
    }

if (data === 'renew_confirm_yes') {
    const state = userStates.get(userId);
    if (state && state.action === 'renew_confirm') {
        await eksekusiRenew(ctx, state.serviceType, state.server, state.data, state.totalHarga, state.isEdurc);
    }
    return;
}
    
    if (data === 'topup') {
        await handleTopup(ctx);
        return;
    }
    if (data === 'topup_confirm_yes') {
        const state = userStates.get(userId);
        if (state && state.action === 'topup' && state.step === 'confirm') {
            await processTopupPayment(ctx, state.amount);
        }
        return;
    }
    
    if (data === 'cek_saldo') {
        const saldo = getSaldo(userId);
        const jumlahAkun = getJumlahAkun(userId);
        const text = `${getHeader(' 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 𝙎𝘼𝙇𝘿𝙊')}
<blockquote><b>· User :</b> ${ctx.from.first_name}
<b>· Saldo :</b> ${formatRp(saldo)}
<b>· Akun :</b> ${jumlahAkun}</blockquote>`;
        await sendTempMessage(ctx, text);
        return;
    }
    
    if (data === 'help') {
        const text = `${getHeader(' 𝘽𝘼𝙉𝙏𝙐𝘼𝙉')}
<blockquote><b>· /menu   - Menu utama</b>
<b>· /saldo  - Cek saldo</b>
<b>· /help   - Bantuan ini</b></blockquote>

 Harga: ${formatHarga()}
 Trial: ${CONFIG.MAX_TRIAL_MENIT} menit, ${CONFIG.MAX_TRIAL_PER_USER}x/hari

<b>· Format Create (STEP BY STEP):</b>
Setiap field akan ditanyakan satu per satu:
<b>SSH:</b> Username → Password → Durasi → IP Limit
<b>Trojan/VLess/VMess:</b> Username → UUID/Password → Durasi → IP Limit → Quota
<b>ZiVPN:</b> Password → Durasi → IP Limit

<b>· Format Renew (STEP BY STEP):</b>
Target Akun → Tambah Hari → IP Limit Baru

<b>· Catatan:</b>
• Pesan hasil (create/trial/renew) <b>TIDAK akan otomatis terhapus</b>
• Hanya menu dan pesan temporary yang terhapus otomatis
• Header gambar hanya tampil di menu utama`;
        await sendTempMessage(ctx, text);
        return;
    }
    
    // ============ ADMIN CALLBACKS ============
    if (data === 'admin_dashboard') {
        await showAdminDashboard(ctx);
        return;
    }
    
    if (data === 'admin_statistik_bot') {
        await showAdminStatistikBot(ctx);
        return;
    }
    
    if (data === 'admin_akun_per_server') {
        await showAdminAkunPerServer(ctx);
        return;
    }
    
    if (data.startsWith('admin_server_list_akun_')) {
        const rest = data.replace('admin_server_list_akun_', '');
        if (rest.includes('_page_')) {
            const parts = rest.split('_page_');
            await showAdminServerAkunList(ctx, parts[0], parseInt(parts[1]));
        } else {
            await showAdminServerAkunList(ctx, rest);
        }
        return;
    }

    // List akun xray per tipe: admin_xray_list_type_{serverId}_{type}
    if (data.startsWith('admin_xray_list_type_')) {
        const rest = data.replace('admin_xray_list_type_', '');
        // format: {serverId}_{type}  — serverId bisa mengandung underscore jadi split dari belakang
        const lastUnderscore = rest.lastIndexOf('_');
        const serverId = rest.substring(0, lastUnderscore);
        const xrayType = rest.substring(lastUnderscore + 1);
        await showAdminServerAkunList(ctx, serverId, 0, xrayType);
        return;
    }

    // Paginasi list akun xray: admin_xray_list_page_{serverId}_{type}_{page}
    if (data.startsWith('admin_xray_list_page_')) {
        const rest = data.replace('admin_xray_list_page_', '');
        // format: {serverId}_{type}_{page}
        const parts = rest.split('_');
        const page = parseInt(parts[parts.length - 1]);
        const xrayType = parts[parts.length - 2];
        const serverId = parts.slice(0, parts.length - 2).join('_');
        await showAdminServerAkunList(ctx, serverId, page, xrayType);
        return;
    }
    
    if (data.startsWith('admin_server_delete_akun_select_')) {
        const serverId = data.replace('admin_server_delete_akun_select_', '');
        await showAdminDeleteAkunServer(ctx, serverId);
        return;
    }

    // Pilih tipe xray untuk delete: admin_del_srv_type_{serverId}_{type}
    if (data.startsWith('admin_del_srv_type_')) {
        const rest = data.replace('admin_del_srv_type_', '');
        const lastUnderscore = rest.lastIndexOf('_');
        const serverId = rest.substring(0, lastUnderscore);
        const serviceType = rest.substring(lastUnderscore + 1);
        await showAdminDeleteAkunList(ctx, serverId, serviceType, 0);
        return;
    }

    // Paginasi list delete: admin_del_akun_page_{serverId}_{serviceType}_{page}
    if (data.startsWith('admin_del_akun_page_')) {
        const rest = data.replace('admin_del_akun_page_', '');
        const parts = rest.split('_');
        const page = parseInt(parts[parts.length - 1]);
        const serviceType = parts[parts.length - 2];
        const serverId = parts.slice(0, parts.length - 2).join('_');
        await showAdminDeleteAkunList(ctx, serverId, serviceType, page);
        return;
    }

    // Pencarian nama: admin_del_akun_search_{serverId}_{serviceType}
    if (data.startsWith('admin_del_akun_search_')) {
        const rest = data.replace('admin_del_akun_search_', '');
        const knownTypes = ['trojan', 'vless', 'vmess', 'ssh', 'zivpn'];
        let serverId = '', serviceType = '';
        for (const t of knownTypes) {
            if (rest.endsWith('_' + t)) {
                serviceType = t;
                serverId = rest.slice(0, rest.length - t.length - 1);
                break;
            }
        }
        if (serverId && serviceType) {
            await showAdminDeleteAkunSearch(ctx, serverId, serviceType);
        } else {
            await sendTempMessage(ctx, ' Format tidak valid.');
        }
        return;
    }

    // Eksekusi delete: admin_do_del_akun_{serverId}_{serviceType}_{username}
    if (data.startsWith('admin_do_del_akun_')) {
        const rest = data.replace('admin_do_del_akun_', '');
        const knownTypes = ['trojan', 'vless', 'vmess', 'ssh', 'zivpn'];
        let serverId = '', serviceType = '', username = '';
        for (const t of knownTypes) {
            const marker = '_' + t + '_';
            const idx = rest.indexOf(marker);
            if (idx !== -1) {
                serverId = rest.substring(0, idx);
                serviceType = t;
                username = rest.substring(idx + marker.length).replace(/~/g, ' ');
                break;
            }
        }
        if (serverId && serviceType && username) {
            await eksekusiAdminDeleteAkunServer(ctx, serverId, serviceType, username);
        } else {
            await sendTempMessage(ctx, ' Format callback tidak valid.');
        }
        return;
    }
    
    if (data === 'admin_list_users') {
        await showAdminListUsers(ctx, 0);
        return;
    }

    if (data === 'admin_manage_reseller') {
        await showAdminManageResellerList(ctx, 0);
        return;
    }

    if (data.startsWith('admin_manage_reseller_page_')) {
        const page = parseInt(data.replace('admin_manage_reseller_page_', ''));
        await showAdminManageResellerList(ctx, page);
        return;
    }

    // Toggle reseller ON/OFF dari LIST (admin_manage_reseller): tetap di halaman list yang sama
    // format: admin_reseller_list_on_{page}_{userId} / admin_reseller_list_off_{page}_{userId}
    if (data.startsWith('admin_reseller_list_on_') || data.startsWith('admin_reseller_list_off_')) {
        if (!isAdmin(ctx.from.id)) return;
        const isOn = data.startsWith('admin_reseller_list_on_');
        const rest = (isOn ? data.replace('admin_reseller_list_on_', '') : data.replace('admin_reseller_list_off_', ''));
        const firstUnderscore = rest.indexOf('_');
        const page = parseInt(rest.substring(0, firstUnderscore)) || 0;
        const targetUserId = rest.substring(firstUnderscore + 1);

        setResellerStatusByAdmin(targetUserId, isOn, ctx.from.id);
        const name = await getUserName(targetUserId, ctx);
        await sendTempMessage(ctx, isOn
            ? `👑 ${name} (<code>${targetUserId}</code>) berhasil dijadikan <b>Reseller</b>.`
            : `🔴 Status Reseller ${name} (<code>${targetUserId}</code>) berhasil dinonaktifkan.`);
        await showAdminManageResellerList(ctx, page);
        return;
    }

    // Toggle reseller ON: admin_reseller_on_{userId}
    if (data.startsWith('admin_reseller_on_')) {
        const targetUserId = data.replace('admin_reseller_on_', '');
        if (!isAdmin(ctx.from.id)) return;
        setResellerStatusByAdmin(targetUserId, true, ctx.from.id);
        const name = await getUserName(targetUserId, ctx);
        await sendTempMessage(ctx, `👑 ${name} (<code>${targetUserId}</code>) berhasil dijadikan <b>Reseller</b>.`);
        await showAdminManageUser(ctx, targetUserId);
        return;
    }

    // Toggle reseller OFF: admin_reseller_off_{userId}
    if (data.startsWith('admin_reseller_off_')) {
        const targetUserId = data.replace('admin_reseller_off_', '');
        if (!isAdmin(ctx.from.id)) return;
        setResellerStatusByAdmin(targetUserId, false, ctx.from.id);
        const name = await getUserName(targetUserId, ctx);
        await sendTempMessage(ctx, `🔴 Status Reseller ${name} (<code>${targetUserId}</code>) berhasil dinonaktifkan.`);
        await showAdminManageUser(ctx, targetUserId);
        return;
    }

    if (data === 'admin_search_users') {
        await showAdminSearchUsers(ctx);
        return;
    }
    
    if (data.startsWith('admin_list_users_page_')) {
        const page = parseInt(data.replace('admin_list_users_page_', ''));
        await showAdminListUsers(ctx, page);
        return;
    }
    
    if (data.startsWith('admin_manage_user_')) {
        const targetUserId = data.replace('admin_manage_user_', '');
        await showAdminManageUser(ctx, targetUserId);
        return;
    }
    
    if (data.startsWith('admin_user_akun_')) {
        let rest = data.replace('admin_user_akun_', '');
        let page = 0;
        if (rest.includes('_page_')) {
            const parts = rest.split('_page_');
            rest = parts[0];
            page = parseInt(parts[1]);
        }
        await showAdminUserAkun(ctx, rest, page);
        return;
    }
    
    if (data.startsWith('admin_add_saldo_user_')) {
        const targetUserId = data.replace('admin_add_saldo_user_', '');
        await showAdminEditSaldoAmount(ctx, 'add', targetUserId);
        return;
    }
    
    if (data.startsWith('admin_reduce_saldo_user_')) {
        const targetUserId = data.replace('admin_reduce_saldo_user_', '');
        await showAdminEditSaldoAmount(ctx, 'reduce', targetUserId);
        return;
    }
    
    if (data.startsWith('admin_add_nominal_')) {
        const amount = parseInt(data.replace('admin_add_nominal_', ''));
        const state = userStates.get(userId);
        if (state && state.action === 'admin_add_saldo_amount') {
            await processAdminEditSaldoNominal(ctx, 'add', amount, state.targetUserId, state.targetName);
        }
        return;
    }
    
    if (data.startsWith('admin_reduce_nominal_')) {
        const amount = parseInt(data.replace('admin_reduce_nominal_', ''));
        const state = userStates.get(userId);
        if (state && state.action === 'admin_reduce_saldo_amount') {
            await processAdminEditSaldoNominal(ctx, 'reduce', amount, state.targetUserId, state.targetName);
        }
        return;
    }
    
    if (data === 'admin_list_akun') {
        await showAdminListAkun(ctx, 0);
        return;
    }
    
    if (data.startsWith('admin_list_akun_page_')) {
        const page = parseInt(data.replace('admin_list_akun_page_', ''));
        await showAdminListAkun(ctx, page);
        return;
    }
    
    if (data === 'admin_transaksi') {
        await showAdminTransaksi(ctx, 0);
        return;
    }
    
    if (data.startsWith('admin_transaksi_page_')) {
        const page = parseInt(data.replace('admin_transaksi_page_', ''));
        await showAdminTransaksi(ctx, page);
        return;
    }
    
    if (data === 'admin_edit_data') {
        await showAdminEditData(ctx);
        return;
    }
    if (data === 'admin_edit_header_main') {
        await startAdminEditHeaderMain(ctx);
        return;
    }

    //  Submenu pengaturan 
    if (data === 'admin_settings_umum')    { await showAdminSettingsUmum(ctx);    return; }
    if (data === 'admin_settings_qris')    { await showAdminSettingsQris(ctx);    return; }
    if (data === 'admin_settings_pakasir') { await showAdminSettingsPakasir(ctx); return; }
    if (data === 'admin_settings_dana')    { await showAdminSettingsDana(ctx);    return; }
    if (data === 'admin_settings_gopay')   { await showAdminSettingsGopay(ctx);   return; }
    if (data === 'admin_settings_github')  { await showAdminSettingsGithub(ctx);  return; }
    if (data === 'admin_settings_github_backup') { await showAdminSettingsGithubBackup(ctx); return; }
    if (data === 'admin_settings_github_sewasc') { await showAdminSettingsGithubSewaSc(ctx); return; }
    
    if (data === 'admin_edit_harga') {
        await handleAdminEditValue(ctx, 'harga', ` <b>Edit Harga per Hari</b>

Harga saat ini: <b>Rp ${CONFIG.HARGA_PER_HARI_PER_IP}</b> /hari/IP

Kirim harga baru (contoh: 500):`);
        return;
    }
    if (data === 'admin_edit_harga_edurc') {
        await handleAdminEditValue(ctx, 'harga_edurc', ` <b>Edit Tambahan Harga VPN EDURC / SSH CloudFront</b>

Tambahan saat ini: <b>+Rp ${CONFIG.HARGA_EDURC_PER_HARI}</b> /hari
(Ditambahkan di atas harga server/global, berlaku untuk VPN EDURC dan SSH CloudFront)

Kirim tambahan harga baru (contoh: 667):`);
        return;
    }
    if (data === 'admin_edit_harga_tambah_ip') {
        await handleAdminEditValue(ctx, 'harga_tambah_ip', ` <b>Edit Harga Tambah IP</b>

Harga saat ini: <b>Rp ${CONFIG.HARGA_TAMBAH_IP_PER_BULAN.toLocaleString('id-ID')}/bulan</b>
  ≈ Rp ${getHargaTambahIpPerHari().toLocaleString('id-ID')}/hari
  ≈ Rp ${getHargaTambahIpPerJam().toLocaleString('id-ID')}/jam

Biaya ini dikenakan untuk setiap IP ke-2 dan seterusnya.

Kirim harga baru dalam Rupiah per bulan (contoh: 3000):`);
        return;
    }
    if (data === 'admin_edit_harga_reseller') {
        await handleAdminEditValue(ctx, 'harga_reseller', ` <b>Edit Harga Join Reseller</b>

Harga saat ini: <b>${formatRp(CONFIG.BIAYA_DAFTAR_RESELLER)}</b>

Biaya ini dikenakan saat user mendaftar sebagai Reseller.
Reseller mendapatkan diskon ${getDiskonResellerPersen()}% untuk semua transaksi.

Kirim harga baru (contoh: 50000):`);
        return;
    }
    if (data === 'admin_edit_diskon_reseller') {
        await handleAdminEditValue(ctx, 'diskon_reseller', ` <b>Edit Diskon Reseller</b>

Diskon saat ini: <b>${getDiskonResellerPersen()}%</b>

Diskon ini berlaku untuk semua harga create &amp; renew akun milik reseller.

Kirim diskon baru dalam PERSEN, angka 0–99 (contoh: 50):`);
        return;
    }
    if (data === 'admin_edit_trial_menit') {
        await handleAdminEditValue(ctx, 'trial_menit', ` <b>Edit Max Trial (menit)</b>

Saat ini: <b>${CONFIG.MAX_TRIAL_MENIT} menit</b>

Kirim durasi baru (contoh: 60):`);
        return;
    }
    if (data === 'admin_edit_trial_per_hari') {
        await handleAdminEditValue(ctx, 'trial_per_hari', ` <b>Edit Max Trial per Hari</b>

Saat ini: <b>${CONFIG.MAX_TRIAL_PER_USER} x/hari</b>

Kirim batas baru (contoh: 3):`);
        return;
    }
    if (data === 'admin_edit_ip_limit') {
        await handleAdminEditValue(ctx, 'ip_limit', ` <b>Edit Max IP Limit</b>

Saat ini: <b>${CONFIG.MAX_IP_LIMIT} IP</b>

Kirim batas baru (contoh: 3):`);
        return;
    }
    if (data === 'admin_edit_min_topup') {
        await handleAdminEditValue(ctx, 'min_topup', ` <b>Edit Minimal Topup</b>

Saat ini: ${formatRp(CONFIG.MIN_TOPUP)}

Kirim minimal baru (contoh: 20000):`);
        return;
    }
    if (data === 'admin_edit_qris_fee') {
        await handleAdminEditValue(ctx, 'qris_fee', ` <b>Edit Fee QRIS</b>

Fee saat ini: <b>${CONFIG.QRIS_FEE_PERSEN > 0 ? CONFIG.QRIS_FEE_PERSEN + '%' : 'Tidak aktif (0)'}</b>

Masukkan persentase fee dalam angka desimal:
• <code>0</code> = Tidak ada fee
• <code>0.7</code> = 0.7% (standar QRIS)
• <code>1</code> = 1%

Fee ini berlaku untuk <b>QRIS Dinamis</b> dan <b>QRIS Pakasir</b>.`);
        return;
    }
    if (data === 'admin_edit_merchant_name') {
        await handleAdminEditValue(ctx, 'merchant_name', ` <b>Edit Nama Merchant</b>

Saat ini: <b>${CONFIG.MERCHANT_NAME}</b>

Kirim nama merchant baru:`);
        return;
    }

    // Di bagian CALLBACK QUERY HANDLER, tambahkan:
if (data === 'admin_edit_default_quota') {
    await handleAdminEditValue(ctx, 'default_quota', ` <b>Edit Default Quota</b>

Saat ini: <b>${CONFIG.DEFAULT_QUOTA} GB</b>

Default quota untuk akun Trojan/VLess/VMess baru.
Masukkan 0 untuk unlimited atau angka positif untuk batasan GB.

Kirim nominal quota baru (contoh: 500):`);
    return;
}
    
    if (data === 'admin_edit_github_token') {
        await handleAdminEditValue(ctx, 'github_token', ` <b>Edit GitHub Token</b>

Token saat ini: ${GITHUB_TOKEN ? `<code>${GITHUB_TOKEN.substring(0,6)}...${GITHUB_TOKEN.slice(-4)}</code>` : ' Belum diset'}

Kirim GitHub Personal Access Token baru.
Token harus punya permission <b>Contents: Read & Write</b>.`);
        return;
    }

    if (data === 'admin_edit_github_owner') {
        await handleAdminEditValue(ctx, 'github_owner', ` <b>Edit GitHub Owner</b>

Owner saat ini: <b>${GITHUB_OWNER || '-'}</b>

Kirim username/org GitHub pemilik repo backup.
Contoh: <code>peyxdev</code>`);
        return;
    }

    if (data === 'admin_edit_github_repo') {
        await handleAdminEditValue(ctx, 'github_repo', ` <b>Edit GitHub Repo</b>

Repo saat ini: <b>${GITHUB_OWNER}/${GITHUB_REPO || '-'}</b>

Kirim nama repo tujuan backup (hanya nama repo, bukan full URL).
Contoh: <code>backup</code>`);
        return;
    }

    if (data === 'admin_edit_github_branch') {
        await handleAdminEditValue(ctx, 'github_branch', ` <b>Edit GitHub Branch</b>

Branch saat ini: <b>${GITHUB_BRANCH || 'main'}</b>

Kirim nama branch repo backup.
Contoh: <code>main</code>`);
        return;
    }

    if (data === 'admin_edit_sc_github_token') {
        await handleAdminEditValue(ctx, 'sc_github_token', ` <b>Edit Token Sewa SC</b>

Token saat ini: ${getScGithubToken() ? `<code>${getScGithubToken().substring(0,6)}...${getScGithubToken().slice(-4)}</code>` : ' Belum diset'}

Kirim GitHub Personal Access Token untuk repo Sewa SC.
Token harus punya permission <b>Contents: Read &amp; Write</b>.`);
        return;
    }

    if (data === 'admin_edit_sc_github_owner') {
        await handleAdminEditValue(ctx, 'sc_github_owner', ` <b>Edit Owner Sewa SC</b>

Owner saat ini: <b>${getScGithubOwner() || '-'}</b>

Kirim username/org GitHub pemilik repo Sewa SC.
Contoh: <code>peyxdev</code>`);
        return;
    }

    if (data === 'admin_edit_sc_github_repo') {
        await handleAdminEditValue(ctx, 'sc_github_repo', ` <b>Edit Repo Sewa SC</b>

Repo saat ini: <b>${getScGithubOwner()}/${getScGithubRepo() || '-'}</b>

Kirim nama repo tujuan data Sewa SC (hanya nama repo, bukan full URL).
Contoh: <code>esce</code>`);
        return;
    }

    if (data === 'admin_edit_sc_github_branch') {
        await handleAdminEditValue(ctx, 'sc_github_branch', ` <b>Edit Branch Sewa SC</b>

Branch saat ini: <b>${getScGithubBranch() || 'main'}</b>

Kirim nama branch repo Sewa SC.
Contoh: <code>main</code>`);
        return;
    }

    if (data === 'admin_edit_qris') {
        if (!isAdmin(ctx.from.id)) return;
        const userId = ctx.from.id.toString();
        userStates.set(userId, { action: 'admin_edit_qris_string' });

        const currentInfo = QRIS_STATIS
            ? ` QRIS saat ini:\n<code>${QRIS_STATIS.substring(0, 60)}...</code>\n(${QRIS_STATIS.length} karakter)`
            : ` QRIS belum diatur`;

        await sendMenu(ctx,
            `${getHeader(' 𝙀𝘿𝙄𝙏 𝙌𝙍𝙄𝙎 𝙎𝙏𝙍𝙄𝙉𝙂')}\n\n` +
            `${currentInfo}\n\n` +
            `Kirim string QRIS statis baru (teks panjang yang dimulai dengan <code>000201...</code>).`,
            Markup.inlineKeyboard([[{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_settings_qris', style: 'danger' }]])
        );
        return;
    }

    if (data === 'admin_edit_qris_image') {
        if (!isAdmin(ctx.from.id)) return;
        const userId = ctx.from.id.toString();
        userStates.set(userId, { action: 'admin_edit_qris_image' });

        const currentInfo = QRIS_STATIS
            ? ` QRIS saat ini:\n<code>${QRIS_STATIS.substring(0, 60)}...</code>\n(${QRIS_STATIS.length} karakter)`
            : ` QRIS belum diatur`;

        await sendMenu(ctx,
            `${getHeader(' 𝙐𝙋𝙇𝙊𝘼𝘿 𝙂𝘼𝙈𝘽𝘼𝙍 𝙌𝙍𝙄𝙎')}\n\n` +
            `${currentInfo}\n\n` +
            `Kirim foto/screenshot QR Code QRIS statis Anda (dari e-wallet/m-banking).\n` +
            `Bot akan otomatis decode gambar jadi string QRIS — tidak perlu situs decoder eksternal.\n\n` +
            `<b>· Pastikan QR terlihat jelas, tidak blur, dan tidak terpotong.</b>`,
            Markup.inlineKeyboard([[{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_settings_qris', style: 'danger' }]])
        );
        return;
    }

    // ==================== QRIS DINAMIS TOGGLE ====================
    if (data === 'admin_qris_dinamis_toggle') {
        if (!isAdmin(ctx.from.id)) return;
        QRIS_DINAMIS_AKTIF = !QRIS_DINAMIS_AKTIF;
        updateEnvValue('QRIS_DINAMIS_AKTIF', QRIS_DINAMIS_AKTIF.toString());
        await sendTempMessage(ctx,
            ` QRIS Dinamis sekarang <b>${QRIS_DINAMIS_AKTIF ? ' ON' : ' OFF'}</b>\n\nBerlaku langsung tanpa restart.`
        );
        await showAdminSettingsQris(ctx);
        return;
    }

    // ==================== PAKASIR ADMIN CALLBACKS ====================
    if (data === 'admin_pakasir_toggle') {
        if (!isAdmin(ctx.from.id)) return;
        PAKASIR_AKTIF = !PAKASIR_AKTIF;
        PAKASIR_TAMPIL = PAKASIR_AKTIF; // sinkronkan TAMPIL dengan AKTIF
        updateEnvValue('PAKASIR_AKTIF', PAKASIR_AKTIF.toString());
        updateEnvValue('PAKASIR_TAMPIL', PAKASIR_TAMPIL.toString());
        await sendTempMessage(ctx,
            ` Pakasir sekarang <b>${PAKASIR_AKTIF ? ' ON' : ' OFF'}</b>\n\nBerlaku langsung tanpa restart.`
        );
        await showAdminSettingsPakasir(ctx);
        return;
    }

    if (data === 'admin_edit_pakasir_apikey') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'pakasir_apikey',
            ` <b>Edit Pakasir API Key</b>\n\n` +
            `Key saat ini: ${PAKASIR_API_KEY ? `<code>${PAKASIR_API_KEY.substring(0,6)}...${PAKASIR_API_KEY.slice(-4)}</code>` : ' Belum diset'}\n\n` +
            `Kirim API Key dari halaman detail Proyek di dashboard Pakasir.`
        );
        return;
    }

    if (data === 'admin_edit_pakasir_slug') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'pakasir_slug',
            ` <b>Edit Pakasir Slug Proyek</b>\n\n` +
            `Slug saat ini: <b>${PAKASIR_SLUG || ' Belum diset'}</b>\n\n` +
            `Slug adalah bagian dari URL proyek kamu di Pakasir.\n` +
            `Contoh: jika URL proyekmu <code>https://app.pakasir.com/pay/<b>tokoku</b>/10000</code>\n` +
            `maka slugnya adalah <code>tokoku</code>`
        );
        return;
    }

    if (data === 'admin_edit_pakasir_merchant') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'pakasir_merchant',
            ` <b>Edit Nama Merchant Pakasir</b>\n\n` +
            `Merchant Pakasir saat ini: <b>${PAKASIR_MERCHANT_NAME || '(belum diset, pakai: ' + CONFIG.MERCHANT_NAME + ')'}</b>\n` +
            `Merchant QRIS Dinamis: <b>${CONFIG.MERCHANT_NAME}</b>\n\n` +
            `Nama ini tampil di caption QRIS Pakasir saat user topup.\n` +
            `Kosongkan (kirim <code>-</code>) untuk fallback ke Merchant utama.`
        );
        return;
    }

    // ==================== DANA ADMIN CALLBACKS ====================
    if (data === 'admin_dana_toggle') {
        if (!isAdmin(ctx.from.id)) return;
        DANA_AKTIF = !DANA_AKTIF;
        updateEnvValue('DANA_AKTIF', DANA_AKTIF.toString());
        await sendTempMessage(ctx,
            ` DANA sekarang <b>${DANA_AKTIF ? ' ON' : ' OFF'}</b>\n\nBerlaku langsung tanpa restart.`
        );
        await showAdminSettingsDana(ctx);
        return;
    }
    if (data === 'admin_edit_dana_nomor') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'dana_nomor',
            ` <b>Edit Nomor DANA</b>\n\n` +
            `Nomor saat ini: <b>${DANA_NOMOR || ' Belum diset'}</b>\n\n` +
            `Masukkan nomor HP yang terdaftar di DANA (contoh: <code>08123456789</code>).`
        );
        return;
    }
    if (data === 'admin_edit_dana_nama') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'dana_nama',
            ` <b>Edit Nama Pemilik DANA</b>\n\n` +
            `Nama saat ini: <b>${DANA_NAMA || ' Belum diset'}</b>\n\n` +
            `Masukkan nama lengkap pemilik akun DANA.`
        );
        return;
    }

    // ==================== GOPAY ADMIN CALLBACKS ====================
    if (data === 'admin_gopay_toggle') {
        if (!isAdmin(ctx.from.id)) return;
        GOPAY_AKTIF = !GOPAY_AKTIF;
        updateEnvValue('GOPAY_AKTIF', GOPAY_AKTIF.toString());
        await sendTempMessage(ctx,
            ` GoPay sekarang <b>${GOPAY_AKTIF ? ' ON' : ' OFF'}</b>\n\nBerlaku langsung tanpa restart.`
        );
        await showAdminSettingsGopay(ctx);
        return;
    }
    if (data === 'admin_edit_gopay_nomor') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'gopay_nomor',
            ` <b>Edit Nomor GoPay</b>\n\n` +
            `Nomor saat ini: <b>${GOPAY_NOMOR || ' Belum diset'}</b>\n\n` +
            `Masukkan nomor HP yang terdaftar di GoPay (contoh: <code>08123456789</code>).`
        );
        return;
    }
    if (data === 'admin_edit_gopay_nama') {
        if (!isAdmin(ctx.from.id)) return;
        await handleAdminEditValue(ctx, 'gopay_nama',
            ` <b>Edit Nama Pemilik GoPay</b>\n\n` +
            `Nama saat ini: <b>${GOPAY_NAMA || ' Belum diset'}</b>\n\n` +
            `Masukkan nama lengkap pemilik akun GoPay.`
        );
        return;
    }

    // ==================== ADMIN: PENGATURAN CEK PEMBAYARAN (DANA/GOPAY/QRIS MANUAL) ====================
    if (data === 'admin_settings_cekbayar') {
        if (!isAdmin(ctx.from.id)) return;
        await showAdminSettingsCekPembayaran(ctx);
        return;
    }

    if (data === 'admin_cekbayar_mode_toggle') {
        if (!isAdmin(ctx.from.id)) return;
        CEK_PEMBAYARAN_MODE = CEK_PEMBAYARAN_MODE === 'button' ? 'upload' : 'button';
        updateEnvValue('CEK_PEMBAYARAN_MODE', CEK_PEMBAYARAN_MODE);
        await sendTempMessage(ctx,
            CEK_PEMBAYARAN_MODE === 'button'
                ? ` Mode diubah ke <b>🔍 Tombol Cek Pembayaran</b>.\n\n⚠️ User TIDAK perlu upload bukti — saldo masuk otomatis saat user klik tombol setelah jeda ${CEK_PEMBAYARAN_DELAY} detik. Pastikan kamu memantau grup notifikasi topup untuk mendeteksi penyalahgunaan.`
                : ` Mode dikembalikan ke <b>📤 Upload Bukti</b>.\n\nUser wajib kirim screenshot bukti transfer (divalidasi OCR) sebelum saldo masuk.`
        );
        await showAdminSettingsCekPembayaran(ctx);
        return;
    }

    if (data === 'admin_cekbayar_delay_edit') {
        if (!isAdmin(ctx.from.id)) return;
        userStates.set(ctx.from.id.toString(), { action: 'edit_cekbayar_delay' });
        await sendTempMessage(ctx,
            ` <b>Edit Jeda Tombol Cek Pembayaran</b>\n\n` +
            `Jeda saat ini: <b>${CEK_PEMBAYARAN_DELAY} detik</b>\n\n` +
            `Kirim jumlah detik jeda minimal sebelum tombol "Cek Pembayaran" boleh mencairkan saldo (disarankan minimal 60–120 detik agar user sempat transfer).`,
            withCancelButton(),
            true
        );
        return;
    }

    // Topup via metode tertentu (dari menu pilih metode)
    if (data === 'topup_via_qris') {
        await handleTopupInput(ctx, 'qris');
        return;
    }
    if (data === 'topup_via_pakasir') {
        await handleTopupInput(ctx, 'pakasir');
        return;
    }
    if (data === 'topup_via_dana') {
        await handleTopupInput(ctx, 'dana');
        return;
    }
    if (data === 'topup_via_gopay') {
        await handleTopupInput(ctx, 'gopay');
        return;
    }

    // ==================== NUMPAD KALKULATOR NOMINAL TOPUP ====================
    if (data.startsWith('topup_num_') || data.startsWith('topup_preset_') || data === 'topup_num_confirm' || data === 'topup_num_cancel') {
        const state = userStates.get(userId);
        if (!state || state.action !== 'topup' || state.step !== 'input_amount') {
            try { await ctx.answerCbQuery(' Sesi topup tidak ditemukan / sudah selesai.', { show_alert: true }); } catch(e) {}
            return;
        }

        // Batal
        if (data === 'topup_num_cancel') {
            userStates.delete(userId);
            try { await ctx.answerCbQuery(' Topup dibatalkan.'); } catch(e) {}
            await showMainMenu(ctx);
            return;
        }

        // Hapus semua
        if (data === 'topup_num_clear') {
            state.input = '';
            userStates.set(userId, state);
            try { await ctx.answerCbQuery(); } catch(e) {}
            await renderTopupNumpad(ctx);
            return;
        }

        // Backspace
        if (data === 'topup_num_del') {
            state.input = (state.input || '').slice(0, -1);
            userStates.set(userId, state);
            try { await ctx.answerCbQuery(); } catch(e) {}
            await renderTopupNumpad(ctx);
            return;
        }

        // Konfirmasi / lanjut
        if (data === 'topup_num_confirm') {
            const amount = parseInt(state.input || '0');
            if (!amount || isNaN(amount) || amount <= 0) {
                try { await ctx.answerCbQuery(' Masukkan nominal terlebih dahulu.', { show_alert: true }); } catch(e) {}
                return;
            }
            try { await ctx.answerCbQuery(); } catch(e) {}

            // Simpan referensi pesan kalkulator agar bisa dihapus setelah pembayaran dibuat
            const calcChatId = ctx.callbackQuery?.message?.chat?.id;
            const calcMessageId = ctx.callbackQuery?.message?.message_id;

            const ok = await processTopupAmount(ctx, amount);
            if (ok) {
                // Hapus pesan kalkulator nominal, karena pesan pembayaran sudah dikirim terpisah
                if (calcChatId && calcMessageId) {
                    try { await ctx.telegram.deleteMessage(calcChatId, calcMessageId); } catch(e) {}
                }
            } else {
                // Gagal (misal di bawah minimal) — kembalikan ke numpad dengan input direset
                const stAfter = userStates.get(userId);
                if (stAfter) {
                    stAfter.input = '';
                    userStates.set(userId, stAfter);
                    await renderTopupNumpad(ctx);
                }
            }
            return;
        }

        // Preset nominal cepat
        if (data.startsWith('topup_preset_')) {
            const amt = parseInt(data.replace('topup_preset_', ''));
            state.input = String(amt);
            userStates.set(userId, state);
            try { await ctx.answerCbQuery(); } catch(e) {}
            await renderTopupNumpad(ctx);
            return;
        }

        // Tombol angka (0-9, atau 000)
        if (data.startsWith('topup_num_')) {
            const digit = data.replace('topup_num_', '');
            let current = state.input || '';
            // Batasi panjang input maksimal 9 digit (~999 juta) agar tidak overflow
            if (current.length >= 9) {
                try { await ctx.answerCbQuery(' Nominal terlalu besar.', { show_alert: true }); } catch(e) {}
                return;
            }
            // Hindari nol berlebih di depan
            if (current === '0') current = '';
            current += digit;
            if (current.length > 9) current = current.slice(0, 9);
            state.input = current;
            userStates.set(userId, state);
            try { await ctx.answerCbQuery(); } catch(e) {}
            await renderTopupNumpad(ctx);
            return;
        }
    }

    if (data === 'admin_server_menu') {
        userStates.delete(userId);
        await showAdminServerMenu(ctx);
        return;
    }
    if (data === 'admin_server_list') {
        await showAdminServerList(ctx);
        return;
    }
    if (data === 'admin_server_add') {
        await showAdminServerAdd(ctx);
        return;
    }
    if (data === 'admin_server_edit') {
        await showAdminServerEdit(ctx);
        return;
    }
    if (data === 'admin_server_delete') {
        await showAdminServerDelete(ctx);
        return;
    }
    if (data === 'admin_server_harga_list') {
        await showAdminServerHargaList(ctx);
        return;
    }
    if (data.startsWith('admin_server_harga_edit_')) {
        const serverId = data.replace('admin_server_harga_edit_', '');
        await showAdminServerHargaEdit(ctx, serverId);
        return;
    }
    if (data.startsWith('admin_server_harga_reset_')) {
        const serverId = data.replace('admin_server_harga_reset_', '');
        SERVERS[serverId].hargaPerHari = null;
        saveServers(SERVERS);
        userStates.delete(userId);
        await sendResultMessage(ctx,
            ` Harga server <b>${SERVERS[serverId]?.name || serverId}</b> direset ke harga global (Rp ${CONFIG.HARGA_PER_HARI_PER_IP.toLocaleString('id-ID')}/hari/IP).`
        );
        await showAdminServerHargaList(ctx);
        return;
    }
    if (data === 'admin_server_quota_list') {
        await showAdminServerQuotaList(ctx);
        return;
    }
    if (data.startsWith('admin_server_quota_edit_')) {
        const serverId = data.replace('admin_server_quota_edit_', '');
        await showAdminServerQuotaEdit(ctx, serverId);
        return;
    }
    if (data.startsWith('admin_server_quota_reset_')) {
        const serverId = data.replace('admin_server_quota_reset_', '');
        if (SERVERS[serverId]) {
            SERVERS[serverId].quotaGb = null;
            saveServers(SERVERS);
        }
        userStates.delete(userId);
        const quotaLabel = CONFIG.DEFAULT_QUOTA === 0 ? 'Unlimited' : `${CONFIG.DEFAULT_QUOTA} GB`;
        await sendResultMessage(ctx,
            ` Quota server <b>${SERVERS[serverId]?.name || serverId}</b> direset ke quota global (${quotaLabel}).`
        );
        await showAdminServerQuotaList(ctx);
        return;
    }
    if (data === 'admin_server_slot_list') {
        await showAdminServerSlotList(ctx);
        return;
    }
    if (data.startsWith('admin_server_slot_total_edit_')) {
        const serverId = data.replace('admin_server_slot_total_edit_', '');
        await showAdminServerSlotTotalEdit(ctx, serverId);
        return;
    }
    if (data.startsWith('admin_server_slot_edit_')) {
        const serverId = data.replace('admin_server_slot_edit_', '');
        await showAdminServerSlotEdit(ctx, serverId);
        return;
    }
    if (data.startsWith('admin_server_slot_terpakai_edit_')) {
        const serverId = data.replace('admin_server_slot_terpakai_edit_', '');
        await showAdminServerSlotTerpakaiEdit(ctx, serverId);
        return;
    }
    if (data.startsWith('admin_server_slot_reset_')) {
        const serverId = data.replace('admin_server_slot_reset_', '');
        if (SERVERS[serverId]) {
            SERVERS[serverId].maxSlot = null;
            saveServers(SERVERS);
        }
        userStates.delete(userId);
        await sendResultMessage(ctx,
            ` Slot server <b>${SERVERS[serverId]?.name || serverId}</b> direset ke <b>Unlimited</b> (tanpa batas).`
        );
        await showAdminServerSlotList(ctx);
        return;
    }
    
    if (data.startsWith('admin_delete_server_')) {
        const serverId = data.replace('admin_delete_server_', '');
        await processAdminServerDelete(ctx, serverId);
        return;
    }
    
    if (data.startsWith('admin_edit_server_')) {
        const serverId = data.replace('admin_edit_server_', '');
        await processAdminServerEditSelect(ctx, serverId);
        return;
    }
    
    if (data === 'admin_edit_field_name') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            await processAdminServerEditField(ctx, 'name', state.serverId);
        }
        return;
    }
    if (data === 'admin_edit_field_apiurl') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            await processAdminServerEditField(ctx, 'apiurl', state.serverId);
        }
        return;
    }
    if (data === 'admin_edit_field_authkey') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            await processAdminServerEditField(ctx, 'authkey', state.serverId);
        }
        return;
    }
    if (data === 'admin_edit_field_type') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            await processAdminServerEditField(ctx, 'type', state.serverId);
        }
        return;
    }
    if (data === 'admin_edit_field_cdn') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            await processAdminServerEditField(ctx, 'cdn', state.serverId);
        }
        return;
    }
    if (data === 'admin_edit_cdn_clear') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            const removed = deleteEdurcDomain(state.serverId);
            userStates.delete(userId);
            await sendResultMessage(ctx, removed
                ? ` Domain CDN (EDURC) untuk server "<b>${state.server.name}</b>" berhasil dihapus. Link EDURC akan kembali memakai domain server asli.`
                : ` Server "<b>${state.server.name}</b>" belum memiliki Domain CDN.`);
            await showAdminServerMenu(ctx);
        }
        return;
    }
    
    if (data === 'admin_edit_type_ssh') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            await processAdminServerEditValue(ctx, 'ssh', 'type', state.serverId);
        }
        return;
    }
    if (data === 'admin_edit_type_xray') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            await processAdminServerEditValue(ctx, 'xray', 'type', state.serverId);
        }
        return;
    }
    if (data === 'admin_edit_type_zivpn') {
        const state = userStates.get(userId);
        if (state && state.action === 'admin_server_edit_field') {
            await processAdminServerEditValue(ctx, 'zivpn', 'type', state.serverId);
        }
        return;
    }
    
    if (data === 'admin_server_type_ssh') {
        await processAdminServerAddType(ctx, 'ssh');
        return;
    }
    if (data === 'admin_server_type_xray') {
        await processAdminServerAddType(ctx, 'xray');
        return;
    }
    if (data === 'admin_server_type_zivpn') {
        await processAdminServerAddType(ctx, 'zivpn');
        return;
    }
    // Di bagian CALLBACK QUERY HANDLER, tambahkan:

    // ==================== AKUN SAYA ====================
    if (data === 'akun_saya') {
        await showAkunSaya(ctx);
        return;
    }
    if (data && data.startsWith('akun_saya_page_')) {
        const page = parseInt(data.replace('akun_saya_page_', ''));
        await showAkunSaya(ctx, page);
        return;
    }
    if (data === 'akun_saya_search') {
        await promptAkunSayaSearch(ctx);
        return;
    }

    // ==================== PAYG CALLBACKS ====================
    if (data === 'payg_menu') {
        await showPaygMenu(ctx);
        return;
    }

    if (data === 'payg_my_akun') {
        await showPaygMyAkun(ctx);
        return;
    }

    if (data === 'payg_stop_list') {
        await showPaygStopList(ctx);
        return;
    }

    if (data.startsWith('payg_stop_confirm_')) {
        const idx = parseInt(data.replace('payg_stop_confirm_', ''));
        await handlePaygStopConfirm(ctx, idx);
        return;
    }

    if (data.startsWith('payg_stop_exec_')) {
        const idx = parseInt(data.replace('payg_stop_exec_', ''));
        await eksekusiStopPayg(ctx, idx);
        return;
    }

    if (data === 'payg_create_ssh' || data === 'payg_create_trojan' || data === 'payg_create_vless' ||
        data === 'payg_create_vmess' || data === 'payg_create_zivpn') {
        const serviceType = data.replace('payg_create_', '');
        await handlePaygCreate(ctx, serviceType);
        return;
    }

    if (data.startsWith('payg_server_')) {
        const serverId = data.replace('payg_server_', '');
        const state = userStates.get(userId);
        if (state && state.action === 'payg_select_server') {
            await processPaygSelectServer(ctx, serverId);
        }
        return;
    }

    if (data === 'payg_confirm_yes') {
        await eksekusiCreatePayg(ctx);
        return;
    }

    // ==================== PAYG PASSWORD CALLBACKS ====================
    if (data === 'payg_pw_random') {
        const state = userStates.get(userId);
        if (state && state.action === 'payg_input' && state.step === 'password') {
            const { serviceType, server, data: d } = state;
            const isXray = ['trojan', 'vless', 'vmess'].includes(serviceType);
            d.password = isXray ? require('crypto').randomUUID() : Math.random().toString(36).substring(2, 12);
            await sendTempMessage(ctx, ` Password di-generate otomatis: <code>${d.password}</code>`);
            await showPaygConfirm(ctx, serviceType, server, d);
        }
        return;
    }

    if (data === 'payg_pw_custom') {
        const state = userStates.get(userId);
        if (state && state.action === 'payg_input' && state.step === 'password') {
            const { serviceType } = state;
            const isXray = ['trojan', 'vless', 'vmess'].includes(serviceType);
            const hint = isXray
                ? `Masukkan <b>UUID</b> (format: <code>xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx</code>)\nAtau password bebas (min 4 karakter)`
                : `Masukkan <b>password</b> (min 4 karakter)\nContoh: <code>mypass123</code>`;
            state.step = 'password_manual';
            userStates.set(userId, state);
            await sendTempMessage(ctx, ` <b>Ketik Password Custom:</b>\n\n${hint}`, withCancelButton(), true);
        }
        return;
    }

    // ==================== IP LIMIT CALLBACKS ====================
    // create_ip_1, create_ip_2, create_ip_custom
    if (data.startsWith('create_ip_')) {
        const val = data.replace('create_ip_', '');
        if (val === 'custom') {
            const state = userStates.get(userId);
            if (state) {
                userStates.set(userId, { ...state, action: 'create_select_ip', waitingCustomIp: true });
                await sendTempMessage(ctx, ` Masukkan jumlah IP/devices:\nContoh: <code>3</code>`, withCancelButton(), true);
            }
        } else {
            await processCreateAfterIpSelect(ctx, parseInt(val));
        }
        return;
    }

    // renew_ip_1, renew_ip_2, renew_ip_custom
    if (data.startsWith('renew_ip_')) {
        const val = data.replace('renew_ip_', '');
        if (val === 'custom') {
            const state = userStates.get(userId);
            if (state) {
                userStates.set(userId, { ...state, action: 'renew_select_ip', waitingCustomIp: true });
                await sendTempMessage(ctx, ` Masukkan jumlah IP/devices:\nContoh: <code>3</code>`, withCancelButton(), true);
            }
        } else {
            await processRenewAfterIpSelect(ctx, parseInt(val));
        }
        return;
    }

    // payg_ip_1, payg_ip_2, payg_ip_custom
    if (data.startsWith('payg_ip_')) {
        const val = data.replace('payg_ip_', '');
        if (val === 'custom') {
            const state = userStates.get(userId);
            if (state) {
                userStates.set(userId, { ...state, action: 'payg_select_ip', waitingCustomIp: true });
                await sendTempMessage(ctx, ` Masukkan jumlah IP/devices:\nContoh: <code>3</code>`, withCancelButton(), true);
            }
        } else {
            await processPaygAfterIpSelect(ctx, parseInt(val));
        }
        return;
    }

if (data === 'admin_backup_menu') {
    await showAdminBackupMenu(ctx);
    return;
}

if (data === 'admin_backup_list') {
    await showAdminBackupList(ctx, 0);
    return;
}

if (data.startsWith('admin_backup_list_page_')) {
    const page = parseInt(data.replace('admin_backup_list_page_', ''));
    await showAdminBackupList(ctx, page);
    return;
}

if (data === 'admin_backup_restore_list') {
    await showAdminBackupRestoreList(ctx);
    return;
}

if (data === 'admin_backup_delete_list') {
    await showAdminBackupDeleteList(ctx);
    return;
}

if (data === 'admin_backup_manual') {
    if (!isAdmin(ctx.from.id)) return;
    await sendTempMessage(ctx, ` Sedang membuat backup dan mengupload ke GitHub...`);
    try {
        const { backupId, filename, githubSha } = await createBackup('manual');
        const localPath = path.join(BACKUP_DIR, filename);
        const st = fs.statSync(localPath);
        const size = st.size > 1024 ? `${(st.size/1024).toFixed(1)} KB` : `${st.size} B`;
        const ghStatus = githubSha
            ? ` Upload GitHub berhasil\n <b>Repo:</b> <code>${GITHUB_OWNER}/${GITHUB_REPO}</code>`
            : ` Upload GitHub gagal (backup lokal tersimpan)`;
        await sendResultMessage(ctx,
            ` <b>Backup berhasil dibuat!</b>\n\n` +
            ` <b>Backup ID:</b> <code>${backupId}</code>\n` +
            ` <b>File:</b> <code>${filename}</code>\n` +
            ` <b>Size:</b> ${size}\n` +
            ` <b>Waktu:</b> ${formatTimestamp()}\n` +
            `${ghStatus}\n\n` +
            `Data yang dibackup: Server, User, Akun, Saldo, Transaksi, Trial`
        );
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal membuat backup: ${e.message}`);
    }
    await showAdminBackupMenu(ctx);
    return;
}

if (data === 'admin_backup_auto_setup') {
    await showAdminAutoBackupSetup(ctx);
    return;
}

if (data === 'admin_backup_auto_stop') {
    if (!isAdmin(ctx.from.id)) return;
    stopAutoBackup();
    await sendResultMessage(ctx, ` <b>Auto Backup dinonaktifkan.</b>\nBackup manual masih bisa dilakukan kapan saja.`);
    await showAdminBackupMenu(ctx);
    return;
}

if (data.startsWith('admin_backup_auto_set_')) {
    if (!isAdmin(ctx.from.id)) return;
    const minutes = parseInt(data.replace('admin_backup_auto_set_', ''));
    startAutoBackup(minutes);
    const label = minutes >= 60 ? `${minutes/60} jam` : `${minutes} menit`;
    await sendResultMessage(ctx,
        ` <b>Auto Backup diaktifkan!</b>\n\n` +
        ` Interval: setiap <b>${label}</b>\n` +
        ` Upload otomatis ke: <code>${GITHUB_OWNER}/${GITHUB_REPO}</code>\n` +
        ` Cache lokal: <code>./backups/</code>\n` +
        ` Maksimal 10 entry backup tersimpan di index`
    );
    await showAdminBackupMenu(ctx);
    return;
}

if (data.startsWith('admin_backup_restore_confirm_')) {
    if (!isAdmin(ctx.from.id)) return;
    const backupId = data.replace('admin_backup_restore_confirm_', '');
    const index = loadBackupIndex();
    const entry = index[backupId];
    const dateStr = entry && entry.createdAt
        ? new Date(entry.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
        : '-';
    const ghBadge = (entry && entry.githubUploaded) ? `\n <b>Sumber:</b> GitHub <code>${GITHUB_OWNER}/${GITHUB_REPO}</code>` : '';
    const text = `${getHeader(' 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝙍𝙀𝙎𝙏𝙊𝙍𝙀')}

 <b>Anda akan merestore data dari:</b>
 ID: <code>${backupId}</code>
 Label: ${entry ? entry.label : '?'}
 Dibuat: ${dateStr}${ghBadge}

 Semua data saat ini (server, akun, saldo, transaksi) akan <b>diganti</b> dengan data dari backup ini.

Lanjutkan?`;
    const keyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝙍𝙚𝙨𝙩𝙤𝙧𝙚 𝙎𝙚𝙠𝙖𝙧𝙖𝙣𝙜', callback_data: `admin_backup_do_restore_${backupId}` }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_backup_restore_list', style: 'danger' }]
    ]);
    await sendMenu(ctx, text, keyboard);
    return;
}

if (data.startsWith('admin_backup_do_restore_')) {
    if (!isAdmin(ctx.from.id)) return;
    const backupId = data.replace('admin_backup_do_restore_', '');
    await sendTempMessage(ctx, ` Sedang merestore data...`);
    try {
        const meta = await restoreBackupById(backupId);
        await sendResultMessage(ctx,
            ` <b>Restore Berhasil!</b>\n\n` +
            ` <b>Backup ID:</b> <code>${backupId}</code>\n` +
            ` <b>Waktu Backup:</b> ${meta.createdAt ? new Date(meta.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : '-'}\n` +
            ` <b>Label:</b> ${meta.label || '-'}\n\n` +
            `Data server, akun, saldo, transaksi, dan trial telah dipulihkan.\n` +
            `Server di-reload ke memory.`
        );
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal restore: ${e.message}`);
    }
    await showAdminBackupMenu(ctx);
    return;
}

if (data.startsWith('admin_backup_delete_confirm_')) {
    if (!isAdmin(ctx.from.id)) return;
    const backupId = data.replace('admin_backup_delete_confirm_', '');
    const index = loadBackupIndex();
    const entry = index[backupId];
    const text = ` Yakin ingin menghapus backup:\n <code>${backupId}</code>  ${entry ? `(${entry.label || '-'})` : ''}\n\n(Hanya dihapus dari lokal & index, file di GitHub tetap ada)`;
    const keyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝙃𝙖𝙥𝙪𝙨', callback_data: `admin_backup_do_delete_${backupId}` }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_backup_delete_list', style: 'danger' }]
    ]);
    await sendMenu(ctx, text, keyboard);
    return;
}

if (data.startsWith('admin_backup_do_delete_')) {
    if (!isAdmin(ctx.from.id)) return;
    const backupId = data.replace('admin_backup_do_delete_', '');
    const index = loadBackupIndex();
    const entry = index[backupId];
    try {
        if (entry) {
            const localPath = path.join(BACKUP_DIR, entry.filename);
            if (fs.existsSync(localPath)) fs.unlinkSync(localPath);
            delete index[backupId];
            saveBackupIndex(index);
        }
        await sendResultMessage(ctx, ` Backup <code>${backupId}</code> berhasil dihapus dari lokal & index.`);
    } catch(e) {
        await sendTempMessage(ctx, ` Gagal hapus: ${e.message}`);
    }
    await showAdminBackupMenu(ctx);
    return;
}

if (data === 'admin_restart_bot') {
    await restartBot(ctx);
    return;
}

if (data === 'admin_restart_confirm') {
    await executeRestart(ctx);
    return;
}
});

// ==================== TEXT MESSAGE HANDLER ====================
bot.on('text', async (ctx) => {
    const userId = ctx.from.id.toString();
    registerUser(ctx.from);
    const message = ctx.message.text.trim();
    const state = userStates.get(userId);
        // Cek broadcast text
    const isBroadcastHandled = await broadcastModule.handleBroadcastTextMessage(ctx, message, userStates);
    if (isBroadcastHandled) return;

    // ==================== TOOLS: CONVERT XRAY YAML ====================
    const isXrayToolHandled = await xrayYamlModule.handleXrayToolText(ctx, { sendMenu, sendTempMessage, trackMessage });
    if (isXrayToolHandled) return;

    if (message.toLowerCase() === 'cancel') {
        userStates.delete(userId);
        await showMainMenu(ctx);
        return;
    }

    // Jika admin sedang input string QRIS
    if (state && state.action === 'admin_edit_qris_string') {
        const qrisString = message.trim();
        if (qrisString.length < 20) {
            await sendTempMessage(ctx, ` String QRIS terlalu pendek. Pastikan Anda mengirim string QRIS yang lengkap.`);
            return;
        }
        await simpanQrisStatis(ctx, qrisString);
        return;
    }

    // Jika admin sedang upload gambar QRIS (tunggu foto, kalau kirim teks cek cancel)
    if (state && state.action === 'admin_edit_qris_image') {
        if (message.trim().toLowerCase() === 'cancel') {
            userStates.delete(userId);
            await showAdminSettingsQris(ctx);
            return;
        }
        await sendTempMessage(ctx, ' Kirim foto/gambar QR Code, bukan teks.');
        return;
    }
    
    if (state && state.action === 'edit_cekbayar_delay') {
        const detik = parseInt(message.replace(/\D/g, ''));
        if (isNaN(detik) || detik < 10) {
            await sendTempMessage(ctx, ` Nilai tidak valid. Minimal 10 detik.`, withCancelButton(), true);
            return;
        }
        userStates.delete(userId);
        CEK_PEMBAYARAN_DELAY = detik;
        updateEnvValue('CEK_PEMBAYARAN_DELAY', detik.toString());
        await sendTempMessage(ctx, ` Jeda tombol Cek Pembayaran diubah menjadi <b>${detik} detik</b>.`);
        await showAdminSettingsCekPembayaran(ctx);
        return;
    }

    if (state && state.action === 'topup' && state.step === 'input_amount') {
        const amount = parseInt(message.replace(/\D/g, ''));
        if (isNaN(amount)) {
            await sendTempMessage(ctx, ` Nominal tidak valid!`);
            return;
        }
        await processTopupAmount(ctx, amount);
        return;
    }
    
    // Ganti bagian create_input:
if (state && state.action === 'create_input') {
    await processCreateInput(ctx, message, state.serviceType, state.server, state.step, state.data, state.isEdurc);
    return;
}

    // ==================== AKUN SAYA - PENCARIAN ====================
    if (state && state.action === 'akun_saya_search_input') {
        await processAkunSayaSearchInput(ctx, message);
        return;
    }

    // ==================== CUSTOM IP TEXT INPUT ====================
    if (state && state.action === 'create_select_ip' && state.waitingCustomIp) {
        const ip = parseInt(message);
        if (isNaN(ip) || ip < 1) {
            await sendTempMessage(ctx, ` Jumlah IP tidak valid. Masukkan angka >= 1`);
            return;
        }
        await processCreateAfterIpSelect(ctx, ip);
        return;
    }

    if (state && state.action === 'renew_select_ip' && state.waitingCustomIp) {
        const ip = parseInt(message);
        if (isNaN(ip) || ip < 1) {
            await sendTempMessage(ctx, ` Jumlah IP tidak valid. Masukkan angka >= 1`);
            return;
        }
        await processRenewAfterIpSelect(ctx, ip);
        return;
    }

    if (state && state.action === 'payg_select_ip' && state.waitingCustomIp) {
        const ip = parseInt(message);
        if (isNaN(ip) || ip < 1) {
            await sendTempMessage(ctx, ` Jumlah IP tidak valid. Masukkan angka >= 1`);
            return;
        }
        await processPaygAfterIpSelect(ctx, ip);
        return;
    }

    // PAYG input handler
    if (state && state.action === 'payg_input') {
        await processPaygInput(ctx, message, state);
        return;
    }
    
    // Ganti bagian renew_input:
if (state && state.action === 'renew_input') {
    await processRenewInput(ctx, message, state.serviceType, state.isEdurc, state.step, state.data, state.server);
    return;
}

    // ==================== SEWA SC TEXT INPUT ====================
    if (state && state.action === 'sewa_sc_input') {
        await processSewaScInput(ctx, message, state);
        return;
    }
    if (state && state.action === 'sewa_bot_input') {
        await processSewaBotInput(ctx, message, state);
        return;
    }
    if (state && state.action === 'admin_bot_revoke_input') {
        await processAdminBotRevokeInput(ctx, message);
        return;
    }
    if (state && state.action === 'admin_edit_header_image_main') {
        if (message.trim().toLowerCase() === 'cancel') {
            userStates.delete(userId);
            await showAdminEditData(ctx);
            return;
        }
        await sendTempMessage(ctx, ' Kirim foto/gambar, bukan teks.', withCancelButton(), true);
        return;
    }
    if (state && state.action === 'sewa_sc_ganti') {
        await processSewaScGantiInput(ctx, message, state);
        return;
    }
    if (state && state.action === 'admin_sc_add_input') {
        await processAdminScAddInput(ctx, message);
        return;
    }
    if (state && state.action === 'admin_topup_bonus_add_input') {
        await processAdminTopupBonusAddInput(ctx, message);
        return;
    }
    if (state && state.action === 'admin_sc_edit') {
        await processAdminScEditInput(ctx, message, state);
        return;
    }
    if (state && state.action === 'admin_sc_adduser') {
        await processAdminScAddUserInput(ctx, message, state);
        return;
    }
    if (state && state.action === 'admin_sc_remove_input') {
        await processAdminScRemoveInput(ctx, message);
        return;
    }
    if (state && state.action === 'admin_sc_paket_add_input') {
        await processAdminScPaketAddInput(ctx, message);
        return;
    }

    // ==================== MODE WILDCARD: TEXT INPUT ====================
    if (state && state.action === 'wildcard_input_link') {
        await processWildcardLinkInput(ctx, message, state.entryId);
        return;
    }
    if (state && state.action === 'wildcard_admin_add') {
        await processWildcardAdminAddInput(ctx, message, state);
        return;
    }

    // ==================== BUG XRAY: TEXT INPUT ====================
    if (state && state.action === 'bug_input_link') {
        await processBugLinkInput(ctx, message, state.entryId, state.mode);
        return;
    }
    if (state && state.action === 'bug_admin_add') {
        await processBugAdminAddInput(ctx, message, state);
        return;
    }

    if (state && state.action === 'admin_server_add') {
        if (state.step === 'input_name') {
            await processAdminServerAddName(ctx, message);
            return;
        }
        if (state.step === 'input_domain') {
            await processAdminServerAddDomain(ctx, message);
            return;
        }
        if (state.step === 'input_authkey') {
            await processAdminServerAddAuthKey(ctx, message);
            return;
        }
        return;
    }
    
    if (state && state.action === 'admin_search_users') {
        userStates.delete(userId);
        await showAdminSearchResults(ctx, message);
        return;
    }

    if (state && state.action === 'admin_del_akun_search') {
        if (message.toLowerCase() === 'cancel') {
            userStates.delete(userId);
            await showAdminDeleteAkunList(ctx, state.serverId, state.serviceType, 0);
            return;
        }
        await showAdminDeleteAkunSearchResult(ctx, message);
        return;
    }

    if (state && (state.action === 'admin_add_saldo_amount' || state.action === 'admin_reduce_saldo_amount')) {
        const amount = parseInt(message.replace(/\D/g, ''));
        if (isNaN(amount) || amount <= 0) {
            await sendTempMessage(ctx, ` Nominal tidak valid!\n\nKetik nominal angka (contoh: 50000)`);
            return;
        }
        const mode = state.action === 'admin_add_saldo_amount' ? 'add' : 'reduce';
        await processAdminEditSaldoNominal(ctx, mode, amount, state.targetUserId, state.targetName);
        return;
    }
    
    // In the text message handler, replace the admin edit section:

if (state && state.action === 'admin_edit_server_harga') {
    await processAdminServerHargaInput(ctx, message, state.serverId);
    return;
}

if (state && state.action === 'admin_edit_server_quota') {
    await processAdminServerQuotaInput(ctx, message, state.serverId);
    return;
}

if (state && state.action === 'admin_edit_server_slot') {
    await processAdminServerSlotInput(ctx, message, state.serverId);
    return;
}

if (state && state.action === 'admin_edit_server_slot_terpakai') {
    await processAdminServerSlotTerpakaiInput(ctx, message, state.serverId);
    return;
}

if (state && state.action && state.action.startsWith('admin_edit_')) {
    const field = state.editField || state.action.replace('admin_edit_', '');
    // Pass ctx as the first parameter and the message as second
    await processAdminEditValue(ctx, ctx.message, field);
    return;
}
    
    if (state && state.action === 'admin_server_edit_field' && state.step === 'input_value') {
        await processAdminServerEditValue(ctx, message, state.editField, state.serverId);
        return;
    }
});

// ==================== PHOTO HANDLER ====================
bot.on('photo', async (ctx) => {
    const userId = ctx.from.id.toString();
    registerUser(ctx.from);
    const isBroadcastHandled = await broadcastModule.handleBroadcastPhotoMessage(ctx, userStates);
    if (isBroadcastHandled) return;

    // Admin sedang ganti gambar header menu utama
    const adminState = userStates.get(userId);
    if (adminState && adminState.action === 'admin_edit_header_image_main') {
        if (!isAdmin(ctx.from.id)) return;
        try {
            const photos = ctx.message.photo;
            const fileId = photos[photos.length - 1].file_id;
            const fileLink = await ctx.telegram.getFileLink(fileId);
            const response = await axios.get(fileLink.href, { responseType: 'arraybuffer' });
            const imageBuffer = Buffer.from(response.data);

            const assetsDir = path.join(__dirname, 'assets');
            if (!fs.existsSync(assetsDir)) fs.mkdirSync(assetsDir, { recursive: true });
            fs.writeFileSync(HEADER_IMAGE_PATH, imageBuffer);

            // Reset cache file_id Telegram supaya gambar baru langsung dipakai
            headerFileId = null;

            userStates.delete(userId);
            await sendResultMessage(ctx, ' Gambar header menu utama berhasil diganti!\n\nPerubahan langsung berlaku tanpa restart.');
            await showAdminEditData(ctx);
        } catch (e) {
            await sendTempMessage(ctx, ` Gagal mengganti gambar header: ${e.message}`);
        }
        return;
    }
    
    // Admin sedang upload gambar QRIS untuk di-decode jadi string
    if (adminState && adminState.action === 'admin_edit_qris_image') {
        if (!isAdmin(ctx.from.id)) return;
        try {
            const photos = ctx.message.photo;
            const fileId = photos[photos.length - 1].file_id;
            const fileLink = await ctx.telegram.getFileLink(fileId);
            const response = await axios.get(fileLink.href, { responseType: 'arraybuffer' });
            const imageBuffer = Buffer.from(response.data);

            const img = await loadImage(imageBuffer);
            const canvas = createCanvas(img.width, img.height);
            const cctx = canvas.getContext('2d');
            cctx.drawImage(img, 0, 0);
            const imageData = cctx.getImageData(0, 0, img.width, img.height);

            const decoded = jsQR(imageData.data, imageData.width, imageData.height);
            if (!decoded || !decoded.data) {
                await sendTempMessage(ctx, ' Gagal membaca QR Code dari gambar. Pastikan foto jelas, tidak blur/terpotong, lalu kirim ulang.');
                return;
            }

            await simpanQrisStatis(ctx, decoded.data);
        } catch (e) {
            await sendTempMessage(ctx, ` Gagal memproses gambar QRIS: ${e.message}`);
        }
        return;
    }

    // Mode CEK_PEMBAYARAN_MODE = 'button' -> user menyelesaikan topup via tombol "Cek Pembayaran",
    // BUKAN dengan upload bukti. Kalau user tetap kirim foto di mode ini, jangan diproses sebagai
    // bukti transfer (supaya tidak salah approve saldo tanpa validasi apapun).
    if (CEK_PEMBAYARAN_MODE === 'button' && (pendingQRIS.has(userId) || pendingDANA.has(userId) || pendingGOPAY.has(userId))) {
        const pendingQ = pendingQRIS.get(userId);
        if (!(pendingQ && pendingQ.metode === 'pakasir')) {
            try { await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id); } catch(e) {}
            await sendTempMessage(ctx,
                `ℹ Tidak perlu kirim screenshot bukti. Silakan transfer sesuai nominal lalu tekan tombol <b>Cek Status Pembayaran</b> setelah melakukan pembayaran`
            );
            return;
        }
    }

    // Jika ada pending QRIS, proses pembayaran dengan validasi hash
    if (pendingQRIS.has(userId)) {
        const pending = pendingQRIS.get(userId);
        // Pakasir: deteksi otomatis via polling — tidak butuh bukti foto
        if (pending && pending.metode === 'pakasir') {
            try { await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id); } catch(e) {}
            await sendTempMessage(ctx,
                `ℹ Pembayaran Pakasir dideteksi <b>otomatis</b>.\n\n` +
                `Tidak perlu kirim screenshot. Bot akan memberikan notifikasi segera setelah pembayaran diterima. `
            );
            return;
        }
        await handlePaymentProof(ctx);
    } else if (pendingDANA.has(userId)) {
        // Bukti transfer DANA
        await handlePaymentProofDana(ctx);
    } else if (pendingGOPAY.has(userId)) {
        // Bukti transfer GoPay
        await handlePaymentProofGopay(ctx);
    } else {
        // Tidak ada sesi topup aktif — hapus gambar diam-diam tanpa balas
        // Mencegah user coba-coba kirim gambar sembarangan
        console.log(`[AntiSpam]  Gambar tanpa pendingQRIS dari user ${userId} — ditolak diam-diam`);
        try { await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id); } catch(e) {}
    }
});

// ==================== AUTO DELETE EXPIRED ACCOUNTS (via API + Local) ====================

// Hapus akun dari server via API (general — berlaku untuk semua tipe)
async function deleteAkunFromServer(server, akun) {
    const svcType = (akun.serviceType || '').toString().trim().toLowerCase();
    const mod = getModule(svcType);

    async function doDelete(identifier) {
        if (svcType === 'ssh')     return await mod.deleteSSH(server, identifier);
        if (svcType === 'trojan')  return await mod.deleteTrojan(server, identifier);
        if (svcType === 'vless')   return await mod.deleteVless(server, identifier);
        if (svcType === 'vmess')   return await mod.deleteVmess(server, identifier);
        if (svcType === 'zivpn')   return await mod.zivpnDelete(server, identifier);
        return { success: false, message: 'Tipe tidak dikenal' };
    }

    try {
        const primaryId = akun.username || akun.password;
        console.log(`[deleteAkunFromServer] type=${svcType} identifier="${primaryId}" server=${server.name}`);
        let result = await doDelete(primaryId);
        console.log(`[deleteAkunFromServer] result: success=${result?.success} msg=${result?.message}`);

        // Retry dengan password jika gagal dan berbeda dari username (handle akun lama)
        if (!result?.success && akun.password && akun.password !== primaryId) {
            console.log(`[deleteAkunFromServer] Retry dengan password: "${akun.password}"`);
            const retry = await doDelete(akun.password);
            console.log(`[deleteAkunFromServer] Retry: success=${retry?.success} msg=${retry?.message}`);
            if (retry?.success) return retry;
        }
        return result;
    } catch(e) {
        console.log(`[deleteAkunFromServer] EXCEPTION: ${e.message}`);
        return { success: false, message: e.message };
    }
}

// Track akun yang sudah dinotif agar tidak duplikat
// Key: `${userId}_${username}_${expired}` → timestamp notif terakhir
const _notifSentMap = new Map();

//  LOCK: cegah checkAndDeleteExpiredAccounts jalan bersamaan (race condition) 
// Ini penyebab utama notif spam: interval 1 menit memanggil fungsi baru
// sementara run sebelumnya masih await API call → akun dibaca 2x sebelum disimpan
let _expiredCheckerRunning = false;

async function checkAndDeleteExpiredAccounts() {
    if (_expiredCheckerRunning) {
        console.log('[ExpiredChecker] Masih berjalan, skip run ini.');
        return 0;
    }
    _expiredCheckerRunning = true;
    try {
        return await _doCheckAndDeleteExpiredAccounts();
    } finally {
        _expiredCheckerRunning = false;
    }
}

async function _doCheckAndDeleteExpiredAccounts() {
    const now = Date.now();
    const sekarang = new Date(now);
    const akunData = loadAkun();
    const servers = loadServers();
    let totalDihapus = 0;
    const daftarHapus = [];

    for (const userId of Object.keys(akunData)) {
        if (!Array.isArray(akunData[userId])) continue;

        const toKeep = []; // akun yang TIDAK expired → tetap tersimpan

        for (const akun of akunData[userId]) {
            // Skip: PAYG (ditangani engine sendiri)
            if (akun.payAsYouGo) { toKeep.push(akun); continue; }

            //  Lewati akun yang baru dibuat (< 5 menit) 
            // PENGECUALIAN: akun trial tidak di-skip, langsung cek expiry berdasarkan duration_minutes
            const isTrial = akun.isTrial === true || (akun.duration_minutes && akun.duration_minutes > 0);
            if (!isTrial && akun.createdAt) {
                try {
                    const ageMin = (sekarang - new Date(akun.createdAt)) / 60000;
                    if (ageMin < 5) {
                        console.log(` Akun baru (${ageMin.toFixed(1)} mnt) - skip: ${akun.username || akun.password}`);
                        toKeep.push(akun);
                        continue;
                    }
                } catch(e) {}
            }

            let isExpired = false;

            //  Cek trial: expired = createdAt + duration_minutes 
            if (akun.isTrial === true || (akun.duration_minutes && akun.duration_minutes > 0)) {
                if (akun.createdAt) {
                    try {
                        const expiredAt = new Date(akun.createdAt).getTime() + ((akun.duration_minutes || 60) * 60000);
                        if (now > expiredAt) {
                            isExpired = true;
                            console.log(` [ExpiredChecker] Trial expired: ${akun.username || akun.password}`);
                        }
                    } catch(e) {
                        console.log(` [ExpiredChecker] Error parsing trial: ${e.message}`);
                    }
                }
            }
            //  Cek akun biasa: gunakan expiredTimestamp atau parse string expired 
            else if (akun.expired && akun.expired !== '-' && akun.expired !== 'Pay As You Go') {
                if (akun.expiredTimestamp) {
                    isExpired = now > akun.expiredTimestamp;
                } else {
                    try {
                        const bulanMap = {
                            'jan':0,'feb':1,'mar':2,'apr':3,'mei':4,'may':4,
                            'jun':5,'jul':6,'agu':7,'aug':7,'sep':8,'okt':9,'oct':9,'nov':10,'des':11,'dec':11
                        };
                        const parts = akun.expired.trim().split(/\s+/);
                        if (parts.length >= 3) {
                            const day   = parseInt(parts[0]);
                            const month = bulanMap[parts[1].toLowerCase().slice(0,3)];
                            const year  = parseInt(parts[2]);
                            if (!isNaN(day) && month !== undefined && !isNaN(year)) {
                                const expMs = new Date(year, month, day, 23, 59, 59).getTime() - (7 * 60 * 60 * 1000);
                                akun.expiredTimestamp = expMs;
                                isExpired = now > expMs;
                            }
                        }
                        if (!isExpired && parts.length < 3) {
                            const d = new Date(akun.expired);
                            if (!isNaN(d.getTime())) isExpired = d <= sekarang;
                        }
                    } catch(e) {
                        console.log(` [ExpiredChecker] Error parsing expired: ${e.message} - skip`);
                    }
                }
            }

            if (!isExpired) { toKeep.push(akun); continue; }

            //  Hapus dari server via API 
            // Cari server: prioritas serverId, lalu serverName (case-insensitive), lalu domain
            let server = null;
            if (akun.serverId && servers[akun.serverId]) {
                server = servers[akun.serverId];
            } else if (akun.serverName) {
                server = Object.values(servers).find(s =>
                    s.name === akun.serverName ||
                    (s.name || '').toLowerCase() === (akun.serverName || '').toLowerCase()
                );
            }
            if (!server && akun.domain) {
                server = Object.values(servers).find(s => s.apiUrl && s.apiUrl.includes(akun.domain));
            }

            // Normalisasi serviceType sebelum delete
            akun.serviceType = (akun.serviceType || '').toString().trim().toLowerCase();

            if (server) {
                console.log(` [ExpiredChecker] Hapus via API: "${akun.username}" (${akun.serviceType}) @ ${server.name} | user: ${userId}`);
                try {
                    const res = await deleteAkunFromServer(server, akun);
                    if (res && res.success) {
                        console.log(` [ExpiredChecker] Berhasil hapus dari server: ${akun.username || akun.password}`);
                    } else {
                        console.log(` [ExpiredChecker] API gagal (tetap hapus lokal): ${res?.message || 'unknown'}`);
                    }
                } catch(e) {
                    console.log(` [ExpiredChecker] Error API: ${e.message}`);
                }
            } else {
                console.log(` [ExpiredChecker] Server tidak ditemukan:`);
                console.log(`   serverId="${akun.serverId||'-'}" serverName="${akun.serverName||'-'}" domain="${akun.domain||'-'}"`);
                console.log(`   Server tersedia: [${Object.values(servers).map(s=>`${s.id}:${s.name}`).join(', ')}]`);
            }

            //  BENAR-BENAR hapus dari JSON (tidak push ke toKeep) 
            totalDihapus++;
            if (server && !akun.isTrial) kurangiSlotTerpakai(server);

            daftarHapus.push({
                userId,
                username: akun.username || akun.password || 'Unknown',
                serviceType: (akun.serviceType || '').toUpperCase(),
                serverName: server ? server.name : (akun.serverName || '-'),
                expired: akun.expired || '-',
                isTrial: !!akun.isTrial
            });

            //  Notifikasi ke user Telegram — satu kali saja per akun 
            const notifKey = `${userId}_${akun.username || akun.password}_${akun.expired || akun.createdAt}`;
            const alreadyNotified = _notifSentMap.get(notifKey);
            if (!alreadyNotified) {
                _notifSentMap.set(notifKey, now);
                try {
                    const serverDisplayName = server ? server.name : (akun.serverName || '-');
                    const label = akun.isTrial ? 'TRIAL AKUN BERAKHIR' : 'AKUN VPN EXPIRED & DIHAPUS';
                    const icon  = akun.isTrial ? '' : '';
                    await bot.telegram.sendMessage(
                        parseInt(userId),
                        `${icon} <b>${label}</b>\n\n` +
                        `🔧 <b>Tipe   :</b> ${(akun.serviceType || '').toUpperCase()}\n` +
                        `👤 <b>Akun   :</b> ${akun.username || akun.password || '-'}\n` +
                        `🌐 <b>Server :</b> ${serverDisplayName}\n` +
                        `📅 <b>Expired:</b> ${akun.expired || '-'}\n\n` +
                        `⚠️ Akun Anda telah <b>dihapus otomatis</b> karena sudah melewati masa aktif.\n` +
                        `🔄 Ketik /menu untuk membuat akun baru.`,
                        { parse_mode: 'HTML' }
                    );
                } catch(e) {
                    console.log(`[ExpiredChecker] Gagal kirim notif ke ${userId}: ${e.message}`);
                }
            }

            // Catatan: penghapusan akun (expired) sengaja TIDAK dicatat ke riwayat transaksi.
        }

        // Ganti list akun dengan yang sudah bersih (expired benar-benar dihapus)
        akunData[userId] = toKeep;
    }

    // Hapus userId yang sudah tidak punya akun (opsional, jaga kebersihan JSON)
    for (const uid of Object.keys(akunData)) {
        if (Array.isArray(akunData[uid]) && akunData[uid].length === 0) {
            delete akunData[uid];
        }
    }

    if (totalDihapus > 0) {
        saveAkun(akunData);
        console.log(` [ExpiredChecker] Selesai: ${totalDihapus} akun dihapus dari JSON`);

        // Notifikasi ringkasan ke admin — satu kali per run
        if (ADMIN_IDS && ADMIN_IDS.length > 0) {
            let notifText = ` <b>AUTO DELETE AKUN EXPIRED</b>\n\n Total: ${totalDihapus} akun\n\n<b>Detail:</b>\n`;
            for (let i = 0; i < Math.min(daftarHapus.length, 10); i++) {
                const h = daftarHapus[i];
                const tag = h.isTrial ? ' (Trial)' : '';
                notifText += `\n${i+1}.  <code>${h.username}</code>${tag}\n    ${h.serviceType} |  ${h.serverName}`;
            }
            if (daftarHapus.length > 10) notifText += `\n\n... dan ${daftarHapus.length - 10} akun lainnya`;
            for (const adminId of ADMIN_IDS) {
                try { await notifBot.telegram.sendMessage(adminId, notifText, { parse_mode: 'HTML' }); } catch(e) {}
            }
        }
    } else {
        console.log('[ExpiredChecker] Tidak ada akun expired.');
    }

    return totalDihapus;
}

// Cek setiap 1 menit (bukan 1 jam)
setInterval(async () => {
    try { await checkAndDeleteExpiredAccounts(); } catch(e) { console.error('[ExpiredChecker] Error:', e.message); }
}, 60 * 1000); // 1 menit

// ==================== AUTO MARK LISENSI BOT SELLER EXPIRED ====================
// Tandai status: 'expired' untuk token yang sudah lewat masaAktif di lisensi.json
// (lifetime tidak pernah ditandai expired, token TIDAK dihapus) dan kirim notifikasi
// ke user + admin.
let _botLisensiCheckerRunning = false;
async function checkAndHapusLisensiBotExpired() {
    if (_botLisensiCheckerRunning) return 0;
    _botLisensiCheckerRunning = true;
    try {
        const dihapus = await checkDanHapusLisensiExpired();
        if (!dihapus || dihapus.length === 0) return 0;

        for (const item of dihapus) {
            console.log(`[LisensiBotChecker] Token expired (status diubah): ${item.token} (${item.nama} | ${item.ip})`);
            if (item.userId) {
                try {
                    await bot.telegram.sendMessage(
                        parseInt(item.userId),
                        ` <b>LISENSI BOT SELLER EXPIRED</b>\n\n` +
                        `🤖 <b>Nama:</b> ${item.nama}\n` +
                        `🌐 <b>IP:</b> <code>${item.ip}</code>\n` +
                        `🔑 <b>Token:</b> <code>${item.token}</code>\n` +
                        `📅 <b>Expired:</b> ${item.masaAktif}\n\n` +
                        `⚠️ Token lisensi Anda sudah <b>melewati masa aktif</b> dan statusnya ditandai expired.\n` +
                        `🔁 Ketik /menu lalu pilih Sewa Bot Seller → Perpanjang Lisensi untuk mengaktifkan kembali token ini.`,
                        { parse_mode: 'HTML' }
                    );
                } catch(e) {
                    console.log(`[LisensiBotChecker] Gagal kirim notif ke ${item.userId}: ${e.message}`);
                }
            }
        }

        if (ADMIN_IDS && ADMIN_IDS.length > 0) {
            let notifText = ` <b>LISENSI BOT EXPIRED (STATUS DIUBAH)</b>\n\n Total: ${dihapus.length} token\n\n<b>Detail:</b>\n`;
            for (let i = 0; i < Math.min(dihapus.length, 10); i++) {
                const h = dihapus[i];
                notifText += `\n${i+1}.  <code>${h.token}</code>\n    ${h.nama} | ${h.ip} | exp ${h.masaAktif}`;
            }
            if (dihapus.length > 10) notifText += `\n\n... dan ${dihapus.length - 10} token lainnya`;
            for (const adminId of ADMIN_IDS) {
                try { await notifBot.telegram.sendMessage(adminId, notifText, { parse_mode: 'HTML' }); } catch(e) {}
            }
        }

        return dihapus.length;
    } catch(e) {
        console.error('[LisensiBotChecker] Error:', e.message);
        return 0;
    } finally {
        _botLisensiCheckerRunning = false;
    }
}

// Cek setiap 1 jam
setInterval(async () => {
    try { await checkAndHapusLisensiBotExpired(); } catch(e) { console.error('[LisensiBotChecker] Error:', e.message); }
}, 60 * 60 * 1000); // 1 jam

// Jalankan sekali saat bot start (15 detik delay)
setTimeout(async () => {
    try { await checkAndHapusLisensiBotExpired(); } catch(e) {}
}, 15000);

// ==================== AUTO CLEAN RESELLER (setiap 6 jam) ====================
setInterval(async () => {
    try { await checkAndCleanReseller(bot, ADMIN_IDS); } catch(e) { console.error('[Reseller] Error auto-clean:', e.message); }
}, 6 * 60 * 60 * 1000); // 6 jam

// Jalankan sekali saat bot start (10 detik delay)
setTimeout(async () => {
    try { await checkAndCleanReseller(bot, ADMIN_IDS); } catch(e) {}
}, 10000);

// Jalankan sekali saat bot start (5 detik delay)
setTimeout(async () => {
    try { await checkAndDeleteExpiredAccounts(); } catch(e) {}
}, 5000);

// Fungsi untuk force check expired (bisa dipanggil admin via command)
async function forceCheckExpired(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    await sendTempMessage(ctx, ' Memeriksa dan menghapus akun expired...');
    const jumlah = await checkAndDeleteExpiredAccounts();
    await sendTempMessage(ctx, ` Selesai! ${jumlah} akun expired telah dihapus.`);
}

// Tambahkan command /checkexpired
bot.command('checkexpired', async (ctx) => {
    await forceCheckExpired(ctx);
});

// ==================== START BOT ====================
async function startBot() {
    console.log('');
    console.log(' TELEGRAM VPN BOT STARTING...');
    console.log(` Main Bot Token: ${BOT_TOKEN.substring(0, 10)}...${BOT_TOKEN.substring(BOT_TOKEN.length - 5)}`);
    if (NOTIF_BOT_TOKEN !== BOT_TOKEN) {
        console.log(` Notif Bot Token: ${NOTIF_BOT_TOKEN.substring(0, 10)}...${NOTIF_BOT_TOKEN.substring(NOTIF_BOT_TOKEN.length - 5)} (TERPISAH)`);
    } else {
        console.log(` Notif Bot Token: sama dengan main bot (set NOTIF_BOT_TOKEN di .env untuk memisahkan)`);
    }
    console.log(` Admin IDs: ${ADMIN_IDS.join(', ') || 'None'}`);
    console.log(` Harga: Rp${CONFIG.HARGA_PER_HARI_PER_IP}/hari/IP | Tambahan EDURC/CF: +Rp${CONFIG.HARGA_EDURC_PER_HARI}/hari`);
    console.log(` Max Trial: ${CONFIG.MAX_TRIAL_MENIT} menit`);
    console.log('');
    
    await loadHeaderImage();
    
    SERVERS = loadServers();
    console.log(` Servers loaded: ${Object.keys(SERVERS).length}`);
    
    loadAndRestoreAutoBackup(); // restore auto backup jika sebelumnya aktif (jalan di background, tidak backup instan saat start)
    
    const stats = getUserStats();
    console.log(` Users: ${stats.jumlahUser}`);
    console.log(` Akun: ${stats.totalAkun}`);
    
    try {
        await bot.launch();
        console.log(' Bot siap!');
        console.log(' Buka Telegram dan cari bot Anda');
        console.log(' Kirim /start untuk memulai');
        console.log(` [PAYG] Engine aktif (setiap 1 jam)`);
        
        if (ADMIN_IDS.length > 0) {
            for (const adminId of ADMIN_IDS) {
                try {
                    await notifBot.telegram.sendMessage(adminId, `<b>🚀 Bot VPN Telah Aktif!</b>

${getHeader('𝘽𝙊𝙏 𝙊𝙉𝙇𝙄𝙉𝙀')}
<blockquote>✅ <b>Status:</b> ONLINE
🖥 <b>Server:</b> ${Object.keys(SERVERS).length}
👥 <b>Users:</b> ${stats.jumlahUser}
📦 <b>Akun:</b> ${stats.totalAkun}</blockquote>

🗑 Auto Delete: Hanya menu dan pesan temporary yang terhapus otomatis
🖼 Header Image: Hanya tampil di menu utama
📋 Pesan Hasil (Create/Trial/Renew): <b>TIDAK akan terhapus otomatis</b>

Ketik /menu untuk memulai.`, { parse_mode: 'HTML' });
                } catch(e) {}
            }
        }
    } catch (err) {
        console.error(' Failed to start bot:', err.message);
    }
    
    process.once('SIGINT', () => bot.stop('SIGINT'));
    process.once('SIGTERM', () => bot.stop('SIGTERM'));
}

startBot();