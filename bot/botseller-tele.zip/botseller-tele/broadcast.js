// broadcast.js - Module untuk fitur broadcast
const { Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');

// File data user
const SALDO_FILE = path.join(__dirname, 'saldo.json');
const AKUN_FILE = path.join(__dirname, 'akun.json');
const TRANSAKSI_FILE = path.join(__dirname, 'transaksi.json');
const TRIAL_FILE = path.join(__dirname, 'trial.json');

// Fungsi helper dari bot utama (akan di-pass dari bot.js)
let getHeader, sendMenu, sendTempMessage, sendResultMessage, isAdmin, loadSaldo, loadAkun, loadTransaksi, loadTrialData, formatTimestamp, bot;

// Inisialisasi module
function initBroadcast(helpers) {
    getHeader = helpers.getHeader;
    sendMenu = helpers.sendMenu;
    sendTempMessage = helpers.sendTempMessage;
    sendResultMessage = helpers.sendResultMessage;
    isAdmin = helpers.isAdmin;
    loadSaldo = helpers.loadSaldo;
    loadAkun = helpers.loadAkun;
    loadTransaksi = helpers.loadTransaksi;
    loadTrialData = helpers.loadTrialData;
    formatTimestamp = helpers.formatTimestamp;
    bot = helpers.bot;
}

// Ambil semua user dari multiple sources
function getAllUsers() {
    const usersSet = new Set();
    
    try {
        const saldo = loadSaldo();
        Object.keys(saldo).forEach(uid => usersSet.add(uid));
    } catch(e) {}
    
    try {
        const akun = loadAkun();
        Object.keys(akun).forEach(uid => usersSet.add(uid));
    } catch(e) {}
    
    try {
        const transaksi = loadTransaksi();
        transaksi.forEach(tx => {
            if (tx.userId) usersSet.add(tx.userId.toString());
        });
    } catch(e) {}
    
    try {
        const trial = loadTrialData();
        Object.keys(trial).forEach(uid => usersSet.add(uid));
    } catch(e) {}
    
    return Array.from(usersSet);
}

// Menu utama broadcast
async function showAdminBroadcastMenu(ctx) {
    if (!isAdmin(ctx.from.id)) return;
    
    const menuText = `${getHeader('𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 𝙈𝙀𝙉𝙐')}
<blockquote>📨 <b>— 𝙅𝙀𝙉𝙄𝙎 𝙋𝙀𝙎𝘼𝙉 —</b>
📝 <b>· Broadcast Teks</b>
  Kirim pesan teks ke semua user
🖼 <b>· Broadcast Gambar</b>
  Kirim gambar + caption ke user</blockquote>
<blockquote>⚠️ <b>— PERINGATAN —</b>
· Pesan akan dikirim ke <b>SEMUA USER</b>
· Pastikan pesan sudah benar
· Proses broadcast bisa memakan waktu
· Kirim <code>cancel</code> untuk membatalkan</blockquote>`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '📝 𝘽𝙧𝙤𝙖𝙙𝙘𝙖𝙨𝙩 𝙏𝙚𝙠𝙨', callback_data: 'broadcast_text' }],
        [{ text: '🖼 𝘽𝙧𝙤𝙖𝙙𝙘𝙖𝙨𝙩 𝙂𝙖𝙢𝙗𝙖𝙧', callback_data: 'broadcast_image' }],
        [{ text: '⬅️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, menuText, keyboard);
}

// Proses broadcast teks
async function processBroadcastText(ctx, messageText, userStates) {
    console.log('[BROADCAST] processBroadcastText called');
    
    if (!isAdmin(ctx.from.id)) return;
    
    if (messageText.toLowerCase() === 'cancel') {
        userStates.delete(ctx.from.id.toString());
        await sendMenu(ctx, `${getHeader('𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 𝘿𝙄𝘽𝘼𝙏𝘼𝙇𝙆𝘼𝙉')}
<blockquote>❌ Broadcast telah dibatalkan.</blockquote>`, Markup.inlineKeyboard([
            [{ text: '⬅️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
        ]));
        return;
    }
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    
    if (!state || state.action !== 'broadcast_menu') {
        console.log('[BROADCAST] No valid state');
        return;
    }
    
    // Simpan entities dari pesan asli user (formatting Telegram native)
    const entities = ctx.message.entities || [];
    
    // Lanjut ke konfirmasi
    userStates.set(userId, {
        action: 'broadcast_menu',
        step: 'waiting_confirmation',
        type: 'text',
        content: messageText,
        entities: entities
    });
    
    const confirmText = `${getHeader('𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏')}
<blockquote>📝 <b>· Jenis:</b> Teks</blockquote>
<blockquote>💬 <b>— 𝙄𝙎𝙄 𝙋𝙀𝙎𝘼𝙉 —</b>
${messageText}</blockquote>
<blockquote>⚠️ Pesan akan dikirim ke <b>SEMUA USER</b>!</blockquote>

<b>Lanjutkan broadcast?</b>`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝙆𝙞𝙧𝙞𝙢!', callback_data: 'broadcast_confirm_yes' }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'broadcast_confirm_no', style: 'danger' }]
    ]);
    
    await sendMenu(ctx, confirmText, keyboard);
}

// Proses broadcast gambar
async function processBroadcastImage(ctx, photoFileId, caption, userStates) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    
    if (!state || state.action !== 'broadcast_menu') return;
    
    // Simpan caption_entities dari pesan asli user (formatting Telegram native)
    const captionEntities = ctx.message.caption_entities || [];
    
    userStates.set(userId, {
        action: 'broadcast_menu',
        step: 'waiting_confirmation',
        type: 'image',
        content: {
            photoId: photoFileId,
            caption: caption || '',
            captionEntities: captionEntities
        }
    });
    
    const previewMsg = caption || '(tanpa caption)';
    const confirmText = `${getHeader('𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄 𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏')}
<blockquote>🖼 <b>· Jenis:</b> Gambar</blockquote>
<blockquote>💬 <b>— 𝘾𝘼𝙋𝙏𝙄𝙊𝙉 —</b>
${previewMsg}</blockquote>
<blockquote>⚠️ Gambar + caption akan dikirim ke <b>SEMUA USER</b>!</blockquote>

<b>Lanjutkan broadcast?</b>`;
    
    const keyboard = Markup.inlineKeyboard([
        [{ text: '✅ 𝙔𝙖, 𝙆𝙞𝙧𝙞𝙢!', callback_data: 'broadcast_confirm_yes' }],
        [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'broadcast_confirm_no', style: 'danger' }]
    ]);
    
    // Kirim preview gambar dengan formatting native Telegram
    await ctx.replyWithPhoto(photoFileId, {
        caption: '📷 Preview Gambar:\n' + (caption || '(tanpa caption)'),
        parse_mode: 'HTML'
    });
    
    await sendMenu(ctx, confirmText, keyboard);
}

// Eksekusi broadcast
async function executeBroadcast(ctx, userStates) {
    if (!isAdmin(ctx.from.id)) return;
    
    const userId = ctx.from.id.toString();
    const state = userStates.get(userId);
    
    if (!state || state.action !== 'broadcast_menu' || state.step !== 'waiting_confirmation') {
        return;
    }
    
    const loadingMsg = await sendTempMessage(ctx, `⏳ <b>Memproses broadcast...</b>\n<blockquote>📊 Mengambil daftar user...</blockquote>`);
    
    // Gunakan fungsi getAllUsersFromBot()
    const allUsers = getAllUsers();
    
    if (allUsers.length === 0) {
        await sendTempMessage(ctx, '❌ <b>Tidak ada user yang terdaftar!</b>');
        userStates.delete(userId);
        await showAdminDashboard(ctx);
        return;
    }
    
    await ctx.telegram.editMessageText(
        ctx.chat.id,
        loadingMsg.message_id,
        undefined,
        `⏳ <b>Memproses broadcast...</b>\n<blockquote>📊 <b>· Total user:</b> ${allUsers.length}\n📨 <b>· Status:</b> Mengirim pesan...\n✅ <b>· Berhasil:</b> 0\n❌ <b>· Gagal:</b> 0</blockquote>`,
        { parse_mode: 'HTML' }
    );
    
    let success = 0;
    let failed = 0;
    const failedUsers = [];
    
    for (let i = 0; i < allUsers.length; i++) {
        const targetUserId = allUsers[i];
        
        try {
            if (state.type === 'text') {
                const sendOpts = {};
                if (state.entities && state.entities.length > 0) {
                    sendOpts.entities = state.entities;
                }
                await bot.telegram.sendMessage(targetUserId, state.content, sendOpts);
            } else if (state.type === 'image') {
                const sendOpts = {};
                if (state.content.captionEntities && state.content.captionEntities.length > 0) {
                    sendOpts.caption_entities = state.content.captionEntities;
                }
                await bot.telegram.sendPhoto(targetUserId, state.content.photoId, {
                    caption: state.content.caption,
                    ...sendOpts
                });
            }
            success++;
        } catch (err) {
            failed++;
            failedUsers.push(targetUserId);
            console.log(`[BROADCAST] Gagal kirim ke ${targetUserId}: ${err.message}`);
        }
        
        // Update progress setiap 10 user
        if ((i + 1) % 10 === 0 || i === allUsers.length - 1) {
            try {
                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    loadingMsg.message_id,
                    undefined,
                    `⏳ <b>Memproses broadcast...</b>\n<blockquote>📊 <b>· Total user:</b> ${allUsers.length}\n📨 <b>· Status:</b> Mengirim pesan...\n✅ <b>· Berhasil:</b> ${success}\n❌ <b>· Gagal:</b> ${failed}\n📈 <b>· Progress:</b> ${Math.round(((i + 1) / allUsers.length) * 100)}%</blockquote>`,
                    { parse_mode: 'HTML' }
                );
            } catch (e) {}
        }
        
        // Delay agar tidak kena rate limit
        await new Promise(resolve => setTimeout(resolve, 50));
    }
    
    // Hapus pesan loading
    try {
        await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id);
    } catch (e) {}
    
    // Kirim laporan
    let reportMsg = `${getHeader('𝙇𝘼𝙋𝙊𝙍𝘼𝙉 𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏')}
<blockquote>📊 <b>— 𝙎𝙏𝘼𝙏𝙄𝙎𝙏𝙄𝙆 —</b>
📨 <b>· Total User:</b> ${allUsers.length}
✅ <b>· Berhasil:</b> ${success}
❌ <b>· Gagal:</b> ${failed}</blockquote>`;
    
    if (failedUsers.length > 0 && failedUsers.length <= 20) {
        reportMsg += `\n<blockquote>❌ <b>— 𝙂𝘼𝙂𝘼𝙇 𝘿𝙄𝙆𝙄𝙍𝙄𝙈 𝙆𝙀 —</b>\n` + failedUsers.map(id => `<code>${id}</code>`).join('\n') + '</blockquote>';
    } else if (failedUsers.length > 20) {
        reportMsg += `\n<blockquote>❌ <b>Gagal dikirim ke ${failedUsers.length} user</b> (tidak ditampilkan)</blockquote>`;
    }
    
    await sendResultMessage(ctx, reportMsg);
    
    // Hapus state user
    userStates.delete(userId);
    await showAdminBroadcastMenu(ctx);
}

// Handler callback untuk broadcast
function getBroadcastCallbacks(userStates) {
    return {
        'admin_broadcast': async (ctx) => {
            await showAdminBroadcastMenu(ctx);
            return true;
        },
        'broadcast_text': async (ctx) => {
            const userId = ctx.from.id.toString();
            userStates.set(userId, {
                action: 'broadcast_menu',
                step: 'waiting_text'
            });
            
            const text = `${getHeader('𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 𝙏𝙀𝙆𝙎')}
<blockquote>📝 Kirimkan pesan teks yang akan
dikirim ke <b>SEMUA USER</b></blockquote>
<blockquote>💡 <b>— 𝙏𝙄𝙋𝙎 —</b>
· Tekan teks untuk ganti gaya font
· Kirim <code>cancel</code> untuk batal</blockquote>

<b>Kirim pesan teks:</b>`;
            
            const keyboard = Markup.inlineKeyboard([
                [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_broadcast', style: 'danger' }]
            ]);
            
            await sendMenu(ctx, text, keyboard);
            return true;
        },
        'broadcast_image': async (ctx) => {
            const userId = ctx.from.id.toString();
            userStates.set(userId, {
                action: 'broadcast_menu',
                step: 'waiting_image'
            });
            
            const text = `${getHeader('𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 𝙂𝘼𝙈𝘽𝘼𝙍')}
<blockquote>🖼 Kirimkan <b>GAMBAR</b> yang akan
dikirim ke <b>SEMUA USER</b></blockquote>
<blockquote>💡 <b>— 𝙏𝙄𝙋𝙎 —</b>
· Kirim gambar dengan caption (opsional)
· Tekan teks caption untuk ganti gaya font
· Kirim <code>cancel</code> untuk batal</blockquote>

<b>Kirim gambar + caption (opsional):</b>`;
            
            const keyboard = Markup.inlineKeyboard([
                [{ text: '❌ 𝘽𝙖𝙩𝙖𝙡', callback_data: 'admin_broadcast', style: 'danger' }]
            ]);
            
            await sendMenu(ctx, text, keyboard);
            return true;
        },
        'broadcast_confirm_yes': async (ctx) => {
            await executeBroadcast(ctx, userStates);
            return true;
        },
        'broadcast_confirm_no': async (ctx) => {
            userStates.delete(ctx.from.id.toString());
            await sendMenu(ctx, `${getHeader('𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 𝘿𝙄𝘽𝘼𝙏𝘼𝙇𝙆𝘼𝙉')}
<blockquote>❌ Broadcast telah dibatalkan.</blockquote>`, Markup.inlineKeyboard([
                [{ text: '⬅️ 𝙆𝙚𝙢𝙗𝙖𝙡𝙞 𝙠𝙚 𝘿𝙖𝙨𝙝𝙗𝙤𝙖𝙧𝙙', callback_data: 'admin_dashboard', style: 'danger' }]
            ]));
            return true;
        }
    };
}

// Handler untuk text message (broadcast)
async function handleBroadcastTextMessage(ctx, message, userStates) {
    const userState = userStates.get(ctx.from.id.toString());
    if (userState && userState.action === 'broadcast_menu' && userState.step === 'waiting_text') {
        await processBroadcastText(ctx, message, userStates);
        return true;
    }
    return false;
}

// Handler untuk photo message (broadcast)
async function handleBroadcastPhotoMessage(ctx, userStates) {
    const userId = ctx.from.id.toString();
    const userState = userStates.get(userId);
    if (userState && userState.action === 'broadcast_menu' && userState.step === 'waiting_image') {
        const largestPhoto = ctx.message.photo[ctx.message.photo.length - 1];
        const photoId = largestPhoto.file_id;
        const caption = ctx.message.caption || '';
        await processBroadcastImage(ctx, photoId, caption, userStates);
        return true;
    }
    return false;
}

module.exports = {
    initBroadcast,
    getBroadcastCallbacks,
    handleBroadcastTextMessage,
    handleBroadcastPhotoMessage,
    showAdminBroadcastMenu
};
