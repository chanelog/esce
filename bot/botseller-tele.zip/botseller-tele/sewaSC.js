// sewaSC.js - Modul Sewa SC Tunneling (git clone + push)
'use strict';

const fs   = require('fs');
const path = require('path');
const { exec } = require('child_process');

// ==================== CONFIG ====================
let SC_GITHUB_TOKEN  = process.env.SC_GITHUB_TOKEN  || process.env.GITHUB_TOKEN || '';
let SC_GITHUB_OWNER  = process.env.SC_GITHUB_OWNER  || process.env.GITHUB_OWNER || 'peyxdev';
let SC_GITHUB_REPO   = process.env.SC_GITHUB_REPO   || 'esce';
let SC_GITHUB_BRANCH = process.env.SC_GITHUB_BRANCH || 'main';

function getScGithubToken()       { return SC_GITHUB_TOKEN; }
function setScGithubToken(nilai)  { SC_GITHUB_TOKEN = nilai; process.env.SC_GITHUB_TOKEN = nilai; }
function getScGithubOwner()       { return SC_GITHUB_OWNER; }
function setScGithubOwner(nilai)  { SC_GITHUB_OWNER = nilai; process.env.SC_GITHUB_OWNER = nilai; }
function getScGithubRepo()        { return SC_GITHUB_REPO; }
function setScGithubRepo(nilai)   { SC_GITHUB_REPO = nilai; process.env.SC_GITHUB_REPO = nilai; }
function getScGithubBranch()      { return SC_GITHUB_BRANCH; }
function setScGithubBranch(nilai) { SC_GITHUB_BRANCH = nilai; process.env.SC_GITHUB_BRANCH = nilai; }

const SC_GIT_DIR  = path.join(__dirname, 'data_sc', 'repo');
const SC_DATA_DIR = path.join(__dirname, 'data_sc');
const SC_IPX_FILE = path.join(SC_DATA_DIR, 'ipx');
const SC_IP_FILE  = path.join(SC_DATA_DIR, 'ip');

const SEWA_SC_FILE   = path.join(__dirname, 'sewa_sc.json');
const SC_PAKET_FILE  = path.join(__dirname, 'sewa_sc_paket.json');

// Harga
let HARGA_SC_PER_IP_30HARI = parseInt(process.env.HARGA_SC_PER_IP_30HARI) || 15000;
let HARGA_SC_LIFETIME      = parseInt(process.env.HARGA_SC_LIFETIME)      || 150000;
// Harga IP tambahan (IP ke-2, ke-3, dst dalam 1x transaksi) — flat, tidak dikali jumlah hari
let HARGA_SC_EXTRA_IP      = parseInt(process.env.HARGA_SC_EXTRA_IP)      || 25000;

function setHargaSC30Hari(nilai)      { HARGA_SC_PER_IP_30HARI = nilai; }
function getHargaSC30Hari()           { return HARGA_SC_PER_IP_30HARI; }
function getHargaSCLifetime()         { return HARGA_SC_LIFETIME; }
function _setHargaSCLifetime(nilai)   { HARGA_SC_LIFETIME = nilai; }
function setHargaSCExtraIp(nilai)     { HARGA_SC_EXTRA_IP = nilai; }
function getHargaSCExtraIp()          { return HARGA_SC_EXTRA_IP; }

// Toggle tampil/sembunyi button "SEWA SC" di main menu user (diatur dari dashboard admin)
let SEWA_SC_AKTIF = process.env.SEWA_SC_AKTIF !== 'false'; // true by default

function isSewaScAktif()              { return SEWA_SC_AKTIF; }
function setSewaScAktif(nilai)        { SEWA_SC_AKTIF = !!nilai; }

// ==================== SETUP DIR ====================
if (!fs.existsSync(SC_DATA_DIR)) fs.mkdirSync(SC_DATA_DIR, { recursive: true });

// ==================== IN-MEMORY CACHE (JSON: paket & sewa) ====================
// Sama seperti bot.js: baca selalu dari memory (pasti terbaru), tulis ke disk async
// di background supaya tidak nge-block event loop / bikin user lain lag pas ada transaksi.
const _cache = {
    paket: { data: null },
    sewa:  { data: null },
};
function _cacheGet(key, file, defaultVal) {
    if (_cache[key].data !== null) return _cache[key].data;
    try {
        if (fs.existsSync(file)) {
            _cache[key].data = JSON.parse(fs.readFileSync(file, 'utf8'));
        } else {
            _cache[key].data = defaultVal;
        }
    } catch(e) {
        _cache[key].data = defaultVal;
    }
    return _cache[key].data;
}
function _cacheSet(key, file, data) {
    _cache[key].data = data;
    fs.writeFile(file, JSON.stringify(data, null, 2), 'utf8', (err) => {
        if (err) console.error(`[sewaSC] Gagal menyimpan ${key}:`, err.message);
    });
}

// ==================== CACHE UNTUK FILE TEKS ipx/ip ====================
// Beda dari JSON di atas: file ini dipakai bareng-bareng dengan proses git
// (loadFromRepo menimpa file ini dari repo, saveToRepo membaca file ini buat di-push).
// Makanya tulisannya pakai fs.promises.writeFile yang DI-AWAIT (bukan fire-and-forget) —
// tetap tidak nge-block event loop (I/O-nya lepas ke thread pool), tapi memastikan
// urutan baca-tulis tetap benar sebelum lanjut ke proses git push.
const fsp = fs.promises;
const _textCache = { ipx: { data: null }, ip: { data: null } };
function _textCacheGet(key, file, defaultVal) {
    if (_textCache[key].data !== null) return _textCache[key].data;
    try {
        if (fs.existsSync(file)) {
            _textCache[key].data = fs.readFileSync(file, 'utf8');
        } else {
            _textCache[key].data = defaultVal;
        }
    } catch(e) {
        _textCache[key].data = defaultVal;
    }
    return _textCache[key].data;
}
async function _textCacheSet(key, file, content) {
    _textCache[key].data = content;
    await fsp.writeFile(file, content, 'utf8');
}
function _textCacheInvalidate(key) {
    _textCache[key].data = null;
}

// ==================== GIT HELPERS ====================

function runCommand(cmd) {
    return new Promise((resolve, reject) => {
        exec(cmd, { timeout: 60000 }, (error, stdout, stderr) => {
            if (error) {
                // Saat exec di-kill karena timeout, stderr biasanya cuma berisi
                // progres git yang sempat tertulis (mis. "Cloning into '...'...")
                // bukan pesan error sebenarnya — jadi kita beri info eksplisit.
                if (error.killed || error.signal) {
                    reject(new Error(
                        `Proses git timeout/terhenti (signal: ${error.signal || 'unknown'}). ` +
                        `Output terakhir: ${(stderr || stdout || '-').trim()}`
                    ));
                    return;
                }
                reject(new Error(stderr || error.message));
                return;
            }
            resolve(stdout || stderr);
        });
    });
}

// ==================== MUTEX UNTUK OPERASI GIT ====================
// SC_GIT_DIR adalah folder yang dipakai BERSAMA oleh semua proses
// (daftar baru, perpanjang, ganti IP, dsb). Tanpa antrian, dua proses yang
// jalan bersamaan bisa saling tabrakan: proses A masih clone/pull ke
// SC_GIT_DIR, lalu proses B mendeteksi pull gagal (karena folder sedang
// ditulis A) dan menghapus folder itu (fs.rmSync) saat A masih memakainya.
// Akibatnya proses A gagal dengan pesan tidak jelas seperti
// "Cloning into '...'..." tanpa keterangan error lanjutan.
// Solusi: jalankan semua operasi git secara berurutan (serial) lewat queue.
let gitQueue = Promise.resolve();
function withGitLock(fn) {
    const run = gitQueue.then(fn, fn); // tetap lanjut walau task sebelumnya reject
    // pastikan queue berikutnya nunggu task ini selesai (sukses atau gagal), tanpa propagate reject ke queue
    gitQueue = run.catch(() => {});
    return run;
}

async function setupGit() {
    const user  = SC_GITHUB_OWNER;
    const email = process.env.GITHUB_EMAIL || `${user}@users.noreply.github.com`;
    try {
        await runCommand(`git config --global user.email "${email}"`);
        await runCommand(`git config --global user.name "${user}"`);
    } catch(e) {}
}

async function cloneOrPullRepo() {
    const token = SC_GITHUB_TOKEN;
    const owner = SC_GITHUB_OWNER;
    const repoUrl = `https://${owner}:${token}@github.com/${owner}/${SC_GITHUB_REPO}.git`;

    if (fs.existsSync(SC_GIT_DIR)) {
        try {
            await runCommand(`cd "${SC_GIT_DIR}" && git pull origin ${SC_GITHUB_BRANCH}`);
            return true;
        } catch(e) {
            // fresh clone
            fs.rmSync(SC_GIT_DIR, { recursive: true, force: true });
        }
    }
    await runCommand(`git clone --depth 1 -b ${SC_GITHUB_BRANCH} "${repoUrl}" "${SC_GIT_DIR}"`);
    return true;
}

async function pushToGitHub(message) {
    await runCommand(`cd "${SC_GIT_DIR}" && git add .`);
    try {
        await runCommand(`cd "${SC_GIT_DIR}" && git commit -m "${message}"`);
    } catch(e) {
        // nothing to commit — ok
        if (!e.message.includes('nothing to commit')) throw e;
        return true;
    }
    await runCommand(`cd "${SC_GIT_DIR}" && git push origin ${SC_GITHUB_BRANCH}`);
    return true;
}

// Sync repo → local files
async function loadFromRepo() {
    await setupGit();
    await cloneOrPullRepo();

    const repoIpx = path.join(SC_GIT_DIR, 'ipx');
    const repoIp  = path.join(SC_GIT_DIR, 'ip');

    if (fs.existsSync(repoIpx)) fs.copyFileSync(repoIpx, SC_IPX_FILE);
    if (fs.existsSync(repoIp))  fs.copyFileSync(repoIp,  SC_IP_FILE);
    // File lokal baru saja ditimpa dari repo (di luar jalur _textCacheSet),
    // jadi cache in-memory yang lama sudah tidak valid — paksa baca ulang dari disk.
    _textCacheInvalidate('ipx');
    _textCacheInvalidate('ip');
}

// local files → commit → push
async function saveToRepo(commitMessage) {
    await cloneOrPullRepo();

    if (fs.existsSync(SC_IPX_FILE)) fs.copyFileSync(SC_IPX_FILE, path.join(SC_GIT_DIR, 'ipx'));
    if (fs.existsSync(SC_IP_FILE))  fs.copyFileSync(SC_IP_FILE,  path.join(SC_GIT_DIR, 'ip'));

    await pushToGitHub(commitMessage);
}

// ==================== FORMAT BARIS (sesuai bot2) ====================
// ipx : ### nama expiredDate IP @VIP
// ip  : ### nama expiredDate IP ON SSHWS @VIP

function makeIpxLine(nama, expiredDate, ip) {
    return `### ${nama} ${expiredDate} ${ip} @VIP`;
}

function makeIpLine(nama, expiredDate, ip) {
    return `### ${nama} ${expiredDate} ${ip} ON SSHWS @VIP`;
}

// ==================== CRUD IP FILE LOKAL ====================

async function ensureFiles() {
    if (!fs.existsSync(SC_IPX_FILE)) await _textCacheSet('ipx', SC_IPX_FILE, '# ADMIN\n');
    if (!fs.existsSync(SC_IP_FILE))  await _textCacheSet('ip',  SC_IP_FILE,  '# SSHWS\n');
}

async function appendIpLocal(nama, expiredDate, ip) {
    await ensureFiles();
    let ipxContent = _textCacheGet('ipx', SC_IPX_FILE, '# ADMIN\n');
    ipxContent += makeIpxLine(nama, expiredDate, ip) + '\n';
    await _textCacheSet('ipx', SC_IPX_FILE, ipxContent);

    let ipContent = _textCacheGet('ip', SC_IP_FILE, '# SSHWS\n');
    ipContent += makeIpLine(nama, expiredDate, ip) + '\n';
    await _textCacheSet('ip', SC_IP_FILE, ipContent);
}

async function deleteIpLocal(ip) {
    let deleted = false;

    if (fs.existsSync(SC_IPX_FILE)) {
        const lines    = _textCacheGet('ipx', SC_IPX_FILE, '').split('\n');
        const newLines = lines.filter(l => !l.includes(ip));
        if (newLines.length !== lines.length) {
            await _textCacheSet('ipx', SC_IPX_FILE, newLines.join('\n'));
            deleted = true;
        }
    }

    if (fs.existsSync(SC_IP_FILE)) {
        const lines    = _textCacheGet('ip', SC_IP_FILE, '').split('\n');
        const newLines = lines.filter(l => !l.includes(ip));
        if (newLines.length !== lines.length) {
            await _textCacheSet('ip', SC_IP_FILE, newLines.join('\n'));
            deleted = true;
        }
    }

    return deleted;
}

// Baris header file (contoh: "# ADMIN", "# SSHWS") diawali "#" tunggal, BUKAN "###" (prefix baris data).
// Sebelumnya `startsWith('#')` juga ikut menskip baris data karena "###" juga diawali "#" — diperbaiki di sini.
function isHeaderLine(trimmedLine) {
    return trimmedLine.startsWith('#') && !trimmedLine.startsWith('###');
}

function readIpLocal() {
    const result = [];
    if (!fs.existsSync(SC_IPX_FILE)) return result;
    const content = _textCacheGet('ipx', SC_IPX_FILE, '');
    for (const line of content.split('\n')) {
        const trimmed = line.trim();
        if (!trimmed || isHeaderLine(trimmed)) continue;
        const parts = trimmed.split(/\s+/);
        // format: ### nama expiredDate IP @VIP  (index 0=###, 1=nama, 2=exp, 3=ip, 4=@VIP)
        if (parts.length >= 4) {
            result.push({
                nama:       parts[1] || '',
                masaAktif:  parts[2] || '',
                ip:         parts[3] || '',
            });
        }
    }
    return result;
}

// Update tanggal expired untuk baris yang IP-nya cocok (nama tetap dipakai dari record lama).
// Return true jika ada baris yang berhasil diperbarui.
async function updateExpiryLocal(ip, nama, masaAktifBaru) {
    let updated = false;

    if (fs.existsSync(SC_IPX_FILE)) {
        const lines = _textCacheGet('ipx', SC_IPX_FILE, '').split('\n');
        const newLines = lines.map(l => {
            const trimmed = l.trim();
            if (!trimmed || isHeaderLine(trimmed)) return l;
            const parts = trimmed.split(/\s+/);
            if (parts.length >= 4 && parts[3] === ip) {
                updated = true;
                return makeIpxLine(nama, masaAktifBaru, ip);
            }
            return l;
        });
        if (updated) await _textCacheSet('ipx', SC_IPX_FILE, newLines.join('\n'));
    }

    if (fs.existsSync(SC_IP_FILE)) {
        const lines = _textCacheGet('ip', SC_IP_FILE, '').split('\n');
        const newLines = lines.map(l => {
            const trimmed = l.trim();
            if (!trimmed || isHeaderLine(trimmed)) return l;
            const parts = trimmed.split(/\s+/);
            if (parts.length >= 4 && parts[3] === ip) {
                return makeIpLine(nama, masaAktifBaru, ip);
            }
            return l;
        });
        await _textCacheSet('ip', SC_IP_FILE, newLines.join('\n'));
    }

    return updated;
}

// ==================== PUBLIC API ====================

async function addIpToRepo(nama, masaAktif, ip) {
    return withGitLock(async () => {
        await loadFromRepo();
        await appendIpLocal(nama, masaAktif, ip);
        await saveToRepo(`sewa-sc: add IP ${ip} (${nama}) exp ${masaAktif}`);
    });
}

async function removeIpFromRepo(ip) {
    return withGitLock(async () => {
        await loadFromRepo();
        const deleted = await deleteIpLocal(ip);
        if (deleted) await saveToRepo(`sewa-sc: remove IP ${ip}`);
        return deleted;
    });
}

// Perpanjang: update tanggal expired untuk IP yang sudah ada di repo (nama & IP tetap sama).
// Jika IP belum ada di repo (mis. push pendaftaran sebelumnya gagal/belum tersinkron),
// fallback: daftarkan sebagai entry baru dengan tanggal baru — supaya data tidak hilang
// dan repo tetap konsisten dengan apa yang sudah dibayar user.
async function updateIpExpiryInRepo(ip, nama, masaAktifBaru) {
    return withGitLock(async () => {
        await loadFromRepo();
        let updated = await updateExpiryLocal(ip, nama, masaAktifBaru);
        let fallback = false;
        if (!updated) {
            await appendIpLocal(nama, masaAktifBaru, ip);
            updated = true;
            fallback = true;
        }
        await saveToRepo(`sewa-sc: perpanjang IP ${ip} (${nama}) exp baru ${masaAktifBaru}${fallback ? ' [fallback: entry baru]' : ''}`);
        return { updated, fallback };
    });
}

async function listIpFromRepo() {
    return withGitLock(async () => {
        await loadFromRepo();
        return readIpLocal();
    });
}

// ==================== HARGA ====================

// Harga 1 IP saja (IP pertama) sesuai paket — dipakai sebagai basis sebelum ditambah IP extra
function hitungHargaSatuIp(jumlahHari) {
    if (jumlahHari === null) return HARGA_SC_LIFETIME;
    const perIpPerHari = HARGA_SC_PER_IP_30HARI / 30;
    return Math.ceil(perIpPerHari * jumlahHari);
}

// jumlahHari === null → lifetime
// IP ke-1 dihitung penuh sesuai harga paket (per hari / lifetime).
// IP ke-2, ke-3, dst (extra) dikenakan harga FLAT HARGA_SC_EXTRA_IP per IP — tidak dikali jumlah hari/lifetime,
// supaya tidak "2x lipat" saat user nambah IP.
function hitungHargaSC(jumlahIp, jumlahHari) {
    if (jumlahIp < 1) return 0;
    const hargaIpPertama = hitungHargaSatuIp(jumlahHari);
    const jumlahExtra     = jumlahIp - 1;
    return hargaIpPertama + (jumlahExtra * HARGA_SC_EXTRA_IP);
}

// Breakdown harga untuk ditampilkan ke user: { hargaIpPertama, jumlahExtra, hargaExtraPerIp, totalExtra, total }
function breakdownHargaSC(jumlahIp, jumlahHari) {
    const hargaIpPertama = hitungHargaSatuIp(jumlahHari);
    const jumlahExtra    = Math.max(0, jumlahIp - 1);
    const totalExtra     = jumlahExtra * HARGA_SC_EXTRA_IP;
    return {
        hargaIpPertama,
        jumlahExtra,
        hargaExtraPerIp: HARGA_SC_EXTRA_IP,
        totalExtra,
        total: hargaIpPertama + totalExtra,
    };
}

// jumlahHari === null → tanggal 2099-12-31 (lifetime)
function formatTanggalExpiry(jumlahHari) {
    if (jumlahHari === null) return '2099-12-31';
    const d = new Date();
    d.setDate(d.getDate() + jumlahHari);
    return d.toISOString().split('T')[0]; // YYYY-MM-DD
}

// Hitung tanggal expired baru untuk PERPANJANG.
// Basis perhitungan: tanggal expired LAMA jika masih aktif (belum lewat), atau hari ini jika sudah expired.
// jumlahHari === null → lifetime (2099-12-31)
function hitungTanggalPerpanjangan(masaAktifLama, jumlahHari) {
    if (jumlahHari === null) return '2099-12-31';
    const now = new Date();
    let basis = new Date(masaAktifLama);
    if (isNaN(basis.getTime()) || basis < now) basis = now; // sudah expired / invalid → mulai dari sekarang
    basis.setDate(basis.getDate() + jumlahHari);
    return basis.toISOString().split('T')[0];
}

// ==================== PAKET SEWA (DINAMIS) ====================
// Paket default — dipakai hanya jika file paket belum ada (first run)
const DEFAULT_PAKET = [
    { id: 'sc_30',       label: '30 Hari',  jumlahHari: 30,  icon: '🛒' },
    { id: 'sc_60',       label: '60 Hari',  jumlahHari: 60,  icon: '📦' },
    { id: 'sc_90',       label: '90 Hari',  jumlahHari: 90,  icon: '📦' },
    { id: 'sc_lifetime', label: 'Lifetime', jumlahHari: null, icon: '♾️' },
];

function loadPaketData() {
    const cached = _cacheGet('paket', SC_PAKET_FILE, null);
    if (cached !== null) return cached;
    // belum ada file → seed dengan default lalu simpan
    savePaketData(DEFAULT_PAKET);
    return DEFAULT_PAKET;
}

function savePaketData(list) {
    _cacheSet('paket', SC_PAKET_FILE, list);
}

function getPaketList() {
    return loadPaketData();
}

function getPaketById(id) {
    return getPaketList().find(p => p.id === id) || null;
}

function slugifyPaketId(label) {
    return 'sc_' + label.toLowerCase().trim().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
}

// jumlahHari: number untuk paket harian, null untuk lifetime
function addPaket(label, jumlahHari, icon) {
    const list = getPaketList();
    let id = slugifyPaketId(label);
    // pastikan id unik
    let suffix = 1;
    const baseId = id;
    while (list.some(p => p.id === id)) {
        id = `${baseId}_${suffix++}`;
    }
    const paket = { id, label, jumlahHari, icon: icon || (jumlahHari === null ? '♾️' : '📦') };
    list.push(paket);
    savePaketData(list);
    return paket;
}

// Hapus paket by id. Return true jika berhasil dihapus.
function removePaket(id) {
    const list = getPaketList();
    const newList = list.filter(p => p.id !== id);
    if (newList.length === list.length) return false;
    savePaketData(newList);
    return true;
}



function loadSewaData() {
    return _cacheGet('sewa', SEWA_SC_FILE, {});
}

function saveSewaData(data) {
    _cacheSet('sewa', SEWA_SC_FILE, data);
}

function tambahSewaRecord(userId, nama, ip, masaAktif, jumlahHari, harga, txId) {
    const data = loadSewaData();
    if (!data[userId]) data[userId] = [];
    data[userId].push({ txId, nama, ip, masaAktif, jumlahHari, harga, createdAt: new Date().toISOString() });
    saveSewaData(data);
}

function getSewaByUser(userId) {
    return loadSewaData()[userId] || [];
}

function getAllSewa() {
    const data = loadSewaData();
    const result = [];
    for (const [userId, list] of Object.entries(data)) {
        list.forEach(s => result.push({ ...s, userId }));
    }
    return result;
}

function hapusSewaRecord(userId, txId) {
    const data = loadSewaData();
    if (!data[userId]) return;
    data[userId] = data[userId].filter(s => s.txId !== txId);
    saveSewaData(data);
}

// Perpanjang: update masaAktif record sewa milik user (by txId), simpan histori perpanjangan.
function perpanjangSewaRecord(userId, txId, masaAktifBaru, hargaPerpanjangan, jumlahHariPerpanjangan) {
    const data = loadSewaData();
    if (!data[userId]) return false;
    const rec = data[userId].find(s => s.txId === txId);
    if (!rec) return false;

    if (!Array.isArray(rec.riwayatPerpanjangan)) rec.riwayatPerpanjangan = [];
    rec.riwayatPerpanjangan.push({
        masaAktifSebelum: rec.masaAktif,
        masaAktifSesudah: masaAktifBaru,
        jumlahHari: jumlahHariPerpanjangan,
        harga: hargaPerpanjangan,
        waktu: new Date().toISOString(),
    });
    rec.masaAktif = masaAktifBaru;
    saveSewaData(data);
    return true;
}

// Update nama dan/atau IP pada record sewa by txId (untuk lifetime ganti IP bebas)
// Kembalikan record lama sebelum diubah (untuk keperluan hapus IP lama di repo)
function updateSewaIpNama(userId, txId, namaBaru, ipBaru) {
    const data = loadSewaData();
    if (!data[userId]) return null;
    const rec = data[userId].find(s => s.txId === txId);
    if (!rec) return null;
    const rekamLama = { nama: rec.nama, ip: rec.ip };
    if (namaBaru) rec.nama = namaBaru;
    if (ipBaru)   rec.ip  = ipBaru;
    if (!Array.isArray(rec.riwayatGanti)) rec.riwayatGanti = [];
    rec.riwayatGanti.push({
        namaSebelum: rekamLama.nama,
        ipSebelum:   rekamLama.ip,
        namaSesudah: rec.nama,
        ipSesudah:   rec.ip,
        waktu: new Date().toISOString(),
    });
    saveSewaData(data);
    return rekamLama;
}

// ==================== EXPORT ====================

module.exports = {
    get HARGA_SC_PER_IP_30HARI() { return HARGA_SC_PER_IP_30HARI; },
    get HARGA_SC_LIFETIME()      { return HARGA_SC_LIFETIME; },
    get HARGA_SC_EXTRA_IP()      { return HARGA_SC_EXTRA_IP; },
    getScGithubToken,
    setScGithubToken,
    getScGithubOwner,
    setScGithubOwner,
    getScGithubRepo,
    setScGithubRepo,
    getScGithubBranch,
    setScGithubBranch,
    setHargaSC30Hari,
    getHargaSC30Hari,
    getHargaSCLifetime,
    _setHargaSCLifetime,
    setHargaSCExtraIp,
    getHargaSCExtraIp,
    isSewaScAktif,
    setSewaScAktif,
    hitungHargaSC,
    hitungHargaSatuIp,
    breakdownHargaSC,
    formatTanggalExpiry,
    hitungTanggalPerpanjangan,
    addIpToRepo,
    removeIpFromRepo,
    updateIpExpiryInRepo,
    listIpFromRepo,
    tambahSewaRecord,
    getSewaByUser,
    getAllSewa,
    hapusSewaRecord,
    perpanjangSewaRecord,
    updateSewaIpNama,
    // paket dinamis
    getPaketList,
    getPaketById,
    addPaket,
    removePaket,
};
