// reseller.js - Modul Fitur Reseller untuk Telegram VPN Bot
// Fitur:
//   - Daftar reseller: Rp 30.000 (sekali bayar)
//   - Status reseller AKTIF selama ada transaksi
//   - Auto hapus status reseller jika tidak ada transaksi 30 hari
//   - Diskon 50% untuk semua harga (create & renew)
//   - Ditampilkan di menu utama (status Member / Reseller)
//   - Tombol "Join Reseller" di main menu

const fs = require('fs');
const path = require('path');

// ==================== FILE STORAGE ====================
const RESELLER_FILE = path.join(__dirname, 'reseller.json');
const RESELLER_CONFIG_FILE = path.join(__dirname, 'reseller_config.json');
const BIAYA_DAFTAR_RESELLER = 30000;
const DEFAULT_DISKON_RESELLER = 0.5; // 50% (dipakai jika reseller_config.json belum ada)
const RESELLER_EXPIRE_HARI = 30; // panjang 1 periode evaluasi (hari)
const MIN_TRANSAKSI_PER_PERIODE = 4; // minimal 4 akun (create/renew) per periode 30 hari agar tetap aktif

// ==================== LOAD / SAVE CONFIG (DISKON RESELLER) ====================
// Diskon disimpan terpisah dari data reseller.json supaya bisa diubah admin
// kapan saja tanpa menyentuh data per-user.
function loadResellerConfig() {
    try {
        if (fs.existsSync(RESELLER_CONFIG_FILE)) {
            const cfg = JSON.parse(fs.readFileSync(RESELLER_CONFIG_FILE, 'utf8'));
            if (typeof cfg.diskonReseller === 'number' && cfg.diskonReseller >= 0 && cfg.diskonReseller < 1) {
                return cfg;
            }
        }
    } catch (e) {
        console.error('[Reseller] Error load config:', e.message);
    }
    return { diskonReseller: DEFAULT_DISKON_RESELLER };
}

function saveResellerConfig(cfg) {
    try {
        fs.writeFileSync(RESELLER_CONFIG_FILE, JSON.stringify(cfg, null, 2));
    } catch (e) {
        console.error('[Reseller] Error save config:', e.message);
    }
}

// Ambil diskon reseller saat ini dalam bentuk pecahan (mis. 0.5 = 50%)
function getDiskonReseller() {
    return loadResellerConfig().diskonReseller;
}

// Ambil diskon reseller saat ini dalam bentuk persen (mis. 50)
function getDiskonResellerPersen() {
    return Math.round(getDiskonReseller() * 100 * 100) / 100; // jaga presisi 2 desimal
}

// Set diskon reseller baru dari nilai PERSEN (0-99), dipanggil dari admin dashboard
function setDiskonReseller(persen) {
    const pecahan = persen / 100;
    saveResellerConfig({ diskonReseller: pecahan });
    return pecahan;
}

// ==================== LOAD / SAVE ====================
function loadReseller() {
    try {
        if (fs.existsSync(RESELLER_FILE)) {
            return JSON.parse(fs.readFileSync(RESELLER_FILE, 'utf8'));
        }
    } catch (e) {
        console.error('[Reseller] Error load:', e.message);
    }
    return {};
}

function saveReseller(data) {
    try {
        fs.writeFileSync(RESELLER_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[Reseller] Error save:', e.message);
    }
}

// ==================== CEK STATUS RESELLER ====================
function isReseller(userId) {
    const data = loadReseller();
    const r = data[userId.toString()];
    if (!r || !r.aktif) return false;
    return true;
}

function getResellerInfo(userId) {
    const data = loadReseller();
    return data[userId.toString()] || null;
}

// ==================== DAFTAR RESELLER ====================
function daftarReseller(userId, txId) {
    const data = loadReseller();
    const uid = userId.toString();
    const now = new Date().toISOString();

    data[uid] = {
        aktif: true,
        daftarAt: now,
        lastTransaksi: now,
        txId: txId,
        periodeMulai: now,       // awal periode evaluasi 30 hari berjalan
        jumlahTransaksiPeriode: 0, // jumlah akun (create/renew) di periode berjalan
    };
    saveReseller(data);
}

// ==================== UPDATE LAST TRANSAKSI ====================
// Dipanggil setiap kali reseller melakukan transaksi (create / renew)
// jumlahAkun = jumlah akun yang dibuat/diperpanjang dalam transaksi ini (default 1)
function updateResellerActivity(userId, jumlahAkun = 1) {
    const data = loadReseller();
    const uid = userId.toString();
    if (data[uid] && data[uid].aktif) {
        data[uid].lastTransaksi = new Date().toISOString();

        // Pastikan field periode ada (untuk data lama / migrasi)
        if (!data[uid].periodeMulai) {
            data[uid].periodeMulai = data[uid].daftarAt || data[uid].lastTransaksi;
        }
        if (typeof data[uid].jumlahTransaksiPeriode !== 'number') {
            data[uid].jumlahTransaksiPeriode = 0;
        }

        data[uid].jumlahTransaksiPeriode += jumlahAkun;
        saveReseller(data);
    }
}

// ==================== HAPUS STATUS RESELLER ====================
function hapusReseller(userId) {
    const data = loadReseller();
    const uid = userId.toString();
    if (data[uid]) {
        data[uid].aktif = false;
        data[uid].hapusAt = new Date().toISOString();
        saveReseller(data);
    }
}

// ==================== HITUNG HARGA RESELLER (DISKON DINAMIS) ====================
function hitungHargaReseller(hargaNormal) {
    return Math.ceil(hargaNormal * (1 - getDiskonReseller()));
}

// ==================== AUTO CHECK & HAPUS RESELLER TIDAK MEMENUHI MINIMAL TRANSAKSI ====================
// Dipanggil oleh setInterval di bot.js
// Setiap akhir periode (30 hari), jika jumlah transaksi (akun) di periode tsb < MIN_TRANSAKSI_PER_PERIODE,
// status reseller dinonaktifkan. Jika memenuhi, periode di-reset dan counter dimulai ulang dari 0.
//
// PENTING soal urutan operasi: seluruh mutasi data + saveReseller() dilakukan LEBIH DULU secara
// synchronous (tanpa ada `await` di tengah-tengahnya), BARU SETELAH ITU kirim notifikasi Telegram
// satu per satu. Ini supaya proses baca-ubah-simpan (read-modify-write) file reseller.json tidak
// "kepotong" oleh fungsi lain (daftarReseller / updateResellerActivity / setResellerStatusByAdmin)
// yang bisa saja jalan bersamaan saat kita masih menunggu (await) pengiriman pesan Telegram —
// kalau save dilakukan belakangan, perubahan dari fungsi lain di tengah jeda itu bisa ketimpa/hilang.
async function checkAndCleanReseller(bot, adminIds) {
    const data = loadReseller();
    const now = Date.now();
    const batasMs = RESELLER_EXPIRE_HARI * 24 * 60 * 60 * 1000;
    const dihapus = []; // { uid, jumlahTransaksiPeriode } yang didowngrade, dipakai untuk notifikasi setelah save

    // ---------- TAHAP 1: mutasi data + tentukan siapa yang didowngrade (murni synchronous) ----------
    for (const [uid, r] of Object.entries(data)) {
        if (!r.aktif) continue;

        // Migrasi data lama yang belum punya field periode
        if (!r.periodeMulai) r.periodeMulai = r.daftarAt || r.lastTransaksi || new Date(now).toISOString();
        if (typeof r.jumlahTransaksiPeriode !== 'number') r.jumlahTransaksiPeriode = 0;

        const periodeMulaiMs = new Date(r.periodeMulai).getTime();
        const selisih = now - periodeMulaiMs;

        if (selisih >= batasMs) {
            if (r.jumlahTransaksiPeriode >= MIN_TRANSAKSI_PER_PERIODE) {
                // Memenuhi minimal transaksi -> tetap aktif, reset periode baru
                data[uid].periodeMulai = new Date().toISOString();
                data[uid].jumlahTransaksiPeriode = 0;
                continue;
            }

            // Tidak memenuhi minimal transaksi -> nonaktifkan
            const jumlahTransaksiPeriodeLama = r.jumlahTransaksiPeriode;
            data[uid].aktif = false;
            data[uid].hapusAt = new Date().toISOString();
            dihapus.push({ uid, jumlahTransaksiPeriode: jumlahTransaksiPeriodeLama });
        }
    }

    const jumlahHapus = dihapus.length;

    // ---------- TAHAP 2: simpan SEKARANG JUGA, sebelum ada await apapun ----------
    saveReseller(data);
    if (jumlahHapus > 0) {
        console.log(`[Reseller] Auto-hapus ${jumlahHapus} reseller (tidak penuhi minimal ${MIN_TRANSAKSI_PER_PERIODE} transaksi/bulan)`);
    }

    // ---------- TAHAP 3: kirim notifikasi (async, TIDAK ada save lagi setelah tahap ini) ----------
    for (const { uid, jumlahTransaksiPeriode } of dihapus) {
        try {
            await bot.telegram.sendMessage(
                parseInt(uid),
                `⚠️ <b>STATUS RESELLER ANDA DI-DOWNGRADE</b>\n\n` +
                `❌ Status Anda diturunkan dari <b>Reseller</b> menjadi <b>Member</b> karena transaksi Anda dalam <b>${RESELLER_EXPIRE_HARI} hari</b> terakhir hanya <b>${jumlahTransaksiPeriode}</b> akun, kurang dari minimal <b>${MIN_TRANSAKSI_PER_PERIODE} transaksi/bulan</b>.\n\n` +
                `✅ Anda masih bisa bergabung kembali sebagai reseller kapan saja dengan biaya <b>Rp 30.000</b>.\n\n` +
                `Ketik /menu → Join Reseller untuk mendaftar ulang.`,
                { parse_mode: 'HTML' }
            );
        } catch (e) {
            console.log(`[Reseller] Gagal notif user ${uid}: ${e.message}`);
        }
    }

    if (jumlahHapus > 0) {
        // Notif ke admin
        if (adminIds && adminIds.length > 0) {
            const dihapusUids = dihapus.map(d => d.uid);
            const notifText =
                `🗑️ <b>AUTO DOWNGRADE RESELLER</b>\n━━━━━━━━━━━━━━━━━━\n` +
                `📊 Total: ${jumlahHapus} reseller diturunkan jadi Member\n` +
                `📋 Alasan: Transaksi kurang dari ${MIN_TRANSAKSI_PER_PERIODE}x dalam ${RESELLER_EXPIRE_HARI} hari\n\n` +
                `User IDs: ${dihapusUids.join(', ')}`;
            for (const adminId of adminIds) {
                try {
                    await bot.telegram.sendMessage(adminId, notifText, { parse_mode: 'HTML' });
                } catch (e) {}
            }
        }
    }

    return jumlahHapus;
}

// ==================== ADMIN: TOGGLE STATUS RESELLER (ON/OFF) ====================
// Dipakai dari dashboard admin untuk mengaktifkan/menonaktifkan status reseller
// SIAPA SAJA user (bukan cuma yang sudah pernah daftar), tanpa melalui flow
// bayar (join_reseller). Jika user belum pernah terdaftar dan diaktifkan oleh
// admin, entry baru dibuat dengan txId 'ADMIN' dan flag adminActivated = true.
function setResellerStatusByAdmin(userId, aktif, adminId = null) {
    const data = loadReseller();
    const uid = userId.toString();
    const now = new Date().toISOString();

    if (!data[uid]) {
        // User belum pernah terdaftar reseller -> buat entry baru
        data[uid] = {
            aktif: !!aktif,
            daftarAt: now,
            lastTransaksi: now,
            txId: 'ADMIN',
            periodeMulai: now,
            jumlahTransaksiPeriode: 0,
            adminActivated: true,
        };
    } else {
        data[uid].aktif = !!aktif;
        if (aktif) {
            // Reset periode evaluasi setiap kali admin meng-ON-kan kembali,
            // supaya user tidak langsung kena downgrade otomatis di periode lama.
            data[uid].periodeMulai = now;
            data[uid].jumlahTransaksiPeriode = 0;
            data[uid].adminActivated = true;
            delete data[uid].hapusAt;
        } else {
            data[uid].hapusAt = now;
        }
    }

    if (adminId) data[uid].lastAdminAction = { by: adminId.toString(), at: now, aktif: !!aktif };

    saveReseller(data);
    return data[uid];
}

// ==================== ADMIN: AMBIL SEMUA DATA RESELLER (yang punya entry) ====================
// Mengembalikan array semua entry reseller (aktif maupun nonaktif pernah daftar),
// terurut: aktif duluan, lalu berdasarkan lastTransaksi terbaru.
function getAllResellerList() {
    const data = loadReseller();
    const list = Object.entries(data).map(([uid, r]) => ({ userId: uid, ...r }));
    list.sort((a, b) => {
        if (a.aktif !== b.aktif) return a.aktif ? -1 : 1;
        const ta = new Date(a.lastTransaksi || a.daftarAt || 0).getTime();
        const tb = new Date(b.lastTransaksi || b.daftarAt || 0).getTime();
        return tb - ta;
    });
    return list;
}

// ==================== LABEL STATUS USER ====================
// Mengembalikan label "👑 Reseller" atau "👤 Member" untuk ditampilkan di menu
function getLabelStatus(userId) {
    return isReseller(userId) ? '👑 Reseller' : '👤 Member';
}

// ==================== FORMAT INFO RESELLER ====================
function formatInfoReseller(userId) {
    if (!isReseller(userId)) return null;
    const r = getResellerInfo(userId);
    if (!r) return null;

    const daftarDate = new Date(r.daftarAt).toLocaleDateString('id-ID', {
        day: 'numeric', month: 'short', year: 'numeric'
    });
    const lastTxDate = new Date(r.lastTransaksi || r.daftarAt).toLocaleDateString('id-ID', {
        day: 'numeric', month: 'short', year: 'numeric'
    });

    // Hitung sisa hari sebelum periode evaluasi berakhir
    const periodeMulaiMs = new Date(r.periodeMulai || r.lastTransaksi || r.daftarAt).getTime();
    const batasMs = RESELLER_EXPIRE_HARI * 24 * 60 * 60 * 1000;
    const sisaMs = batasMs - (Date.now() - periodeMulaiMs);
    const sisaHari = Math.max(0, Math.ceil(sisaMs / (24 * 60 * 60 * 1000)));
    const jumlahTransaksiPeriode = typeof r.jumlahTransaksiPeriode === 'number' ? r.jumlahTransaksiPeriode : 0;

    return {
        daftarAt: daftarDate,
        lastTransaksi: lastTxDate,
        sisaHariSebelumExpire: sisaHari,
        jumlahTransaksiPeriode,
        minimalTransaksiPeriode: MIN_TRANSAKSI_PER_PERIODE,
        kurangTransaksi: Math.max(0, MIN_TRANSAKSI_PER_PERIODE - jumlahTransaksiPeriode),
        diskonPersen: getDiskonResellerPersen(),
    };
}

module.exports = {
    BIAYA_DAFTAR_RESELLER,
    RESELLER_EXPIRE_HARI,
    MIN_TRANSAKSI_PER_PERIODE,
    isReseller,
    getResellerInfo,
    daftarReseller,
    hapusReseller,
    updateResellerActivity,
    hitungHargaReseller,
    checkAndCleanReseller,
    getLabelStatus,
    formatInfoReseller,
    setResellerStatusByAdmin,
    getAllResellerList,
    getDiskonReseller,
    getDiskonResellerPersen,
    setDiskonReseller,
};
