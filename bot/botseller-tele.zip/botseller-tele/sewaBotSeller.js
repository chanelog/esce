// sewaBotSeller.js - Modul Sewa Bot Seller (generate token lisensi + simpan ke lisensi.json)
'use strict';

const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');

// ==================== CONFIG ====================
// Bot & web server (pxstore.web.id) ada di satu mesin yang sama, jadi lisensi.json
// cukup ditulis langsung ke path filesystem-nya — tidak perlu HTTP upload / secret.
// Sesuaikan path ini kalau lokasi root web kamu berbeda.
let LISENSI_FILE_PATH = process.env.LISENSI_BOT_FILE_PATH || '/var/www/pxstore.web.id/sewa-bot/lisensi.json';
let LISENSI_PUBLIC_URL = process.env.LISENSI_BOT_PUBLIC_URL || 'https://pxstore.web.id/sewa-bot/lisensi.json';

function getLisensiFilePath()        { return LISENSI_FILE_PATH; }
function setLisensiFilePath(nilai)   { LISENSI_FILE_PATH = nilai; process.env.LISENSI_BOT_FILE_PATH = nilai; _cacheInvalidate('lisensi'); }
function getLisensiPublicUrl()        { return LISENSI_PUBLIC_URL; }
function setLisensiPublicUrl(nilai)   { LISENSI_PUBLIC_URL = nilai; process.env.LISENSI_BOT_PUBLIC_URL = nilai; }

const BOT_SELLER_DATA_DIR  = path.join(__dirname, 'data_sewa_bot');
const SEWA_BOT_FILE        = path.join(__dirname, 'sewa_bot_seller.json');  // riwayat sewa per-user
const BOT_PAKET_FILE       = path.join(__dirname, 'sewa_bot_paket.json');

if (!fs.existsSync(BOT_SELLER_DATA_DIR)) fs.mkdirSync(BOT_SELLER_DATA_DIR, { recursive: true });

// ==================== IN-MEMORY CACHE (samain pola dengan bot.js) ====================
// Tanpa cache ini, kalau saveXxx() ditulis async (non-blocking), ada celah race:
// loadXxx() yang dipanggil sepersekian detik setelahnya bisa baca file lama dari disk
// (soalnya tulisan async-nya belum kelar). Dengan cache, baca SELALU dari memory yang
// sudah pasti terbaru (di-update sinkron di saveXxx), sementara tulis ke disk jalan
// di background — jadi konsisten DAN tidak nge-block event loop (freeze bot).
const _cache = {
    botPaket: { data: null },
    lisensi:  { data: null },
    sewaBot:  { data: null },
};

function _cacheGet(key, file, defaultVal) {
    if (_cache[key].data !== null) return _cache[key].data;
    try {
        if (fs.existsSync(file)) {
            _cache[key].data = JSON.parse(fs.readFileSync(file, 'utf8'));
        } else {
            _cache[key].data = defaultVal;
        }
    } catch(e) {
        _cache[key].data = defaultVal;
    }
    return _cache[key].data;
}

// Update cache SEKARANG (sinkron), lalu tulis ke disk di background (async, tidak di-await)
// supaya tidak menahan event loop / bikin user lain nge-lag saat ada transaksi sewa bot.
function _cacheSet(key, file, data) {
    _cache[key].data = data;
    const json = JSON.stringify(data, null, 2);
    fs.writeFile(file, json, 'utf8', (err) => {
        if (err) console.error(`[sewaBotSeller] Gagal menyimpan ${key}:`, err.message);
    });
}

function _cacheInvalidate(key) {
    _cache[key].data = null;
}

// Harga
let HARGA_BOT_SELLER_30HARI = parseInt(process.env.HARGA_BOT_SELLER_30HARI) || 20000;
let HARGA_BOT_SELLER_LIFETIME = parseInt(process.env.HARGA_BOT_SELLER_LIFETIME) || 200000;

function setHargaBotSeller30Hari(nilai) { HARGA_BOT_SELLER_30HARI = nilai; }
function getHargaBotSeller30Hari()      { return HARGA_BOT_SELLER_30HARI; }
function setHargaBotSellerLifetime(n)   { HARGA_BOT_SELLER_LIFETIME = n; }
function getHargaBotSellerLifetime()    { return HARGA_BOT_SELLER_LIFETIME; }

// Toggle tampil/sembunyi menu "Sewa Bot Seller"
let SEWA_BOT_AKTIF = process.env.SEWA_BOT_AKTIF !== 'false';
function isSewaBotAktif()        { return SEWA_BOT_AKTIF; }
function setSewaBotAktif(nilai)  { SEWA_BOT_AKTIF = !!nilai; }

// ==================== PAKET ====================
const DEFAULT_BOT_PAKET = [
    { id: 'bot_30',       label: '30 Hari',  jumlahHari: 30,  icon: '🤖' },
    { id: 'bot_60',       label: '60 Hari',  jumlahHari: 60,  icon: '🤖' },
    { id: 'bot_90',       label: '90 Hari',  jumlahHari: 90,  icon: '🤖' },
    { id: 'bot_lifetime', label: 'Lifetime', jumlahHari: null, icon: '♾️' },
];

function loadBotPaketData() {
    const cached = _cacheGet('botPaket', BOT_PAKET_FILE, null);
    if (cached !== null) return cached;
    saveBotPaketData(DEFAULT_BOT_PAKET);
    return DEFAULT_BOT_PAKET;
}
function saveBotPaketData(list) { _cacheSet('botPaket', BOT_PAKET_FILE, list); }
function getBotPaketList()      { return loadBotPaketData(); }
function getBotPaketById(id)    { return getBotPaketList().find(p => p.id === id) || null; }

function hitungHargaBotSeller(jumlahHari) {
    if (jumlahHari === null) return HARGA_BOT_SELLER_LIFETIME;
    const perHari = HARGA_BOT_SELLER_30HARI / 30;
    return Math.ceil(perHari * jumlahHari);
}

function formatTanggalExpiryBot(jumlahHari) {
    if (jumlahHari === null) return '2099-12-31';
    const d = new Date();
    d.setDate(d.getDate() + jumlahHari);
    return d.toISOString().split('T')[0];
}

// ==================== TOKEN LISENSI ====================
// Token random, panjangnya disesuaikan dengan masa aktif (makin lama makin panjang) supaya
// terasa "unik per masa aktif", lalu ditambah checksum singkat dari payload.
function generateLisensiToken(masaAktif) {
    const hariTersisa = Math.max(1, Math.ceil((new Date(masaAktif) - new Date()) / 86400000));
    const panjang = Math.min(24, Math.max(12, Math.round(hariTersisa / 10) + 12));
    const acak = crypto.randomBytes(panjang).toString('hex').slice(0, panjang).toUpperCase();
    const blok = acak.match(/.{1,4}/g).join('-');
    return `PX-${blok}`;
}

// ==================== MASTER LISENSI (file langsung dibaca script install via web) ====================
function ensureLisensiDir() {
    const dir = path.dirname(LISENSI_FILE_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function loadLisensiLocal() {
    return _cacheGet('lisensi', LISENSI_FILE_PATH, []);
}

function saveLisensiLocal(list) {
    ensureLisensiDir();
    _cacheSet('lisensi', LISENSI_FILE_PATH, list);
}

// Tambah 1 entri lisensi baru → tulis ulang lisensi.json langsung di lokasi web server
async function tambahLisensiDanUpload({ token, nama, ip, masaAktif, jumlahHari, userId }) {
    const list = loadLisensiLocal();
    list.push({
        token,
        nama,
        ip,
        masaAktif,
        jumlahHari,
        userId,
        status: 'active',
        createdAt: new Date().toISOString(),
    });
    saveLisensiLocal(list);
    return list;
}

// Update masaAktif token tertentu (perpanjangan).
// Kalau lisensi sudah lewat expired, masa aktif baru dihitung mulai dari SEKARANG
// (bukan ditambahkan dari tanggal lama yang sudah lewat), supaya user tidak rugi.
// Kalau jumlahHariTambahan null → upgrade ke lifetime.
// Return: { masaAktifBaru, jumlahHariBaru } kalau sukses, false kalau token tidak ada.
async function perpanjangLisensiDanUpload(token, jumlahHariTambahan) {
    const list = loadLisensiLocal();
    const item = list.find(l => l.token === token);
    if (!item) return false;

    let masaAktifBaru;
    let jumlahHariBaru;

    if (jumlahHariTambahan === null) {
        // Upgrade ke lifetime
        masaAktifBaru  = '2099-12-31';
        jumlahHariBaru = null;
    } else if (item.jumlahHari === null) {
        // Sudah lifetime, perpanjangan tidak mengubah apa-apa
        masaAktifBaru  = item.masaAktif;
        jumlahHariBaru = null;
    } else {
        const now = new Date();
        const expiredLama  = item.masaAktif ? new Date(item.masaAktif) : null;
        const sudahExpired = !expiredLama || isNaN(expiredLama.getTime()) || expiredLama < now;
        const basis = sudahExpired ? now : expiredLama;

        const d = new Date(basis);
        d.setDate(d.getDate() + jumlahHariTambahan);
        masaAktifBaru  = d.toISOString().split('T')[0];
        jumlahHariBaru = (item.jumlahHari || 0) + jumlahHariTambahan;
    }

    item.masaAktif  = masaAktifBaru;
    item.jumlahHari = jumlahHariBaru;
    item.status     = 'active';
    item.updatedAt  = new Date().toISOString();
    saveLisensiLocal(list);
    return { masaAktifBaru, jumlahHariBaru };
}

// Hapus / revoke token
async function hapusLisensiDanUpload(token) {
    const list = loadLisensiLocal();
    const newList = list.filter(l => l.token !== token);
    if (newList.length === list.length) return false;
    saveLisensiLocal(newList);
    return true;
}

// ==================== AUTO MARK LISENSI EXPIRED ====================
// Scan lisensi.json, tandai status: 'expired' untuk semua token yang sudah lewat masaAktif
// (kecuali lifetime, ditandai dengan jumlahHari === null / masaAktif 2099-12-31).
// Token TIDAK dihapus dari lisensi.json — hanya status-nya yang diubah, supaya histori
// tetap ada dan token bisa diperpanjang lagi (status balik ke 'active' otomatis saat
// perpanjangLisensiDanUpload dipanggil).
// Mengembalikan array entri yang BARU SAJA ditandai expired (untuk notifikasi dari bot.js).
async function checkDanHapusLisensiExpired() {
    const list = loadLisensiLocal();
    if (!Array.isArray(list) || list.length === 0) return [];

    const now = new Date();
    const baruExpired = [];
    let adaPerubahan = false;

    for (const item of list) {
        // Lifetime tidak pernah expired
        if (item.jumlahHari === null) continue;

        // Sudah ditandai expired sebelumnya, skip (jangan kirim notif berulang)
        if (item.status === 'expired') continue;

        const expDate = item.masaAktif ? new Date(item.masaAktif) : null;
        const isExpired = !expDate || isNaN(expDate.getTime()) || expDate < now;

        if (isExpired) {
            item.status = 'expired';
            item.expiredAt = new Date().toISOString();
            baruExpired.push(item);
            adaPerubahan = true;
        }
    }

    if (adaPerubahan) {
        saveLisensiLocal(list);
    }

    return baruExpired;
}
function loadSewaBotData() {
    return _cacheGet('sewaBot', SEWA_BOT_FILE, {});
}
function saveSewaBotData(data) { _cacheSet('sewaBot', SEWA_BOT_FILE, data); }

function tambahSewaBotRecord(userId, { txId, token, nama, ip, masaAktif, jumlahHari, harga }) {
    const data = loadSewaBotData();
    if (!data[userId]) data[userId] = [];
    data[userId].push({ txId, token, nama, ip, masaAktif, jumlahHari, harga, createdAt: new Date().toISOString() });
    saveSewaBotData(data);
}
function getSewaBotByUser(userId) { return loadSewaBotData()[userId] || []; }

// Update riwayat sewa milik user setelah token-nya diperpanjang, supaya
// sewa_bot_seller.json tetap sinkron dengan lisensi.json (tanggal & jumlah hari terbaru).
// hargaTambahan ditambahkan ke field harga (akumulasi total yang sudah dibayar untuk token ini).
function perpanjangSewaBotRecord(userId, token, masaAktifBaru, jumlahHariBaru, hargaTambahan) {
    const data = loadSewaBotData();
    const list = data[userId];
    if (!Array.isArray(list)) return false;
    const item = list.find(s => s.token === token);
    if (!item) return false;
    item.masaAktif  = masaAktifBaru;
    item.jumlahHari = jumlahHariBaru;
    item.harga      = (item.harga || 0) + (hargaTambahan || 0);
    item.updatedAt  = new Date().toISOString();
    saveSewaBotData(data);
    return true;
}

// Cari record sewa (token) milik user lewat token, dipakai saat user mau perpanjang.
function getSewaBotByToken(userId, token) {
    const list = getSewaBotByUser(userId);
    return list.find(s => s.token === token) || null;
}
function getAllSewaBot() {
    const data = loadSewaBotData();
    const result = [];
    for (const [userId, list] of Object.entries(data)) list.forEach(s => result.push({ ...s, userId }));
    return result;
}

// ==================== EXPORT ====================
module.exports = {
    getLisensiFilePath, setLisensiFilePath,
    getLisensiPublicUrl, setLisensiPublicUrl,
    setHargaBotSeller30Hari, getHargaBotSeller30Hari,
    setHargaBotSellerLifetime, getHargaBotSellerLifetime,
    isSewaBotAktif, setSewaBotAktif,
    getBotPaketList, getBotPaketById,
    hitungHargaBotSeller,
    formatTanggalExpiryBot,
    generateLisensiToken,
    tambahLisensiDanUpload,
    perpanjangLisensiDanUpload,
    hapusLisensiDanUpload,
    checkDanHapusLisensiExpired,
    loadLisensiLocal,
    tambahSewaBotRecord,
    perpanjangSewaBotRecord,
    getSewaBotByUser,
    getSewaBotByToken,
    getAllSewaBot,
};
