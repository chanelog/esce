// ==================== ZIVPN MODULE LENGKAP ====================
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const AKUN_FILE = path.join(__dirname, 'akun.json');

// ==================== HELPER FUNCTIONS ====================
function cleanUnicodeText(text) {
    if (!text) return '';
    return String(text)
        .replace(/ð®ð©/g, '🇮🇩')
        .replace(/ð®ðª/g, '🇺🇸')
        .replace(/ð®ðº/g, '🇸🇬')
        .replace(/ð®ð»/g, '🇲🇾');
}

function generateRandomPassword(length = 10) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// ==================== API CALLS ====================
async function callZivpnAPI(server, endpoint, method = 'GET', data = null) {
    try {
        let apiUrl = server.apiUrl.replace(/\/$/, '');
        const fullUrl = `${apiUrl}${endpoint}`;
        
        const headers = {
            'X-API-Key': server.authKey,
            'Content-Type': 'application/json'
        };
        
        console.log(`📡 ZiVPN API [${method}]: ${fullUrl}`);
        
        let response;
        if (method === 'GET') {
            response = await axios.get(fullUrl, { headers, timeout: 30000 });
        } else {
            response = await axios.post(fullUrl, data, { headers, timeout: 30000 });
        }
        
        console.log(`📡 Response Status: ${response.status}`);
        
        if (response.status === 200) {
            return { success: true, data: response.data };
        }
        return { success: false, message: `HTTP ${response.status}` };
    } catch (error) {
        console.error(`❌ ZiVPN API Error:`, error.message);
        if (error.response) {
            return { success: false, message: error.response.data?.message || `HTTP ${error.response.status}` };
        }
        return { success: false, message: error.message };
    }
}

async function zivpnCreate(server, password, days, iplimit = 0) {
    return await callZivpnAPI(server, '/api/user/create', 'POST', {
        password: password,
        days: parseInt(days),
        ip_limit: parseInt(iplimit)
    });
}

// Fungsi zivpnTrial universal (HANYA SATU DEFINISI)
async function zivpnTrial(server, minutes = 30) {
    return await callZivpnAPI(server, '/api/user/trial', 'POST', { 
        minutes: parseInt(minutes) 
    });
}

async function zivpnDelete(server, password) {
    return await callZivpnAPI(server, '/api/user/delete', 'POST', { password: password });
}

async function zivpnRenew(server, password, days) {
    return await callZivpnAPI(server, '/api/user/renew', 'POST', {
        password: password,
        days: parseInt(days)
    });
}

async function zivpnList(server) {
    const result = await callZivpnAPI(server, '/api/users', 'GET');
    if (result.success) {
        let users = [];
        if (Array.isArray(result.data)) {
            users = result.data;
        } else if (result.data && result.data.data && Array.isArray(result.data.data)) {
            users = result.data.data;
        } else if (result.data && result.data.users && Array.isArray(result.data.users)) {
            users = result.data.users;
        } else {
            users = [];
        }
        return { success: true, users: users };
    }
    return result;
}

async function zivpnDetail(server, password) {
    const result = await zivpnList(server);
    if (result.success && result.users) {
        const user = result.users.find(u => u.password === password || u.username === password);
        if (user) {
            return { success: true, data: user };
        }
        return { success: false, message: 'User tidak ditemukan' };
    }
    return result;
}

// ==================== ACCOUNT STORAGE ====================
function saveZivpnAccount(serverName, password, data) {
    try {
        let accounts = {};
        if (fs.existsSync(AKUN_FILE)) {
            accounts = JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        }
        if (!accounts.services) accounts.services = {};
        if (!accounts.services.zivpn) accounts.services.zivpn = {};
        if (!accounts.services.zivpn[serverName]) accounts.services.zivpn[serverName] = {};
        
        accounts.services.zivpn[serverName][password] = {
            password: password,
            data: data,
            saved_at: new Date().toISOString()
        };
        fs.writeFileSync(AKUN_FILE, JSON.stringify(accounts, null, 2));
        return true;
    } catch (error) {
        console.error('Error saving ZiVPN account:', error);
        return false;
    }
}

function deleteZivpnAccount(serverName, password) {
    try {
        if (!fs.existsSync(AKUN_FILE)) return true;
        const accounts = JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        if (accounts.services && accounts.services.zivpn && 
            accounts.services.zivpn[serverName] && 
            accounts.services.zivpn[serverName][password]) {
            delete accounts.services.zivpn[serverName][password];
            if (Object.keys(accounts.services.zivpn[serverName]).length === 0) {
                delete accounts.services.zivpn[serverName];
            }
            fs.writeFileSync(AKUN_FILE, JSON.stringify(accounts, null, 2));
        }
        return true;
    } catch (error) {
        return false;
    }
}

function getZivpnCount() {
    try {
        if (!fs.existsSync(AKUN_FILE)) return 0;
        const accounts = JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        let count = 0;
        if (accounts.services && accounts.services.zivpn) {
            for (const server of Object.values(accounts.services.zivpn)) {
                count += Object.keys(server).length;
            }
        }
        return count;
    } catch (error) {
        return 0;
    }
}

async function getAllZivpnAccounts() {
    try {
        if (!fs.existsSync(AKUN_FILE)) return "📭 Tidak ada data akun ZiVPN";
        const accounts = JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        if (!accounts.services || !accounts.services.zivpn) {
            return "📭 Tidak ada data akun ZiVPN";
        }
        
        let result = "";
        let total = 0;
        
        for (const [serverName, serverAccounts] of Object.entries(accounts.services.zivpn)) {
            if (Object.keys(serverAccounts).length > 0) {
                result += `\n🌐 **Server:** <code>${cleanUnicodeText(serverName)}</code>\n`;
                result += `<code>────────────────────</code>\n`;
                
                for (const [password, acc] of Object.entries(serverAccounts)) {
                    total++;
                    const data = acc.data || {};
                    const trialMark = data.is_trial ? ' 🎯 (TRIAL)' : '';
                    result += `🔑 <b>Password:</b> <code>${password}</code>${trialMark}\n`;
                    if (data.limit_ip !== undefined) result += `   🌐 Limit IP: ${data.limit_ip}\n`;
                    if (data.expired_date) result += `   ⏰ Expired: ${data.expired_date}\n`;
                    result += `\n`;
                }
            }
        }
        
        if (total === 0) return "📭 Tidak ada data akun ZiVPN";
        return `${result}\n📊 <b>STATISTIK:</b> <code>${total} akun</code>`;
    } catch (error) {
        return `❌ Error: ${error.message}`;
    }
}

// ==================== HANDLER UNTUK BOT ====================
let zivpnStates = {};

async function showZivpnMenu(bot, chatId, userId, SERVERS) {
    const zivpnServers = Object.values(SERVERS).filter(s => s.type === 'zivpn');
    const totalAccounts = getZivpnCount();
    
    const text = `
<b>🔥 ZIVPN MANAGER</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>🌐 Server ZiVPN:</b> <code>${zivpnServers.length}</code>
<b>👥 Total Akun:</b> <code>${totalAccounts}</code>
<b>📡 Status:</b> <code>🟢 Active</code>

<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>
<b>🔰 Pilih perintah untuk mengelola ZiVPN:</b>
`;
    
    const buttons = [
        [{ text: '🎯 TRIAL', callback_data: 'zivpn-trial' }, { text: '✨ CREATE', callback_data: 'zivpn-create' }],
        [{ text: '🎲 RANDOM', callback_data: 'zivpn-random' }, { text: '🔄 RENEW', callback_data: 'zivpn-renew' }],
        [{ text: '🗑️ DELETE', callback_data: 'zivpn-delete' }, { text: '📊 DETAIL', callback_data: 'zivpn-detail' }],
        [{ text: '👥 LIST USER', callback_data: 'zivpn-list' }],
        [{ text: '◀️ Kembali ke Menu Utama', callback_data: 'menu' }]
    ];
    
    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    });
}

async function selectZivpnServer(bot, chatId, userId, action, SERVERS) {
    const servers = Object.values(SERVERS).filter(s => s.type === 'zivpn');
    
    if (servers.length === 0) {
        await bot.sendMessage(chatId, '❌ <b>Tidak ada server ZiVPN yang tersedia</b>\n\nSilakan tambah server dengan tipe ZIVPN terlebih dahulu.', { parse_mode: 'HTML' });
        return null;
    }
    
    const buttons = servers.map(server => [
        { text: `🔥 ${server.name}`, callback_data: `zivpn-srv-${server.id}-${action}` }
    ]);
    buttons.push([{ text: '❌ Batal', callback_data: `back-zivpn-menu` }]);
    
    const text = `🌐 <b>Pilih Server ZiVPN untuk ${action.toUpperCase()}</b>:`;
    
    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    });
    
    return new Promise((resolve) => {
        const handler = async (callbackQuery) => {
            const data = callbackQuery.data;
            if (data.startsWith(`zivpn-srv-`) && data.includes(action)) {
                const parts = data.split('-');
                const serverId = parts[2];
                const server = SERVERS[serverId];
                if (server) {
                    bot.removeListener('callback_query', handler);
                    resolve(server);
                } else {
                    resolve(null);
                }
            } else if (data === `back-zivpn-menu`) {
                bot.removeListener('callback_query', handler);
                resolve(null);
            }
        };
        
        bot.on('callback_query', handler);
        
        setTimeout(() => {
            bot.removeListener('callback_query', handler);
            resolve(null);
        }, 60000);
    });
}

async function handleZivpnTrial(bot, chatId, userId, SERVERS) {
    const server = await selectZivpnServer(bot, chatId, userId, 'trial', SERVERS);
    if (!server) {
        await showZivpnMenu(bot, chatId, userId, SERVERS);
        return;
    }
    
    zivpnStates[userId] = { action: 'trial', server: server };
    
    const buttons = [
        [{ text: '⏰ 30 Menit', callback_data: 'zivpn-dur-30' }, { text: '⏰ 60 Menit', callback_data: 'zivpn-dur-60' }],
        [{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]
    ];
    
    const text = `✅ <b>Server dipilih:</b> <code>${server.name}</code>\n\n<b>Pilih durasi trial:</b>`;
    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    });
}

// Fungsi processZivpnTrial (HANYA SATU DEFINISI)
async function processZivpnTrial(bot, chatId, userId, duration, SERVERS) {
    const state = zivpnStates[userId];
    if (!state || state.action !== 'trial') return;
    
    const server = state.server;
    const minutes = parseInt(duration); // 30 atau 60
    
    const loadingMsg = await bot.sendMessage(chatId, '⏳ <b>Membuat trial account...</b>', { parse_mode: 'HTML' });
    
    // Panggil dengan parameter minutes
    const result = await zivpnTrial(server, minutes);
    
    await bot.deleteMessage(chatId, loadingMsg.message_id);
    
    if (result.success && result.data) {
        const trialData = result.data;
        const password = trialData.password;
        const expiredDate = new Date(trialData.expired);
        const trialMinutes = trialData.duration_minutes || minutes;
        
        const successMsg = `
🎯 <b>TRIAL ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

🌐 <b>Server:</b> <code>${server.name}</code>

✅ <b>Trial account berhasil dibuat</b>
🔑 <b>Password:</b> <code>${password}</code>
🌐 <b>Limit IP:</b> <code>${trialData.ip_limit || 1}</code>
⏰ <b>Durasi:</b> <code>${trialMinutes} menit</code>
📅 <b>Expired:</b> <code>${expiredDate.toLocaleString()}</code>

🤖 <b>» @PeyxDev</b>
`;
        await bot.sendMessage(chatId, successMsg, { parse_mode: 'HTML' });
        
        saveZivpnAccount(server.name, password, {
            is_trial: true,
            duration: trialMinutes,
            expired_date: expiredDate.toISOString(),
            ip_limit: trialData.ip_limit || 1
        });
    } else {
        await bot.sendMessage(chatId, `❌ <b>Gagal membuat trial:</b> <code>${result.message}</code>`, { parse_mode: 'HTML' });
    }
    
    delete zivpnStates[userId];
    await showZivpnMenu(bot, chatId, userId, SERVERS);
}

// Handler untuk callback durasi trial
async function handleZivpnTrialDuration(bot, chatId, userId, duration, SERVERS) {
    await processZivpnTrial(bot, chatId, userId, duration, SERVERS);
}

async function handleZivpnCreate(bot, chatId, userId, SERVERS) {
    const server = await selectZivpnServer(bot, chatId, userId, 'create', SERVERS);
    if (!server) {
        await showZivpnMenu(bot, chatId, userId, SERVERS);
        return;
    }
    
    zivpnStates[userId] = { action: 'create', server: server, step: 1, data: {} };
    
    const text = `
<b>✨ CREATE ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Step 1/3 - Masukkan Password / Username</b>
✅ <b>Server:</b> <code>${server.name}</code>

Contoh: <code>user123</code>
`;
    const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    });
}

async function handleZivpnRandom(bot, chatId, userId, SERVERS) {
    const server = await selectZivpnServer(bot, chatId, userId, 'random', SERVERS);
    if (!server) {
        await showZivpnMenu(bot, chatId, userId, SERVERS);
        return;
    }
    
    zivpnStates[userId] = { action: 'random', server: server, step: 1, data: {} };
    
    const text = `
<b>🎲 RANDOM ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Step 1/2 - Masukkan Masa Aktif (hari)</b>
✅ <b>Server:</b> <code>${server.name}</code>

Contoh: <code>30</code>
`;
    const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    });
}

async function handleZivpnRenew(bot, chatId, userId, SERVERS) {
    const server = await selectZivpnServer(bot, chatId, userId, 'renew', SERVERS);
    if (!server) {
        await showZivpnMenu(bot, chatId, userId, SERVERS);
        return;
    }
    
    zivpnStates[userId] = { action: 'renew', server: server, step: 1, data: {} };
    
    const text = `
<b>🔄 RENEW ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Step 1/2 - Masukkan Password</b>
✅ <b>Server:</b> <code>${server.name}</code>
`;
    const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    });
}

async function handleZivpnDelete(bot, chatId, userId, SERVERS) {
    const server = await selectZivpnServer(bot, chatId, userId, 'delete', SERVERS);
    if (!server) {
        await showZivpnMenu(bot, chatId, userId, SERVERS);
        return;
    }
    
    zivpnStates[userId] = { action: 'delete', server: server, data: {} };
    
    const text = `
<b>🗑️ DELETE ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Masukkan Password yang akan dihapus</b>
✅ <b>Server:</b> <code>${server.name}</code>

⚠️ <b>Peringatan:</b> Tindakan ini TIDAK DAPAT DIBATALKAN!
`;
    const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    });
}

async function handleZivpnDetail(bot, chatId, userId, SERVERS) {
    const server = await selectZivpnServer(bot, chatId, userId, 'detail', SERVERS);
    if (!server) {
        await showZivpnMenu(bot, chatId, userId, SERVERS);
        return;
    }
    
    zivpnStates[userId] = { action: 'detail', server: server, data: {} };
    
    const text = `
<b>📊 DETAIL ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Masukkan Password</b>
✅ <b>Server:</b> <code>${server.name}</code>
`;
    const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    });
}

async function handleZivpnList(bot, chatId, userId, SERVERS) {
    const server = await selectZivpnServer(bot, chatId, userId, 'list', SERVERS);
    if (!server) {
        await showZivpnMenu(bot, chatId, userId, SERVERS);
        return;
    }
    
    const loadingMsg = await bot.sendMessage(chatId, '⏳ <b>Memuat daftar akun...</b>', { parse_mode: 'HTML' });
    
    const result = await zivpnList(server);
    
    await bot.deleteMessage(chatId, loadingMsg.message_id);
    
    if (result.success && result.users) {
        const users = result.users;
        if (!users || users.length === 0) {
            await bot.sendMessage(chatId, `📭 <b>Tidak ada akun ZiVPN di server</b> <code>${server.name}</code>\n\n💡 Tips: Buat akun baru dengan menu CREATE atau RANDOM`, { parse_mode: 'HTML' });
        } else {
            let listText = `📋 <b>DAFTAR AKUN ZIVPN - ${server.name}</b>\n<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>\n\n`;
            for (let i = 0; i < Math.min(users.length, 30); i++) {
                const user = users[i];
                listText += `🔑 <b>Password:</b> <code>${user.password || user.username || '-'}</code>\n`;
                listText += `   🌐 <b>Limit IP:</b> <code>${user.ip_limit || user.ipLimit || 0}</code>\n`;
                listText += `   📅 <b>Expired:</b> <code>${user.expired || user.expiry_date || '-'}</code>\n`;
                listText += `   📋 <b>Status:</b> <code>${user.status || 'active'}</code>\n\n`;
            }
            if (users.length > 30) {
                listText += `\n<code>...dan ${users.length - 30} akun lainnya</code>`;
            }
            await bot.sendMessage(chatId, listText, { parse_mode: 'HTML' });
        }
    } else {
        await bot.sendMessage(chatId, `❌ <b>Gagal mengambil daftar akun:</b>\n<code>${result.message || 'Unknown error'}</code>\n\n💡 Pastikan API server ZiVPN berjalan dengan benar.`, { parse_mode: 'HTML' });
    }
    
    await showZivpnMenu(bot, chatId, userId, SERVERS);
}

async function processZivpnInput(bot, chatId, userId, message, SERVERS) {
    const state = zivpnStates[userId];
    if (!state) return false;
    
    const input = message.text.trim();
    
    if (state.action === 'create') {
        if (state.step === 1) {
            if (input.length < 3) {
                await bot.sendMessage(chatId, '❌ <b>Password terlalu pendek! Minimal 3 karakter.</b>', { parse_mode: 'HTML' });
                return false;
            }
            state.data.password = input;
            state.step = 2;
            
            const text = `
<b>✨ CREATE ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Step 2/3 - Masukkan Masa Aktif (hari)</b>
✅ <b>Server:</b> <code>${state.server.name}</code>
🔑 <b>Password:</b> <code>${state.data.password}</code>

Contoh: <code>30</code>
`;
            const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
            await bot.sendMessage(chatId, text, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: buttons }
            });
            return false;
            
        } else if (state.step === 2) {
            const days = parseInt(input);
            if (isNaN(days) || days < 1) {
                await bot.sendMessage(chatId, '❌ <b>Masa aktif harus berupa angka positif!</b>', { parse_mode: 'HTML' });
                return false;
            }
            state.data.days = days;
            state.step = 3;
            
            const text = `
<b>✨ CREATE ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Step 3/3 - Masukkan Limit IP</b>
✅ <b>Server:</b> <code>${state.server.name}</code>
🔑 <b>Password:</b> <code>${state.data.password}</code>
📅 <b>Masa Aktif:</b> <code>${days} hari</code>

Contoh: <code>2</code> (0 = unlimited)
`;
            const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
            await bot.sendMessage(chatId, text, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: buttons }
            });
            return false;
            
        } else if (state.step === 3) {
            const iplimit = parseInt(input);
            if (isNaN(iplimit) || iplimit < 0) {
                await bot.sendMessage(chatId, '❌ <b>Limit IP harus berupa angka!</b>', { parse_mode: 'HTML' });
                return false;
            }
            
            const loadingMsg = await bot.sendMessage(chatId, '⏳ <b>Membuat akun...</b>', { parse_mode: 'HTML' });
            
            const result = await zivpnCreate(state.server, state.data.password, state.data.days, iplimit);
            
            await bot.deleteMessage(chatId, loadingMsg.message_id);
            
            if (result.success) {
                const expiredDate = new Date();
                expiredDate.setDate(expiredDate.getDate() + state.data.days);
                
                const successMsg = `
✅ <b>AKUN ZIVPN BERHASIL DIBUAT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

🌐 <b>Server:</b> <code>${state.server.name}</code>

┌─ <b>ACCOUNT DETAILS</b>
├─ <b>Password:</b> <code>${state.data.password}</code>
├─ <b>Limit IP:</b> <code>${iplimit}</code>
├─ <b>Masa Aktif:</b> <code>${state.data.days} hari</code>
└─ <b>Expired:</b> <code>${expiredDate.toISOString().split('T')[0]}</code>

🤖 <b>» @PeyxDev</b>
`;
                await bot.sendMessage(chatId, successMsg, { parse_mode: 'HTML' });
                saveZivpnAccount(state.server.name, state.data.password, {
                    limit_ip: iplimit,
                    expired: state.data.days,
                    expired_date: expiredDate.toISOString().split('T')[0]
                });
            } else {
                await bot.sendMessage(chatId, `❌ <b>Gagal membuat akun:</b> <code>${result.message}</code>`, { parse_mode: 'HTML' });
            }
            
            delete zivpnStates[userId];
            await showZivpnMenu(bot, chatId, userId, SERVERS);
            return true;
        }
        
    } else if (state.action === 'random') {
        if (state.step === 1) {
            const days = parseInt(input);
            if (isNaN(days) || days < 1) {
                await bot.sendMessage(chatId, '❌ <b>Masa aktif harus berupa angka positif!</b>', { parse_mode: 'HTML' });
                return false;
            }
            state.data.days = days;
            state.step = 2;
            
            const text = `
<b>🎲 RANDOM ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Step 2/2 - Masukkan Limit IP</b>
✅ <b>Server:</b> <code>${state.server.name}</code>
📅 <b>Masa Aktif:</b> <code>${days} hari</code>

Contoh: <code>2</code> (0 = unlimited)
`;
            const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
            await bot.sendMessage(chatId, text, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: buttons }
            });
            return false;
            
        } else if (state.step === 2) {
            const iplimit = parseInt(input);
            if (isNaN(iplimit) || iplimit < 0) {
                await bot.sendMessage(chatId, '❌ <b>Limit IP harus berupa angka!</b>', { parse_mode: 'HTML' });
                return false;
            }
            
            const password = generateRandomPassword();
            const loadingMsg = await bot.sendMessage(chatId, '⏳ <b>Membuat akun random...</b>', { parse_mode: 'HTML' });
            
            const result = await zivpnCreate(state.server, password, state.data.days, iplimit);
            
            await bot.deleteMessage(chatId, loadingMsg.message_id);
            
            if (result.success) {
                const expiredDate = new Date();
                expiredDate.setDate(expiredDate.getDate() + state.data.days);
                
                const successMsg = `
🎲 <b>RANDOM ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

🌐 <b>Server:</b> <code>${state.server.name}</code>

✅ <b>Random account berhasil dibuat</b>
🔑 <b>Password:</b> <code>${password}</code>
🌐 <b>Limit IP:</b> <code>${iplimit}</code>
📅 <b>Expired:</b> <code>${expiredDate.toISOString().split('T')[0]}</code>

🤖 <b>» @PeyxDev</b>
`;
                await bot.sendMessage(chatId, successMsg, { parse_mode: 'HTML' });
                saveZivpnAccount(state.server.name, password, {
                    limit_ip: iplimit,
                    expired: state.data.days,
                    expired_date: expiredDate.toISOString().split('T')[0]
                });
            } else {
                await bot.sendMessage(chatId, `❌ <b>Gagal membuat akun random:</b> <code>${result.message}</code>`, { parse_mode: 'HTML' });
            }
            
            delete zivpnStates[userId];
            await showZivpnMenu(bot, chatId, userId, SERVERS);
            return true;
        }
        
    } else if (state.action === 'renew') {
        if (state.step === 1) {
            state.data.password = input;
            state.step = 2;
            
            const text = `
<b>🔄 RENEW ZIVPN ACCOUNT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>Step 2/2 - Masukkan Tambahan Hari</b>
✅ <b>Server:</b> <code>${state.server.name}</code>
🔑 <b>Password:</b> <code>${state.data.password}</code>

Contoh: <code>30</code>
`;
            const buttons = [[{ text: '❌ Batal', callback_data: 'back-zivpn-menu' }]];
            await bot.sendMessage(chatId, text, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: buttons }
            });
            return false;
            
        } else if (state.step === 2) {
            const days = parseInt(input);
            if (isNaN(days) || days < 1) {
                await bot.sendMessage(chatId, '❌ <b>Jumlah hari harus berupa angka positif!</b>', { parse_mode: 'HTML' });
                return false;
            }
            
            const loadingMsg = await bot.sendMessage(chatId, '⏳ <b>Renew akun...</b>', { parse_mode: 'HTML' });
            
            const result = await zivpnRenew(state.server, state.data.password, days);
            
            await bot.deleteMessage(chatId, loadingMsg.message_id);
            
            if (result.success) {
                await bot.sendMessage(chatId, `🔄 <b>Akun dengan password</b> <code>${state.data.password}</code> <b>berhasil direnew!</b>\n📅 <b>Tambahan:</b> <code>${days} hari</code>`, { parse_mode: 'HTML' });
            } else {
                await bot.sendMessage(chatId, `❌ <b>Gagal renew akun:</b> <code>${result.message}</code>`, { parse_mode: 'HTML' });
            }
            
            delete zivpnStates[userId];
            await showZivpnMenu(bot, chatId, userId, SERVERS);
            return true;
        }
        
    } else if (state.action === 'delete') {
        const password = input;
        
        const confirmMsg = await bot.sendMessage(chatId, `⚠️ <b>Apakah Anda yakin ingin menghapus akun dengan password</b> <code>${password}</code> <b>?</b>\nTindakan ini TIDAK DAPAT DIBATALKAN!`, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '✅ Ya, Hapus', callback_data: `zivpn-confirm-delete` }, { text: '❌ Tidak', callback_data: 'back-zivpn-menu' }]
                ]
            }
        });
        
        zivpnStates[userId].data = { password: password };
        zivpnStates[userId].confirmMsgId = confirmMsg.message_id;
        return false;
        
    } else if (state.action === 'detail') {
        const password = input;
        const loadingMsg = await bot.sendMessage(chatId, '⏳ <b>Mengambil detail akun...</b>', { parse_mode: 'HTML' });
        
        const result = await zivpnDetail(state.server, password);
        
        await bot.deleteMessage(chatId, loadingMsg.message_id);
        
        if (result.success && result.data) {
            const data = result.data;
            const detailMsg = `
📊 <b>DETAIL AKUN ZIVPN</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━━━━━</code>

🌐 <b>Server:</b> <code>${state.server.name}</code>
🔑 <b>Password:</b> <code>${data.password || password}</code>
🌐 <b>Limit IP:</b> <code>${data.ip_limit || data.ipLimit || 0}</code>
📅 <b>Expired:</b> <code>${data.expired || data.expiry_date || '-'}</code>
📋 <b>Status:</b> <code>${data.status || 'active'}</code>

🤖 <b>» @PeyxDev</b>
`;
            await bot.sendMessage(chatId, detailMsg, { parse_mode: 'HTML' });
        } else {
            await bot.sendMessage(chatId, `❌ <b>Gagal mengambil detail:</b> <code>${result.message || 'User tidak ditemukan'}</code>`, { parse_mode: 'HTML' });
        }
        
        delete zivpnStates[userId];
        await showZivpnMenu(bot, chatId, userId, SERVERS);
        return true;
    }
    
    return false;
}

async function confirmZivpnDelete(bot, chatId, userId, SERVERS) {
    const state = zivpnStates[userId];
    if (!state || state.action !== 'delete') return;
    
    const password = state.data.password;
    const server = state.server;
    
    if (state.confirmMsgId) {
        try {
            await bot.deleteMessage(chatId, state.confirmMsgId);
        } catch (e) {}
    }
    
    const loadingMsg = await bot.sendMessage(chatId, '⏳ <b>Menghapus akun...</b>', { parse_mode: 'HTML' });
    
    const result = await zivpnDelete(server, password);
    
    await bot.deleteMessage(chatId, loadingMsg.message_id);
    
    if (result.success) {
        deleteZivpnAccount(server.name, password);
        await bot.sendMessage(chatId, `✅ <b>Akun dengan password</b> <code>${password}</code> <b>berhasil dihapus!</b>`, { parse_mode: 'HTML' });
    } else {
        await bot.sendMessage(chatId, `❌ <b>Gagal menghapus akun:</b> <code>${result.message}</code>`, { parse_mode: 'HTML' });
    }
    
    delete zivpnStates[userId];
    await showZivpnMenu(bot, chatId, userId, SERVERS);
}

// ==================== EKSPOR ====================
module.exports = {
    // API Functions
    zivpnCreate,
    zivpnTrial,        // ← TAMBAHKAN INI
    zivpnDelete,
    zivpnRenew,
    zivpnList,
    zivpnDetail,
    generateRandomPassword,
    saveZivpnAccount,
    deleteZivpnAccount,
    getZivpnCount,
    getAllZivpnAccounts,
    cleanUnicodeText,
    
    // Handler Functions
    showZivpnMenu,
    handleZivpnTrial,
    handleZivpnTrialDuration,  // ← TAMBAHKAN INI
    handleZivpnCreate,
    handleZivpnRandom,
    handleZivpnRenew,
    handleZivpnDelete,
    handleZivpnDetail,
    handleZivpnList,
    processZivpnInput,
    confirmZivpnDelete,
    zivpnStates
};