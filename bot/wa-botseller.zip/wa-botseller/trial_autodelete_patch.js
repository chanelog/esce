// ============================================================
// PATCH: AUTO-DELETE TRIAL ACCOUNTS
// ============================================================
// Cara pakai:
// 1. Tambahkan TRIAL_ACTIVE_FILE di bagian "File paths" (sekitar baris 126)
// 2. Ganti fungsi eksekusiTrial dengan versi di bawah
// 3. Tambahkan semua fungsi baru di bawah ini setelah fungsi eksekusiTrial
// 4. Panggil restoreTrialSchedulers() di dalam client.on('ready', ...) setelah isReady = true
// ============================================================

// ============================================================
// LANGKAH 1: Tambahkan di bagian File paths (sekitar baris 126-129)
// ============================================================

// const TRIAL_ACTIVE_FILE = path.join(__dirname, 'trial_active.json');


// ============================================================
// LANGKAH 2: Fungsi load/save trial aktif
// Tambahkan setelah fungsi saveTrialData (sekitar baris 926)
// ============================================================

function loadTrialActive() {
    try {
        if (fs.existsSync(TRIAL_ACTIVE_FILE)) {
            return JSON.parse(fs.readFileSync(TRIAL_ACTIVE_FILE, 'utf8'));
        }
    } catch(e) {}
    return [];
}

function saveTrialActive(data) {
    try {
        fs.writeFileSync(TRIAL_ACTIVE_FILE, JSON.stringify(data, null, 2));
    } catch(e) {
        console.log('[TrialActive] Gagal simpan:', e.message);
    }
}

function addTrialActive(entry) {
    const data = loadTrialActive();
    // Hapus entry lama untuk username yang sama (jika ada)
    const filtered = data.filter(t => !(t.username === entry.username && t.serverId === entry.serverId));
    filtered.push(entry);
    saveTrialActive(filtered);
}

function removeTrialActive(username, serverId) {
    const data = loadTrialActive();
    const filtered = data.filter(t => !(t.username === username && t.serverId === serverId));
    saveTrialActive(filtered);
}


// ============================================================
// LANGKAH 3: Fungsi eksekusi delete trial via API
// Tambahkan setelah fungsi removeTrialActive di atas
// ============================================================

/**
 * Hapus akun trial dari server via API sesuai serviceType
 * @param {Object} server - object server dari SERVERS
 * @param {string} serviceType - 'ssh' | 'trojan' | 'vless' | 'vmess' | 'zivpn'
 * @param {string} username - username / password akun trial
 */
async function deleteTrialFromServer(server, serviceType, username) {
    try {
        const mod = getModule(serviceType);
        let result;

        if (serviceType === 'ssh') {
            result = await mod.deleteSSH(server, username);
        } else if (serviceType === 'trojan') {
            result = await mod.deleteTrojan(server, username);
        } else if (serviceType === 'vless') {
            result = await mod.deleteVless(server, username);
        } else if (serviceType === 'vmess') {
            result = await mod.deleteVmess(server, username);
        } else if (serviceType === 'zivpn') {
            result = await mod.zivpnDelete(server, username);
        } else {
            result = { success: false, message: `Tipe tidak dikenal: ${serviceType}` };
        }

        if (result && result.success) {
            console.log(`✅ [TrialDelete] Berhasil hapus trial ${serviceType.toUpperCase()} "${username}" dari server ${server.name}`);
        } else {
            console.log(`⚠️ [TrialDelete] Gagal hapus trial "${username}": ${result?.message || 'Unknown error'}`);
        }
        return result;
    } catch(err) {
        console.log(`❌ [TrialDelete] Error hapus trial "${username}": ${err.message}`);
        return { success: false, message: err.message };
    }
}


/**
 * Schedule auto-delete untuk satu entry trial
 * @param {Object} entry - { username, serviceType, serverId, expiredAt, userId, chatId }
 */
function scheduleTrialAutoDelete(entry) {
    const now = Date.now();
    const delay = Math.max(0, entry.expiredAt - now);
    const delayMinutes = Math.round(delay / 60000);

    console.log(`⏰ [TrialSchedule] "${entry.username}" (${entry.serviceType}) akan dihapus dalam ${delayMinutes} menit`);

    setTimeout(async () => {
        console.log(`🗑️ [TrialDelete] Memulai hapus trial "${entry.username}" (${entry.serviceType}) dari server ID: ${entry.serverId}`);

        // Reload SERVERS untuk memastikan data terbaru
        const servers = loadServers();
        const server = servers[entry.serverId];

        if (!server) {
            console.log(`❌ [TrialDelete] Server ID "${entry.serverId}" tidak ditemukan, skip hapus trial "${entry.username}"`);
            removeTrialActive(entry.username, entry.serverId);
            return;
        }

        // Hapus dari server
        const result = await deleteTrialFromServer(server, entry.serviceType, entry.username);

        // Hapus dari akun.json lokal
        try {
            const akun = loadAkun();
            if (akun[entry.userId]) {
                akun[entry.userId] = akun[entry.userId].filter(a =>
                    !(a.username === entry.username && a.isTrial === true)
                );
                saveAkun(akun);
                console.log(`🗑️ [TrialDelete] Dihapus dari akun.json lokal untuk user ${entry.userId}`);
            }
        } catch(e) {
            console.log(`[TrialDelete] Gagal hapus dari akun.json: ${e.message}`);
        }

        // Hapus dari trial_active.json
        removeTrialActive(entry.username, entry.serverId);

        // Notifikasi ke user jika chatId tersedia
        if (entry.chatId && isReady) {
            try {
                await sendAutoDelete(
                    entry.chatId,
                    `⏰ *Trial Akun Telah Berakhir*\n\n` +
                    `🔐 Tipe    : *${entry.serviceType.toUpperCase()}*\n` +
                    `👤 Username: *${entry.username}*\n` +
                    `🌐 Server  : *${server.name}*\n\n` +
                    `❌ Akun trial Anda telah dihapus otomatis.\n` +
                    `✅ Silakan buat akun berbayar dengan */menu*`,
                    60000
                );
            } catch(e) {
                console.log(`[TrialDelete] Gagal kirim notif ke user: ${e.message}`);
            }
        }

        console.log(`✅ [TrialDelete] Selesai hapus trial "${entry.username}" dari ${server.name}`);
    }, delay);
}


/**
 * Restore semua scheduler trial saat bot restart
 * Panggil di dalam client.on('ready', ...) setelah isReady = true
 */
function restoreTrialSchedulers() {
    const activeTrials = loadTrialActive();
    const now = Date.now();
    let restored = 0;
    let expired = 0;

    for (const entry of activeTrials) {
        if (entry.expiredAt > now) {
            // Belum expired: schedule hapus
            scheduleTrialAutoDelete(entry);
            restored++;
        } else {
            // Sudah expired saat bot mati: hapus sekarang
            console.log(`🗑️ [TrialRestore] Trial "${entry.username}" sudah expired saat bot mati, hapus segera`);
            (async () => {
                const servers = loadServers();
                const server = servers[entry.serverId];
                if (server) {
                    await deleteTrialFromServer(server, entry.serviceType, entry.username);
                    // Hapus dari akun.json lokal
                    const akun = loadAkun();
                    if (akun[entry.userId]) {
                        akun[entry.userId] = akun[entry.userId].filter(a =>
                            !(a.username === entry.username && a.isTrial === true)
                        );
                        saveAkun(akun);
                    }
                }
                removeTrialActive(entry.username, entry.serverId);
            })();
            expired++;
        }
    }

    console.log(`✅ [TrialRestore] Restored ${restored} scheduler trial aktif, ${expired} langsung dihapus (sudah expired)`);
}


// ============================================================
// LANGKAH 4: Ganti fungsi eksekusiTrial (mulai baris 1983)
// dengan versi di bawah ini yang menyimpan ke trial_active.json
// dan memanggil scheduleTrialAutoDelete
// ============================================================

async function eksekusiTrial(chatId, userId, serviceType, server, duration) {
    const module = getModule(serviceType);
    const loading = await client.sendMessage(chatId, '⏳ Membuat trial...');
    const timestamp = Date.now().toString().slice(-6);
    const username = `trial${timestamp}`;
    const domain = server.apiUrl.split('/')[2]?.split(':')[0] || server.name;

    try {
        let result;

        if (serviceType === 'ssh') {
            result = await module.trialSSH(server, username, duration);
        } else if (serviceType === 'trojan') {
            result = await module.trialTrojan(server, username, duration);
        } else if (serviceType === 'vless') {
            result = await module.trialVless(server, username, duration);
        } else if (serviceType === 'vmess') {
            result = await module.trialVmess(server, username, duration);
        } else if (serviceType === 'zivpn') {
            const pw = `trial${Math.random().toString(36).substring(2, 10)}`;
            result = await module.zivpnCreate(server, pw, 1, 1);
            if (result?.success) result.data = { password: pw, username: pw };
        }

        try { await loading.delete(true); } catch(e) {}

        if (result && result.success) {
            catatTrial(userId);

            // Hitung waktu expired
            const expiredAt = Date.now() + (duration * 60 * 1000);
            const expiredDate = new Date(expiredAt);
            const expiredDisplay = expiredDate.toLocaleString('id-ID', {
                timeZone: 'Asia/Jakarta',
                day: 'numeric', month: 'short', year: 'numeric',
                hour: '2-digit', minute: '2-digit'
            });

            const apiData = result.data || result;
            let uuid = apiData.uuid || apiData.password;

            if ((serviceType === 'vless' || serviceType === 'vmess') && !uuid) {
                const { randomUUID } = require('crypto');
                uuid = randomUUID();
            }

            let password = apiData.password || apiData.uuid || username;

            const akunData = {
                username: username,
                password: password,
                uuid: uuid,
                expired: expiredDisplay,
                iplimit: 1,
                quota: 1,
                duration_minutes: duration,
                domain: domain,
                serviceType: serviceType,
                serverName: server.name
            };

            if (serviceType === 'zivpn') {
                akunData.username = password;
                akunData.password = password;
                akunData.uuid = password;
            }

            tambahAkun(userId, { ...akunData, isTrial: true });

            // =============================================
            // SIMPAN KE trial_active.json & SCHEDULE DELETE
            // =============================================
            const trialEntry = {
                username: serviceType === 'zivpn' ? password : username,
                serviceType: serviceType,
                serverId: server.id,
                serverName: server.name,
                expiredAt: expiredAt,
                userId: userId,
                chatId: chatId,
                createdAt: new Date().toISOString()
            };
            addTrialActive(trialEntry);
            scheduleTrialAutoDelete(trialEntry);
            console.log(`⏰ [Trial] Auto-delete scheduled: "${trialEntry.username}" (${serviceType}) dalam ${duration} menit`);
            // =============================================

            await client.sendMessage(chatId, formatTrialMessage(serviceType, akunData, server.name));
        } else {
            await sendAutoDelete(chatId, `❌ Gagal trial: ${result?.message || 'Unknown'}`);
        }
    } catch(err) {
        try { await loading.delete(true); } catch(e) {}
        await sendAutoDelete(chatId, `❌ Error: ${err.message}`);
    }

    delete processState[userId];
    await showMainMenu(chatId, userId);
}


// ============================================================
// LANGKAH 5: Di dalam client.on('ready', async () => { ... })
// Tambahkan baris ini setelah isReady = true:
//
//   restoreTrialSchedulers();
//   console.log('⏰ [Trial] Auto-delete scheduler restored');
//
// ============================================================
