// bot.js - VPN Bot with QRIS Payment & Auto Approval (Polling + Teks Jadi Satu Pesan)
require('dotenv').config();
const { Client, LocalAuth, Poll } = require('whatsapp-web.js');
const qrcodeTerminal = require('qrcode-terminal');
const QRCode = require('qrcode');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { MessageMedia } = require('whatsapp-web.js');
const FormData = require('form-data');

// Import modules
const sshModule = require('./ssh.js');
const trojanModule = require('./trojan.js');
const vlessModule = require('./vless.js');
const vmessModule = require('./vmess.js');
const zivpnModule = require('./zivpn.js');

// ==================== OPTIMASI ====================
process.removeAllListeners('warning');
process.env.PUPPETEER_SKIP_DOWNLOAD = 'true';
process.env.NODE_NO_WARNINGS = '1';

if (global.gc) {
    setInterval(() => { try { global.gc(); } catch(e) {} }, 60000);
}

// ==================== KONFIGURASI DARI .ENV ====================
const ADMIN_NUMBERS = process.env.ADMIN_NUMBERS
    ? process.env.ADMIN_NUMBERS.split(',').map(n => n.trim().replace('@c.us', ''))
    : [];

// ==================== DYNAMIC ADMIN MANAGEMENT ====================
const ADMIN_FILE = path.join(__dirname, 'admins.json');

function loadAdmins() {
    try {
        if (fs.existsSync(ADMIN_FILE)) {
            return JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf8'));
        }
    } catch(e) {}
    // Inisialisasi dari .env jika file belum ada
    return { admins: [...ADMIN_NUMBERS] };
}

function saveAdmins(adminList) {
    try {
        fs.writeFileSync(ADMIN_FILE, JSON.stringify({ admins: adminList }, null, 2));
        // Update juga di .env agar sinkron
        updateEnvValue('ADMIN_NUMBERS', adminList.join(','));
        return true;
    } catch(e) {
        console.log('Gagal simpan admins:', e.message);
        return false;
    }
}

function getAdminList() {
    const data = loadAdmins();
    return data.admins || [];
}

function addAdmin(number) {
    // Normalisasi ke format 62xxx
    let clean = number.toString().replace(/[^0-9]/g, '');
    if (!isLID(clean)) {
        if (clean.startsWith('0')) clean = '62' + clean.substring(1);
        if (!clean.startsWith('62') && clean.length >= 9) clean = '62' + clean;
    }
    const list = getAdminList();
    // Cek duplikat (cocokkan digits)
    for (const existing of list) {
        if (existing.replace(/[^0-9]/g, '') === clean) return false;
    }
    list.push(clean);
    saveAdmins(list);
    return true;
}

function removeAdmin(number) {
    const clean = number.toString().replace(/[^0-9]/g, '');
    let list = getAdminList();
    const before = list.length;
    list = list.filter(n => n.replace(/[^0-9]/g, '') !== clean);
    if (list.length === before) return false;
    saveAdmins(list);
    return true;
}

// Harga & Paket
// ==================== CONFIG DINAMIS (bisa diubah tanpa restart) ====================
const CONFIG = {
    HARGA_PER_HARI_PER_IP: parseInt(process.env.HARGA_PER_HARI_PER_IP) || 267,
    MAX_TRIAL_MENIT:       parseInt(process.env.MAX_TRIAL_MENIT)        || 60,
    MAX_TRIAL_PER_USER:    parseInt(process.env.MAX_TRIAL_PER_USER)     || 1,
    MAX_IP_LIMIT:          parseInt(process.env.MAX_IP_LIMIT)           || 5,
    DEFAULT_QUOTA:         parseInt(process.env.DEFAULT_QUOTA)          || 100,
    MIN_TOPUP:             parseInt(process.env.MIN_TOPUP)              || 10000,
    MERCHANT_NAME:         process.env.MERCHANT_NAME                    || 'PEYX STORE',
};

function updateConfig(key, value) {
    CONFIG[key] = value;
    updateEnvValue(key, value.toString());
    console.log(`Config updated: ${key} = ${value}`);
}
// ==================== TELEGRAM CONFIG ====================
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_ADMIN_ID = process.env.TELEGRAM_ADMIN_ID;
const TELEGRAM_GROUP_ID = process.env.TELEGRAM_GROUP_ID;

console.log('📱 Telegram Bot Token:', TELEGRAM_BOT_TOKEN ? '✅ Loaded' : '❌ Not found');
console.log('👤 Telegram Admin ID:', TELEGRAM_ADMIN_ID ? '✅ Loaded' : '❌ Not found');
console.log('👥 Telegram Group ID:', TELEGRAM_GROUP_ID ? '✅ Loaded' : '❌ Not found');

// QRIS Dinamis
const QRIS_STATIS          = process.env.QRIS_STATIS          || '';
const QRIS_API_URL         = process.env.QRIS_API_URL          || 'https://api-mininxd.vercel.app/qris';
// CONFIG.MERCHANT_NAME dan CONFIG.MIN_TOPUP sudah dipindah ke CONFIG object di atas

// File paths
const CONFIG_FILE       = path.join(__dirname, 'server.json');
const SALDO_FILE        = path.join(__dirname, 'saldo.json');
const TRANSAKSI_FILE    = path.join(__dirname, 'transaksi.json');
const TRIAL_FILE        = path.join(__dirname, 'trial.json');
const TRIAL_ACTIVE_FILE = path.join(__dirname, 'trial_active.json'); // trial aktif yang belum expired
const AKUN_FILE         = path.join(__dirname, 'akun.json');
const USERNAMES_FILE    = path.join(__dirname, 'usernames.json');
const QRIS_CENTER_ICON  = path.join(__dirname, 'assets', 'icon.png');
const SESSION_PATH      = path.join(__dirname, 'session');

// ==================== CLEANUP SESSION LOCK ====================
const lockFiles = [
    path.join(SESSION_PATH, 'SingletonLock'),
    path.join(SESSION_PATH, 'SingletonSocket'),
    path.join(SESSION_PATH, 'SingletonCookie'),
    path.join(SESSION_PATH, 'lockfile')
];

for (const lockFile of lockFiles) {
    if (fs.existsSync(lockFile)) {
        try {
            fs.unlinkSync(lockFile);
            console.log(`🗑️ Deleted lock file: ${lockFile}`);
        } catch(e) {}
    }
}

// ==================== CLIENT ====================
const client = new Client({
    authStrategy: new LocalAuth({ 
        clientId: "vpn-bot", 
        dataPath: SESSION_PATH 
    }),
    puppeteer: {
        headless: true,
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-gpu',
            '--disable-software-rasterizer',
            '--disable-extensions',
            '--disable-background-timer-throttling',
            '--disable-backgrounding-occluded-windows',
            '--disable-renderer-backgrounding',
            '--disable-ipc-flooding-protection',
            '--no-default-browser-check',
            '--no-first-run',
            '--disk-cache-size=0',
            '--media-cache-size=0',
            '--log-level=3',
            '--silent',
            '--max-old-space-size=512'
        ],
        timeout: 60000,
        dumpio: false,
        ignoreHTTPSErrors: true,
        defaultViewport: null
    },
    qrMaxRetries: 5,
    takeoverTimeoutMs: 60000,
    takeoverOnConflict: true
});

const BOT_START_TIME = Date.now();
let SERVERS = {};
let isReady = false;

// State management
let processState     = {};
let serverSelState   = {};
let pendingQRIS      = {};

// ==================== PERSISTENT POLL STATE ====================
const POLL_STATE_FILE = path.join(__dirname, 'pollstate.json');

function loadPollState() {
    try {
        if (fs.existsSync(POLL_STATE_FILE)) {
            const raw = JSON.parse(fs.readFileSync(POLL_STATE_FILE, 'utf8'));
            const map = new Map();
            for (const [k, v] of Object.entries(raw)) {
                map.set(k, v);
            }
            console.log(`📂 Loaded ${map.size} poll states from file`);
            return map;
        }
    } catch(e) {
        console.log('⚠️ Failed to load pollstate.json:', e.message);
    }
    return new Map();
}

function savePollState() {
    try {
        const obj = {};
        for (const [k, v] of pollState.entries()) {
            obj[k] = v;
        }
        fs.writeFileSync(POLL_STATE_FILE, JSON.stringify(obj, null, 2));
    } catch(e) {
        console.log('⚠️ Failed to save pollstate.json:', e.message);
    }
}

let pollState = loadPollState();

// Anti duplicate & spam
const processedMessages = new Map();
const userLastCommand   = new Map();
const userLocks         = new Map();
const userRateLimits    = new Map();

// Cache nama user
const userNamesCache = new Map();

// ==================== QUEUE SYSTEM ====================
const messageQueue = [];
let isProcessingQueue = false;
const MAX_CONCURRENT = 3;
let activeProcesses = 0;
const userLastResponse = new Map();

// File operation queue
const fileQueue = [];
let isFileWriting = false;

async function writeFileAsync(filePath, data) {
    return new Promise((resolve, reject) => {
        fileQueue.push({ filePath, data, resolve, reject });
        processFileQueue();
    });
}

async function processFileQueue() {
    if (isFileWriting || fileQueue.length === 0) return;
    
    isFileWriting = true;
    const { filePath, data, resolve, reject } = fileQueue.shift();
    
    try {
        await fs.promises.writeFile(filePath, JSON.stringify(data, null, 2));
        resolve();
    } catch (error) {
        reject(error);
    } finally {
        isFileWriting = false;
        setTimeout(processFileQueue, 10);
    }
}

async function addToQueue(msg) {
    return new Promise((resolve) => {
        messageQueue.push({ msg, resolve, timestamp: Date.now() });
        processMessageQueue();
    });
}

async function processMessageQueue() {
    if (isProcessingQueue || messageQueue.length === 0) return;
    
    isProcessingQueue = true;
    
    while (messageQueue.length > 0 && activeProcesses < MAX_CONCURRENT) {
        const item = messageQueue.shift();
        
        if (Date.now() - item.timestamp > 10000) {
            item.resolve();
            continue;
        }
        
        activeProcesses++;
        
        (async () => {
            try {
                await handleMessageWithLock(item.msg);
            } catch (error) {
                console.error('Queue error:', error);
            } finally {
                activeProcesses--;
                item.resolve();
                setTimeout(() => processMessageQueue(), 10);
            }
        })();
    }
    
    isProcessingQueue = false;
}

async function withUserLock(userId, callback) {
    let waitCount = 0;
    while (userLocks.get(userId) && waitCount < 50) {
        await new Promise(resolve => setTimeout(resolve, 100));
        waitCount++;
    }
    
    if (userLocks.get(userId)) return null;
    
    userLocks.set(userId, true);
    try {
        return await callback();
    } finally {
        setTimeout(() => userLocks.set(userId, false), 50);
    }
}

function checkRateLimit(userId) {
    const now = Date.now();
    const userLimit = userRateLimits.get(userId) || [];
    const recent = userLimit.filter(time => now - time < 2000);
    
    if (recent.length >= 5) return false;
    
    recent.push(now);
    userRateLimits.set(userId, recent);
    return true;
}

function isDuplicate(messageId) {
    const now = Date.now();
    const existing = processedMessages.get(messageId);
    
    if (existing && (now - existing) < 10000) return true;
    
    processedMessages.set(messageId, now);
    
    for (const [id, timestamp] of processedMessages) {
        if (now - timestamp > 30000) processedMessages.delete(id);
    }
    
    return false;
}

async function sendReaction(msg, emoji) {
    try {
        if (msg && msg.react) {
            await msg.react(emoji);
            console.log(`✅ Reaction ${emoji} sent`);
        }
    } catch(e) {
        console.log(`❌ Failed to send reaction: ${e.message}`);
    }
}

// ==================== AUTO DELETE HELPER ====================
// Kirim pesan lalu hapus otomatis setelah delayMs (default 30 detik)
// Pesan result akun (create/renew/trial success) TIDAK pakai ini
async function sendAutoDelete(chatId, text, delayMs = 30000) {
    try {
        const sent = await client.sendMessage(chatId, text);
        setTimeout(async () => {
            try {
                await sent.delete(true); // true = hapus untuk semua orang
            } catch(e) {
                console.log(`[AutoDelete] Gagal hapus pesan: ${e.message}`);
            }
        }, delayMs);
        return sent;
    } catch(e) {
        console.log(`[sendAutoDelete] Error: ${e.message}`);
        return null;
    }
}

// Hapus pesan setelah delay
async function deleteAfter(msg, delayMs = 30000) {
    if (!msg) return;
    setTimeout(async () => {
        try {
            await msg.delete(true);
        } catch(e) {
            console.log(`[deleteAfter] Gagal hapus: ${e.message}`);
        }
    }, delayMs);
}

// ==================== HELPER ====================
function getCleanUserId(userId) {
    return userId.toString().replace('@c.us', '').replace('@lid', '');
}

// ==================== FORMAT ADMIN ID ====================
function formatAdminId(admin) {
    let adminId = admin.toString().trim();
    
    // Jika sudah dalam format yang benar, return
    if (adminId.includes('@c.us') || adminId.includes('@lid')) {
        return adminId;
    }
    
    // Jika hanya angka (User ID), tambahkan @c.us
    if (/^\d+$/.test(adminId)) {
        return adminId + '@c.us';
    }
    
    // Jika nomor telepon dimulai dengan 62 atau 08
    if (adminId.startsWith('62') || adminId.startsWith('0')) {
        return adminId + '@c.us';
    }
    
    // Default
    return adminId + '@c.us';
}

// ==================== UPDATE ENV VALUE ====================
function updateEnvValue(key, value) {
    try {
        const envPath = path.join(__dirname, '.env');
        let content = fs.readFileSync(envPath, 'utf8');
        const regex = new RegExp(`^${key}=.*$`, 'm');
        const newLine = `${key}=${value}`;
        
        if (regex.test(content)) {
            content = content.replace(regex, newLine);
        } else {
            content += `\n${newLine}`;
        }
        
        fs.writeFileSync(envPath, content, 'utf8');
        console.log(`✅ Updated .env: ${key}=${value}`);
        return true;
    } catch(e) {
        console.log('Gagal update .env:', e.message);
        return false;
    }
}

// ==================== PM2 RESTART FUNCTION ====================
async function restartBotWithPM2(chatId, userId, perubahan) {
    try {
        const { exec } = require('child_process');
        
        await sendAutoDelete(chatId, `✅ *${perubahan} berhasil diubah!*\n\n🔄 *Memulai ulang bot...*\n⏳ Mohon tunggu 10-15 detik.\n\n_Bot akan otomatis restart menggunakan systemctl_`);
        
        exec('systemctl restart wa-bot', (error, stdout, stderr) => {
            if (error) {
                console.error(`❌ Restart error: ${error.message}`);
                client.sendMessage(chatId, `❌ Gagal merestart otomatis. Silakan restart manual: *systemctl restart wa-bot*`);
            } else {
                console.log(`✅ Bot restart initiated via systemctl`);
            }
        });
        
        setTimeout(() => {
            process.exit(0);
        }, 2000);
        
    } catch(e) {
        console.error('Restart error:', e.message);
        await sendAutoDelete(chatId, `❌ Gagal merestart bot: ${e.message}\nSilakan restart manual: *systemctl restart wa-bot*`);
    }
}

// ==================== AUTO CLEANUP FILES ====================
// DEFINISIKAN TEMP_DIR DULU SEBELUM DIPAKAI
const TEMP_DIR = path.join(__dirname, 'temp');

// Buat folder temp jika belum ada
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR);
}

// Fungsi untuk menghapus file setelah waktu tertentu
async function scheduleFileDelete(filePath, delayMs = 600000) {
    setTimeout(() => {
        try {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log(`🗑️ Deleted temp file: ${filePath}`);
            }
        } catch(e) {
            console.log(`Failed to delete ${filePath}:`, e.message);
        }
    }, delayMs);
}

// Fungsi untuk membersihkan semua file temp lama
function cleanupOldTempFiles() {
    try {
        if (!fs.existsSync(TEMP_DIR)) return;
        const files = fs.readdirSync(TEMP_DIR);
        const now = Date.now();
        const oneHourAgo = now - 3600000;
        let deleted = 0;
        
        for (const file of files) {
            const filePath = path.join(TEMP_DIR, file);
            try {
                const stats = fs.statSync(filePath);
                if (stats.mtimeMs < oneHourAgo) {
                    fs.unlinkSync(filePath);
                    deleted++;
                    console.log(`🗑️ Cleaned old temp file: ${file}`);
                }
            } catch(e) {}
        }
        if (deleted > 0) console.log(`🗑️ Cleaned ${deleted} old temp files`);
    } catch(e) {
        console.log('Cleanup error:', e.message);
    }
}

// ==================== CLEANUP EXPIRED PENDING PAYMENTS ====================
setInterval(async () => {
    const now = Date.now();
    let expiredCount = 0;
    
    for (const [userId, pending] of Object.entries(pendingQRIS)) {
        if (pending.expiresAt && now > pending.expiresAt) {
            delete pendingQRIS[userId];
            expiredCount++;
            console.log(`🗑️ Cleaned expired pending payment for ${userId}`);

            // Hapus pesan QRIS untuk semua orang
            if (pending.qrMessageId) {
                try {
                    const msgToDelete = await client.getMessageById(pending.qrMessageId);
                    if (msgToDelete) await msgToDelete.delete(true);
                } catch(e) {
                    console.log(`[Cleanup] Gagal hapus QR msg: ${e.message}`);
                }
            }

            // Kirim notif expired ke user, auto-delete 30 detik
            if (pending.chatId) {
                try {
                    await sendAutoDelete(pending.chatId,
                        `⏰ *Waktu pembayaran telah habis!*\n\n` +
                        `Kode TX: \`${pending.txId}\`\n` +
                        `Nominal: ${formatRp(pending.amount)}\n\n` +
                        `Silakan lakukan topup ulang dengan memilih *Topup Saldo* di menu.`,
                        30000
                    );
                } catch(e) {}
            }
        }
    }
    
    if (expiredCount > 0) {
        console.log(`🗑️ Cleaned ${expiredCount} expired pending payments`);
    }
}, 60000); // Cek setiap 1 menit

// Jalankan cleanup file saat startup
cleanupOldTempFiles();

// Jalankan cleanup file setiap 30 menit
setInterval(cleanupOldTempFiles, 30 * 60 * 1000);

// ==================== CACHE LID -> NOMOR TELEPON ====================
// WhatsApp terbaru pakai LID (angka panjang) bukan nomor langsung
const LID_PHONE_FILE = path.join(__dirname, 'lid_phone.json');
const lidPhoneCache = new Map();

function loadLidPhoneCache() {
    try {
        if (fs.existsSync(LID_PHONE_FILE)) {
            const data = JSON.parse(fs.readFileSync(LID_PHONE_FILE, 'utf8'));
            for (const [lid, phone] of Object.entries(data)) {
                lidPhoneCache.set(lid, phone);
            }
            console.log(`📂 Loaded ${lidPhoneCache.size} LID->Phone mappings`);
        }
    } catch(e) {}
}

function saveLidPhoneCache() {
    try {
        const obj = {};
        for (const [lid, phone] of lidPhoneCache.entries()) {
            obj[lid] = phone;
        }
        fs.writeFileSync(LID_PHONE_FILE, JSON.stringify(obj, null, 2));
    } catch(e) {}
}

function cacheLidPhone(lid, phone) {
    if (!lid || !phone) return;
    const cleanLid = lid.toString().replace(/[^0-9]/g, '');
    const cleanPhone = phone.toString().replace(/[^0-9]/g, '');
    if (!cleanLid || !cleanPhone) return;
    if (lidPhoneCache.get(cleanLid) === cleanPhone) return; // sudah sama
    lidPhoneCache.set(cleanLid, cleanPhone);
    saveLidPhoneCache();
    console.log(`🔗 Cached LID->Phone: ${cleanLid} -> ${cleanPhone}`);
}

// Muat cache saat startup
loadLidPhoneCache();

// Deteksi apakah ID adalah LID (bukan nomor telepon)
// LID biasanya angka > 13 digit atau tidak diawali 62/08/+62
function isLID(id) {
    const clean = id.toString().replace(/[^0-9]/g, '');
    // Nomor telepon Indonesia: 10-14 digit, diawali 62 atau 08
    if (clean.startsWith('62') && clean.length >= 10 && clean.length <= 15) return false;
    if (clean.startsWith('0') && clean.length >= 9 && clean.length <= 14) return false;
    // LID: angka panjang yang bukan format nomor telepon
    if (clean.length > 14) return true;
    return false;
}

// ==================== MENDAPATKAN NOMOR TELEPON ====================
async function getPhoneNumberFromId(userId) {
    const cleanId = getCleanUserId(userId);
    
    // Cek cache LID dulu
    if (isLID(cleanId)) {
        const cached = lidPhoneCache.get(cleanId.replace(/[^0-9]/g, ''));
        if (cached) {
            console.log(`📞 LID cache hit: ${cleanId} -> ${cached}`);
            return cached;
        }
    }
    
    // Coba via kontak WhatsApp
    // Coba dengan @lid dulu (untuk LID), lalu @c.us
    const tryIds = [];
    if (isLID(cleanId)) {
        tryIds.push(cleanId + '@lid');
        tryIds.push(cleanId + '@c.us');
    } else {
        tryIds.push(cleanId + '@c.us');
        tryIds.push(cleanId + '@lid');
    }
    
    for (const contactId of tryIds) {
        try {
            const contact = await client.getContactById(contactId);
            let phoneNumber = contact.number || contact.id.user || '';
            
            // Jika dapat nomor dari @lid, coba juga ambil nomor asli dari properti lain
            if (contact.id && contact.id._serialized) {
                // Format: 628xxx@c.us
                const fromSerial = contact.id._serialized.replace('@c.us', '').replace('@lid', '').replace(/[^0-9]/g, '');
                if (fromSerial && !isLID(fromSerial)) {
                    phoneNumber = fromSerial;
                }
            }
            
            phoneNumber = phoneNumber.toString().replace(/[^0-9]/g, '');
            
            if (!phoneNumber || isLID(phoneNumber)) continue;
            
            // Normalisasi ke format 62xxx
            if (phoneNumber.startsWith('0')) {
                phoneNumber = '62' + phoneNumber.substring(1);
            }
            if (!phoneNumber.startsWith('62') && phoneNumber.length >= 9) {
                phoneNumber = '62' + phoneNumber;
            }
            
            // Simpan ke cache jika ini LID
            if (isLID(cleanId)) {
                cacheLidPhone(cleanId, phoneNumber);
            }
            
            console.log(`📞 Convert ID ${userId} -> Phone: ${phoneNumber}`);
            return phoneNumber;
        } catch(e) {
            // Lanjut ke tryId berikutnya
        }
    }
    
    // Fallback: kembalikan cleanId apa adanya
    console.log(`⚠️ Gagal resolve nomor untuk ${userId}, pakai cleanId: ${cleanId}`);
    return cleanId;
}

// ==================== CEK ADMIN ====================
async function isAdminAsync(userId) {
    const cleanId = getCleanUserId(userId);
    const currentAdmins = getAdminList();
    
    // Cek 1: cocokkan LID langsung (jika admin disimpan sebagai LID)
    const cleanIdNum = cleanId.replace(/[^0-9]/g, '');
    for (const admin of currentAdmins) {
        const cleanAdmin = admin.toString().replace(/[^0-9]/g, '');
        if (cleanIdNum === cleanAdmin) {
            console.log(`✅ Admin match (direct ID): ${cleanIdNum}`);
            return true;
        }
    }
    
    // Cek 2: coba resolve ke nomor telepon lalu cocokkan
    const phoneNumber = await getPhoneNumberFromId(userId);
    
    console.log(`🔍 Cek admin untuk: ID=${cleanId}, Phone=${phoneNumber}`);
    console.log(`📋 Daftar admin aktif: ${currentAdmins.join(', ')}`);
    
    // Jika nomor masih LID (gagal resolve), tidak bisa cocokkan
    if (isLID(phoneNumber)) {
        console.log(`⚠️ Gagal resolve ke nomor, LID belum di-cache: ${phoneNumber}`);
        return false;
    }
    
    for (const admin of currentAdmins) {
        const cleanAdmin = admin.toString().replace(/[^0-9]/g, '');
        if (phoneNumber === cleanAdmin) {
            // Simpan LID ke cache agar pengecekan berikutnya langsung match
            if (isLID(cleanId)) cacheLidPhone(cleanId, phoneNumber);
            console.log(`✅ Admin match (phone): ${phoneNumber} === ${cleanAdmin}`);
            return true;
        }
        if (phoneNumber === '0' + cleanAdmin.substring(2)) {
            if (isLID(cleanId)) cacheLidPhone(cleanId, phoneNumber);
            console.log(`✅ Admin match (0 format): ${phoneNumber}`);
            return true;
        }
        if (phoneNumber === cleanAdmin.substring(2) && cleanAdmin.startsWith('62')) {
            if (isLID(cleanId)) cacheLidPhone(cleanId, phoneNumber);
            console.log(`✅ Admin match (no 62): ${phoneNumber}`);
            return true;
        }
    }
    
    console.log(`❌ Bukan admin: ${phoneNumber}`);
    return false;
}

function formatRp(amount) {
    return 'Rp ' + amount.toLocaleString('id-ID');
}

function formatTimestamp() {
    return new Date().toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta', day: 'numeric', month: 'short',
        year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
}

function getHeader(title) {
    return `╔══━━────── • ──────━━══╗\n   ${title}\n╚══━━────── • ──────━━══╝`;
}

function getGreeting() {
    const now = new Date();
    const hours = now.getHours();
    if (hours >= 3 && hours < 11) return "🌅 Selamat Pagi";
    else if (hours >= 11 && hours < 15) return "☀️ Selamat Siang";
    else if (hours >= 15 && hours < 18) return "🌇 Selamat Sore";
    else return "🌙 Selamat Malam";
}

function hitungHarga(days, iplimit) {
    return CONFIG.HARGA_PER_HARI_PER_IP * days * iplimit;
}

function formatHarga() {
    return `${formatRp(CONFIG.HARGA_PER_HARI_PER_IP)}/hari/IP`;
}

// ==================== SEND POLL (TEKS + POLLING JADI SATU) ====================
async function sendPoll(chatId, userId, textMenu, options, type, context = {}) {
    // Gabungkan teks menu dengan pertanyaan polling
    const question = textMenu + '\n\n📋 Pilih menu di bawah ini:';
    
    const poll = new Poll(question, options, { allowMultipleAnswers: false });
    const sent = await client.sendMessage(chatId, poll);
    
    const cleanUserId = getCleanUserId(userId);
    pollState.set(sent.id._serialized, {
        userId: cleanUserId,
        chatId: chatId,
        type, 
        options, 
        context, 
        timestamp: Date.now()
    });
    
    // Simpan ke file agar tetap ada walau bot restart / user keluar chat
    // Poll TIDAK pernah expired - tetap bisa diklik kapan saja
    savePollState();
    return sent;
}

// ==================== AKUN MANAGEMENT ====================
function loadAkun() {
    try {
        if (fs.existsSync(AKUN_FILE)) {
            return JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        }
    } catch(e) {}
    return {};
}

function saveAkun(data) {
    writeFileAsync(AKUN_FILE, data);
}

function tambahAkun(userId, akunInfo) {
    const akun = loadAkun();
    if (!akun[userId]) akun[userId] = [];
    akun[userId].push({
        ...akunInfo,
        createdAt: new Date().toISOString(),
        status: 'active'
    });
    saveAkun(akun);
}

function getJumlahAkun(userId) {
    const akun = loadAkun();
    return akun[userId] ? akun[userId].length : 0;
}

function getAllAkunCount() {
    const akun = loadAkun();
    let total = 0;
    for (const userId in akun) {
        total += akun[userId].length;
    }
    return total;
}

// ==================== SALDO MANAGEMENT ====================
function loadSaldo() {
    try {
        if (fs.existsSync(SALDO_FILE)) {
            return JSON.parse(fs.readFileSync(SALDO_FILE, 'utf8'));
        }
    } catch(e) {}
    return {};
}

function saveSaldo(data) {
    writeFileAsync(SALDO_FILE, data);
}

function getSaldo(userId) {
    const data = loadSaldo();
    return data[userId] || 0;
}

function setSaldo(userId, amount) {
    const data = loadSaldo();
    data[userId] = Math.max(0, amount);
    saveSaldo(data);
    return true;
}

function tambahSaldo(userId, amount) {
    const cur = getSaldo(userId);
    const newAmount = cur + amount;
    setSaldo(userId, newAmount);
    return newAmount;
}

function kurangiSaldo(userId, amount) {
    const cur = getSaldo(userId);
    if (cur < amount) return false;
    const newAmount = cur - amount;
    setSaldo(userId, newAmount);
    return true;
}

// ==================== TRANSAKSI MANAGEMENT ====================
function loadTransaksi() {
    try {
        if (fs.existsSync(TRANSAKSI_FILE)) {
            return JSON.parse(fs.readFileSync(TRANSAKSI_FILE, 'utf8'));
        }
    } catch(e) {}
    return [];
}

function simpanTransaksi(tx) {
    const data = loadTransaksi();
    data.unshift(tx);
    if (data.length > 1000) data.splice(1000);
    writeFileAsync(TRANSAKSI_FILE, data);
}

function generateTxId() {
    return 'TX' + Date.now().toString().slice(-8) + Math.floor(Math.random()*100).toString().padStart(2,'0');
}

// ==================== TRIAL MANAGEMENT ====================
function loadTrialData() {
    try {
        if (fs.existsSync(TRIAL_FILE)) {
            return JSON.parse(fs.readFileSync(TRIAL_FILE, 'utf8'));
        }
    } catch(e) {}
    return {};
}

function saveTrialData(data) {
    writeFileAsync(TRIAL_FILE, data);
}

function cekBisaTrial(userId) {
    const data = loadTrialData();
    const today = new Date().toDateString();
    const userTrials = data[userId] || [];
    const trialsToday = userTrials.filter(t => new Date(t).toDateString() === today);
    return trialsToday.length < CONFIG.MAX_TRIAL_PER_USER;
}

function catatTrial(userId) {
    const data = loadTrialData();
    if (!data[userId]) data[userId] = [];
    data[userId].push(new Date().toISOString());
    saveTrialData(data);
}

// ==================== TRIAL ACTIVE MANAGEMENT (AUTO-DELETE) ====================
function loadTrialActive() {
    try {
        if (fs.existsSync(TRIAL_ACTIVE_FILE)) {
            return JSON.parse(fs.readFileSync(TRIAL_ACTIVE_FILE, 'utf8'));
        }
    } catch(e) {}
    return [];
}

function saveTrialActive(data) {
    try {
        fs.writeFileSync(TRIAL_ACTIVE_FILE, JSON.stringify(data, null, 2));
    } catch(e) {
        console.log('[TrialActive] Gagal simpan:', e.message);
    }
}

function addTrialActive(entry) {
    const data = loadTrialActive();
    const filtered = data.filter(t => !(t.username === entry.username && t.serverId === entry.serverId));
    filtered.push(entry);
    saveTrialActive(filtered);
}

function removeTrialActive(username, serverId) {
    const data = loadTrialActive();
    const filtered = data.filter(t => !(t.username === username && t.serverId === serverId));
    saveTrialActive(filtered);
}

async function deleteTrialFromServer(server, serviceType, username) {
    try {
        const mod = getModule(serviceType);
        let result;
        if (serviceType === 'ssh') {
            result = await mod.deleteSSH(server, username);
        } else if (serviceType === 'trojan') {
            result = await mod.deleteTrojan(server, username);
        } else if (serviceType === 'vless') {
            result = await mod.deleteVless(server, username);
        } else if (serviceType === 'vmess') {
            result = await mod.deleteVmess(server, username);
        } else if (serviceType === 'zivpn') {
            result = await mod.zivpnDelete(server, username);
        } else {
            result = { success: false, message: `Tipe tidak dikenal: ${serviceType}` };
        }
        if (result && result.success) {
            console.log(`✅ [TrialDelete] Berhasil hapus ${serviceType.toUpperCase()} "${username}" dari ${server.name}`);
        } else {
            console.log(`⚠️ [TrialDelete] Gagal hapus "${username}": ${result?.message || 'Unknown'}`);
        }
        return result;
    } catch(err) {
        console.log(`❌ [TrialDelete] Error hapus "${username}": ${err.message}`);
        return { success: false, message: err.message };
    }
}

function scheduleTrialAutoDelete(entry) {
    const now = Date.now();
    const delay = Math.max(0, entry.expiredAt - now);
    const delayMinutes = Math.round(delay / 60000);
    console.log(`⏰ [TrialSchedule] "${entry.username}" (${entry.serviceType}) dihapus dalam ${delayMinutes} menit`);

    setTimeout(async () => {
        console.log(`🗑️ [TrialDelete] Hapus trial "${entry.username}" (${entry.serviceType}), server: ${entry.serverId}`);

        const servers = loadServers();
        const server = servers[entry.serverId];

        if (!server) {
            console.log(`❌ [TrialDelete] Server "${entry.serverId}" tidak ditemukan, skip`);
            removeTrialActive(entry.username, entry.serverId);
            return;
        }

        // Hapus dari server via API
        await deleteTrialFromServer(server, entry.serviceType, entry.username);

        // Hapus dari akun.json lokal
        try {
            const akun = loadAkun();
            if (akun[entry.userId]) {
                akun[entry.userId] = akun[entry.userId].filter(a =>
                    !(a.username === entry.username && a.isTrial === true)
                );
                saveAkun(akun);
            }
        } catch(e) {
            console.log(`[TrialDelete] Gagal hapus dari akun.json: ${e.message}`);
        }

        // Hapus dari trial_active.json
        removeTrialActive(entry.username, entry.serverId);

        // Notifikasi ke user
        if (entry.chatId && isReady) {
            try {
                await sendAutoDelete(
                    entry.chatId,
                    `⏰ *Trial Akun Telah Berakhir*\n\n` +
                    `🔐 Tipe    : *${entry.serviceType.toUpperCase()}*\n` +
                    `👤 Username: *${entry.username}*\n` +
                    `🌐 Server  : *${server.name}*\n\n` +
                    `❌ Akun trial Anda telah dihapus otomatis.\n` +
                    `✅ Silakan buat akun berbayar dengan */menu*`,
                    60000
                );
            } catch(e) {
                console.log(`[TrialDelete] Gagal kirim notif: ${e.message}`);
            }
        }

        console.log(`✅ [TrialDelete] Selesai: "${entry.username}" dari ${server.name}`);
    }, delay);
}

function restoreTrialSchedulers() {
    const activeTrials = loadTrialActive();
    const now = Date.now();
    let restored = 0;
    let expired = 0;

    for (const entry of activeTrials) {
        if (entry.expiredAt > now) {
            scheduleTrialAutoDelete(entry);
            restored++;
        } else {
            console.log(`🗑️ [TrialRestore] "${entry.username}" sudah expired, hapus segera`);
            (async () => {
                const servers = loadServers();
                const server = servers[entry.serverId];
                if (server) {
                    await deleteTrialFromServer(server, entry.serviceType, entry.username);
                    const akun = loadAkun();
                    if (akun[entry.userId]) {
                        akun[entry.userId] = akun[entry.userId].filter(a =>
                            !(a.username === entry.username && a.isTrial === true)
                        );
                        saveAkun(akun);
                    }
                }
                removeTrialActive(entry.username, entry.serverId);
            })();
            expired++;
        }
    }
    console.log(`✅ [TrialRestore] ${restored} scheduler restored, ${expired} langsung dihapus (expired)`);
}

// ==================== SERVER MANAGEMENT ====================
// ==================== SERVER MANAGEMENT ====================
function loadServers() {
    try {
        if (fs.existsSync(CONFIG_FILE)) {
            const data = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
            const servers = data.servers || {};
            const formatted = {};
            for (const [id, info] of Object.entries(servers)) {
                formatted[id] = {
                    id, 
                    name: info.name || `Server ${id}`,
                    apiUrl: (info.api_url || '').replace(/\/$/, ''),
                    authKey: info.auth_key || '',
                    type: info.type || 'ssh',  // type: ssh, xray, zivpn
                    serviceType: info.service_type || null  // untuk xray: vmess, vless, trojan
                };
            }
            return formatted;
        }
    } catch(e) {}
    return {};
}

function saveServers(servers) {
    const data = { servers: {} };
    for (const [id, info] of Object.entries(servers)) {
        data.servers[id] = { 
            name: info.name, 
            api_url: info.apiUrl, 
            auth_key: info.authKey, 
            type: info.type,
            service_type: info.serviceType || null
        };
    }
    writeFileAsync(CONFIG_FILE, data);
}

function generateServerId() {
    let num = 1;
    while (Object.keys(SERVERS).includes(`server${num}`)) num++;
    return `server${num}`;
}

SERVERS = loadServers();

// ==================== USERNAME MANAGEMENT ====================
function loadUserNames() {
    try {
        if (fs.existsSync(USERNAMES_FILE)) {
            return JSON.parse(fs.readFileSync(USERNAMES_FILE, 'utf8'));
        }
    } catch(e) {}
    return {};
}

function saveUserNames(names) {
    writeFileAsync(USERNAMES_FILE, names);
}

async function getUserName(userId) {
    const cleanId = getCleanUserId(userId);
    
    // Cek cache memory dulu
    if (userNamesCache.has(cleanId)) {
        const cached = userNamesCache.get(cleanId);
        if (cached && cached !== 'User' && cached !== 'Guest' && cached !== cleanId) {
            console.log(`📛 Using cached name: ${cached}`);
            return cached;
        }
    }
    
    // Cek file usernames.json
    const savedNames = loadUserNames();
    if (savedNames[cleanId] && savedNames[cleanId] !== 'User' && savedNames[cleanId] !== 'Guest' && savedNames[cleanId] !== cleanId) {
        userNamesCache.set(cleanId, savedNames[cleanId]);
        console.log(`📛 Using saved name: ${savedNames[cleanId]}`);
        return savedNames[cleanId];
    }
    
    try {
        // Format ID yang benar untuk WhatsApp
        let contactId = cleanId;
        if (!contactId.includes('@c.us') && !contactId.includes('@s.whatsapp.net')) {
            contactId = cleanId + '@c.us';
        }
        
        console.log(`🔍 Fetching contact for: ${contactId}`);
        const contact = await client.getContactById(contactId);
        
        // Debug: lihat semua properti yang tersedia
        console.log(`📋 Contact data:`, {
            pushname: contact.pushname,
            name: contact.name,
            shortName: contact.shortName,
            verifiedName: contact.verifiedName,
            number: contact.number
        });
        
        // Ambil nama dengan prioritas
        let name = null;
        
        if (contact.pushname && contact.pushname !== 'undefined' && contact.pushname.trim().length > 0) {
            name = contact.pushname;
            console.log(`✅ Got pushname: ${name}`);
        } else if (contact.name && contact.name !== 'undefined' && contact.name.trim().length > 0) {
            name = contact.name;
            console.log(`✅ Got name: ${name}`);
        } else if (contact.shortName && contact.shortName !== 'undefined' && contact.shortName.trim().length > 0) {
            name = contact.shortName;
            console.log(`✅ Got shortName: ${name}`);
        } else if (contact.verifiedName && contact.verifiedName !== 'undefined' && contact.verifiedName.trim().length > 0) {
            name = contact.verifiedName;
            console.log(`✅ Got verifiedName: ${name}`);
        } else {
            // Jika tidak ada nama, gunakan nomor telepon
            name = contact.number || cleanId;
            console.log(`⚠️ Using number as name: ${name}`);
        }
        
        // Bersihkan nama
        name = name.replace(/[^\w\s\-\.]/gi, '').trim();
        if (name.length === 0 || name === 'undefined') {
            name = 'User';
        }
        
        // Simpan ke cache dan file
        userNamesCache.set(cleanId, name);
        savedNames[cleanId] = name;
        saveUserNames(savedNames);
        
        console.log(`💾 Saved username: ${cleanId} -> "${name}"`);
        return name;
        
    } catch(e) {
        console.log(`❌ Gagal ambil nama untuk ${cleanId}: ${e.message}`);
        
        // Fallback: coba ambil dari pesan yang pernah dikirim
        try {
            const messages = await client.searchMessages('', { fromMe: false, limit: 1 });
            for (const msg of messages) {
                const msgUserId = getCleanUserId(msg.author || msg.from);
                if (msgUserId === cleanId) {
                    if (msg._data && msg._data.pushName) {
                        const msgName = msg._data.pushName.replace(/[^\w\s\-\.]/gi, '').trim();
                        if (msgName && msgName.length > 0) {
                            userNamesCache.set(cleanId, msgName);
                            savedNames[cleanId] = msgName;
                            saveUserNames(savedNames);
                            console.log(`💾 Got name from message: ${msgName}`);
                            return msgName;
                        }
                    }
                }
            }
        } catch(err) {}
        
        return 'User';
    }
}

// ==================== QRIS FUNCTIONS ====================
async function generateQRISDinamis(amount) {
    if (!QRIS_STATIS) throw new Error('QRIS_STATIS belum dikonfigurasi di .env');
    const url = `${QRIS_API_URL}?qris=${encodeURIComponent(QRIS_STATIS)}&nominal=${amount}`;
    const res = await axios.get(url, { timeout: 15000 });
    const qrString = res.data.QR || res.data.qr || res.data.qris;
    if (!qrString) throw new Error('API QRIS tidak mengembalikan data');
    return qrString;
}

async function generateQRCodeWithCenterIcon(qrString, iconPath) {
    return new Promise((resolve, reject) => {
        const { createCanvas, loadImage } = require('canvas');
        
        QRCode.toBuffer(qrString, {
            type: 'png',
            width: 500,
            margin: 2,
            color: { dark: '#000000', light: '#FFFFFF' }
        }, async (err, qrBuffer) => {
            if (err) {
                reject(err);
                return;
            }
            
            try {
                const qrImage = await loadImage(qrBuffer);
                const qrSize = qrImage.width;
                const iconSize = Math.floor(qrSize * 0.2);
                const canvas = createCanvas(qrSize, qrSize);
                const ctx = canvas.getContext('2d');
                ctx.drawImage(qrImage, 0, 0, qrSize, qrSize);
                
                let iconImage = null;
                if (fs.existsSync(iconPath)) {
                    try {
                        iconImage = await loadImage(iconPath);
                    } catch(e) {}
                }
                
                if (iconImage) {
                    const x = (qrSize - iconSize) / 2;
                    const y = (qrSize - iconSize) / 2;
                    ctx.beginPath();
                    ctx.arc(qrSize / 2, qrSize / 2, iconSize / 2 + 5, 0, 2 * Math.PI);
                    ctx.fillStyle = '#FFFFFF';
                    ctx.fill();
                    ctx.drawImage(iconImage, x, y, iconSize, iconSize);
                }
                
                const buffer = canvas.toBuffer('image/png');
                
                // Simpan ke file temp dengan nama unik
                const tempFile = path.join(TEMP_DIR, `qris_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.png`);
                fs.writeFileSync(tempFile, buffer);
                console.log(`💾 QRIS saved to: ${tempFile}`);
                
                // Jadwal hapus setelah 10 menit (600000 ms)
                scheduleFileDelete(tempFile, 600000);
                
                resolve(buffer);
            } catch(err) {
                console.error('Error generating QR code:', err);
                resolve(qrBuffer);
            }
        });
    });
}

async function kirimNotifikasiAdminTopup(userId, userName, amount, newSaldo) {
    const timestamp = formatTimestamp();
    const message = `<b>✅ TOPUP BERHASIL</b>
    
<b>👤 User:</b> ${userName}
<b>🆔 User ID:</b> ${userId}
<b>💰 Nominal:</b> ${formatRp(amount)}
<b>💳 Saldo Baru:</b> ${formatRp(newSaldo)}
<b>⏰ Waktu:</b> ${timestamp}`;

    // Kirim ke GROUP Telegram
    await sendToTelegram(message, null, 'group');
}

// ==================== TOPUP & PEMBAYARAN ====================
async function mulaiPembayaranQRIS(chatId, userId, amount, tujuan, callback) {
    const txId = generateTxId();
    const expiresAt = Date.now() + 10 * 60 * 1000; // 10 menit
    const userName = await getUserName(userId);
    const cleanUserId = getCleanUserId(userId);

    const loading = await client.sendMessage(chatId, '⏳ Membuat QRIS dinamis...');

    // Simpan messageId untuk cleanup nanti
    let qrMessageId = null;

    try {
        const qrString = await generateQRISDinamis(amount);
        const qrImageBuffer = await generateQRCodeWithCenterIcon(qrString, QRIS_CENTER_ICON);
        
        try { await loading.delete(true); } catch(e) {}
        
        pendingQRIS[cleanUserId] = { 
            amount, 
            txId, 
            tujuan, 
            callback, 
            expiresAt,
            chatId: chatId, 
            userName: userName,
            qrMessageId: null  // akan diisi setelah kirim
        };
        
        const qrBase64 = qrImageBuffer.toString('base64');
        const qrMedia = new MessageMedia('image/png', qrBase64);
        
        const caption = `${getHeader('💳 PEMBAYARAN QRIS')}
╭──────────────────╮
│ ├ *User :* ${userName}
│ ├ *Merchant :* ${tujuan}
│ ├ *Nominal :* *${formatRp(amount)}*
│ ├ *Kode TX :* \`${txId}\`
│ ├ *Berlaku :* 10 menit
╰──────────────────╯

📸 *Langkah:*
1. Scan QR code di atas
2. Lakukan pembayaran sebesar *${formatRp(amount)}*
3. Kirim screenshot bukti pembayaran KE CHAT INI

✅ Saldo akan otomatis masuk setelah bukti dikirim

⏰ *Peringatan:* QRIS akan kadaluarsa dalam 10 menit!`;

        const qrMessage = await client.sendMessage(chatId, qrMedia, { caption: caption });
        qrMessageId = qrMessage.id._serialized;

        // Simpan qrMessageId ke pendingQRIS
        if (pendingQRIS[cleanUserId]) {
            pendingQRIS[cleanUserId].qrMessageId = qrMessageId;
        }

        // Auto expired setelah 10 menit - HAPUS PESAN QRIS + kirim notif
        setTimeout(async () => {
            if (pendingQRIS[cleanUserId] && pendingQRIS[cleanUserId].txId === txId) {
                const pending = pendingQRIS[cleanUserId];
                delete pendingQRIS[cleanUserId];
                
                // Hapus pesan QRIS untuk semua orang
                if (pending.qrMessageId) {
                    try {
                        const msgToDelete = await client.getMessageById(pending.qrMessageId);
                        if (msgToDelete) await msgToDelete.delete(true);
                        console.log(`🗑️ Deleted expired QR message for TX: ${txId}`);
                    } catch(e) {
                        console.log(`Failed to delete QR message: ${e.message}`);
                    }
                }
                
                // Kirim pesan expired lalu auto-delete setelah 30 detik
                if (pending && pending.chatId) {
                    await sendAutoDelete(pending.chatId,
                        `⏰ *Waktu pembayaran telah habis!*\n\n` +
                        `Kode TX: \`${txId}\`\n` +
                        `Nominal: ${formatRp(amount)}\n\n` +
                        `Silakan lakukan topup ulang dengan memilih *Topup Saldo* di menu.`,
                        30000
                    );
                }
                console.log(`⏰ Auto-expired: Payment ${txId} for ${userName} has expired`);
            }
        }, 10 * 60 * 1000);

    } catch(err) {
        try { await loading.delete(true); } catch(e) {}
        await sendAutoDelete(chatId, `❌ Gagal membuat QRIS: ${err.message}`);
    }
}

async function handleTopup(chatId, userId) {
    const cleanUserId = getCleanUserId(userId);
    
    processState[cleanUserId] = { 
        action: 'topup_amount', 
        waitingForInput: true,
        chatId: chatId
    };
    
    const userName = await getUserName(cleanUserId);
    const currentSaldo = getSaldo(cleanUserId);

    await client.sendMessage(chatId, `${getHeader('💰 TOPUP SALDO')}
╭────────────────────╮
│ ├ *User    :* ${userName}
│ ├ *Saldo saat ini :* ${formatRp(currentSaldo)}
│ ├ *Min. Topup     :* ${formatRp(CONFIG.MIN_TOPUP)}
╰────────────────────╯

Kirim nominal topup (contoh: *5000*):
Ketik *cancel* untuk batal`);
}

// ==================== TELEGRAM NOTIFICATION ====================
async function sendToTelegram(message, photoBuffer = null, target = 'admin') {
    // target: 'admin' untuk chat pribadi, 'group' untuk grup
    let chatId;
    
    if (target === 'group') {
        chatId = TELEGRAM_GROUP_ID;
        if (!chatId) {
            console.log('⚠️ Telegram Group ID not configured');
            return false;
        }
    } else {
        chatId = TELEGRAM_ADMIN_ID;
        if (!chatId) {
            console.log('⚠️ Telegram Admin ID not configured');
            return false;
        }
    }
    
    if (!TELEGRAM_BOT_TOKEN) {
        console.log('⚠️ Telegram Bot Token not configured');
        return false;
    }
    
    try {
        if (photoBuffer) {
            // Kirim foto ke Telegram
            const FormData = require('form-data');
            const form = new FormData();
            form.append('chat_id', chatId);
            form.append('photo', photoBuffer, { filename: 'bukti.jpg', contentType: 'image/jpeg' });
            form.append('caption', message);
            form.append('parse_mode', 'HTML');
            
            await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto`, form, {
                headers: form.getHeaders()
            });
        } else {
            // Kirim pesan teks ke Telegram
            await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
                chat_id: chatId,
                text: message,
                parse_mode: 'HTML',
                disable_web_page_preview: true
            });
        }
        console.log(`✅ Notification sent to Telegram ${target === 'group' ? 'Group' : 'Admin'}`);
        return true;
    } catch (error) {
        console.error(`❌ Failed to send to Telegram ${target}:`, error.message);
        if (error.response) {
            console.error('Telegram response:', error.response.data);
        }
        return false;
    }
}

async function handleBuktiPembayaran(chatId, userId, msg) {
    const cleanUserId = getCleanUserId(userId);
    const pending = pendingQRIS[cleanUserId];
    
    if (!pending) {
        await sendAutoDelete(chatId, '❌ Tidak ada topup yang sedang berjalan.\n\nGunakan /menu dan pilih *Topup Saldo* untuk memulai.', 20000);
        return false;
    }
    
    if (Date.now() > pending.expiresAt) {
        delete pendingQRIS[cleanUserId];
        // Hapus pesan QRIS jika masih ada
        if (pending.qrMessageId) {
            try {
                const qrMsg = await client.getMessageById(pending.qrMessageId);
                if (qrMsg) await qrMsg.delete(true);
            } catch(e) {}
        }
        await sendAutoDelete(chatId, '⏰ Waktu pembayaran sudah habis. Silakan topup ulang dengan /menu', 20000);
        return true;
    }

    const isImage = msg.type === 'image' || (msg.hasMedia === true);
    
    if (!isImage) {
        await sendAutoDelete(chatId, '📸 Kirim *foto/screenshot* bukti pembayaran.\n\nKetik *cancel* untuk membatalkan.', 20000);
        return true;
    }

    let userName = pending.userName;
    if (!userName || userName === 'User') {
        userName = await getUserName(cleanUserId);
        pendingQRIS[cleanUserId].userName = userName;
    }

    const loading = await client.sendMessage(chatId, '⏳ Memproses bukti pembayaran...');

    try {
        const media = await msg.downloadMedia();
        if (!media || !media.data) {
            throw new Error('Gagal mengunduh gambar');
        }
        
        // Hapus pesan bukti pembayaran user (untuk semua orang) setelah diproses
        try { await msg.delete(true); } catch(e) {}

        // Simpan bukti pembayaran ke temp (opsional, untuk arsip)
        const buktiFile = path.join(TEMP_DIR, `bukti_${pending.txId}_${Date.now()}.jpg`);
        const buktiBuffer = Buffer.from(media.data, 'base64');
        fs.writeFileSync(buktiFile, buktiBuffer);
        scheduleFileDelete(buktiFile, 3600000); // Hapus setelah 1 jam
        
        // Kirim ke Telegram Admin (opsional)
        if (TELEGRAM_BOT_TOKEN && TELEGRAM_ADMIN_ID) {
            const caption = `<b>📸 BUKTI PEMBAYARAN</b>
            
<b>👤 User:</b> ${userName}
<b>🆔 User ID:</b> ${cleanUserId}
<b>💰 Nominal:</b> ${formatRp(pending.amount)}
<b>📝 TX ID:</b> ${pending.txId}
<b>⏰ Waktu:</b> ${formatTimestamp()}`;
            
            await sendToTelegram(caption, buktiBuffer, 'admin');
        }
        
        try { await loading.delete(true); } catch(e) {}

        // Hapus pesan QRIS setelah pembayaran berhasil diproses
        if (pending.qrMessageId) {
            try {
                const qrMsg = await client.getMessageById(pending.qrMessageId);
                if (qrMsg) await qrMsg.delete(true);
            } catch(e) {}
        }
        
        const amount = pending.amount;
        const txId = pending.txId;
        const callback = pending.callback;
        
        delete pendingQRIS[cleanUserId];
        
        if (callback) {
            await callback();
        }
        
        const newSaldo = getSaldo(cleanUserId);
        
        // Pesan sukses pembayaran — auto-delete 60 detik
        await sendAutoDelete(chatId, 
            `✅ *PEMBAYARAN BERHASIL!*\n\n` +
            `👤 *User:* ${userName}\n` +
            `💰 *Nominal:* ${formatRp(amount)}\n` +
            `💳 *Saldo Baru:* ${formatRp(newSaldo)}\n` +
            `📝 *Kode TX:* \`${txId}\`\n\n` +
            `Silakan gunakan menu *Create Akun* untuk membuat VPN.`,
            60000
        );
        
        await showMainMenu(chatId, cleanUserId);
        
    } catch(err) {
        try { await loading.delete(true); } catch(e) {}
        console.error('Error processing payment proof:', err);
        await sendAutoDelete(chatId, `❌ Gagal memproses bukti: ${err.message}\n\nSilakan kirim ulang bukti pembayaran.`, 20000);
    }

    return true;
}

async function processTopupAmount(chatId, userId, msg) {
    const cleanUserId = getCleanUserId(userId);
    const state = processState[cleanUserId];
    
    if (!state || state.action !== 'topup_amount') return false;

    const input = msg.body.trim();
    
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Topup dibatalkan.');
        delete processState[cleanUserId];
        await showMainMenu(chatId, cleanUserId);
        return true;
    }

    const amount = parseInt(input.replace(/\D/g, ''));
    if (isNaN(amount) || amount < CONFIG.MIN_TOPUP) {
        await sendAutoDelete(chatId, `❌ Minimal topup ${formatRp(CONFIG.MIN_TOPUP)}\nKetik *cancel* untuk batal`);
        return false;
    }

    delete processState[cleanUserId];

    const userName = await getUserName(cleanUserId);
    
    await mulaiPembayaranQRIS(chatId, cleanUserId, amount, CONFIG.MERCHANT_NAME, async () => {
        const newSaldo = tambahSaldo(cleanUserId, amount);
        
        simpanTransaksi({
            txId: generateTxId(), 
            userId: cleanUserId, 
            userName: userName,
            type: 'topup', 
            amount,
            keterangan: `Topup Saldo oleh ${userName}`, 
            waktu: new Date().toISOString(), 
            status: 'success'
        });
        
        await kirimNotifikasiAdminTopup(cleanUserId, userName, amount, newSaldo);
    });
}

// ==================== API CALL ====================
async function callApi(server, endpoint, payload = null, method = 'POST') {
    try {
        const url = `${server.apiUrl}${endpoint}`;
        const headers = { 'x-api-key': server.authKey, 'Content-Type': 'application/json' };
        let response;
        if (method === 'POST') response = await axios.post(url, payload, { headers, timeout: 30000 });
        else response = await axios.get(url, { headers, timeout: 30000 });
        return response.data;
    } catch(error) {
        if (error.response) return { success: false, message: error.response.data?.message || `HTTP ${error.response.status}` };
        return { success: false, message: error.message };
    }
}

function getModule(serviceType) {
    const map = { ssh: sshModule, trojan: trojanModule, vless: vlessModule, vmess: vmessModule, zivpn: zivpnModule };
    return map[serviceType] || sshModule;
}

// ==================== SELECT SERVER ====================
async function selectServer(chatId, userId, serviceType, action) {
    let available = [];
    
    if (serviceType === 'zivpn') {
        available = Object.values(SERVERS).filter(s => s.type === 'zivpn');
    } else if (serviceType === 'ssh') {
        available = Object.values(SERVERS).filter(s => s.type === 'ssh');
    } else if (serviceType === 'vmess' || serviceType === 'vless' || serviceType === 'trojan') {
        available = Object.values(SERVERS).filter(s => s.type === 'xray');
    } else {
        available = Object.values(SERVERS).filter(s => s.type !== 'zivpn');
    }

    if (available.length === 0) {
        let serverTypeHint = '';
        if (serviceType === 'ssh') serverTypeHint = 'SSH';
        else if (serviceType === 'zivpn') serverTypeHint = 'ZiVPN';
        else serverTypeHint = 'XRAY';
        
        await sendAutoDelete(chatId, `❌ Tidak ada server untuk *${serviceType.toUpperCase()}*\n\nSilakan tambah server dengan tipe *${serverTypeHint}* terlebih dahulu.`);
        return null;
    }
    
    if (available.length === 1) return available[0];

    // Buat opsi polling - HANYA nama server, tanpa tambahan (type) agar mudah dicocokkan
    const opts = available.map(s => {
        let icon = '🛡️';
        if (s.type === 'zivpn') icon = '🔥';
        else if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        return `${icon} ${s.name}`;  // <-- Hanya icon + nama
    });
    opts.push('❌ Batal');

    // Kirim polling
    const question = `🌐 Pilih Server untuk ${action} ${serviceType.toUpperCase()}`;
    
    console.log(`📤 Mengirim polling selectServer dengan ${opts.length} opsi`);
    
    await sendPoll(chatId, userId, question, opts, 'server_select', { 
        serviceType, 
        action, 
        servers: available 
    });

    return new Promise(resolve => {
        // Hapus state lama jika ada
        if (serverSelState[userId]) {
            clearTimeout(serverSelState[userId].timeout);
            delete serverSelState[userId];
        }
        
        const timeout = setTimeout(() => {
            if (serverSelState[userId]) {
                console.log(`⏰ Timeout selectServer untuk ${userId}`);
                serverSelState[userId].resolve(null);
                delete serverSelState[userId];
            }
        }, 60000);
        
        serverSelState[userId] = { resolve, timeout, servers: available };
    });
}

// ==================== CREATE ACCOUNT STEP BY STEP ====================
async function processCreateStepByStep(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || !state.action || !state.action.startsWith('create_step_')) return false;
    
    const input = msg.body.trim();
    
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Pembuatan akun dibatalkan.');
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return true;
    }
    
    const action = state.action;
    const serviceType = state.serviceType;
    const server = state.server;
    const data = state.data || {};
    
    // ========== STEP 1: Input Username (kecuali ZiVPN langsung password) ==========
    if (action === 'create_step_username') {
        if (!input || input.length < 3) {
            await sendAutoDelete(chatId, '❌ Username terlalu pendek (minimal 3 karakter). Silakan coba lagi.\nKetik *cancel* untuk batal.');
            return false;
        }
        
        // Cek apakah username sudah ada (opsional)
        data.username = input;
        
        processState[userId] = {
            action: 'create_step_days',
            serviceType: serviceType,
            server: server,
            step: 2,
            data: data,
            waitingForInput: true
        };
        
        await sendAutoDelete(chatId, 
            `✅ Username: *${input}*\n\n` +
            `📝 *Langkah 2/4: Berapa hari?*\n\n` +
            `Masukkan durasi berlangganan (dalam hari).\n\n` +
            `Contoh: *30* (untuk 30 hari)\n\n` +
            `💰 Harga: ${formatHarga()}\n` +
            `🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP (otomatis)\n` +
            `${serviceType !== 'ssh' ? `💾 Quota: ${CONFIG.DEFAULT_QUOTA} GB (otomatis)\n` : ''}` +
            `Ketik *cancel* untuk batal`);
        return true;
    }
    
    // ========== STEP 2: Input Hari ==========
    if (action === 'create_step_days') {
        const days = parseInt(input);
        if (isNaN(days) || days < 1 || days > 365) {
            await sendAutoDelete(chatId, '❌ Jumlah hari tidak valid. Masukkan angka 1-365.\nKetik *cancel* untuk batal.');
            return false;
        }
        
        data.days = days;
        const totalHarga = hitungHarga(days, CONFIG.MAX_IP_LIMIT);
        data.totalHarga = totalHarga;
        
        // Untuk ZiVPN, langsung ke konfirmasi (tanpa password terpisah)
        if (serviceType === 'zivpn') {
            processState[userId] = {
                action: 'create_step_confirm',
                serviceType: serviceType,
                server: server,
                data: data,
                waitingForInput: false
            };
            
            const confirmText = `${getHeader('💳 KONFIRMASI PEMBAYARAN')}
╭──────────────────╮
│ 📋 *Ringkasan Akun ZiVPN*
│ ├ 🔐 Password: ${data.username}
│ ├ 📅 Durasi: ${days} hari
│ ├ 🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP
│ └ 💰 Total Harga: ${formatRp(totalHarga)}
╰──────────────────╯

💰 *Saldo Anda:* ${formatRp(getSaldo(userId))}

Lanjutkan pembuatan akun?`;
            
            await sendPoll(chatId, userId, confirmText, ['✅ Ya, Lanjutkan', '❌ Batal'], 'create_confirm', {
                serviceType: serviceType,
                server: server,
                parsed: { password: data.username, days: days, iplimit: CONFIG.MAX_IP_LIMIT },
                totalHarga: totalHarga
            });
            return true;
        }
        
        // Untuk SSH, Trojan, VLess, VMess lanjut ke step password
        processState[userId] = {
            action: 'create_step_password',
            serviceType: serviceType,
            server: server,
            step: 3,
            data: data,
            waitingForInput: true
        };
        
        await sendAutoDelete(chatId,
            `✅ Durasi: *${days} hari*\n💰 Total: *${formatRp(totalHarga)}*\n\n` +
            `📝 *Langkah 3/4: Buat Password*\n\n` +
            `Silakan kirim *password* untuk akun Anda.\n\n` +
            `Contoh: *mypass123* atau ketik *random* untuk password otomatis\n\n` +
            `Ketik *cancel* untuk batal`);
        return true;
    }
    
    // ========== STEP 3: Input Password (kecuali ZiVPN) ==========
    if (action === 'create_step_password') {
        let password = input;
        
        // Cek apakah user ingin random password
        if (password.toLowerCase() === 'random') {
            password = Math.random().toString(36).substring(2, 12);
            await sendAutoDelete(chatId, `🔑 Password otomatis dibuat: *${password}*`);
        }
        
        if (password.length < 4) {
            await sendAutoDelete(chatId, '❌ Password terlalu pendek (minimal 4 karakter). Silakan coba lagi.\nKetik *cancel* untuk batal.');
            return false;
        }
        
        data.password = password;
        
        processState[userId] = {
            action: 'create_step_confirm',
            serviceType: serviceType,
            server: server,
            data: data,
            waitingForInput: false
        };
        
        const days = data.days;
        const totalHarga = data.totalHarga;
        
        let ringkasan = '';
        if (serviceType === 'ssh') {
            ringkasan = `🔐 Username: ${data.username}\n🔑 Password: ${password}\n📅 Durasi: ${days} hari\n🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP`;
        } else {
            ringkasan = `🔐 Username: ${data.username}\n🔑 Password: ${password}\n📅 Durasi: ${days} hari\n🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP\n💾 Quota: ${CONFIG.DEFAULT_QUOTA} GB`;
        }
        
        const confirmText = `${getHeader('💳 KONFIRMASI PEMBAYARAN')}
╭───────────────────╮
│ 📋 *Ringkasan Akun ${serviceType.toUpperCase()}*
│ ├ ${ringkasan}
│ └ 💰 Total Harga: ${formatRp(totalHarga)}
╰───────────────────╯

💰 *Saldo Anda:* ${formatRp(getSaldo(userId))}

Lanjutkan pembuatan akun?`;
        
        await sendPoll(chatId, userId, confirmText, ['✅ Ya, Lanjutkan', '❌ Batal'], 'create_confirm', {
            serviceType: serviceType,
            server: server,
            parsed: { 
                username: data.username, 
                password: password, 
                days: days, 
                iplimit: CONFIG.MAX_IP_LIMIT,
                quota: CONFIG.DEFAULT_QUOTA
            },
            totalHarga: totalHarga
        });
        return true;
    }
    
    return false;
}

// ==================== CREATE ACCOUNT ====================
async function handleCreate(chatId, userId, serviceType) {
    const server = await selectServer(chatId, userId, serviceType, 'CREATE');
    if (!server) return;

    // Mulai proses step by step
    processState[userId] = { 
        action: 'create_step_username',
        serviceType: serviceType,
        server: server,
        step: 1,
        data: {},
        waitingForInput: true
    };
    
    let stepText = '';
    let example = '';
    
    if (serviceType === 'zivpn') {
        stepText = '📝 *Langkah 1/3: Buat Password*\n\nSilakan kirim *password* untuk akun ZiVPN Anda.\n\nContoh: *mypass123*';
    } else if (serviceType === 'ssh') {
        stepText = '📝 *Langkah 1/4: Buat Username*\n\nSilakan kirim *username* untuk akun SSH Anda.\n\nContoh: *user123*';
    } else {
        stepText = '📝 *Langkah 1/4: Buat Username*\n\nSilakan kirim *username* untuk akun Anda.\n\nContoh: *user123*';
    }
    
    await client.sendMessage(chatId, 
        `${getHeader(`✨ CREATE ${serviceType.toUpperCase()} (Step by Step)`)}
╭───────────────────╮
│ ├ *Server :* ${server.name}
│ ├ 💰 *Harga:* ${formatHarga()}
│ ├ 💳 *Saldo:* ${formatRp(getSaldo(userId))}
╰───────────────────╯

${stepText}

Ketik *cancel* untuk membatalkan`);
}

async function processCreate(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'create' || !state.waitingForInput) return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return true;
    }

    const parts = input.split('.').map(p => p.trim());
    const { serviceType, server } = state;

    let parsed = null;
    
    if (serviceType === 'zivpn') {
        if (parts.length < 2) { 
            await sendAutoDelete(chatId, '❌ Format: password.hari\nContoh: mypass123.30'); 
            return false; 
        }
        parsed = { password: parts[0], days: parseInt(parts[1]), iplimit: CONFIG.MAX_IP_LIMIT };
        
    } else if (serviceType === 'ssh') {
        if (parts.length < 3) { 
            await sendAutoDelete(chatId, '❌ Format: username.hari.password\nContoh: user123.30.random'); 
            return false; 
        }
        parsed = { username: parts[0], days: parseInt(parts[1]), iplimit: CONFIG.MAX_IP_LIMIT, password: parts[2] };
        
    } else {
        if (parts.length < 3) { 
            await sendAutoDelete(chatId, '❌ Format: username.hari.password\nContoh: user123.30.random\n\nIP Limit & Quota otomatis dari server'); 
            return false; 
        }
        parsed = { username: parts[0], days: parseInt(parts[1]), iplimit: CONFIG.MAX_IP_LIMIT, quota: CONFIG.DEFAULT_QUOTA, password: parts[2] };
    }

    if (!parsed || isNaN(parsed.days) || parsed.days < 1) {
        await sendAutoDelete(chatId, '❌ Data tidak valid. Cek kembali formatnya.');
        return false;
    }

    const totalHarga = hitungHarga(parsed.days, parsed.iplimit);
    const saldoUser = getSaldo(userId);

    if (saldoUser < totalHarga) {
        await sendAutoDelete(chatId,
            `❌ *Saldo tidak cukup!*\n\n` +
            `💰 Harga  : *${formatRp(totalHarga)}* (${parsed.days}hr × ${parsed.iplimit}IP)\n` +
            `💳 Saldo  : *${formatRp(saldoUser)}*\n` +
            `📉 Kurang : *${formatRp(totalHarga - saldoUser)}*\n\n` +
            `Gunakan menu *Topup Saldo* untuk mengisi saldo.`);
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return true;
    }

    processState[userId] = { ...state, action: 'create_confirm', parsed, totalHarga, waitingForInput: false };

    const confirmText = `${getHeader('💳 KONFIRMASI PEMBAYARAN')}\n\n${serviceType.toUpperCase()} ${parsed.days} hari × ${parsed.iplimit} IP = ${formatRp(totalHarga)}${serviceType !== 'zivpn' && serviceType !== 'ssh' ? `\n📦 Quota: ${parsed.quota} GB` : ''}`;
    
    await sendPoll(chatId, userId, confirmText, ['✅ Bayar dengan Saldo', '❌ Batal'], 'create_confirm', { serviceType, server, parsed, totalHarga });

    return true;
}

async function eksekusiCreate(chatId, userId, serviceType, server, parsed, totalHarga) {
    console.log(`🚀 Eksekusi create: ${serviceType} untuk ${userId}, total: ${totalHarga}`);
    
    const userName = await getUserName(userId);
    
    // Validasi IP Limit
    if (parsed.iplimit > CONFIG.MAX_IP_LIMIT) {
        await sendAutoDelete(chatId, `❌ IP Limit melebihi batas maksimal (${CONFIG.MAX_IP_LIMIT})`);
        await showMainMenu(chatId, userId);
        return;
    }
    
    // Kurangi saldo
    if (!kurangiSaldo(userId, totalHarga)) {
        await sendAutoDelete(chatId, '❌ Saldo tidak cukup!');
        await showMainMenu(chatId, userId);
        return;
    }
    
    // Catat transaksi
    simpanTransaksi({
        txId: generateTxId(), 
        userId, 
        userName: userName,
        type: 'create', 
        amount: totalHarga,
        keterangan: `${userName} create ${serviceType.toUpperCase()} ${parsed.username || parsed.password} ${parsed.days}hr ${parsed.iplimit}IP`,
        waktu: new Date().toISOString(), 
        status: 'success'
    });
    
    const loading = await client.sendMessage(chatId, '⏳ Memproses pembuatan akun...');
    const module = getModule(serviceType);
    const domain = server.apiUrl.split('/')[2]?.split(':')[0] || server.name;
    
    try {
        let result;
        const expiredDate = new Date();
        expiredDate.setDate(expiredDate.getDate() + parsed.days);
        const expiredDisplay = expiredDate.toLocaleDateString('id-ID', { day:'numeric', month:'short', year:'numeric' });
        
        let password = parsed.password;
        let username = parsed.username;
        
        // Untuk ZiVPN, password adalah username yang diinput
        if (serviceType === 'zivpn') {
            password = parsed.password || parsed.username;
            username = password;
        }
        
        if (password === 'random') {
            password = Math.random().toString(36).substring(2, 12);
        }
        
        // Panggil API sesuai service type
        if (serviceType === 'zivpn') {
            result = await module.zivpnCreate(server, password, parsed.days, parsed.iplimit);
        } else if (serviceType === 'ssh') {
            result = await module.createSSH(server, username, password, parsed.days, parsed.iplimit);
        } else if (serviceType === 'trojan') {
            result = await module.createTrojan(server, username, password, parsed.days, parsed.iplimit, parsed.quota || CONFIG.DEFAULT_QUOTA);
        } else if (serviceType === 'vless') {
            result = await module.createVless(server, username, password, parsed.days, parsed.iplimit, parsed.quota || CONFIG.DEFAULT_QUOTA);
        } else if (serviceType === 'vmess') {
            result = await module.createVmess(server, username, password, parsed.days, parsed.iplimit, parsed.quota || CONFIG.DEFAULT_QUOTA);
        }
        
        try { await loading.delete(true); } catch(e) {}
        
        if (result && result.success) {
            const akunData = {
                username: username || password,
                password: password,
                uuid: password,
                expired: expiredDisplay,
                iplimit: parsed.iplimit,
                quota: parsed.quota || CONFIG.DEFAULT_QUOTA,
                domain: domain,
                serviceType: serviceType,
                serverName: server.name
            };
            
            tambahAkun(userId, akunData);
            
            const msg = formatCreateMessage(serviceType, akunData, server.name);
            await client.sendMessage(chatId, msg + `\n\n💰 *Sisa Saldo:* ${formatRp(getSaldo(userId))}`);
        } else {
            // Gagal, kembalikan saldo
            tambahSaldo(userId, totalHarga);
            await sendAutoDelete(chatId, `❌ Gagal membuat akun: ${result?.message || 'Unknown error'}\n💰 Saldo telah dikembalikan.`);
        }
    } catch(err) {
        try { await loading.delete(true); } catch(e) {}
        tambahSaldo(userId, totalHarga);
        await sendAutoDelete(chatId, `❌ Error: ${err.message}\n💰 Saldo telah dikembalikan.`);
    }
    
    delete processState[userId];
    await showMainMenu(chatId, userId);
}

// ==================== TRIAL ACCOUNT ====================
async function handleTrial(chatId, userId, serviceType) {
    if (!cekBisaTrial(userId)) {
        await sendAutoDelete(chatId, `❌ Batas trial hari ini sudah habis (max ${CONFIG.MAX_TRIAL_PER_USER}x/hari)`);
        return;
    }

    const server = await selectServer(chatId, userId, serviceType, 'TRIAL');
    if (!server) return;

    await eksekusiTrial(chatId, userId, serviceType, server, CONFIG.MAX_TRIAL_MENIT);
}

async function eksekusiTrial(chatId, userId, serviceType, server, duration) {
    const module = getModule(serviceType);
    const loading = await client.sendMessage(chatId, '⏳ Membuat trial...');
    const timestamp = Date.now().toString().slice(-6);
    const username = `trial${timestamp}`;
    const domain = server.apiUrl.split('/')[2]?.split(':')[0] || server.name;

    try {
        let result;
        
        if (serviceType === 'ssh') {
            result = await module.trialSSH(server, username, duration);
        } else if (serviceType === 'trojan') {
            result = await module.trialTrojan(server, username, duration);
        } else if (serviceType === 'vless') {
            result = await module.trialVless(server, username, duration);
        } else if (serviceType === 'vmess') {
            result = await module.trialVmess(server, username, duration);
        } else if (serviceType === 'zivpn') {
            const pw = `trial${Math.random().toString(36).substring(2, 10)}`;
            result = await module.zivpnCreate(server, pw, 1, 1);
            if (result?.success) result.data = { password: pw, username: pw };
        }

        try { await loading.delete(true); } catch(e) {}

        if (result && result.success) {
            catatTrial(userId);

            // Hitung waktu expired dalam ms (untuk auto-delete scheduler)
            const expiredAt = Date.now() + (duration * 60 * 1000);
            const expiredDate = new Date(expiredAt);
            const expiredDisplay = expiredDate.toLocaleString('id-ID', { timeZone:'Asia/Jakarta', day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });

            const apiData = result.data || result;
            let uuid = apiData.uuid || apiData.password;
            
            if ((serviceType === 'vless' || serviceType === 'vmess') && !uuid) {
                const { randomUUID } = require('crypto');
                uuid = randomUUID();
            }
            
            let password = apiData.password || apiData.uuid || username;
            
            const akunData = {
                username: username,
                password: password,
                uuid: uuid,
                expired: expiredDisplay,
                iplimit: 1,
                quota: 1,
                duration_minutes: duration,
                domain: domain,
                serviceType: serviceType,
                serverName: server.name
            };
            
            if (serviceType === 'zivpn') {
                akunData.username = password;
                akunData.password = password;
                akunData.uuid = password;
            }

            tambahAkun(userId, { ...akunData, isTrial: true });

            // ===== AUTO-DELETE SCHEDULER =====
            // Simpan ke trial_active.json dan jadwalkan penghapusan otomatis
            const trialIdentifier = serviceType === 'zivpn' ? password : username;
            const trialEntry = {
                username: trialIdentifier,
                serviceType: serviceType,
                serverId: server.id,
                serverName: server.name,
                expiredAt: expiredAt,
                userId: userId,
                chatId: chatId,
                createdAt: new Date().toISOString()
            };
            addTrialActive(trialEntry);
            scheduleTrialAutoDelete(trialEntry);
            console.log(`⏰ [Trial] Auto-delete dijadwalkan: "${trialIdentifier}" (${serviceType}) dalam ${duration} menit`);
            // =================================

            await client.sendMessage(chatId, formatTrialMessage(serviceType, akunData, server.name));
        } else {
            await sendAutoDelete(chatId, `❌ Gagal trial: ${result?.message || 'Unknown'}`);
        }
    } catch(err) {
        try { await loading.delete(true); } catch(e) {}
        await sendAutoDelete(chatId, `❌ Error: ${err.message}`);
    }

    delete processState[userId];
    await showMainMenu(chatId, userId);
}

// ==================== RENEW ACCOUNT STEP BY STEP ====================
async function processRenewStepByStep(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || !state.action || !state.action.startsWith('renew_step_')) return false;
    
    const input = msg.body.trim();
    
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Perpanjangan akun dibatalkan.');
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return true;
    }
    
    const action = state.action;
    const serviceType = state.serviceType;
    const server = state.server;
    const data = state.data || {};
    
    // ========== STEP 1: Input Username/Password ==========
    if (action === 'renew_step_username') {
        if (!input || input.length < 3) {
            await sendAutoDelete(chatId, '❌ Username/Password terlalu pendek (minimal 3 karakter). Silakan coba lagi.\nKetik *cancel* untuk batal.');
            return false;
        }
        
        data.target = input;
        
        processState[userId] = {
            action: 'renew_step_days',
            serviceType: serviceType,
            server: server,
            step: 2,
            data: data,
            waitingForInput: true
        };
        
        await sendAutoDelete(chatId, 
            `✅ Target: *${input}*\n\n` +
            `📝 *Langkah 2/2: Tambah berapa hari?*\n\n` +
            `Masukkan durasi tambahan (dalam hari).\n\n` +
            `Contoh: *30* (untuk menambah 30 hari)\n\n` +
            `💰 Harga: ${formatHarga()}\n` +
            `🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP (otomatis)\n\n` +
            `Ketik *cancel* untuk batal`);
        return true;
    }
    
    // ========== STEP 2: Input Hari ==========
    if (action === 'renew_step_days') {
        const days = parseInt(input);
        if (isNaN(days) || days < 1 || days > 365) {
            await sendAutoDelete(chatId, '❌ Jumlah hari tidak valid. Masukkan angka 1-365.\nKetik *cancel* untuk batal.');
            return false;
        }
        
        data.days = days;
        const totalHarga = hitungHarga(days, CONFIG.MAX_IP_LIMIT);
        data.totalHarga = totalHarga;
        
        processState[userId] = {
            action: 'renew_step_confirm',
            serviceType: serviceType,
            server: server,
            data: data,
            waitingForInput: false
        };
        
        const confirmText = `${getHeader('💳 KONFIRMASI RENEW')}
╭───────────────────╮
│ 📋 *Ringkasan Perpanjangan*
│ ├ ${serviceType === 'zivpn' ? '🔐 Password' : '👤 Username'}: ${data.target}
│ ├ 📅 Tambah: +${days} hari
│ ├ 🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP
│ └ 💰 Total Harga: ${formatRp(totalHarga)}
╰───────────────────╯

💰 *Saldo Anda:* ${formatRp(getSaldo(userId))}

Lanjutkan perpanjangan akun?`;
        
        await sendPoll(chatId, userId, confirmText, ['✅ Ya, Lanjutkan', '❌ Batal'], 'renew_confirm', {
            serviceType: serviceType,
            server: server,
            parsed: { target: data.target, days: days },
            totalHarga: totalHarga
        });
        return true;
    }
    
    return false;
}

// ==================== RENEW ACCOUNT ====================
async function handleRenew(chatId, userId, serviceType) {
    const server = await selectServer(chatId, userId, serviceType, 'RENEW');
    if (!server) return;

    // Mulai proses renew step by step
    processState[userId] = { 
        action: 'renew_step_username',
        serviceType: serviceType,
        server: server,
        step: 1,
        data: {},
        waitingForInput: true
    };
    
    let stepText = '';
    if (serviceType === 'zivpn') {
        stepText = '📝 *Langkah 1/2: Masukkan Password*\n\nSilakan kirim *password* akun ZiVPN yang ingin diperpanjang.\n\nContoh: *mypass123*';
    } else {
        stepText = '📝 *Langkah 1/2: Masukkan Username*\n\nSilakan kirim *username* akun yang ingin diperpanjang.\n\nContoh: *user123*';
    }
    
    await client.sendMessage(chatId, 
        `${getHeader(`🔄 RENEW ${serviceType.toUpperCase()} (Step by Step)`)}
╭───────────────────╮
│ ├ *Server :* ${server.name}
│ ├ 💰 *Harga:* ${formatHarga()}
│ ├ 💳 *Saldo:* ${formatRp(getSaldo(userId))}
╰───────────────────╯

${stepText}

Ketik *cancel* untuk membatalkan`);
}

async function processRenew(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'renew' || !state.waitingForInput) return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return true;
    }

    const parts = input.split('.').map(p => p.trim());
    const { serviceType, server } = state;

    let parsed = null;
    if (serviceType === 'zivpn') {
        if (parts.length < 2) { 
            await sendAutoDelete(chatId, '❌ Format: password.tambah_hari\nContoh: *mypass123.30*'); 
            return false; 
        }
        parsed = { target: parts[0], days: parseInt(parts[1]) };
    } else {
        if (parts.length < 2) { 
            await sendAutoDelete(chatId, '❌ Format: username.tambah_hari\nContoh: *user123.30*'); 
            return false; 
        }
        parsed = { target: parts[0], days: parseInt(parts[1]) };
    }

    if (!parsed || isNaN(parsed.days) || parsed.days < 1) {
        await sendAutoDelete(chatId, '❌ Data tidak valid.');
        return false;
    }

    const totalHarga = hitungHarga(parsed.days, CONFIG.MAX_IP_LIMIT);
    const saldoUser = getSaldo(userId);

    if (saldoUser < totalHarga) {
        await sendAutoDelete(chatId,
            `❌ *Saldo tidak cukup!*\n\n` +
            `💰 Harga  : *${formatRp(totalHarga)}* (${parsed.days}hr × ${CONFIG.MAX_IP_LIMIT}IP)\n` +
            `💳 Saldo  : *${formatRp(saldoUser)}*\n` +
            `📉 Kurang : *${formatRp(totalHarga - saldoUser)}*`);
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return true;
    }

    processState[userId] = { ...state, action: 'renew_confirm', parsed, totalHarga, waitingForInput: false };

    const confirmText = `${getHeader('💳 KONFIRMASI RENEW')}\n\n${serviceType.toUpperCase()} "${parsed.target}" +${parsed.days} hari = ${formatRp(totalHarga)}`;
    
    await sendPoll(chatId, userId, confirmText, ['✅ Bayar dengan Saldo', '❌ Batal'], 'renew_confirm', { serviceType, server, parsed, totalHarga });

    return true;
}

async function eksekusiRenew(chatId, userId, serviceType, server, parsed, totalHarga) {
    console.log(`🚀 Eksekusi renew: ${serviceType} untuk ${userId}, target: ${parsed.target}, days: ${parsed.days}`);
    
    const userName = await getUserName(userId);
    
    // Kurangi saldo
    if (!kurangiSaldo(userId, totalHarga)) {
        await sendAutoDelete(chatId, '❌ Saldo tidak cukup!');
        await showMainMenu(chatId, userId);
        return;
    }
    
    // Catat transaksi
    simpanTransaksi({
        txId: generateTxId(),
        userId: userId,
        userName: userName,
        type: 'renew',
        amount: totalHarga,
        keterangan: `Renew ${serviceType.toUpperCase()} ${parsed.target} +${parsed.days}hr (${CONFIG.MAX_IP_LIMIT}IP)`,
        waktu: new Date().toISOString(),
        status: 'success'
    });
    
    const loading = await client.sendMessage(chatId, '⏳ Memproses perpanjangan...');
    const module = getModule(serviceType);
    
    try {
        let result;
        
        if (serviceType === 'ssh') {
            result = await module.renewSSH(server, parsed.target, parsed.days);
        } else if (serviceType === 'trojan') {
            result = await module.renewTrojan(server, parsed.target, parsed.days);
        } else if (serviceType === 'vless') {
            result = await module.renewVless(server, parsed.target, parsed.days);
        } else if (serviceType === 'vmess') {
            result = await module.renewVmess(server, parsed.target, parsed.days);
        } else if (serviceType === 'zivpn') {
            result = await module.zivpnRenew(server, parsed.target, parsed.days);
        }
        
        try { await loading.delete(true); } catch(e) {}
        
        if (result && result.success) {
            const oldExpired = result.data?.old_expired || '-';
            const newExpired = result.data?.new_expired || '-';
            const daysAdded = result.data?.days_added || parsed.days;
            const ipLimit = result.data?.ip_limit || CONFIG.MAX_IP_LIMIT;
            
            const serviceUpper = serviceType.toUpperCase();
            const renewMessage = `
🔄 *${serviceUpper} ACCOUNT RENEWED*
━━━━━━━━━━━━━━━━━━━━━
*${serviceType === 'zivpn' ? 'Password' : 'Username'}: ${parsed.target}*
*IP Limit:* ${ipLimit}
*Expired Sebelum:* ${oldExpired}
*Expired Baru:* ${newExpired}
*Durasi Tambahan:* ${daysAdded} hari
━━━━━━━━━━━━━━━━━━━━━
📅 *Waktu:* ${formatTimestamp()}
*Status:* ✅ Berhasil diperpanjang`;
            
            await client.sendMessage(chatId, renewMessage + `\n\n💰 *Sisa Saldo:* ${formatRp(getSaldo(userId))}`);
            
            // Update akun di database lokal
            const akun = loadAkun();
            if (akun[userId]) {
                for (let i = 0; i < akun[userId].length; i++) {
                    if (akun[userId][i].username === parsed.target || akun[userId][i].password === parsed.target) {
                        akun[userId][i].expired = newExpired;
                        break;
                    }
                }
                saveAkun(akun);
            }
        } else {
            // Gagal, kembalikan saldo
            tambahSaldo(userId, totalHarga);
            await sendAutoDelete(chatId, `❌ Gagal memperpanjang: ${result?.message || 'Unknown error'}\n💰 Saldo telah dikembalikan.`);
        }
    } catch(err) {
        try { await loading.delete(true); } catch(e) {}
        tambahSaldo(userId, totalHarga);
        await sendAutoDelete(chatId, `❌ Error: ${err.message}\n💰 Saldo telah dikembalikan.`);
    }
    
    delete processState[userId];
    await showMainMenu(chatId, userId);
}

// ==================== FORMAT MESSAGES ====================
function formatCreateMessage(service, data, serverName) {
    const domain = data.domain || serverName;
    const timestamp = formatTimestamp();
    
    if (service === 'ssh') {
        const payloadWS = "GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]";
        const payloadTLS = `GET wss://${domain}/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`;
        
        return `
*🔔 SSH ACCOUNT CREATED*
━━━━━━━━━━━━━━━━━━━━━
*Username:* ${data.username}
*Password:* ${data.password}
*IP Limit:* ${data.iplimit}
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
*🔗 SSH WebSocket:*
${domain}:80@${data.username}:${data.password}
━━━━━━━━━━━━━━━━━━━━━
*🔗 SSH SSL:*
${domain}:443@${data.username}:${data.password}
━━━━━━━━━━━━━━━━━━━━━
*🔗 SSH UDP:*
${domain}:1-65535@${data.username}:${data.password}
━━━━━━━━━━━━━━━━━━━━━
*📋 Payload WS:*
${payloadWS}
━━━━━━━━━━━━━━━━━━━━━
*📋 Payload TLS:*
${payloadTLS}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
✅ Status: Berhasil dibuat`;
    }
    else if (service === 'trojan') {
        const trojanTLS = `trojan://${data.password}@${domain}:443?security=tls&type=ws&path=/trojan&host=${domain}&sni=${domain}#${data.username}`;
        const trojanHTTP = `trojan://${data.password}@${domain}:80?security=none&type=ws&path=/trojan&host=${domain}#${data.username}`;
        const trojanGRPC = `trojan://${data.password}@${domain}:443?security=tls&type=grpc&serviceName=trojan-grpc&host=${domain}&sni=${domain}#${data.username}`;
        
        return `
*🔔 TROJAN ACCOUNT CREATED*
━━━━━━━━━━━━━━━━━━━━━
*Username:* ${data.username}
*Password:* ${data.password}
*Quota:* ${data.quota || 0} GB
*IP Limit:* ${data.iplimit}
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
*🔗 TLS (443):*
${trojanTLS}
━━━━━━━━━━━━━━━━━━━━━
*🔗 HTTP (80):*
${trojanHTTP}
━━━━━━━━━━━━━━━━━━━━━
*🔗 GRPC:*
${trojanGRPC}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
✅ Status: Berhasil dibuat`;
    }
    else if (service === 'vless') {
        const vlessTLS = `vless://${data.uuid || data.password}@${domain}:443?encryption=none&security=tls&type=ws&host=${domain}&path=/vless&sni=${domain}#${data.username}`;
        const vlessHTTP = `vless://${data.uuid || data.password}@${domain}:80?encryption=none&security=none&type=ws&host=${domain}&path=/vless#${data.username}`;
        const vlessGRPC = `vless://${data.uuid || data.password}@${domain}:443?encryption=none&security=tls&type=grpc&serviceName=vless-grpc&sni=${domain}#${data.username}`;
        
        return `
*🔔 VLESS ACCOUNT CREATED*
━━━━━━━━━━━━━━━━━━━━━
*Username:* ${data.username}
*UUID:* ${data.uuid || data.password}
*Quota:* ${data.quota || 0} GB
*IP Limit:* ${data.iplimit}
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
*🔗 TLS (443):*
${vlessTLS}
━━━━━━━━━━━━━━━━━━━━━
*🔗 HTTP (80):*
${vlessHTTP}
━━━━━━━━━━━━━━━━━━━━━
*🔗 GRPC:*
${vlessGRPC}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
✅ Status: Berhasil dibuat`;
    }
    else if (service === 'vmess') {
        const vmessTLS = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "443",
            id: data.uuid || data.password, aid: "0", net: "ws", path: "/vmess",
            host: domain, tls: "tls"
        })).toString('base64')}`;
        
        const vmessHTTP = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "80",
            id: data.uuid || data.password, aid: "0", net: "ws", path: "/vmess",
            host: domain, tls: "none"
        })).toString('base64')}`;
        
        const vmessGRPC = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "443",
            id: data.uuid || data.password, aid: "0", net: "grpc", path: "vmess-grpc",
            host: domain, tls: "tls"
        })).toString('base64')}`;
        
        return `
*🔔 VMESS ACCOUNT CREATED*
━━━━━━━━━━━━━━━━━━━━━
*Username:* ${data.username}
*UUID:* ${data.uuid || data.password}
*Quota:* ${data.quota || 0} GB
*IP Limit:* ${data.iplimit}
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
*🔗 TLS (443):*
${vmessTLS}
━━━━━━━━━━━━━━━━━━━━━
*🔗 HTTP (80):*
${vmessHTTP}
━━━━━━━━━━━━━━━━━━━━━
*🔗 GRPC:*
${vmessGRPC}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
✅ Status: Berhasil dibuat`;
    }
    else if (service === 'zivpn') {
        return `
*🔔 ZIVPN ACCOUNT CREATED*
━━━━━━━━━━━━━━━━━━━━━
*Password:* ${data.password}
*IP Limit:* ${data.iplimit}
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
✅ Status: Berhasil dibuat`;
    }
    return '';
}

function formatTrialMessage(service, data, serverName) {
    const domain = data.domain || serverName;
    const timestamp = formatTimestamp();
    
    if (service === 'ssh') {
        const payloadWS = "GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]";
        const payloadTLS = `GET wss://${domain}/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`;
        
        return `
*⏰ TRIAL SSH ACCOUNT*
━━━━━━━━━━━━━━━━━━━━━
*Username:* ${data.username}
*Password:* ${data.password}
*IP Limit:* ${data.iplimit || 1}
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
*🔗 SSH WebSocket:*
${domain}:80@${data.username}:${data.password}
━━━━━━━━━━━━━━━━━━━━━
*🔗 SSH SSL:*
${domain}:443@${data.username}:${data.password}
━━━━━━━━━━━━━━━━━━━━━
*🔗 SSH UDP:*
${domain}:1-65535@${data.username}:${data.password}
━━━━━━━━━━━━━━━━━━━━━
*📋 Payload WS:*
${payloadWS}
━━━━━━━━━━━━━━━━━━━━━
*📋 Payload TLS:*
${payloadTLS}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
📌 Catatan: Trial berlaku ${data.duration_minutes} menit`;
    }
    else if (service === 'trojan') {
        const trojanTLS = `trojan://${data.password}@${domain}:443?security=tls&type=ws&path=/trojan&host=${domain}&sni=${domain}#${data.username}`;
        const trojanHTTP = `trojan://${data.password}@${domain}:80?security=none&type=ws&path=/trojan&host=${domain}#${data.username}`;
        const trojanGRPC = `trojan://${data.password}@${domain}:443?security=tls&type=grpc&serviceName=trojan-grpc&host=${domain}&sni=${domain}#${data.username}`;
        
        return `
*⏰ TRIAL TROJAN ACCOUNT*
━━━━━━━━━━━━━━━━━━━━━
*Username:* ${data.username}
*Password:* ${data.password}
*Quota:* 1 GB
*IP Limit:* 1
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
*🔗 TLS (443):*
${trojanTLS}
━━━━━━━━━━━━━━━━━━━━━
*🔗 HTTP (80):*
${trojanHTTP}
━━━━━━━━━━━━━━━━━━━━━
*🔗 GRPC:*
${trojanGRPC}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
📌 Catatan: Trial berlaku ${data.duration_minutes} menit`;
    }
    else if (service === 'vless') {
        const vlessTLS = `vless://${data.uuid || data.password}@${domain}:443?encryption=none&security=tls&type=ws&host=${domain}&path=/vless&sni=${domain}#${data.username}`;
        const vlessHTTP = `vless://${data.uuid || data.password}@${domain}:80?encryption=none&security=none&type=ws&host=${domain}&path=/vless#${data.username}`;
        const vlessGRPC = `vless://${data.uuid || data.password}@${domain}:443?encryption=none&security=tls&type=grpc&serviceName=vless-grpc&sni=${domain}#${data.username}`;
        
        return `
*⏰ TRIAL VLESS ACCOUNT*
━━━━━━━━━━━━━━━━━━━━━
*Username:* ${data.username}
*UUID:* ${data.uuid || data.password}
*Quota:* 1 GB
*IP Limit:* 1
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
*🔗 TLS (443):*
${vlessTLS}
━━━━━━━━━━━━━━━━━━━━━
*🔗 HTTP (80):*
${vlessHTTP}
━━━━━━━━━━━━━━━━━━━━━
*🔗 GRPC:*
${vlessGRPC}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
📌 Catatan: Trial berlaku ${data.duration_minutes} menit`;
    }
    else if (service === 'vmess') {
        const vmessTLS = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "443",
            id: data.uuid || data.password, aid: "0", net: "ws", path: "/vmess",
            host: domain, tls: "tls"
        })).toString('base64')}`;
        
        const vmessHTTP = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "80",
            id: data.uuid || data.password, aid: "0", net: "ws", path: "/vmess",
            host: domain, tls: "none"
        })).toString('base64')}`;
        
        const vmessGRPC = `vmess://${Buffer.from(JSON.stringify({
            v: "2", ps: data.username, add: domain, port: "443",
            id: data.uuid || data.password, aid: "0", net: "grpc", path: "vmess-grpc",
            host: domain, tls: "tls"
        })).toString('base64')}`;
        
        return `
*⏰ TRIAL VMESS ACCOUNT*
━━━━━━━━━━━━━━━━━━━━━
*Username:* ${data.username}
*UUID:* ${data.uuid || data.password}
*Quota:* 1 GB
*IP Limit:* 1
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
*🔗 TLS (443):*
${vmessTLS}
━━━━━━━━━━━━━━━━━━━━━
*🔗 HTTP (80):*
${vmessHTTP}
━━━━━━━━━━━━━━━━━━━━━
*🔗 GRPC:*
${vmessGRPC}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
📌 Catatan: Trial berlaku ${data.duration_minutes} menit`;
    }
    else if (service === 'zivpn') {
        return `
*⏰ TRIAL ZIVPN ACCOUNT*
━━━━━━━━━━━━━━━━━━━━━
*Password:* ${data.password}
*IP Limit:* 1
*Expired:* ${data.expired}
*Domain:* ${domain}
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${timestamp}
📌 Catatan: Trial berlaku ${data.duration_minutes} menit`;
    }
    return '';
}

// ==================== GET ALL USERS FROM ALL SOURCES ====================
// ==================== GET ALL USERS FROM ALL SOURCES ====================
function getAllUserIds() {
    const allUsers = new Set();
    
    // Ambil dari saldo.json
    const saldo = loadSaldo();
    console.log(`📂 Saldo.json users: ${Object.keys(saldo).length}`);
    Object.keys(saldo).forEach(id => allUsers.add(id));
    
    // Ambil dari akun.json
    const akun = loadAkun();
    console.log(`📂 Akun.json users: ${Object.keys(akun).length}`);
    Object.keys(akun).forEach(id => allUsers.add(id));
    
    // Ambil dari transaksi.json
    const transaksi = loadTransaksi();
    const transaksiUsers = new Set();
    transaksi.forEach(tx => {
        if (tx.userId) transaksiUsers.add(tx.userId);
    });
    console.log(`📂 Transaksi.json users: ${transaksiUsers.size}`);
    transaksiUsers.forEach(id => allUsers.add(id));
    
    // Ambil dari usernames.json
    const usernames = loadUserNames();
    console.log(`📂 Usernames.json users: ${Object.keys(usernames).length}`);
    Object.keys(usernames).forEach(id => allUsers.add(id));
    
    // Ambil dari trial.json
    const trial = loadTrialData();
    console.log(`📂 Trial.json users: ${Object.keys(trial).length}`);
    Object.keys(trial).forEach(id => allUsers.add(id));
    
    console.log(`📊 Total unique users from all sources: ${allUsers.size}`);
    
    // Log semua user ID untuk debug
    console.log(`📋 User IDs: ${Array.from(allUsers).join(', ')}`);
    
    return allUsers;
}

// ==================== GET ALL USERS WITH DETAILS ====================
function getAllUsersWithDetails() {
    const allUserIds = getAllUserIds();
    const saldo = loadSaldo();
    const akun = loadAkun();
    const result = [];
    
    for (const userId of allUserIds) {
        result.push({
            userId: userId,
            saldo: saldo[userId] || 0,
            totalAkun: akun[userId] ? akun[userId].length : 0
        });
    }
    
    // Urutkan berdasarkan saldo tertinggi
    result.sort((a, b) => b.saldo - a.saldo);
    
    return result;
}

// ==================== DASHBOARD & STATS ====================
// ==================== USER STATS (UPDATED) ====================
function getUserStats() {
    const saldo = loadSaldo();
    const transaksi = loadTransaksi();
    const akun = loadAkun();
    
    // Gunakan getAllUserIds untuk jumlah user sebenarnya
    const allUsers = getAllUserIds();
    const jumlahUser = allUsers.size;
    
    const totalSaldo = Object.values(saldo).reduce((a, b) => a + b, 0);
    const totalAkun = getAllAkunCount();
    const totalTransaksi = transaksi.length;
    
    // Transaksi hari ini
    const today = new Date().toDateString();
    const txHariIni = transaksi.filter(t => new Date(t.waktu).toDateString() === today);
    const totalTxHariIni = txHariIni.reduce((a, t) => a + (t.amount || 0), 0);
    
    // Hitung user yang pernah topup
    const usersWithTopup = new Set();
    transaksi.forEach(tx => {
        if (tx.type === 'topup' && tx.userId) {
            usersWithTopup.add(tx.userId);
        }
    });
    
    return { 
        jumlahUser, 
        totalSaldo, 
        totalAkun,
        totalTransaksi,
        txHariIni: txHariIni.length,
        totalTxHariIni,
        usersWithTopup: usersWithTopup.size
    };
}

// ==================== SHOW MAIN MENU (TEKS + POLLING JADI SATU) ====================
async function showMainMenu(chatId, userId) {
    SERVERS = loadServers();
    const saldo = getSaldo(userId);
    const totalAkunDibuat = getJumlahAkun(userId);
    let fullName = await getUserName(userId);

    // Jika masih 'User', coba cara lain
    if (fullName === 'User') {
        try {
            const contact = await client.getContactById(userId + '@c.us');
            if (contact && contact.pushname) {
                fullName = contact.pushname;
                const savedNames = loadUserNames();
                savedNames[userId] = fullName;
                saveUserNames(savedNames);
                userNamesCache.set(userId, fullName);
            }
        } catch(e) {}
    }
    
    // ==================== CEK ADMIN ====================
    let isAdmin = false;
    let displayNumber = '';
    try {
        const phoneNumber = await getPhoneNumberFromId(userId);
        // Tampilkan nomor yang readable
        if (phoneNumber && !isLID(phoneNumber)) {
            displayNumber = '+' + phoneNumber;
        } else {
            // Fallback ke userId jika nomor belum bisa di-resolve
            displayNumber = userId;
        }
        isAdmin = await isAdminAsync(userId);
    } catch(e) {
        console.log('Gagal cek admin:', e.message);
        displayNumber = userId;
    }
    // ===================================================
    
    // Hitung total transaksi user
    const transaksi = loadTransaksi();
    let totalTransaksiUser = 0;
    let totalNominalTransaksi = 0;
    
    for (const tx of transaksi) {
        if (tx.userId === userId || tx.userId === userId.toString()) {
            totalTransaksiUser++;
            if (tx.amount) totalNominalTransaksi += tx.amount;
        }
    }
    
    const trialData = loadTrialData();
    const today = new Date().toDateString();
    const userTrials = trialData[userId] || [];
    const trialsToday = userTrials.filter(t => new Date(t).toDateString() === today);
    const sisaTrial = Math.max(0, CONFIG.MAX_TRIAL_PER_USER - trialsToday.length);
    
    const serverCount = Object.keys(SERVERS).length;
    const greeting = getGreeting();
    
    // Tampilkan badge admin jika user adalah admin
    const adminBadge = isAdmin ? ' 👑 ADMIN' : '';
    
    // Gabungkan semua teks menu ke dalam satu string untuk pertanyaan polling
    const menuText = `${getHeader('           𝐏 𝐗  𝐒 𝐓 𝐎 𝐑 𝐄  𝐁 𝐎 𝐓')}
╭─────────────────────╮
│  ${greeting}, *${fullName}*
│  📞 *Nomor:* ${displayNumber}
│  ╰───────────────────╯
│
│  📊 *STATISTIK USER*
│  ├ 💰 *Saldo:* ${formatRp(saldo)}
│  ├ 📝 *Total Transaksi:* ${totalTransaksiUser}
│  └ 📦 *Total Akun:* ${totalAkunDibuat}
│
│  🎫 *LAYANAN*
│  ├ 🎟️ *Sisa Trial:* ${sisaTrial}/${CONFIG.MAX_TRIAL_PER_USER}
│  └ 🌐 *Server:* ${serverCount}
│
│  ⚙️ *HARGA*
│  ├ 💵 *Rp ${CONFIG.HARGA_PER_HARI_PER_IP}/hari*
│  ├ 🔗 *Max IP:* ${CONFIG.MAX_IP_LIMIT}
│  └ 💾 *Bandwith:* ${CONFIG.DEFAULT_QUOTA} GB
╰─────────────────────╯
${adminBadge}`;

    const menuOptions = ['▸ Create Akun 🚀', '▸ Trial Akun ⏱️', '▸ Renew Akun ♻️', '▸ Topup Saldo 💵', '▸ Riwayat Transaksi 📜'];
    
    // Tambahkan menu Dashboard jika user adalah admin
    if (isAdmin) {
        menuOptions.push('▸ Dashboard ⚙️');
    }
    
    // Kirim polling dengan teks menu sebagai pertanyaan
    await sendPoll(chatId, userId, menuText, menuOptions, 'main_menu', {});
}

// ==================== RIWAYAT TRANSAKSI USER ====================
async function showRiwayatTransaksiUser(chatId, userId) {
    const cleanUserId = getCleanUserId(userId);
    const semua = loadTransaksi();
    
    // Filter transaksi milik user ini
    const txUser = semua.filter(tx => 
        tx.userId === cleanUserId || tx.userId === cleanUserId.toString()
    );
    
    if (txUser.length === 0) {
        await client.sendMessage(chatId, 
            `${getHeader('📜 RIWAYAT TRANSAKSI')}\n\n` +
            `❌ Belum ada riwayat transaksi.\n\n` +
            `Ketik */menu* untuk kembali ke menu utama.`
        );
        return;
    }
    
    // Tampilkan maksimal 10 transaksi terakhir
    const recent = txUser.slice(0, 10);
    
    const nama = await getUserName(cleanUserId);
    const saldo = getSaldo(cleanUserId);
    
    // Hitung total topup dan total belanja
    let totalTopup = 0;
    let totalBelanja = 0;
    for (const tx of txUser) {
        if (tx.type === 'topup') totalTopup += (tx.amount || 0);
        else if (tx.type === 'purchase' || tx.type === 'create' || tx.type === 'renew') totalBelanja += (tx.amount || 0);
    }
    
    let detail = '';
    for (const tx of recent) {
        let icon = '💳';
        let jenis = tx.type || 'transaksi';
        
        if (tx.type === 'topup') { icon = '⬆️'; jenis = 'Topup'; }
        else if (tx.type === 'purchase' || tx.type === 'create') { icon = '🛒'; jenis = 'Beli Akun'; }
        else if (tx.type === 'renew') { icon = '♻️'; jenis = 'Renew Akun'; }
        else if (tx.type === 'trial') { icon = '⏱️'; jenis = 'Trial'; }
        else if (tx.type === 'debit') { icon = '⬇️'; jenis = 'Debit'; }
        else if (tx.type === 'credit') { icon = '⬆️'; jenis = 'Kredit'; }
        else if (tx.type === 'payg_create') { icon = '⚡'; jenis = 'Aktif PAYG'; }
        else if (tx.type === 'payg_deduct') { icon = '⏰'; jenis = 'PAYG/Jam'; }
        else if (tx.type === 'payg_delete') { icon = '🚫'; jenis = 'PAYG Hapus'; }
        
        const waktu = tx.waktu 
            ? new Date(tx.waktu).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
            : '-';
        
        const nominal = tx.amount ? formatRp(tx.amount) : '-';
        const ket = tx.keterangan ? `\n│    📝 ${tx.keterangan}` : '';
        const txId = tx.txId ? `\n│    🔖 \`${tx.txId}\`` : '';
        const status = tx.status === 'success' ? '✅' : tx.status === 'failed' ? '❌' : '⏳';
        
        detail += `│\n│  ${icon} *${jenis}* ${status}${txId}\n│    💰 ${nominal}\n│    🕐 ${waktu}${ket}\n`;
    }
    
    const sisaInfo = txUser.length > 10 ? `\n_...dan ${txUser.length - 10} transaksi lainnya_` : '';
    
    const msg = `${getHeader('📜 RIWAYAT TRANSAKSI')}
╭─────────────────────╮
│  👤 *${nama}*
│  💳 *Saldo:* ${formatRp(saldo)}
│  📊 *Total Transaksi:* ${txUser.length}
│  ├ ⬆️ Total Topup: ${formatRp(totalTopup)}
│  └ 🛒 Total Belanja: ${formatRp(totalBelanja)}
╰─────────────────────╯

📋 *10 Transaksi Terakhir:*
╭─────────────────────╮
${detail}╰─────────────────────╯${sisaInfo}

Ketik */menu* untuk kembali`;

    await client.sendMessage(chatId, msg);
}

async function showDashboard(chatId, userId) {
    const stats = getUserStats();
    
    const msg = `${getHeader('📊 *DASHBOARD*')}
╭─────────────────────╮
│ ├ *Total User Bot:* ${stats.jumlahUser}
│ ├ *User Pernah Topup:* ${stats.usersWithTopup}
│ ├ *User Tanpa Topup:* ${stats.jumlahUser - stats.usersWithTopup}
│ ├ *Total Akun:* ${stats.totalAkun}
│ ├ *Total Saldo:* ${formatRp(stats.totalSaldo)}
│ ├ *Total Transaksi:* ${stats.totalTransaksi}
│ ├ *Tx Hari Ini:* ${stats.txHariIni} (${formatRp(stats.totalTxHariIni)})
│ ├ *Server Aktif:* ${Object.keys(SERVERS).length}
│ ├ *Harga:* ${formatHarga()}
╰─────────────────────╯

📅 *Update:* ${formatTimestamp()}`;

    const dashboardOptions = [
    '▸ Lihat Semua User & Saldo 👥',
    '▸ Lihat Semua Akun User 📦',
    '▸ List Akun per Server 📋',
    '▸ Detail Akun per Server 🔍',
    '▸ Delete Akun per Server 🗑️',
    '▸ Riwayat Transaksi 📜',
    '▸ Tambah Saldo Manual 💰',
    '▸ Kurangi Saldo Manual 💸',
    '▸ Server Management 🌐',
    '▸ Edit Data Bot ✏️',
    '▸ Kelola Admin 👑',
    '◂ Kembali 🔙'
];
    
    await sendPoll(chatId, userId, msg, dashboardOptions, 'dashboard_menu', {});
}

// ==================== ADMIN MANAGEMENT MENU ====================
async function showAdminManageMenu(chatId, userId) {
    const adminList = getAdminList();
    let listText = '';
    if (adminList.length === 0) {
        listText = '│  _(Belum ada admin)_\n';
    } else {
        adminList.forEach((num, i) => {
            const cleanNum = num.replace(/[^0-9]/g, '');
            // Jika LID, coba tampilkan nomor aslinya dari cache
            let display = '+' + cleanNum;
            if (isLID(cleanNum)) {
                const cached = lidPhoneCache.get(cleanNum);
                display = `LID:${cleanNum}` + (cached ? ` (+${cached})` : ' (nomor belum di-cache)');
            }
            listText += `│  ${i + 1}. ${display}\n`;
        });
    }
    
    const msg = `${getHeader('👑 KELOLA ADMIN')}
╭─────────────────────╮
│ 📋 *Daftar Admin Aktif:*
${listText}╰─────────────────────╯

Pilih aksi:`;

    const options = [
        '➕ Tambah Admin',
        '🗑️ Hapus Admin',
        '◀️ Kembali ke Dashboard'
    ];
    
    await sendPoll(chatId, userId, msg, options, 'admin_manage_menu', {});
}

async function handleTambahAdmin(chatId, userId) {
    processState[userId] = { action: 'input_tambah_admin', waitingForInput: true };
    await client.sendMessage(chatId,
        `👑 *TAMBAH ADMIN BARU*\n\n` +
        `Kirim *nomor WhatsApp* admin baru.\n\n` +
        `Format: *628xxxxxxxxxx* atau *08xxxxxxxxxx*\n\n` +
        `Ketik *cancel* untuk batal`);
}

async function handleHapusAdmin(chatId, userId) {
    const adminList = getAdminList();
    if (adminList.length === 0) {
        await sendAutoDelete(chatId, '❌ Tidak ada admin untuk dihapus.');
        await showAdminManageMenu(chatId, userId);
        return;
    }
    
    const options = adminList.map(num => {
        const cleanNum = num.replace(/[^0-9]/g, '');
        if (isLID(cleanNum)) {
            const cached = lidPhoneCache.get(cleanNum);
            return `🗑️ ${cached ? '+' + cached : 'LID:' + cleanNum}`;
        }
        return `🗑️ +${cleanNum}`;
    });
    options.push('❌ Batal');
    
    await sendPoll(chatId, userId,
        `${getHeader('🗑️ HAPUS ADMIN')}\n\nPilih admin yang ingin dihapus:`,
        options, 'select_admin_to_delete', { adminList });
}

async function processInputTambahAdmin(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'input_tambah_admin') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        delete processState[userId];
        await sendAutoDelete(chatId, '❌ Dibatalkan.');
        await showAdminManageMenu(chatId, userId);
        return true;
    }
    
    // Bersihkan dan normalisasi nomor
    let clean = input.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) clean = '62' + clean.substring(1);
    if (!clean.startsWith('62') && clean.length >= 9 && !isLID(clean)) clean = '62' + clean;
    
    if (clean.length < 10) {
        await sendAutoDelete(chatId,
            '❌ Nomor tidak valid. Minimal 10 digit.\n' +
            'Contoh: *628123456789* atau *08123456789*\n\n' +
            'Ketik *cancel* untuk batal');
        return false;
    }
    
    delete processState[userId];
    const added = addAdmin(clean);
    
    if (!added) {
        await sendAutoDelete(chatId, `⚠️ Nomor *+${clean}* sudah ada di daftar admin.`);
    } else {
        await client.sendMessage(chatId,
            `✅ *Admin baru berhasil ditambahkan!*\n\n` +
            `📞 Nomor: *+${clean}*\n\n` +
            `_Perubahan langsung aktif tanpa restart._`);
        console.log(`👑 Admin baru ditambahkan: ${clean} oleh ${userId}`);
    }
    
    await showAdminManageMenu(chatId, userId);
    return true;
}

// ==================== EDIT DATA BOT MENU ====================
async function showEditDataMenu(chatId, userId) {
    const currentValues = `${getHeader('⚙️ EDIT DATA BOT')}
╭─────────────────────╮
│ ├ *Harga per hari* : Rp ${CONFIG.HARGA_PER_HARI_PER_IP}
│ ├ *Max Trial* : ${CONFIG.MAX_TRIAL_MENIT} menit
│ ├ *Max Trial/Hari* : ${CONFIG.MAX_TRIAL_PER_USER}x
│ ├ *Max IP Limit* : ${CONFIG.MAX_IP_LIMIT} IP
│ ├ *Minimal Topup* : ${formatRp(CONFIG.MIN_TOPUP)}
│ ├ *Nama Merchant* : ${CONFIG.MERCHANT_NAME}
│ ├ *Default Quota* : ${CONFIG.DEFAULT_QUOTA} GB
╰─────────────────────╯

Pilih data yang ingin diedit:`;

    const editOptions = [
        '💰 Harga per Hari',
        '⏱️ Max Trial (menit)',
        '🎫 Max Trial per Hari',
        '🔌 Max IP Limit',
        '💵 Minimal Topup',
        '🏪 Nama Merchant',
        '💾 Default Quota',
        '◀️ Kembali ke Dashboard'
    ];
    
    await sendPoll(chatId, userId, currentValues, editOptions, 'edit_data_menu', {});
}

// ==================== EDIT DATA BOT HANDLERS ====================
// Edit Harga
async function handleEditHarga(chatId, userId) {
    processState[userId] = { action: 'edit_harga', waitingForInput: true };
    await client.sendMessage(chatId, 
        `💰 *Edit Harga per Hari*\n\n` +
        `Harga saat ini: *Rp ${CONFIG.HARGA_PER_HARI_PER_IP}* /hari/IP\n\n` +
        `Kirim harga baru (contoh: *500*):\n` +
        `Ketik *cancel* untuk batal`);
}

// Edit Max Trial (menit)
async function handleEditTrialMenit(chatId, userId) {
    processState[userId] = { action: 'edit_trial_menit', waitingForInput: true };
    await client.sendMessage(chatId, 
        `⏱️ *Edit Max Trial (menit)*\n\n` +
        `Saat ini: *${CONFIG.MAX_TRIAL_MENIT}* menit\n\n` +
        `Kirim durasi baru (contoh: *60*):\n` +
        `Ketik *cancel* untuk batal`);
}

// Edit Max Trial per Hari
async function handleEditTrialPerHari(chatId, userId) {
    processState[userId] = { action: 'edit_trial_per_hari', waitingForInput: true };
    await client.sendMessage(chatId, 
        `🎫 *Edit Max Trial per Hari*\n\n` +
        `Saat ini: *${CONFIG.MAX_TRIAL_PER_USER}* x/hari\n\n` +
        `Kirim batas baru (contoh: *3*):\n` +
        `Ketik *cancel* untuk batal`);
}

// Edit Max IP Limit
async function handleEditIpLimit(chatId, userId) {
    processState[userId] = { action: 'edit_ip_limit', waitingForInput: true };
    await client.sendMessage(chatId, 
        `🔌 *Edit Max IP Limit*\n\n` +
        `Saat ini: *${CONFIG.MAX_IP_LIMIT}* IP\n\n` +
        `Kirim batas baru (contoh: *3*):\n` +
        `Ketik *cancel* untuk batal`);
}

// Edit Minimal Topup
async function handleEditMinTopup(chatId, userId) {
    processState[userId] = { action: 'edit_min_topup', waitingForInput: true };
    await client.sendMessage(chatId, 
        `💵 *Edit Minimal Topup*\n\n` +
        `Saat ini: *${formatRp(CONFIG.MIN_TOPUP)}*\n\n` +
        `Kirim minimal baru (contoh: *20000*):\n` +
        `Ketik *cancel* untuk batal`);
}

// Edit Nama Merchant
async function handleEditMerchantName(chatId, userId) {
    processState[userId] = { action: 'edit_merchant_name', waitingForInput: true };
    await client.sendMessage(chatId, 
        `🏪 *Edit Nama Merchant*\n\n` +
        `Saat ini: *${CONFIG.MERCHANT_NAME}*\n\n` +
        `Kirim nama merchant baru:\n` +
        `Ketik *cancel* untuk batal`);
}

// Edit Default Quota
async function handleEditQuota(chatId, userId) {
    processState[userId] = { action: 'edit_quota', waitingForInput: true };
    await client.sendMessage(chatId, 
        `💾 *Edit Default Quota*\n\n` +
        `Quota saat ini: *${CONFIG.DEFAULT_QUOTA} GB*\n\n` +
        `Kirim quota baru (contoh: *200*):\n` +
        `Ketik *cancel* untuk batal`);
}

// ==================== POLL VOTE HANDLER ====================
client.on('vote_update', async (vote) => {
    if (!isReady) return;
    try {
        const pollMsgId = vote.parentMessage.id._serialized;
        const state = pollState.get(pollMsgId);
        if (!state) return;

        const { userId, chatId, type, options, context } = state;
        
        // ✅ DEKLARASI SEL HANYA SEKALI DI SINI
        const sel = vote.selectedOptions[0]?.name;
        if (!sel) return;

        console.log(`🗳️ Poll [${type}] dari ${userId}: ${sel}`);
        pollState.delete(pollMsgId);
        savePollState(); // Simpan perubahan ke file

        // Hapus pesan poll setelah dipilih (untuk semua orang)
        try {
            const pollMsg = await client.getMessageById(pollMsgId);
            if (pollMsg) await pollMsg.delete(true);
        } catch(e) {
            console.log(`[Poll] Gagal hapus poll: ${e.message}`);
        }

        if (type === 'main_menu') {
    const map = {
        '▸ Create Akun 🚀': () => showCreateModeMenu(chatId, userId),
        '▸ Trial Akun ⏱️': () => showServiceMenuTrial(chatId, userId),
        '▸ Renew Akun ♻️': () => showServiceMenuRenew(chatId, userId),
        '▸ Topup Saldo 💵': () => handleTopup(chatId, userId),
        '▸ Riwayat Transaksi 📜': () => showRiwayatTransaksiUser(chatId, userId),
    };
    
    // Jika ada menu Dashboard untuk admin
    if (map[sel]) {
        await map[sel]();
    } else if (sel === '▸ Dashboard ⚙️') {
        await showDashboard(chatId, userId);
    } else {
        await showMainMenu(chatId, userId);
    }
}

else if (type === 'view_server_detail') {
    
    if (sel === '◂ Kembali') {
        await showServerMenu(chatId, userId);
        return;
    }
    
    const servers = context.servers;
    let selectedServer = null;
    
    for (const s of servers) {
        let icon = '';
        if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        else if (s.type === 'zivpn') icon = '🔥';
        const optionText = `${icon} ${s.name} (${s.type.toUpperCase()})`;
        if (optionText === sel) {
            selectedServer = s;
            break;
        }
    }
    
    if (!selectedServer) {
        await sendAutoDelete(chatId, '❌ Server tidak ditemukan.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    let typeIcon = '';
    let typeLabel = '';
    if (selectedServer.type === 'ssh') {
        typeIcon = '🔒';
        typeLabel = 'SSH';
    } else if (selectedServer.type === 'xray') {
        typeIcon = '📡';
        typeLabel = 'XRAY (VMess/VLess/Trojan)';
    } else if (selectedServer.type === 'zivpn') {
        typeIcon = '🔥';
        typeLabel = 'ZiVPN';
    }
    
    const detailText = `${getHeader('📡 DETAIL SERVER')}
${typeIcon} *${selectedServer.name}*
━━━━━━━━━━━━━━━━━━━━━
📋 Tipe    : ${typeLabel}
📡 API     : ${selectedServer.apiUrl}
🔑 Auth Key: \`${selectedServer.authKey}\`
🆔 ID      : \`${selectedServer.id}\`
━━━━━━━━━━━━━━━━━━━━━
📅 Waktu: ${formatTimestamp()}`;
    
    await client.sendMessage(chatId, detailText);
    await showServerMenu(chatId, userId);
}

else if (type === 'service_status_select') {
    if (sel === '◂ Kembali') {
        await showServerMenu(chatId, userId);
        return;
    }

    const servers = context.servers;
    let selectedServer = null;

    for (const s of servers) {
        const icon = s.type === 'ssh' ? '🔒' : s.type === 'xray' ? '📡' : '🔥';
        const optionText = `${icon} ${s.name}`;
        if (optionText === sel) {
            selectedServer = s;
            break;
        }
    }

    if (!selectedServer) {
        await sendAutoDelete(chatId, '❌ Server tidak ditemukan.');
        await showServerMenu(chatId, userId);
        return;
    }

    const loadingMsg = await client.sendMessage(chatId, `⏳ Mengambil status service dari *${selectedServer.name}*...`);
    await handleViewServiceStatus(chatId, userId, selectedServer, loadingMsg);
}

else if (type === 'server_menu') {
    
    console.log(`📡 Server menu selected: ${sel}`);
    
    if (sel === '▸ Lihat Detail Server 👀') {
        await showServerDetailList(chatId, userId);
    }
    else if (sel === '▸ Status Service Server 🖥️') {
        await showServiceStatusSelect(chatId, userId);
    }
    else if (sel === '▸ Tambah Server ➕') {
        await handleAddServer(chatId, userId);
    }
    else if (sel === '▸ Edit Server ✏️') {
        await showServerEditList(chatId, userId);  // <-- sudah benar
    }
    else if (sel === '▸ Hapus Server 🗑️') {
        await showServerDeleteList(chatId, userId);  // <-- perlu ditambahkan
    }
    else if (sel === '◂ Kembali 🔙') {
        await showDashboard(chatId, userId);
    }
    else {
        await showServerMenu(chatId, userId);
    }
}
        // ==================== DASHBOARD MENU ====================
        else if (type === 'dashboard_menu') {
    const map = {
        '▸ Lihat Semua User & Saldo 👥': () => showAllUserSaldo(chatId),
        '▸ Lihat Semua Akun User 📦': () => showAllUserAkun(chatId),
        '▸ List Akun per Server 📋': () => showSelectServerForList(chatId, userId),
        '▸ Detail Akun per Server 🔍': () => showSelectServerForDetail(chatId, userId),
        '▸ Delete Akun per Server 🗑️': () => showSelectServerForDelete(chatId, userId),
        '▸ Riwayat Transaksi 📜': () => showRiwayatTransaksi(chatId),
        '▸ Tambah Saldo Manual 💰': () => handleEditSaldoAdmin(chatId, userId, 'add'),
        '▸ Kurangi Saldo Manual 💸': () => handleEditSaldoAdmin(chatId, userId, 'reduce'),
        '▸ Server Management 🌐': () => showServerMenu(chatId, userId),
        '▸ Edit Data Bot ✏️': () => showEditDataMenu(chatId, userId), 
        '▸ Kelola Admin 👑': () => showAdminManageMenu(chatId, userId),
        '◂ Kembali 🔙': () => showMainMenu(chatId, userId),
    };
    if (map[sel]) {
        await map[sel]();
    } else {
        await showDashboard(chatId, userId);
    }
}

else if (type === 'admin_manage_menu') {
    if (sel === '➕ Tambah Admin') {
        await handleTambahAdmin(chatId, userId);
    } else if (sel === '🗑️ Hapus Admin') {
        await handleHapusAdmin(chatId, userId);
    } else if (sel === '◀️ Kembali ke Dashboard') {
        await showDashboard(chatId, userId);
    } else {
        await showAdminManageMenu(chatId, userId);
    }
}

else if (type === 'select_admin_to_delete') {
    if (sel === '❌ Batal') {
        await showAdminManageMenu(chatId, userId);
        return;
    }
    
    // Cari admin yang dipilih berdasarkan opsi yang ditampilkan
    const adminList = context.adminList;
    let targetNum = null;
    
    for (const num of adminList) {
        const cleanNum = num.replace(/[^0-9]/g, '');
        let expectedOption = '';
        if (isLID(cleanNum)) {
            const cached = lidPhoneCache.get(cleanNum);
            expectedOption = `🗑️ ${cached ? '+' + cached : 'LID:' + cleanNum}`;
        } else {
            expectedOption = `🗑️ +${cleanNum}`;
        }
        if (expectedOption === sel) {
            targetNum = cleanNum;
            break;
        }
    }
    
    if (!targetNum) {
        await sendAutoDelete(chatId, '❌ Admin tidak ditemukan.');
        await showAdminManageMenu(chatId, userId);
        return;
    }
    
    // Cegah admin hapus dirinya sendiri
    const selfClean = getCleanUserId(userId).replace(/[^0-9]/g, '');
    const selfPhone = await getPhoneNumberFromId(userId);
    if (targetNum === selfClean || targetNum === selfPhone.replace(/[^0-9]/g, '')) {
        await sendAutoDelete(chatId, '❌ Anda tidak dapat menghapus diri sendiri dari daftar admin.');
        await showAdminManageMenu(chatId, userId);
        return;
    }
    
    const removed = removeAdmin(targetNum);
    if (removed) {
        const display = isLID(targetNum) ? `LID:${targetNum}` : `+${targetNum}`;
        await client.sendMessage(chatId, `✅ *Admin berhasil dihapus!*\n\n📞 Nomor: *${display}*\n\n_Perubahan langsung aktif._`);
        console.log(`👑 Admin dihapus: ${targetNum} oleh ${userId}`);
    } else {
        await sendAutoDelete(chatId, `❌ Admin tidak ditemukan di daftar.`);
    }
    await showAdminManageMenu(chatId, userId);
}

else if (type === 'edit_data_menu') {
    console.log(`✏️ Edit data menu selected: ${sel}`);
    
    if (sel === '💰 Harga per Hari') {
        await handleEditHarga(chatId, userId);
    }
    else if (sel === '⏱️ Max Trial (menit)') {
        await handleEditTrialMenit(chatId, userId);
    }
    else if (sel === '🎫 Max Trial per Hari') {
        await handleEditTrialPerHari(chatId, userId);
    }
    else if (sel === '🔌 Max IP Limit') {
        await handleEditIpLimit(chatId, userId);
    }
    else if (sel === '💵 Minimal Topup') {
        await handleEditMinTopup(chatId, userId);
    }
    else if (sel === '🏪 Nama Merchant') {
        await handleEditMerchantName(chatId, userId);
    }
    else if (sel === '💾 Default Quota') {
        await handleEditQuota(chatId, userId);
    }
    else if (sel === '◀️ Kembali ke Dashboard') {
        await showDashboard(chatId, userId);
    }
    else {
        await showEditDataMenu(chatId, userId);
    }
}
        // ==================== CREATE MODE SELECT ====================
        else if (type === 'create_mode_select') {
            if (sel === '◂ Kembali') {
                await showMainMenu(chatId, userId);
            } else if (sel === '📦 Create Biasa') {
                await showServiceMenuCreate(chatId, userId);
            } else if (sel === '⚡ Pay As You Go (PAYG)') {
                await showServiceMenuPayg(chatId, userId);
            } else {
                await showCreateModeMenu(chatId, userId);
            }
        }
        // ==================== SERVICE SELECT PAYG ====================
        else if (type === 'service_select_payg') {
            const svcMap = {
                '▸ SSH': 'ssh', '▸ Trojan': 'trojan',
                '▸ VLess': 'vless', '▸ VMess': 'vmess', '▸ ZiVPN': 'zivpn'
            };
            if (sel === '◂ Kembali') {
                await showCreateModeMenu(chatId, userId);
                return;
            }
            const svc = svcMap[sel];
            if (svc) await handleCreatePayg(chatId, userId, svc);
        }
        // ==================== PAYG CONFIRM ====================
        else if (type === 'payg_confirm') {
            const { serviceType, server, data } = context;
            if (sel === '❌ Batal') {
                await sendAutoDelete(chatId, '❌ Pembuatan akun PAYG dibatalkan.');
                delete processState[userId];
                await showMainMenu(chatId, userId);
            } else if (sel === '✅ Ya, Aktifkan PAYG') {
                await eksekusiCreatePayg(chatId, userId, serviceType, server, data);
            }
        }
        // ==================== SERVICE SELECT CREATE ====================
        else if (type === 'service_select_create') {
            const svcMap = { 
                '▸ SSH': 'ssh', 
                '▸ Trojan': 'trojan', 
                '▸ VLess': 'vless', 
                '▸ VMess': 'vmess', 
                '▸ ZiVPN': 'zivpn' 
            };
            if (sel === '◂ Kembali') { 
                await showMainMenu(chatId, userId); 
                return; 
            }
            const svc = svcMap[sel];
            if (svc) await handleCreate(chatId, userId, svc);
        }
        // ==================== SERVICE SELECT TRIAL ====================
        else if (type === 'service_select_trial') {
            const svcMap = { 
                '▸ SSH': 'ssh', 
                '▸ Trojan': 'trojan', 
                '▸ VLess': 'vless', 
                '▸ VMess': 'vmess', 
                '▸ ZiVPN': 'zivpn' 
            };
            if (sel === '◂ Kembali') { 
                await showMainMenu(chatId, userId); 
                return; 
            }
            const svc = svcMap[sel];
            if (svc) await handleTrial(chatId, userId, svc);
        }
        // ==================== SERVICE SELECT RENEW ====================
        else if (type === 'service_select_renew') {
            const svcMap = { 
                '▸ SSH': 'ssh', 
                '▸ Trojan': 'trojan', 
                '▸ VLess': 'vless', 
                '▸ VMess': 'vmess', 
                '▸ ZiVPN': 'zivpn' 
            };
            if (sel === '◂ Kembali') { 
                await showMainMenu(chatId, userId); 
                return; 
            }
            const svc = svcMap[sel];
            if (svc) await handleRenew(chatId, userId, svc);
        }
        // ==================== SERVER SELECT ====================
        else if (type === 'server_select') {
    // Ambil pilihan dari polling
    
    console.log(`📡 Server select: ${sel}`);
    
    // Handle Batal - PERBAIKI INI
    if (sel === '❌ Batal') {
        console.log(`❌ User ${userId} membatalkan pilihan server`);
        
        // Resolve promise dengan null
        if (serverSelState[userId] && serverSelState[userId].resolve) {
            clearTimeout(serverSelState[userId].timeout);
            serverSelState[userId].resolve(null);
            delete serverSelState[userId];
        }
        
        // Kirim pesan konfirmasi batal
        await sendAutoDelete(chatId, '❌ Pemilihan server dibatalkan.');
        
        // Kembali ke menu sebelumnya
        await showMainMenu(chatId, userId);
        return;
    }
    
    // Cari server yang dipilih
    const servers = context.servers;
    let selectedServer = null;
    
    // Cocokkan dengan opsi yang ada (tanpa tambahan teks)
    for (let i = 0; i < servers.length; i++) {
        const s = servers[i];
        let icon = '';
        if (s.type === 'zivpn') icon = '🔥';
        else if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        
        // Format opsi yang dikirim
        const optionText = `${icon} ${s.name}`;
        
        if (optionText === sel) {
            selectedServer = s;
            break;
        }
    }
    
    if (selectedServer) {
        console.log(`✅ Server dipilih: ${selectedServer.name}`);
        
        if (serverSelState[userId] && serverSelState[userId].resolve) {
            clearTimeout(serverSelState[userId].timeout);
            serverSelState[userId].resolve(selectedServer);
            delete serverSelState[userId];
        }
    } else {
        console.log(`❌ Server tidak ditemukan untuk pilihan: ${sel}`);
        
        if (serverSelState[userId] && serverSelState[userId].resolve) {
            clearTimeout(serverSelState[userId].timeout);
            serverSelState[userId].resolve(null);
            delete serverSelState[userId];
        }
        
        await sendAutoDelete(chatId, '❌ Server tidak ditemukan. Silakan coba lagi.');
        await showMainMenu(chatId, userId);
    }
}
        // ==================== CREATE CONFIRM ====================
        else if (type === 'create_confirm') {
    
    console.log(`💰 Create confirm: ${sel} untuk user ${userId}`);
    
    // Ambil data dari context
    const { serviceType, server, parsed, totalHarga } = context;
    
    if (sel === '❌ Batal') {
        await sendAutoDelete(chatId, '❌ Pembuatan akun dibatalkan.');
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return;
    }
    
    if (sel === '✅ Ya, Lanjutkan') {
        // Cek saldo sebelum eksekusi
        const saldoUser = getSaldo(userId);
        if (saldoUser < totalHarga) {
            await sendAutoDelete(chatId,
                `❌ *Saldo tidak cukup!*\n\n` +
                `💰 Harga  : *${formatRp(totalHarga)}*\n` +
                `💳 Saldo  : *${formatRp(saldoUser)}*\n` +
                `📉 Kurang : *${formatRp(totalHarga - saldoUser)}*\n\n` +
                `Silakan topup saldo terlebih dahulu.`);
            delete processState[userId];
            await showMainMenu(chatId, userId);
            return;
        }
        
        // Panggil eksekusiCreate
        await eksekusiCreate(chatId, userId, serviceType, server, parsed, totalHarga);
    }
}
        // ==================== RENEW CONFIRM ====================
        else if (type === 'renew_confirm') {
    
    console.log(`🔄 Renew confirm: ${sel} untuk user ${userId}`);
    
    // Ambil data dari context
    const { serviceType, server, parsed, totalHarga } = context;
    
    if (sel === '❌ Batal') {
        await sendAutoDelete(chatId, '❌ Perpanjangan akun dibatalkan.');
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return;
    }
    
    if (sel === '✅ Ya, Lanjutkan') {
        // Cek saldo sebelum eksekusi
        const saldoUser = getSaldo(userId);
        if (saldoUser < totalHarga) {
            await sendAutoDelete(chatId,
                `❌ *Saldo tidak cukup!*\n\n` +
                `💰 Harga  : *${formatRp(totalHarga)}*\n` +
                `💳 Saldo  : *${formatRp(saldoUser)}*\n` +
                `📉 Kurang : *${formatRp(totalHarga - saldoUser)}*\n\n` +
                `Silakan topup saldo terlebih dahulu.`);
            delete processState[userId];
            await showMainMenu(chatId, userId);
            return;
        }
        
        // Panggil eksekusiRenew
        await eksekusiRenew(chatId, userId, serviceType, server, parsed, totalHarga);
    }
}

else if (type === 'select_server_to_edit') {
    
    if (sel === '❌ Batal') {
        await showServerMenu(chatId, userId);
        return;
    }
    
    const servers = context.servers;
    let selectedServer = null;
    
    for (const s of servers) {
        let icon = '';
        if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        else if (s.type === 'zivpn') icon = '🔥';
        const optionText = `${icon} ${s.name} (${s.type.toUpperCase()})`;
        if (optionText === sel) {
            selectedServer = s;
            break;
        }
    }
    
    if (!selectedServer) {
        await sendAutoDelete(chatId, '❌ Server tidak ditemukan.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    // Simpan server yang dipilih ke state
    processState[userId] = {
        action: 'edit_server_choose_field',
        serverId: selectedServer.id,
        serverName: selectedServer.name,
        serverType: selectedServer.type,
        serverApiUrl: selectedServer.apiUrl,
        serverAuthKey: selectedServer.authKey,
        waitingForInput: false
    };
    
    // Tampilkan pilihan komponen yang ingin diedit
    const editOptions = [
        '📛 Nama Server',
        '🏷️ Tipe Server',
        '🌐 Domain & Port',
        '🔑 Auth Key',
        '◂ Kembali ke Menu Server'
    ];
    
    const currentData = `${getHeader(`✏️ EDIT SERVER: ${selectedServer.name}`)}
╭─────────────────╮
│ 📛 Nama    : ${selectedServer.name}
│ 🏷️ Tipe    : ${selectedServer.type.toUpperCase()}
│ 🌐 API     : ${selectedServer.apiUrl}
│ 🔑 Auth Key: \`${selectedServer.authKey}\`
╰─────────────────╯

Pilih komponen yang ingin diedit:`;
    
    await sendPoll(chatId, userId, currentData, editOptions, 'edit_server_choose_field', {});
}

else if (type === 'edit_server_choose_field') {
    
    if (sel === '◂ Kembali ke Menu Server') {
        await showServerMenu(chatId, userId);
        return;
    }
    
    const state = processState[userId];
    if (!state || state.action !== 'edit_server_choose_field') return;
    
    if (sel === '📛 Nama Server') {
        processState[userId] = {
            action: 'edit_server_name',
            serverId: state.serverId,
            waitingForInput: true
        };
        await client.sendMessage(chatId, 
            `✏️ *Edit Nama Server*\n\n` +
            `Nama saat ini: *${state.serverName}*\n\n` +
            `Kirim nama baru:\n` +
            `Ketik *cancel* untuk batal`);
    }
    else if (sel === '🏷️ Tipe Server') {
        processState[userId] = {
            action: 'edit_server_type',
            serverId: state.serverId,
            waitingForInput: true
        };
        await client.sendMessage(chatId, 
            `✏️ *Edit Tipe Server*\n\n` +
            `Tipe saat ini: *${state.serverType.toUpperCase()}*\n\n` +
            `Pilih tipe baru:\n` +
            `1. 🔒 SSH\n` +
            `2. 📡 XRAY (VMess/VLess/Trojan)\n` +
            `3. 🔥 ZiVPN\n\n` +
            `Kirim nomor 1-3:\n` +
            `Ketik *cancel* untuk batal`);
    }
    else if (sel === '🌐 Domain & Port') {
        processState[userId] = {
            action: 'edit_server_domain',
            serverId: state.serverId,
            waitingForInput: true
        };
        // Parse domain dan port dari apiUrl
        const apiUrl = state.serverApiUrl;
        const domainPort = apiUrl.replace('http://', '');
        await client.sendMessage(chatId, 
            `✏️ *Edit Domain & Port*\n\n` +
            `Saat ini: *${domainPort}*\n\n` +
            `Kirim domain dan port baru (contoh: *cloud.peyx.site:8585*):\n` +
            `Ketik *cancel* untuk batal`);
    }
    else if (sel === '🔑 Auth Key') {
        processState[userId] = {
            action: 'edit_server_auth',
            serverId: state.serverId,
            waitingForInput: true
        };
        await client.sendMessage(chatId, 
            `✏️ *Edit Auth Key*\n\n` +
            `Auth Key saat ini: \`${state.serverAuthKey}\`\n\n` +
            `Kirim auth key baru (minimal 5 karakter):\n` +
            `Ketik *cancel* untuk batal`);
    }
}

else if (type === 'select_server_to_delete') {
    
    if (sel === '❌ Batal') {
        await showServerMenu(chatId, userId);
        return;
    }
    
    const servers = context.servers;
    let selectedServer = null;
    
    for (const s of servers) {
        let icon = '';
        if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        else if (s.type === 'zivpn') icon = '🔥';
        const optionText = `${icon} ${s.name} (${s.type.toUpperCase()})`;
        if (optionText === sel) {
            selectedServer = s;
            break;
        }
    }
    
    if (!selectedServer) {
        await sendAutoDelete(chatId, '❌ Server tidak ditemukan.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    // Konfirmasi hapus
    await sendPoll(chatId, userId, 
        `⚠️ *KONFIRMASI HAPUS SERVER*\n\n` +
        `Apakah Anda yakin ingin menghapus server *${selectedServer.name}*?\n\n` +
        `🗑️ Tipe: ${selectedServer.type.toUpperCase()}\n` +
        `📡 API: ${selectedServer.apiUrl}\n\n` +
        `⚠️ Tindakan ini tidak dapat dibatalkan!`,
        ['✅ Ya, Hapus', '❌ Tidak, Batal'],
        'confirm_delete_server',
        { serverId: selectedServer.id, serverName: selectedServer.name }
    );
}

else if (type === 'confirm_delete_server') {
    
    if (sel === '❌ Tidak, Batal') {
        await sendAutoDelete(chatId, '❌ Penghapusan dibatalkan.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    if (sel === '✅ Ya, Hapus') {
        const serverId = context.serverId;
        const serverName = context.serverName;
        
        if (SERVERS[serverId]) {
            delete SERVERS[serverId];
            saveServers(SERVERS);
            await sendAutoDelete(chatId, `✅ Server *${serverName}* berhasil dihapus.`);
        } else {
            await sendAutoDelete(chatId, `❌ Server tidak ditemukan.`);
        }
        
        await showServerMenu(chatId, userId);
    }
}

        // Tambahkan di dalam client.on('vote_update', async (vote) => { ... })
// Setelah case 'renew_confirm' atau sebelum closing bracket

// ==================== SELECT USER FOR SALDO ====================
// ==================== SELECT USER FOR SALDO (TAMBAH/KURANG) ====================
else if (type === 'select_user_for_saldo') {
    
    console.log(`📊 Poll select_user_for_saldo, selected: ${sel}`);
    
    const itemsPerPage = context.itemsPerPage || 10;
    let currentPage = context.currentPage || 0;
    const userList = context.userList;
    const mode = context.mode;
    
    // Handle Batal
    if (sel === '❌ Batal') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        await showDashboard(chatId, userId);
        return;
    }
    
    // Handle Next Page
    if (sel === '📄 Next Page ➡️') {
        currentPage++;
        if (currentPage >= Math.ceil(userList.length / itemsPerPage)) {
            currentPage = 0;
        }
        
        const startIdx = currentPage * itemsPerPage;
        const endIdx = Math.min(startIdx + itemsPerPage, userList.length);
        const options = [];
        
        for (let i = startIdx; i < endIdx; i++) {
            const user = userList[i];
            const shortName = user.name.length > 25 ? user.name.substring(0, 25) + '...' : user.name;
            options.push(`👤 ${shortName} | 💰 ${formatRp(user.saldo)} | 📦 ${user.akunCount} akun`);
        }
        
        if (userList.length > itemsPerPage) {
            options.push('📄 Next Page ➡️');
        }
        if (currentPage > 0) {
            options.push('◀️ Previous Page');
        }
        options.push('❌ Batal');
        
        const modeText = mode === 'add' ? 'TAMBAH SALDO' : 'KURANGI SALDO';
        const headerText = `${getHeader(`💰 ${modeText}`)}\n\n📋 Klik pilihan user di bawah ini (Halaman ${currentPage + 1}):\n\n`;
        
        await sendPoll(chatId, userId, headerText, options, 'select_user_for_saldo', {
            mode: mode,
            userList: userList,
            currentPage: currentPage,
            itemsPerPage: itemsPerPage
        });
        return;
    }
    
    // Handle Previous Page
    if (sel === '◀️ Previous Page') {
        currentPage--;
        if (currentPage < 0) {
            currentPage = Math.ceil(userList.length / itemsPerPage) - 1;
        }
        
        const startIdx = currentPage * itemsPerPage;
        const endIdx = Math.min(startIdx + itemsPerPage, userList.length);
        const options = [];
        
        for (let i = startIdx; i < endIdx; i++) {
            const user = userList[i];
            const shortName = user.name.length > 25 ? user.name.substring(0, 25) + '...' : user.name;
            options.push(`👤 ${shortName} | 💰 ${formatRp(user.saldo)} | 📦 ${user.akunCount} akun`);
        }
        
        if (userList.length > itemsPerPage) {
            options.push('📄 Next Page ➡️');
        }
        if (currentPage > 0) {
            options.push('◀️ Previous Page');
        }
        options.push('❌ Batal');
        
        const modeText = mode === 'add' ? 'TAMBAH SALDO' : 'KURANGI SALDO';
        const headerText = `${getHeader(`💰 ${modeText}`)}\n\n📋 Klik pilihan user di bawah ini (Halaman ${currentPage + 1}):\n\n`;
        
        await sendPoll(chatId, userId, headerText, options, 'select_user_for_saldo', {
            mode: mode,
            userList: userList,
            currentPage: currentPage,
            itemsPerPage: itemsPerPage
        });
        return;
    }
    
    // Cari user yang dipilih berdasarkan nama
    let selectedUser = null;
    let selectedIndex = -1;
    
    for (let i = 0; i < userList.length; i++) {
        const user = userList[i];
        const optionText = `👤 ${user.name.length > 25 ? user.name.substring(0, 25) + '...' : user.name} | 💰 ${formatRp(user.saldo)} | 📦 ${user.akunCount} akun`;
        if (optionText === sel) {
            selectedUser = user;
            selectedIndex = i;
            break;
        }
    }
    
    if (!selectedUser) {
        await sendAutoDelete(chatId, '❌ Gagal menemukan user yang dipilih.');
        await showDashboard(chatId, userId);
        return;
    }
    
    console.log(`✅ User selected: ${selectedUser.name} (${selectedUser.userId})`);
    
    // Simpan ke state untuk input nominal
    processState[userId] = {
        action: 'input_saldo_amount',
        mode: mode,
        targetUserId: selectedUser.userId,
        targetName: selectedUser.name,
        waitingForInput: true
    };
    
    const modeText = mode === 'add' ? 'TAMBAH' : 'KURANGI';
    await client.sendMessage(chatId, 
        `✅ *User Dipilih:* ${selectedUser.name}\n\n` +
        `💰 *${modeText} SALDO*\n\n` +
        `👤 *User:* ${selectedUser.name}\n` +
        `🆔 *ID:* ${selectedUser.userId}\n` +
        `💳 *Saldo Saat Ini:* ${formatRp(selectedUser.saldo)}\n\n` +
        `📝 Kirim *nominal* (contoh: *50000*):\n` +
        `Ketik *cancel* untuk batal`);
}

// ==================== SELECT SERVER FOR LIST AKUN ====================
else if (type === 'select_server_for_list') {
    if (sel === '❌ Batal') {
        await showDashboard(chatId, userId);
        return;
    }

    const servers = context.servers;
    let selectedServer = null;
    for (const s of servers) {
        let icon = s.type === 'ssh' ? '🔒' : s.type === 'xray' ? '📡' : '🔥';
        if (`${icon} ${s.name} (${s.type.toUpperCase()})` === sel) {
            selectedServer = s;
            break;
        }
    }

    if (!selectedServer) {
        await sendAutoDelete(chatId, '❌ Server tidak ditemukan.');
        await showDashboard(chatId, userId);
        return;
    }

    // Jika server xray dan belum ada serviceType spesifik, minta pilih type
    if (selectedServer.type === 'xray' && !selectedServer.serviceType) {
        await sendPoll(chatId, userId,
            `${getHeader('📋 LIST AKUN - PILIH TYPE')}\n\n` +
            `🌐 Server: *${selectedServer.name}*\n\n` +
            `📡 Pilih tipe protokol XRAY:`,
            ['📦 VMess', '🔷 VLess', '🛡️ Trojan', '❌ Batal'],
            'select_xray_type_for_list',
            { server: selectedServer }
        );
        return;
    }

    await adminListAkunPerServer(chatId, userId, selectedServer);
}

// ==================== SELECT XRAY TYPE FOR LIST ====================
else if (type === 'select_xray_type_for_list') {
    if (sel === '❌ Batal') {
        await showDashboard(chatId, userId);
        return;
    }

    const server = context.server;
    let xrayType = null;
    if (sel === '📦 VMess') xrayType = 'vmess';
    else if (sel === '🔷 VLess') xrayType = 'vless';
    else if (sel === '🛡️ Trojan') xrayType = 'trojan';

    if (!xrayType) {
        await sendAutoDelete(chatId, '❌ Type tidak valid.');
        await showDashboard(chatId, userId);
        return;
    }

    // Set serviceType sesuai pilihan
    const serverWithType = { ...server, serviceType: xrayType };
    await adminListAkunPerServer(chatId, userId, serverWithType);
}

// ==================== SELECT SERVER FOR DETAIL AKUN ====================
else if (type === 'select_server_for_detail') {
    if (sel === '❌ Batal') {
        await showDashboard(chatId, userId);
        return;
    }

    const servers = context.servers;
    let selectedServer = null;
    for (const s of servers) {
        let icon = s.type === 'ssh' ? '🔒' : s.type === 'xray' ? '📡' : '🔥';
        if (`${icon} ${s.name} (${s.type.toUpperCase()})` === sel) {
            selectedServer = s;
            break;
        }
    }

    if (!selectedServer) {
        await sendAutoDelete(chatId, '❌ Server tidak ditemukan.');
        await showDashboard(chatId, userId);
        return;
    }

    if (selectedServer.type === 'xray' && !selectedServer.serviceType) {
        await sendPoll(chatId, userId,
            `${getHeader('🔍 DETAIL AKUN - PILIH TYPE')}\n\n` +
            `🌐 Server: *${selectedServer.name}*\n\n` +
            `📡 Pilih tipe protokol XRAY:`,
            ['📦 VMess', '🔷 VLess', '🛡️ Trojan', '❌ Batal'],
            'select_xray_type_for_detail',
            { server: selectedServer }
        );
        return;
    }

    await showAkunListForDetail(chatId, userId, selectedServer);
}

// ==================== SELECT XRAY TYPE FOR DETAIL ====================
else if (type === 'select_xray_type_for_detail') {
    if (sel === '❌ Batal') {
        await showDashboard(chatId, userId);
        return;
    }

    const server = context.server;
    let xrayType = null;
    if (sel === '📦 VMess') xrayType = 'vmess';
    else if (sel === '🔷 VLess') xrayType = 'vless';
    else if (sel === '🛡️ Trojan') xrayType = 'trojan';

    if (!xrayType) {
        await sendAutoDelete(chatId, '❌ Type tidak valid.');
        await showDashboard(chatId, userId);
        return;
    }

    const serverWithType = { ...server, serviceType: xrayType };
    await showAkunListForDetail(chatId, userId, serverWithType);
}

// ==================== SELECT AKUN TO DETAIL ====================
else if (type === 'select_akun_to_detail') {
    if (sel === '❌ Batal') {
        await showDashboard(chatId, userId);
        return;
    }
    if (sel === '📄 Next Page ➡️') {
        const nextPage = (context.currentPage || 0) + 1;
        await showAkunListForDetailPage(chatId, userId, context.server, context.akunList, nextPage);
        return;
    }
    if (sel === '◀️ Previous Page') {
        const prevPage = Math.max(0, (context.currentPage || 1) - 1);
        await showAkunListForDetailPage(chatId, userId, context.server, context.akunList, prevPage);
        return;
    }

    const akunList = context.akunList;
    const server = context.server;
    let targetAkun = null;
    for (const akun of akunList) {
        const identifier = akun.username || akun.password || '-';
        const status = akun.status || 'active';
        const expired = akun.expiry_date || akun.expired || '-';
        const expShort = expired.length > 12 ? expired.substring(0, 12) : expired;
        const optText = `👤 ${identifier} | ${status} | exp: ${expShort}`;
        if (optText === sel) {
            targetAkun = akun;
            break;
        }
    }

    if (!targetAkun) {
        await sendAutoDelete(chatId, '❌ Akun tidak ditemukan.');
        await showDashboard(chatId, userId);
        return;
    }

    await adminDetailAkun(chatId, userId, server, targetAkun);
}

// ==================== SELECT SERVER FOR DELETE AKUN ====================
else if (type === 'select_server_for_delete') {
    if (sel === '❌ Batal') {
        await showDashboard(chatId, userId);
        return;
    }

    const servers = context.servers;
    let selectedServer = null;
    for (const s of servers) {
        let icon = s.type === 'ssh' ? '🔒' : s.type === 'xray' ? '📡' : '🔥';
        if (`${icon} ${s.name} (${s.type.toUpperCase()})` === sel) {
            selectedServer = s;
            break;
        }
    }

    if (!selectedServer) {
        await sendAutoDelete(chatId, '❌ Server tidak ditemukan.');
        await showDashboard(chatId, userId);
        return;
    }

    // Jika server xray dan belum ada serviceType spesifik, minta pilih type
    if (selectedServer.type === 'xray' && !selectedServer.serviceType) {
        await sendPoll(chatId, userId,
            `${getHeader('🗑️ DELETE AKUN - PILIH TYPE')}\n\n` +
            `🌐 Server: *${selectedServer.name}*\n\n` +
            `📡 Pilih tipe protokol XRAY:`,
            ['📦 VMess', '🔷 VLess', '🛡️ Trojan', '❌ Batal'],
            'select_xray_type_for_delete',
            { server: selectedServer }
        );
        return;
    }

    await showAkunListForDelete(chatId, userId, selectedServer);
}

// ==================== SELECT XRAY TYPE FOR DELETE ====================
else if (type === 'select_xray_type_for_delete') {
    if (sel === '❌ Batal') {
        await showDashboard(chatId, userId);
        return;
    }

    const server = context.server;
    let xrayType = null;
    if (sel === '📦 VMess') xrayType = 'vmess';
    else if (sel === '🔷 VLess') xrayType = 'vless';
    else if (sel === '🛡️ Trojan') xrayType = 'trojan';

    if (!xrayType) {
        await sendAutoDelete(chatId, '❌ Type tidak valid.');
        await showDashboard(chatId, userId);
        return;
    }

    // Set serviceType sesuai pilihan
    const serverWithType = { ...server, serviceType: xrayType };
    await showAkunListForDelete(chatId, userId, serverWithType);
}

// ==================== SELECT AKUN TO DELETE ====================
else if (type === 'select_akun_to_delete') {
    if (sel === '❌ Batal') {
        await showDashboard(chatId, userId);
        return;
    }
    if (sel === '📄 Next Page ➡️') {
        const nextPage = (context.currentPage || 0) + 1;
        await showAkunListForDeletePage(chatId, userId, context.server, context.akunList, nextPage);
        return;
    }
    if (sel === '◀️ Previous Page') {
        const prevPage = Math.max(0, (context.currentPage || 1) - 1);
        await showAkunListForDeletePage(chatId, userId, context.server, context.akunList, prevPage);
        return;
    }

    // Cocokkan username dari teks opsi
    const akunList = context.akunList;
    let targetAkun = null;
    for (const akun of akunList) {
        const identifier = akun.username || akun.password || '-';
        const status = akun.status || 'active';
        const expired = akun.expiry_date || akun.expired || '-';
        const optText = `👤 ${identifier} | ${status} | exp: ${expired}`;
        if (optText === sel) {
            targetAkun = akun;
            break;
        }
    }

    if (!targetAkun) {
        await sendAutoDelete(chatId, '❌ Akun tidak ditemukan.');
        await showDashboard(chatId, userId);
        return;
    }

    const identifier = targetAkun.username || targetAkun.password || '-';
    const server = context.server;

    await sendPoll(chatId, userId,
        `⚠️ *KONFIRMASI HAPUS AKUN*\n\n` +
        `Server : *${server.name}*\n` +
        `Tipe   : *${(server.serviceType || server.type).toUpperCase()}*\n` +
        `Akun   : *${identifier}*\n\n` +
        `⚠️ Tindakan ini tidak dapat dibatalkan!`,
        ['✅ Ya, Hapus Akun', '❌ Batal'],
        'confirm_delete_akun_server',
        { server: server, akun: targetAkun }
    );
}

// ==================== CONFIRM DELETE AKUN SERVER ====================
else if (type === 'confirm_delete_akun_server') {
    if (sel === '❌ Batal') {
        await sendAutoDelete(chatId, '❌ Penghapusan dibatalkan.');
        await showDashboard(chatId, userId);
        return;
    }

    if (sel === '✅ Ya, Hapus Akun') {
        const server = context.server;
        const akun = context.akun;
        const identifier = akun.username || akun.password || '-';
        const serviceType = server.serviceType || server.type;

        const loading = await client.sendMessage(chatId, `⏳ Menghapus akun *${identifier}* dari server *${server.name}*...`);

        try {
            const mod = getModule(serviceType);
            let result;

            if (serviceType === 'ssh') {
                result = await mod.deleteSSH(server, identifier);
            } else if (serviceType === 'trojan') {
                result = await mod.deleteTrojan(server, identifier);
            } else if (serviceType === 'vless') {
                result = await mod.deleteVless(server, identifier);
            } else if (serviceType === 'vmess') {
                result = await mod.deleteVmess(server, identifier);
            } else if (serviceType === 'zivpn') {
                result = await mod.zivpnDelete(server, identifier);
            } else {
                result = { success: false, message: 'Tipe tidak dikenal' };
            }

            try { await loading.delete(true); } catch(e) {}

            if (result && result.success) {
                await sendAutoDelete(chatId,
                    `✅ *AKUN BERHASIL DIHAPUS*\n\n` +
                    `🗑️ Akun    : *${identifier}*\n` +
                    `🌐 Server  : *${server.name}*\n` +
                    `⚙️ Tipe    : *${serviceType.toUpperCase()}*\n\n` +
                    `📅 Waktu: ${formatTimestamp()}`,
                    30000
                );
            } else {
                await sendAutoDelete(chatId,
                    `❌ *Gagal menghapus akun!*\n\n` +
                    `Akun   : *${identifier}*\n` +
                    `Error  : ${result?.message || 'Unknown error'}`,
                    30000
                );
            }
        } catch (err) {
            try { await loading.delete(true); } catch(e) {}
            await sendAutoDelete(chatId, `❌ Error: ${err.message}`);
        }

        await showDashboard(chatId, userId);
    }
}

    } catch(err) {
        console.error('❌ Poll error:', err);
    }
});

// ==================== ADMIN: LIST AKUN PER SERVER ====================
async function showSelectServerForList(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server yang tersedia.');
        await showDashboard(chatId, userId);
        return;
    }

    const options = servers.map(s => {
        const icon = s.type === 'ssh' ? '🔒' : s.type === 'xray' ? '📡' : '🔥';
        return `${icon} ${s.name} (${s.type.toUpperCase()})`;
    });
    options.push('❌ Batal');

    const headerText = `${getHeader('📋 LIST AKUN PER SERVER')}\n\n📌 Pilih server untuk melihat daftar akun:\n`;
    await sendPoll(chatId, userId, headerText, options, 'select_server_for_list', { servers });
}

async function showSelectServerForDelete(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server yang tersedia.');
        await showDashboard(chatId, userId);
        return;
    }

    const options = servers.map(s => {
        const icon = s.type === 'ssh' ? '🔒' : s.type === 'xray' ? '📡' : '🔥';
        return `${icon} ${s.name} (${s.type.toUpperCase()})`;
    });
    options.push('❌ Batal');

    const headerText = `${getHeader('🗑️ DELETE AKUN PER SERVER')}\n\n⚠️ *Pilih server* untuk memilih akun yang akan dihapus:\n`;
    await sendPoll(chatId, userId, headerText, options, 'select_server_for_delete', { servers });
}

async function showSelectServerForDetail(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server yang tersedia.');
        await showDashboard(chatId, userId);
        return;
    }

    const options = servers.map(s => {
        const icon = s.type === 'ssh' ? '🔒' : s.type === 'xray' ? '📡' : '🔥';
        return `${icon} ${s.name} (${s.type.toUpperCase()})`;
    });
    options.push('❌ Batal');

    const headerText = `${getHeader('🔍 DETAIL AKUN PER SERVER')}\n\n📌 Pilih server untuk melihat detail akun:\n`;
    await sendPoll(chatId, userId, headerText, options, 'select_server_for_detail', { servers });
}

async function showAkunListForDetail(chatId, userId, server) {
    const loading = await client.sendMessage(chatId, `⏳ Mengambil daftar akun dari *${server.name}*...`);

    try {
        const serviceType = server.serviceType || server.type;
        const mod = getModule(serviceType);
        let result;

        if (serviceType === 'ssh') {
            result = await mod.listAllSSH(server);
        } else if (serviceType === 'trojan') {
            result = await mod.listAllTrojan(server);
        } else if (serviceType === 'vless') {
            result = await mod.listAllVless(server);
        } else if (serviceType === 'vmess') {
            result = await mod.listAllVmess(server);
        } else if (serviceType === 'zivpn') {
            const raw = await mod.zivpnList(server);
            if (raw.success && raw.users) {
                result = {
                    status: 'success',
                    users: raw.users.map(u => ({
                        username: u.password || u.username || '-',
                        expiry_date: u.expired || u.expiry_date || '-',
                        status: u.status || 'active'
                    }))
                };
            } else {
                result = { status: 'error', users: [], message: raw.message || 'Gagal' };
            }
        } else {
            result = { status: 'error', users: [], message: 'Tipe server tidak dikenal.' };
        }

        try { await loading.delete(true); } catch(e) {}

        if (result.status !== 'success' || !result.users || result.users.length === 0) {
            const errMsg = result.status !== 'success'
                ? `❌ Gagal mengambil data: ${result.message || 'Unknown error'}`
                : `📭 Tidak ada akun di server *${server.name}*`;
            await sendAutoDelete(chatId, errMsg);
            await showDashboard(chatId, userId);
            return;
        }

        server.serviceType = serviceType;
        await showAkunListForDetailPage(chatId, userId, server, result.users, 0);

    } catch (err) {
        try { await loading.delete(true); } catch(e) {}
        await sendAutoDelete(chatId, `❌ Error: ${err.message}`);
        await showDashboard(chatId, userId);
    }
}

async function showAkunListForDetailPage(chatId, userId, server, akunList, page) {
    const itemsPerPage = 8;
    const totalPages = Math.ceil(akunList.length / itemsPerPage);
    const startIdx = page * itemsPerPage;
    const endIdx = Math.min(startIdx + itemsPerPage, akunList.length);

    const options = [];
    for (let i = startIdx; i < endIdx; i++) {
        const akun = akunList[i];
        const identifier = akun.username || akun.password || '-';
        const status = akun.status || 'active';
        const expired = akun.expiry_date || akun.expired || '-';
        const expShort = expired.length > 12 ? expired.substring(0, 12) : expired;
        options.push(`👤 ${identifier} | ${status} | exp: ${expShort}`);
    }

    if (totalPages > 1 && page < totalPages - 1) options.push('📄 Next Page ➡️');
    if (page > 0) options.push('◀️ Previous Page');
    options.push('❌ Batal');

    const typeLabel = (server.serviceType || server.type).toUpperCase();
    const headerText = `${getHeader('🔍 DETAIL AKUN - ' + server.name)}\n\n` +
        `🌐 Server : *${server.name}*\n` +
        `⚙️ Tipe   : *${typeLabel}*\n` +
        `📊 Total  : ${akunList.length} akun | Hal ${page + 1}/${totalPages}\n\n` +
        `📌 *Pilih akun untuk melihat detail:*\n`;

    await sendPoll(chatId, userId, headerText, options, 'select_akun_to_detail', {
        server,
        akunList,
        currentPage: page,
        itemsPerPage
    });
}

async function adminDetailAkun(chatId, userId, server, akun) {
    const serviceType = server.serviceType || server.type;
    const identifier = akun.username || akun.password || '-';
    const loading = await client.sendMessage(chatId, `⏳ Mengambil detail *${identifier}* dari *${server.name}*...`);

    try {
        const mod = getModule(serviceType);
        let d = null;
        const host = server.apiUrl?.replace(/https?:\/\//, '').split(':')[0] || 'host';

        if (serviceType === 'ssh') {
            // SSH tidak punya endpoint /detail — ambil dari /list lalu filter
            const listResult = await mod.listSSH(server);
            if (listResult && listResult.success && listResult.data) {
                const found = listResult.data.find(u => u.username === identifier);
                if (found) {
                    d = {
                        username: found.username,
                        expired: found.expired,
                        status: found.status || 'active'
                    };
                }
            }
        } else if (serviceType === 'trojan') {
            const r = await mod.detailTrojan(server, identifier);
            if (r && r.success) d = r.data;
        } else if (serviceType === 'vless') {
            const r = await mod.detailVless(server, identifier);
            if (r && r.success) d = r.data;
        } else if (serviceType === 'vmess') {
            const r = await mod.detailVmess(server, identifier);
            if (r && r.success) d = r.data;
        } else if (serviceType === 'zivpn') {
            const r = await mod.zivpnDetail(server, identifier);
            if (r && r.success) d = r.data;
        }

        try { await loading.delete(true); } catch(e) {}

        if (!d) {
            await sendAutoDelete(chatId, `❌ Akun *${identifier}* tidak ditemukan di server *${server.name}*`);
            await showDashboard(chatId, userId);
            return;
        }

        let msg = '';

        if (serviceType === 'ssh') {
            msg = `${getHeader('🔒 DETAIL AKUN SSH')}
╭────────────────────╮
│ 🌐 Server   : ${server.name}
│ 👤 Username : ${d.username || identifier}
│ 📅 Expired  : ${d.expired || '-'}
│ 📋 Status   : ${d.status || 'active'}
╰────────────────────╯

🌐 *Server Info*
┣ Host : ${host}
┗ API  : ${server.apiUrl || '-'}

📅 Dicek: ${formatTimestamp()}`;

        } else if (serviceType === 'trojan') {
            // d.username = parts[1], d.password = parts[3], d.expired = parts[2]
            const pass = d.password || identifier;
            const trojanTLS = `trojan://${pass}@${host}:443?security=tls&type=ws&path=/trojan&host=${host}&sni=${host}#${d.username || identifier}`;
            const trojanHTTP = `trojan://${pass}@${host}:80?security=none&type=ws&path=/trojan&host=${host}#${d.username || identifier}`;
            msg = `${getHeader('🛡️ DETAIL AKUN TROJAN')}
╭────────────────────╮
│ 🌐 Server   : ${server.name}
│ 👤 Username : ${d.username || identifier}
│ 🔑 Password : ${pass}
│ 📅 Expired  : ${d.expired || '-'}
│ 🔗 IP Limit : ${d.ip_limit || '-'}
│ 💾 Quota    : ${d.quota || '-'} GB
│ 📋 Status   : ${d.status || 'active'}
╰────────────────────╯

🔗 *Link TLS (443)*
\`${trojanTLS}\`

🔗 *Link HTTP (80)*
\`${trojanHTTP}\`

📅 Dicek: ${formatTimestamp()}`;

        } else if (serviceType === 'vless') {
            // d.uuid = parts[3]
            const uuid = d.uuid || identifier;
            const vlessTLS = `vless://${uuid}@${host}:443?encryption=none&security=tls&type=ws&host=${host}&path=/vless&sni=${host}#${d.username || identifier}`;
            const vlessHTTP = `vless://${uuid}@${host}:80?encryption=none&security=none&type=ws&host=${host}&path=/vless#${d.username || identifier}`;
            msg = `${getHeader('🔷 DETAIL AKUN VLESS')}
╭────────────────────╮
│ 🌐 Server   : ${server.name}
│ 👤 Username : ${d.username || identifier}
│ 🆔 UUID     : ${uuid}
│ 📅 Expired  : ${d.expired || '-'}
│ 🔗 IP Limit : ${d.ip_limit || '-'}
│ 💾 Quota    : ${d.quota || '-'} GB
│ 📋 Status   : ${d.status || 'active'}
╰────────────────────╯

🔗 *Link TLS (443)*
\`${vlessTLS}\`

🔗 *Link HTTP (80)*
\`${vlessHTTP}\`

📅 Dicek: ${formatTimestamp()}`;

        } else if (serviceType === 'vmess') {
            // d.uuid = parts[3]
            const uuid = d.uuid || identifier;
            const vmessConfig = Buffer.from(JSON.stringify({
                v: '2', ps: d.username || identifier, add: host,
                port: '443', id: uuid, aid: '0',
                net: 'ws', type: 'none', host: host,
                path: '/vmess', tls: 'tls'
            })).toString('base64');
            msg = `${getHeader('📦 DETAIL AKUN VMESS')}
╭────────────────────╮
│ 🌐 Server   : ${server.name}
│ 👤 Username : ${d.username || identifier}
│ 🆔 UUID     : ${uuid}
│ 📅 Expired  : ${d.expired || '-'}
│ 🔗 IP Limit : ${d.ip_limit || '-'}
│ 💾 Quota    : ${d.quota || '-'} GB
│ 📋 Status   : ${d.status || 'active'}
╰────────────────────╯

🔗 *VMess Link*
\`vmess://${vmessConfig}\`

📅 Dicek: ${formatTimestamp()}`;

        } else if (serviceType === 'zivpn') {
            const pass = d.password || d.username || identifier;
            msg = `${getHeader('🔥 DETAIL AKUN ZIVPN')}
╭────────────────────╮
│ 🌐 Server   : ${server.name}
│ 🔑 Password : ${pass}
│ 📅 Expired  : ${d.expired || d.expiry_date || '-'}
│ 🔗 IP Limit : ${d.ip_limit || d.ipLimit || '-'}
│ 📋 Status   : ${d.status || 'active'}
╰────────────────────╯

📅 Dicek: ${formatTimestamp()}`;
        }

        await client.sendMessage(chatId, msg);

    } catch (err) {
        try { await loading.delete(true); } catch(e) {}
        await sendAutoDelete(chatId, `❌ Error: ${err.message}`);
    }

    await showDashboard(chatId, userId);
}

async function adminListAkunPerServer(chatId, userId, server) {
    const loading = await client.sendMessage(chatId, `⏳ Mengambil daftar akun dari *${server.name}*...`);

    try {
        const serviceType = server.serviceType || server.type;
        const mod = getModule(serviceType);
        let result;

        if (serviceType === 'ssh') {
            result = await mod.listAllSSH(server);
        } else if (serviceType === 'trojan') {
            result = await mod.listAllTrojan(server);
        } else if (serviceType === 'vless') {
            result = await mod.listAllVless(server);
        } else if (serviceType === 'vmess') {
            result = await mod.listAllVmess(server);
        } else if (serviceType === 'zivpn') {
            const raw = await mod.zivpnList(server);
            if (raw.success && raw.users) {
                result = {
                    status: 'success',
                    users: raw.users.map(u => ({
                        username: u.password || u.username || '-',
                        expiry_date: u.expired || u.expiry_date || '-',
                        status: u.status || 'active'
                    }))
                };
            } else {
                result = { status: 'error', users: [], message: raw.message || 'Gagal' };
            }
        } else {
            result = { status: 'error', users: [], message: 'Tipe server tidak dikenal. Untuk XRAY, pilih vmess/vless/trojan.' };
        }

        try { await loading.delete(true); } catch(e) {}

        if (result.status !== 'success' || !result.users || result.users.length === 0) {
            const noAkunMsg = result.status !== 'success'
                ? `❌ Gagal mengambil data: ${result.message || 'Unknown error'}`
                : `📭 *Tidak ada akun* di server *${server.name}*`;
            await sendAutoDelete(chatId, noAkunMsg);
            await showDashboard(chatId, userId);
            return;
        }

        const users = result.users;
        const icon = serviceType === 'ssh' ? '🔒' : serviceType === 'zivpn' ? '🔥' : '📡';
        const typeLabel = serviceType.toUpperCase();

        let msg = `${getHeader(`📋 AKUN ${typeLabel} - ${server.name}`)}\n`;
        msg += `╭───────────────────╮\n`;
        msg += `│ 🌐 Server  : ${server.name}\n`;
        msg += `│ ⚙️ Tipe    : ${typeLabel}\n`;
        msg += `│ 👥 Total   : ${users.length} akun\n`;
        msg += `╰───────────────────╯\n\n`;
        msg += `┏━━━━━━━━━━━━━━━━━━━┓\n`;

        for (let i = 0; i < Math.min(50, users.length); i++) {
            const u = users[i];
            const identifier = u.username || u.password || '-';
            const expired = u.expiry_date || u.expired || '-';
            const status = u.status || 'active';
            const statusIcon = status === 'active' ? '🟢' : status === 'expired' ? '🔴' : '🟡';

            msg += `┃ ${i + 1}. ${icon} *${identifier}*\n`;
            msg += `┃    ${statusIcon} Status  : ${status}\n`;
            msg += `┃    📅 Expired : ${expired}\n`;
            msg += `┃    ─────────────────\n`;
        }

        msg += `┗━━━━━━━━━━━━━━━━━━━┛\n`;
        if (users.length > 50) {
            msg += `\n📌 *Catatan:* ${users.length - 50} akun lainnya tidak ditampilkan.\n`;
        }
        msg += `\n📅 Diperbarui: ${formatTimestamp()}`;

        await client.sendMessage(chatId, msg);

    } catch (err) {
        try { await loading.delete(true); } catch(e) {}
        await sendAutoDelete(chatId, `❌ Error: ${err.message}`);
    }

    await showDashboard(chatId, userId);
}

async function showAkunListForDelete(chatId, userId, server) {
    const loading = await client.sendMessage(chatId, `⏳ Mengambil daftar akun dari *${server.name}*...`);

    try {
        const serviceType = server.serviceType || server.type;
        const mod = getModule(serviceType);
        let result;

        if (serviceType === 'ssh') {
            result = await mod.listAllSSH(server);
        } else if (serviceType === 'trojan') {
            result = await mod.listAllTrojan(server);
        } else if (serviceType === 'vless') {
            result = await mod.listAllVless(server);
        } else if (serviceType === 'vmess') {
            result = await mod.listAllVmess(server);
        } else if (serviceType === 'zivpn') {
            const raw = await mod.zivpnList(server);
            if (raw.success && raw.users) {
                result = {
                    status: 'success',
                    users: raw.users.map(u => ({
                        username: u.password || u.username || '-',
                        expiry_date: u.expired || u.expiry_date || '-',
                        status: u.status || 'active'
                    }))
                };
            } else {
                result = { status: 'error', users: [], message: raw.message || 'Gagal' };
            }
        } else {
            result = { status: 'error', users: [], message: 'Tipe tidak dikenal. Untuk XRAY, pilih vmess/vless/trojan.' };
        }

        try { await loading.delete(true); } catch(e) {}

        if (result.status !== 'success' || !result.users || result.users.length === 0) {
            const errMsg = result.status !== 'success'
                ? `❌ Gagal mengambil data: ${result.message || 'Unknown error'}`
                : `📭 Tidak ada akun di server *${server.name}*`;
            await sendAutoDelete(chatId, errMsg);
            await showDashboard(chatId, userId);
            return;
        }

        // Tambahkan serviceType ke server object agar tersedia di context
        server.serviceType = serviceType;
        await showAkunListForDeletePage(chatId, userId, server, result.users, 0);

    } catch (err) {
        try { await loading.delete(true); } catch(e) {}
        await sendAutoDelete(chatId, `❌ Error: ${err.message}`);
        await showDashboard(chatId, userId);
    }
}

async function showAkunListForDeletePage(chatId, userId, server, akunList, page) {
    const itemsPerPage = 8; // Lebih kecil karena teks opsi lebih panjang
    const totalPages = Math.ceil(akunList.length / itemsPerPage);
    const startIdx = page * itemsPerPage;
    const endIdx = Math.min(startIdx + itemsPerPage, akunList.length);

    const options = [];
    for (let i = startIdx; i < endIdx; i++) {
        const akun = akunList[i];
        const identifier = akun.username || akun.password || '-';
        const status = akun.status || 'active';
        const expired = akun.expiry_date || akun.expired || '-';
        // Potong expired jika terlalu panjang
        const expShort = expired.length > 12 ? expired.substring(0, 12) : expired;
        options.push(`👤 ${identifier} | ${status} | exp: ${expShort}`);
    }

    if (totalPages > 1 && page < totalPages - 1) options.push('📄 Next Page ➡️');
    if (page > 0) options.push('◀️ Previous Page');
    options.push('❌ Batal');

    const headerText = `${getHeader('🗑️ DELETE AKUN - ' + server.name)}\n\n` +
        `🌐 Server : *${server.name}*\n` +
        `📊 Total  : ${akunList.length} akun | Hal ${page + 1}/${totalPages}\n\n` +
        `⚠️ *Pilih akun yang akan dihapus:*\n`;

    await sendPoll(chatId, userId, headerText, options, 'select_akun_to_delete', {
        server,
        akunList,
        currentPage: page,
        itemsPerPage
    });
}

// ==================== SERVICE MENUS ====================
// ==================== CREATE MODE MENU ====================
async function showCreateModeMenu(chatId, userId) {
    const perJam = Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * CONFIG.MAX_IP_LIMIT / 24);
    const menuText = `${getHeader('✨ CREATE AKUN')}
╭───────────────────╮
│  Pilih mode pembuatan akun:
│
│  📦 *Create Biasa*
│  ├ Bayar di muka sesuai hari
│  └ Harga: ${formatRp(CONFIG.HARGA_PER_HARI_PER_IP)}/hari/IP
│
│  ⚡ *Pay As You Go (PAYG)*
│  ├ Bayar per jam dari saldo
│  ├ Harga: ≈${formatRp(perJam)}/jam (${CONFIG.MAX_IP_LIMIT} IP)
│  └ Akun expired jika saldo habis
╰───────────────────╯

💳 *Saldo:* ${formatRp(getSaldo(userId))}`;
    await sendPoll(chatId, userId, menuText,
        ['📦 Create Biasa', '⚡ Pay As You Go (PAYG)', '◂ Kembali'],
        'create_mode_select', {});
}

// ==================== PAYG CREATE FLOW ====================
async function handleCreatePayg(chatId, userId, serviceType) {
    const server = await selectServer(chatId, userId, serviceType, 'CREATE PAYG');
    if (!server) return;

    const perJam = Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * CONFIG.MAX_IP_LIMIT / 24);

    processState[userId] = {
        action: 'payg_step_username',
        serviceType,
        server,
        data: {},
        waitingForInput: true
    };

    let stepText = '';
    if (serviceType === 'zivpn') {
        stepText = '📝 Masukkan *password* untuk akun ZiVPN PAYG Anda.\nContoh: *mypass123*';
        processState[userId].action = 'payg_step_password_only';
    } else if (serviceType === 'ssh') {
        stepText = '📝 *Langkah 1/2: Buat Username*\nContoh: *user123*';
    } else {
        stepText = '📝 *Langkah 1/2: Buat Username*\nContoh: *user123*';
    }

    await client.sendMessage(chatId,
        `${getHeader(`⚡ CREATE PAYG ${serviceType.toUpperCase()}`)}
╭───────────────────╮
│ ├ *Server :* ${server.name}
│ ├ ⏱️ *Tarif :* ${formatRp(perJam)}/jam
│ ├ 💳 *Saldo :* ${formatRp(getSaldo(userId))}
╰───────────────────╯

${stepText}

Ketik *cancel* untuk membatalkan`);
}

async function processCreatePayg(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || !state.action || !state.action.startsWith('payg_step_')) return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Pembuatan akun PAYG dibatalkan.');
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return true;
    }

    const { serviceType, server, data } = state;
    const perJam = Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * CONFIG.MAX_IP_LIMIT / 24);

    // ===== ZiVPN: hanya password =====
    if (state.action === 'payg_step_password_only') {
        if (input.length < 4) {
            await sendAutoDelete(chatId, '❌ Password minimal 4 karakter.\nKetik *cancel* untuk batal.');
            return false;
        }
        data.password = input;

        const confirmText = `${getHeader('⚡ KONFIRMASI PAYG')}
╭───────────────────╮
│ 📋 *ZiVPN Pay As You Go*
│ ├ 🔐 Password: ${input}
│ ├ 🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP
│ ├ ⏱️ Tarif: ${formatRp(perJam)}/jam
│ └ 🌐 Server: ${server.name}
╰───────────────────╯

💳 *Saldo:* ${formatRp(getSaldo(userId))}
⚠️ Akun aktif selama saldo mencukupi

Lanjutkan?`;
        await sendPoll(chatId, userId, confirmText,
            ['✅ Ya, Aktifkan PAYG', '❌ Batal'],
            'payg_confirm',
            { serviceType, server, data: { ...data } });
        return true;
    }

    // ===== SSH/Trojan/VLess/VMess: username dulu =====
    if (state.action === 'payg_step_username') {
        if (!input || input.length < 3) {
            await sendAutoDelete(chatId, '❌ Username minimal 3 karakter.\nKetik *cancel* untuk batal.');
            return false;
        }
        data.username = input;
        processState[userId] = { ...state, action: 'payg_step_password', data };
        await sendAutoDelete(chatId,
            `✅ Username: *${input}*\n\n📝 *Langkah 2/2: Buat Password*\nContoh: *mypass123* atau ketik *random*\n\nKetik *cancel* untuk batal`);
        return true;
    }

    // ===== Step password =====
    if (state.action === 'payg_step_password') {
        let password = input;
        if (password.toLowerCase() === 'random') {
            password = Math.random().toString(36).substring(2, 12);
            await sendAutoDelete(chatId, `🔑 Password otomatis: *${password}*`);
        }
        if (password.length < 4) {
            await sendAutoDelete(chatId, '❌ Password minimal 4 karakter.\nKetik *cancel* untuk batal.');
            return false;
        }
        data.password = password;

        let ringkasan = '';
        if (serviceType === 'ssh') {
            ringkasan = `👤 Username: ${data.username}\n│ ├ 🔑 Password: ${password}\n│ ├ 🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP`;
        } else {
            ringkasan = `👤 Username: ${data.username}\n│ ├ 🔑 Password: ${password}\n│ ├ 🔗 IP Limit: ${CONFIG.MAX_IP_LIMIT} IP\n│ ├ 💾 Quota: ${CONFIG.DEFAULT_QUOTA} GB`;
        }

        const confirmText = `${getHeader('⚡ KONFIRMASI PAYG')}
╭───────────────────╮
│ 📋 *${serviceType.toUpperCase()} Pay As You Go*
│ ├ ${ringkasan}
│ ├ ⏱️ Tarif: ${formatRp(perJam)}/jam
│ └ 🌐 Server: ${server.name}
╰───────────────────╯

💳 *Saldo:* ${formatRp(getSaldo(userId))}
⚠️ Akun aktif selama saldo mencukupi

Lanjutkan?`;
        await sendPoll(chatId, userId, confirmText,
            ['✅ Ya, Aktifkan PAYG', '❌ Batal'],
            'payg_confirm',
            { serviceType, server, data: { ...data } });
        return true;
    }

    return false;
}

async function eksekusiCreatePayg(chatId, userId, serviceType, server, data) {
    const userName = await getUserName(userId);
    const perJam = Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * CONFIG.MAX_IP_LIMIT / 24);

    // Cek minimal saldo: minimal 1 jam
    if (getSaldo(userId) < perJam) {
        await sendAutoDelete(chatId,
            `❌ *Saldo tidak cukup untuk PAYG!*\n\n` +
            `⏱️ Minimum: ${formatRp(perJam)} (untuk 1 jam)\n` +
            `💳 Saldo Anda: ${formatRp(getSaldo(userId))}\n\n` +
            `Silakan topup saldo terlebih dahulu.`);
        delete processState[userId];
        await showMainMenu(chatId, userId);
        return;
    }

    const loading = await client.sendMessage(chatId, '⏳ Membuat akun PAYG...');
    const mod = getModule(serviceType);
    const domain = server.apiUrl.split('/')[2]?.split(':')[0] || server.name;

    try {
        let result;
        let username = data.username;
        let password = data.password;

        if (serviceType === 'zivpn') {
            password = data.password;
            username = password;
            // Buat akun dengan durasi 36500 hari (tidak terbatas, PAYG yang mengatur)
            result = await mod.zivpnCreate(server, password, 36500, CONFIG.MAX_IP_LIMIT);
        } else if (serviceType === 'ssh') {
            result = await mod.createSSH(server, username, password, 36500, CONFIG.MAX_IP_LIMIT);
        } else if (serviceType === 'trojan') {
            result = await mod.createTrojan(server, username, password, 36500, CONFIG.MAX_IP_LIMIT, CONFIG.DEFAULT_QUOTA);
        } else if (serviceType === 'vless') {
            result = await mod.createVless(server, username, password, 36500, CONFIG.MAX_IP_LIMIT, CONFIG.DEFAULT_QUOTA);
        } else if (serviceType === 'vmess') {
            result = await mod.createVmess(server, username, password, 36500, CONFIG.MAX_IP_LIMIT, CONFIG.DEFAULT_QUOTA);
        }

        try { await loading.delete(true); } catch(e) {}

        if (result && result.success) {
            const akunData = {
                username: username || password,
                password,
                uuid: password,
                expired: 'Pay As You Go',
                iplimit: CONFIG.MAX_IP_LIMIT,
                quota: CONFIG.DEFAULT_QUOTA,
                domain,
                serviceType,
                serverName: server.name,
                serverId: server.id,
                payAsYouGo: true,
                hargaPerJam: perJam,
                paygCreatedAt: new Date().toISOString(),
                paygLastDeduct: new Date().toISOString(),
                status: 'active'
            };

            tambahAkun(userId, akunData);

            simpanTransaksi({
                txId: generateTxId(),
                userId,
                userName,
                type: 'payg_create',
                amount: 0,
                keterangan: `Aktivasi PAYG ${serviceType.toUpperCase()} ${username || password} (${formatRp(perJam)}/jam)`,
                waktu: new Date().toISOString(),
                status: 'success'
            });

            const msg = formatCreateMessage(serviceType, { ...akunData, expired: 'Pay As You Go (per jam)' }, server.name);
            await client.sendMessage(chatId,
                msg +
                `\n\n⚡ *Mode: Pay As You Go*` +
                `\n⏱️ *Tarif:* ${formatRp(perJam)}/jam` +
                `\n💳 *Saldo:* ${formatRp(getSaldo(userId))}` +
                `\n⚠️ Akun otomatis dihapus jika saldo habis`);
        } else {
            await sendAutoDelete(chatId, `❌ Gagal membuat akun PAYG: ${result?.message || 'Unknown error'}`);
        }
    } catch(err) {
        try { await loading.delete(true); } catch(e) {}
        await sendAutoDelete(chatId, `❌ Error: ${err.message}`);
    }

    delete processState[userId];
    await showMainMenu(chatId, userId);
}

// ==================== PAYG ENGINE ====================
async function deleteAkunFromServer(server, akun) {
    try {
        const serviceType = akun.serviceType;
        const identifier = akun.username || akun.password;
        const mod = getModule(serviceType);
        let result;
        if (serviceType === 'ssh') result = await mod.deleteSSH(server, identifier);
        else if (serviceType === 'trojan') result = await mod.deleteTrojan(server, identifier);
        else if (serviceType === 'vless') result = await mod.deleteVless(server, identifier);
        else if (serviceType === 'vmess') result = await mod.deleteVmess(server, identifier);
        else if (serviceType === 'zivpn') result = await mod.zivpnDelete(server, identifier);
        else result = { success: false, message: 'Tipe tidak dikenal' };
        return result;
    } catch(e) {
        console.log(`[PAYG] Gagal hapus dari server: ${e.message}`);
        return { success: false, message: e.message };
    }
}

async function jalankanPayAsYouGo() {
    if (!isReady) return;
    console.log('⏰ [PAYG] Pemotongan saldo per jam...');

    const akun = loadAkun();
    const now = new Date();
    let totalPotong = 0, totalHapus = 0;

    for (const [userId, akunList] of Object.entries(akun)) {
        if (!Array.isArray(akunList)) continue;
        const akunToKeep = [];
        const akunDeleted = [];

        for (const a of akunList) {
            if (!a.payAsYouGo || a.status === 'deleted') {
                akunToKeep.push(a);
                continue;
            }

            const perJam = a.hargaPerJam || Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * (a.iplimit || 1) / 24);
            const saldoUser = getSaldo(userId);

            if (saldoUser >= perJam) {
                // Potong saldo
                kurangiSaldo(userId, perJam);
                a.paygLastDeduct = now.toISOString();
                totalPotong++;

                simpanTransaksi({
                    txId: generateTxId(), userId,
                    type: 'payg_deduct', amount: perJam,
                    keterangan: `PAYG/jam: ${a.username || a.password} (${(a.serviceType || '').toUpperCase()})`,
                    waktu: now.toISOString(), status: 'success'
                });

                akunToKeep.push(a);

                // Peringatan saldo tinggal ≤ 3 jam
                const sisaSaldo = getSaldo(userId);
                const sisaJam = Math.floor(sisaSaldo / perJam);
                if (sisaJam <= 3 && sisaJam > 0) {
                    try {
                        await client.sendMessage(userId + '@c.us',
                            `⚠️ *PERINGATAN SALDO PAYG!*\n\n` +
                            `Akun *${a.username || a.password}* (${(a.serviceType || '').toUpperCase()})\n` +
                            `💳 Sisa Saldo: ${formatRp(sisaSaldo)}\n` +
                            `⏳ Estimasi habis: *${sisaJam} jam lagi*\n\n` +
                            `Segera topup agar akun tidak dihapus!\n` +
                            `Ketik */menu* → Topup Saldo 💵`);
                    } catch(e) {}
                }
            } else {
                // Saldo habis → hapus akun
                console.log(`[PAYG] Saldo habis: ${userId} → hapus ${a.username || a.password}`);
                const server = a.serverId ? SERVERS[a.serverId] : Object.values(SERVERS).find(s => s.name === a.serverName);
                if (server) await deleteAkunFromServer(server, a);

                a.status = 'deleted';
                a.deletedAt = now.toISOString();
                a.deleteReason = 'PAYG saldo habis';
                akunDeleted.push(a);
                totalHapus++;

                simpanTransaksi({
                    txId: generateTxId(), userId,
                    type: 'payg_delete', amount: 0,
                    keterangan: `PAYG auto-hapus: ${a.username || a.password} (saldo habis)`,
                    waktu: now.toISOString(), status: 'success'
                });

                try {
                    await client.sendMessage(userId + '@c.us',
                        `🚫 *AKUN PAYG DIHAPUS OTOMATIS*\n\n` +
                        `Akun dihapus karena *saldo habis*.\n\n` +
                        `🔐 *Akun:* ${a.username || a.password}\n` +
                        `📡 *Tipe:* ${(a.serviceType || '').toUpperCase()}\n` +
                        `🌐 *Server:* ${a.serverName || '-'}\n` +
                        `💳 *Saldo:* ${formatRp(getSaldo(userId))}\n\n` +
                        `Topup dan buat akun baru via */menu*`);
                } catch(e) {}
            }
        }

        akun[userId] = [...akunToKeep, ...akunDeleted];
    }

    saveAkun(akun);
    console.log(`✅ [PAYG] Selesai: ${totalPotong} dipotong, ${totalHapus} dihapus`);
}

let paygInterval = null;
function startPayAsYouGoInterval() {
    if (paygInterval) clearInterval(paygInterval);
    paygInterval = setInterval(async () => {
        try { await jalankanPayAsYouGo(); } catch(e) { console.error('[PAYG] Error:', e.message); }
    }, 60 * 60 * 1000);
    console.log('✅ [PAYG] Interval aktif (setiap 1 jam)');
}
// ==================== END PAYG ENGINE ====================

async function showServiceMenuCreate(chatId, userId) {
    const menuText = `${getHeader('✨ CREATE AKUN')}\n\nPilih layanan yang ingin dibuat:`;
    await sendPoll(chatId, userId, menuText, ['▸ SSH', '▸ Trojan', '▸ VLess', '▸ VMess', '▸ ZiVPN', '◂ Kembali'], 'service_select_create', {});
}

async function showServiceMenuPayg(chatId, userId) {
    const perJam = Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * CONFIG.MAX_IP_LIMIT / 24);
    const menuText = `${getHeader('⚡ CREATE PAYG')}\n\nTarif: ≈${formatRp(perJam)}/jam\nPilih layanan:`;
    await sendPoll(chatId, userId, menuText, ['▸ SSH', '▸ Trojan', '▸ VLess', '▸ VMess', '▸ ZiVPN', '◂ Kembali'], 'service_select_payg', {});
}

async function showServiceMenuTrial(chatId, userId) {
    const menuText = `${getHeader('⏱️ TRIAL AKUN')}\n\nPilih layanan untuk trial (${CONFIG.MAX_TRIAL_MENIT} menit):`;
    await sendPoll(chatId, userId, menuText, ['▸ SSH', '▸ Trojan', '▸ VLess', '▸ VMess', '▸ ZiVPN', '◂ Kembali'], 'service_select_trial', {});
}

async function showServiceMenuRenew(chatId, userId) {
    const menuText = `${getHeader('🔄 RENEW AKUN')}\n\nPilih layanan yang akan diperpanjang:`;
    await sendPoll(chatId, userId, menuText, ['▸ SSH', '▸ Trojan', '▸ VLess', '▸ VMess', '▸ ZiVPN', '◂ Kembali'], 'service_select_renew', {});
}

async function showServerList(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    let txt = `${getHeader('📡 DAFTAR SERVER')}\n`;
    txt += `━━━━━━━━━━━━━━━━━━━\n`;
    
    for (const s of servers) {
        let icon = '🛡️';
        let typeLabel = '';
        
        if (s.type === 'zivpn') {
            icon = '🔥';
            typeLabel = 'ZiVPN';
        } else if (s.type === 'ssh') {
            icon = '🔒';
            typeLabel = 'SSH';
        } else if (s.type === 'xray') {
            icon = '📡';
            typeLabel = 'XRAY (VMess/VLess/Trojan)';
        }
        
        txt += `\n${icon} *${s.name}*\n`;
        txt += `   📋 Tipe: ${typeLabel}\n`;
        txt += `   📡 API: ${s.apiUrl}\n`;
        txt += `   🔑 Auth: ${s.authKey}\n`;
        txt += `   ━━━━━━━━━━━━━━━━━━━\n`;
    }
    
    await client.sendMessage(chatId, txt);
    await showServerMenu(chatId, userId);
}

// ==================== PROCESS EDIT FUNCTIONS ====================
async function processEditHarga(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_harga') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showEditDataMenu(chatId, userId);
        return true;
    }
    
    const newHarga = parseInt(input);
    if (isNaN(newHarga) || newHarga < 100) {
        await sendAutoDelete(chatId, '❌ Harga tidak valid. Minimal Rp 100');
        return false;
    }
    
    updateConfig('HARGA_PER_HARI_PER_IP', newHarga);
    delete processState[userId];
    await client.sendMessage(chatId, `✅ *Harga berhasil diubah!*\n\n💰 Harga baru: *Rp ${newHarga}/hari/IP*\n\n_Perubahan langsung aktif tanpa restart._`);
    await showEditDataMenu(chatId, userId);
    return true;
}

async function processEditTrialMenit(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_trial_menit') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showEditDataMenu(chatId, userId);
        return true;
    }
    
    const newTrial = parseInt(input);
    if (isNaN(newTrial) || newTrial < 1) {
        await sendAutoDelete(chatId, '❌ Durasi tidak valid');
        return false;
    }
    
    updateConfig('MAX_TRIAL_MENIT', newTrial);
    delete processState[userId];
    await client.sendMessage(chatId, `✅ *Max Trial berhasil diubah!*\n\n⏱️ Max Trial baru: *${newTrial} menit*\n\n_Perubahan langsung aktif tanpa restart._`);
    await showEditDataMenu(chatId, userId);
    return true;
}

async function processEditTrialPerHari(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_trial_per_hari') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showEditDataMenu(chatId, userId);
        return true;
    }
    
    const newLimit = parseInt(input);
    if (isNaN(newLimit) || newLimit < 1) {
        await sendAutoDelete(chatId, '❌ Batas tidak valid');
        return false;
    }
    
    updateConfig('MAX_TRIAL_PER_USER', newLimit);
    delete processState[userId];
    await client.sendMessage(chatId, `✅ *Max Trial/Hari berhasil diubah!*\n\n🎫 Max Trial baru: *${newLimit}x/hari*\n\n_Perubahan langsung aktif tanpa restart._`);
    await showEditDataMenu(chatId, userId);
    return true;
}

async function processEditIpLimit(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_ip_limit') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showEditDataMenu(chatId, userId);
        return true;
    }
    
    const newIpLimit = parseInt(input);
    if (isNaN(newIpLimit) || newIpLimit < 1) {
        await sendAutoDelete(chatId, '❌ IP Limit tidak valid');
        return false;
    }
    
    updateConfig('MAX_IP_LIMIT', newIpLimit);
    delete processState[userId];
    await client.sendMessage(chatId, `✅ *Max IP Limit berhasil diubah!*\n\n🔌 IP Limit baru: *${newIpLimit} IP*\n\n_Perubahan langsung aktif tanpa restart._`);
    await showEditDataMenu(chatId, userId);
    return true;
}

async function processEditMinTopup(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_min_topup') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showEditDataMenu(chatId, userId);
        return true;
    }
    
    const newMinTopup = parseInt(input);
    if (isNaN(newMinTopup) || newMinTopup < 1000) {
        await sendAutoDelete(chatId, '❌ Minimal Topup tidak valid (min Rp 1.000)');
        return false;
    }
    
    updateConfig('MIN_TOPUP', newMinTopup);
    delete processState[userId];
    await client.sendMessage(chatId, `✅ *Minimal Topup berhasil diubah!*\n\n💵 Min Topup baru: *${formatRp(newMinTopup)}*\n\n_Perubahan langsung aktif tanpa restart._`);
    await showEditDataMenu(chatId, userId);
    return true;
}

async function processEditMerchantName(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_merchant_name') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showEditDataMenu(chatId, userId);
        return true;
    }
    
    if (!input || input.length < 3) {
        await sendAutoDelete(chatId, '❌ Nama merchant terlalu pendek');
        return false;
    }
    
    updateConfig('MERCHANT_NAME', input);
    delete processState[userId];
    await client.sendMessage(chatId, `✅ *Nama Merchant berhasil diubah!*\n\n🏪 Merchant baru: *${input}*\n\n_Perubahan langsung aktif tanpa restart._`);
    await showEditDataMenu(chatId, userId);
    return true;
}

async function processEditQuota(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_quota') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showEditDataMenu(chatId, userId);
        return true;
    }
    
    const newQuota = parseInt(input);
    if (isNaN(newQuota) || newQuota < 1) {
        await sendAutoDelete(chatId, '❌ Quota tidak valid (minimal 1 GB)');
        return false;
    }
    
    updateConfig('DEFAULT_QUOTA', newQuota);
    delete processState[userId];
    await client.sendMessage(chatId, `✅ *Default Quota berhasil diubah!*\n\n💾 Quota baru: *${newQuota} GB*\n\n_Perubahan langsung aktif tanpa restart._`);
    await showEditDataMenu(chatId, userId);
    return true;
}

async function showServerDetailList(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    const options = servers.map((s, i) => {
        let icon = '';
        if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        else if (s.type === 'zivpn') icon = '🔥';
        return `${icon} ${s.name} (${s.type.toUpperCase()})`;
    });
    options.push('◂ Kembali');
    
    const headerText = `${getHeader('📡 LIHAT DETAIL SERVER')}\n\n📋 Pilih server yang ingin dilihat:\n`;
    
    await sendPoll(chatId, userId, headerText, options, 'view_server_detail', { servers: servers });
}

async function showServiceStatusSelect(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server.');
        await showServerMenu(chatId, userId);
        return;
    }

    const options = servers.map(s => {
        const icon = s.type === 'ssh' ? '🔒' : s.type === 'xray' ? '📡' : '🔥';
        return `${icon} ${s.name}`;
    });
    options.push('◂ Kembali');

    const headerText = `${getHeader('🖥️ STATUS SERVICE SERVER')}\n\n📋 Pilih server untuk cek status service:\n`;

    await sendPoll(chatId, userId, headerText, options, 'service_status_select', { servers });
}

async function handleViewServiceStatus(chatId, userId, server, loadingMsg = null) {
    try {
        const response = await axios.post(
            `${server.apiUrl}/api/services/status`,
            {},
            { headers: { 'x-api-key': server.authKey }, timeout: 30000 }
        );

        // Hapus pesan loading
        if (loadingMsg) {
            try { await loadingMsg.delete(true); } catch(e) {}
        }

        const data = response.data;
        if (!data.success) {
            await sendAutoDelete(chatId, `❌ Gagal ambil status: ${data.message || 'Unknown error'}`, 10000);
            await showServerMenu(chatId, userId);
            return;
        }

        const sys = data.data.system;
        const svc = data.data.services;
        const icon = server.type === 'ssh' ? '🔒' : server.type === 'xray' ? '📡' : '🔥';

        const st = (v) => v ? '✅ Running' : '❌ Stopped';

        const msg = `${getHeader('🖥️ STATUS SERVICE')}
${icon} *${server.name}*
━━━━━━━━━━━━━━━━━━━━━
🖥️ *OS*       : ${sys.os}
🌐 *IP*       : \`${sys.ip}\`
🔗 *Domain*   : \`${sys.domain}\`
💻 *CPU*      : ${sys.cpu}
🔢 *Cores*    : ${sys.cores}
🧠 *RAM*      : ${sys.ram_used} / ${sys.ram_total} (${sys.ram_percent})
━━━━━━━━━━━━━━━━━━━━━
📋 *SERVICE STATUS*
━━━━━━━━━━━━━━━━━━━━━
🔄 WS: ${st(svc.ws)}
🔒 SSH: ${st(svc.ssh)}
📡 Xray: ${st(svc.xray)}
⏰ Cron: ${st(svc.cron)}
🌐 Nginx: ${st(svc.nginx)}
🔥 ZiVPN: ${st(svc.zivpn)}
🛡️ OpenVPN: ${st(svc.openvpn)}
⚖️ HAProxy: ${st(svc.haproxy)}
🚫 Fail2Ban: ${st(svc.fail2ban)}
🔐 IPTables: ${st(svc.iptables)}
🔁 RC-Local: ${st(svc.rcLocal)}
💧 Dropbear: ${st(svc.dropbear)}
📶 UDP Custom: ${st(svc.udp)}
🎮 BadVPN 7100: ${st(svc.badvpn1)}
🎮 BadVPN 7200: ${st(svc.badvpn2)}
🎮 BadVPN 7300: ${st(svc.badvpn3)}
━━━━━━━━━━━━━━━━━━━━━
📅 *Waktu*: ${formatTimestamp()}`;

        await sendAutoDelete(chatId, msg, 10000);

    } catch (err) {
        // Hapus pesan loading jika error
        if (loadingMsg) {
            try { await loadingMsg.delete(true); } catch(e) {}
        }
        await sendAutoDelete(chatId, `❌ Gagal koneksi ke server *${server.name}*\n\n_${err.message}_`, 10000);
    }

    await showServerMenu(chatId, userId);
}

async function showServerEditList(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server untuk diedit.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    const options = servers.map((s, i) => {
        let icon = '';
        if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        else if (s.type === 'zivpn') icon = '🔥';
        return `${icon} ${s.name} (${s.type.toUpperCase()})`;
    });
    options.push('❌ Batal');
    
    const headerText = `${getHeader('✏️ EDIT SERVER')}\n\n📋 Pilih server yang akan diedit:\n`;
    
    await sendPoll(chatId, userId, headerText, options, 'select_server_to_edit', { servers: servers });
}

async function showServerDeleteList(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server untuk dihapus.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    const options = servers.map((s, i) => {
        let icon = '';
        if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        else if (s.type === 'zivpn') icon = '🔥';
        return `${icon} ${s.name} (${s.type.toUpperCase()})`;
    });
    options.push('❌ Batal');
    
    const headerText = `${getHeader('🗑️ HAPUS SERVER')}\n\n⚠️ *Peringatan!* Server yang dihapus tidak dapat dikembalikan.\n\n📋 Pilih server yang akan dihapus:\n`;
    
    await sendPoll(chatId, userId, headerText, options, 'select_server_to_delete', { servers: servers });
}

// ==================== PROCESS EDIT SERVER COMPONENTS ====================
async function processEditServerName(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_server_name') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }
    
    if (!input || input.length < 3) {
        await sendAutoDelete(chatId, '❌ Nama terlalu pendek (minimal 3 karakter)');
        return false;
    }
    
    const serverId = state.serverId;
    const oldName = SERVERS[serverId].name;
    
    SERVERS[serverId].name = input;
    saveServers(SERVERS);
    
    await sendAutoDelete(chatId, `✅ Nama server berhasil diubah dari *${oldName}* menjadi *${input}*`);
    delete processState[userId];
    await showServerMenu(chatId, userId);
    return true;
}

async function processEditServerType(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_server_type') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }
    
    const typeMap = {
        '1': 'ssh',
        '2': 'xray',
        '3': 'zivpn'
    };
    
    let newType = typeMap[input];
    if (!newType) {
        await sendAutoDelete(chatId, '❌ Pilihan tidak valid. Kirim nomor 1-3');
        return false;
    }
    
    const serverId = state.serverId;
    const oldType = SERVERS[serverId].type;
    
    SERVERS[serverId].type = newType;
    saveServers(SERVERS);
    
    let typeIcon = '';
    if (newType === 'ssh') typeIcon = '🔒';
    else if (newType === 'xray') typeIcon = '📡';
    else if (newType === 'zivpn') typeIcon = '🔥';
    
    await sendAutoDelete(chatId, `✅ Tipe server berhasil diubah dari *${oldType.toUpperCase()}* menjadi ${typeIcon} *${newType.toUpperCase()}*`);
    delete processState[userId];
    await showServerMenu(chatId, userId);
    return true;
}

async function processEditServerDomain(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_server_domain') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }
    
    // Format: domain:port
    const parts = input.split(':');
    if (parts.length !== 2) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan: *domain:port*\nContoh: *cloud.peyx.site:8585*');
        return false;
    }
    
    const domain = parts[0];
    const port = parseInt(parts[1]);
    
    if (isNaN(port)) {
        await sendAutoDelete(chatId, '❌ Port harus berupa angka!');
        return false;
    }
    
    if (!domain || domain.length < 3) {
        await sendAutoDelete(chatId, '❌ Domain tidak valid!');
        return false;
    }
    
    const serverId = state.serverId;
    const oldApiUrl = SERVERS[serverId].apiUrl;
    
    SERVERS[serverId].apiUrl = `http://${domain}:${port}`;
    saveServers(SERVERS);
    
    await sendAutoDelete(chatId, `✅ Domain & port berhasil diubah dari *${oldApiUrl}* menjadi *http://${domain}:${port}*`);
    delete processState[userId];
    await showServerMenu(chatId, userId);
    return true;
}

async function processEditServerAuth(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_server_auth') return false;
    
    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }
    
    if (!input || input.length < 5) {
        await sendAutoDelete(chatId, '❌ Auth key terlalu pendek (minimal 5 karakter)');
        return false;
    }
    
    const serverId = state.serverId;
    const oldAuth = SERVERS[serverId].authKey;
    
    SERVERS[serverId].authKey = input;
    saveServers(SERVERS);
    
    await sendAutoDelete(chatId, `✅ Auth key berhasil diubah dari \`${oldAuth}\` menjadi \`${input}\``);
    delete processState[userId];
    await showServerMenu(chatId, userId);
    return true;
}

// ==================== SERVER MANAGEMENT ====================
async function showServerMenu(chatId, userId) {
    const servers = Object.values(SERVERS);
    
    // Hitung statistik server per tipe
    const sshCount = servers.filter(s => s.type === 'ssh').length;
    const xrayCount = servers.filter(s => s.type === 'xray').length;
    const zivpnCount = servers.filter(s => s.type === 'zivpn').length;

    // Buat daftar server untuk ditampilkan
    let serverList = '';
    for (let i = 0; i < servers.length; i++) {
        const s = servers[i];
        let icon = '';
        if (s.type === 'ssh') icon = '🔒';
        else if (s.type === 'xray') icon = '📡';
        else if (s.type === 'zivpn') icon = '🔥';
        serverList += `\n${icon} ${i+1}. *${s.name}* (${s.type.toUpperCase()})`;
    }

    const menuText = `${getHeader('⚙️ SERVER MANAGEMENT')}
╭───────────────────╮
│ ├ *Total Server:* ${servers.length}
│ ├ ├ 🔒 SSH Server   : ${sshCount}
│ ├ ├ 📡 XRAY Server  : ${xrayCount}
│ ├ └ 🔥 ZiVPN Server : ${zivpnCount}
╰───────────────────╯
${servers.length > 0 ? `\n📋 *Daftar Server:*${serverList}` : '\n📭 Belum ada server'}

📌 Pilih aksi di bawah ini:`;

    const serverOptions = [
        '▸ Lihat Detail Server 👀',
        '▸ Status Service Server 🖥️',
        '▸ Tambah Server ➕',
        '▸ Edit Server ✏️',
        '▸ Hapus Server 🗑️',
        '◂ Kembali 🔙'
    ];
    
    await sendPoll(chatId, userId, menuText, serverOptions, 'server_menu', {});
}

async function handleAddServer(chatId, userId) {
    processState[userId] = { action: 'add_server', waitingForInput: true };
    await client.sendMessage(chatId,
        `${getHeader('➕ TAMBAH SERVER')}

📝 Format:
\`nama.tipe.domain:port.auth_key\`

*Tipe server (pilih salah satu):*
┌─────────────────────┐
│ 🔒 \`ssh\`   → Untuk SSH         
│ 📡 \`xray\`  → Untuk VMess/VLess/Trojan 
│ 🔥 \`zivpn\` → Untuk ZiVPN        
└─────────────────────┘

*Contoh:*
▸ SSH:   \`server1.ssh.example.com:22.key123\`
▸ XRAY:  \`server2.xray.example.com:8585.key456\`
▸ ZiVPN: \`server3.zivpn.example.com:8080.key789\`

Ketik *cancel* untuk batal`);
}

async function processAddServer(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'add_server') return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }

    // Cari titik pertama (pemisah nama dan tipe)
    const firstDotIndex = input.indexOf('.');
    if (firstDotIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah!\n\nGunakan: *nama.tipe.domain:port.auth_key*\nContoh: *server1.ssh.example.com:22.key123*');
        return false;
    }
    
    const name = input.substring(0, firstDotIndex).trim();
    const remaining = input.substring(firstDotIndex + 1).trim();
    
    // Cari titik kedua (pemisah tipe dan domain)
    const secondDotIndex = remaining.indexOf('.');
    if (secondDotIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Tipe server tidak ditemukan.\n\nGunakan: *nama.tipe.domain:port.auth_key*');
        return false;
    }
    
    const type = remaining.substring(0, secondDotIndex).toLowerCase();
    const rest = remaining.substring(secondDotIndex + 1);
    
    // Validasi tipe server
    const validTypes = ['ssh', 'xray', 'zivpn'];
    if (!validTypes.includes(type)) {
        await sendAutoDelete(chatId, `❌ Tipe server *${type}* tidak dikenal!\n\nTipe yang tersedia:\n🔒 ssh\n📡 xray\n🔥 zivpn\n\nContoh: *server1.ssh.example.com:22.key123*`);
        return false;
    }
    
    // Cari titik terakhir atau colon untuk auth_key
    const lastColonIndex = rest.lastIndexOf(':');
    if (lastColonIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan domain:port.auth_key\nContoh: *example.com:8585.key123*');
        return false;
    }
    
    // Pisahkan domain:port dan auth_key
    const domainPortPart = rest.substring(0, lastColonIndex);
    const authKey = rest.substring(lastColonIndex + 1);
    
    // Pisahkan domain dan port
    const portColonIndex = domainPortPart.lastIndexOf(':');
    if (portColonIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan domain:port\nContoh: *example.com:8585*');
        return false;
    }
    
    const domain = domainPortPart.substring(0, portColonIndex);
    const port = parseInt(domainPortPart.substring(portColonIndex + 1));
    
    if (isNaN(port)) {
        await sendAutoDelete(chatId, '❌ Port harus berupa angka!');
        return false;
    }
    
    if (!authKey || authKey.length < 5) {
        await sendAutoDelete(chatId, '❌ Auth key terlalu pendek (minimal 5 karakter)!');
        return false;
    }

    // Buat server baru
    const newId = generateServerId();
    SERVERS[newId] = { 
        id: newId, 
        name: name, 
        apiUrl: `http://${domain}:${port}`,
        authKey: authKey, 
        type: type
    };
    saveServers(SERVERS);

    // Pesan sukses dengan informasi tipe
    let typeIcon = '';
    let typeLabel = '';
    if (type === 'ssh') {
        typeIcon = '🔒';
        typeLabel = 'SSH';
    } else if (type === 'xray') {
        typeIcon = '📡';
        typeLabel = 'XRAY (VMess/VLess/Trojan)';
    } else if (type === 'zivpn') {
        typeIcon = '🔥';
        typeLabel = 'ZiVPN';
    }

    await client.sendMessage(chatId, 
        `✅ *Server berhasil ditambahkan!*\n\n` +
        `${typeIcon} *${name}*\n` +
        `📋 Tipe: ${typeLabel}\n` +
        `📡 API: http://${domain}:${port}\n` +
        `🔑 Auth: ${authKey}`);
    
    delete processState[userId];
    await showServerMenu(chatId, userId);
    return true;
}async function processAddServer(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'add_server') return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }

    // ==================== PARSING DARI BELAKANG ====================
    // Format: NAMA.TIPE.DOMAIN:PORT.AUTH_KEY
    // Contoh: ID NEVACLOUD.ssh.cloud.peyx.site:8585.PX-LxwmRU46fI
    
    // Step 1: Cari titik terakhir (pemisah auth_key)
    const lastDotIndex = input.lastIndexOf('.');
    if (lastDotIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan: *nama.tipe.domain:port.auth_key*');
        return false;
    }
    
    const authKey = input.substring(lastDotIndex + 1);
    const beforeAuth = input.substring(0, lastDotIndex);
    
    // Step 2: Cari colon (pemisah domain:port)
    const colonIndex = beforeAuth.lastIndexOf(':');
    if (colonIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan: *domain:port*\nContoh: *cloud.peyx.site:8585*');
        return false;
    }
    
    const domainPort = beforeAuth.substring(0, colonIndex);
    const portStr = beforeAuth.substring(colonIndex + 1);
    const port = parseInt(portStr);
    
    if (isNaN(port)) {
        await sendAutoDelete(chatId, '❌ Port harus berupa angka!');
        return false;
    }
    
    // Step 3: Cari titik pertama dan kedua di domainPort untuk pisahkan nama dan tipe
    // domainPort berisi: NAMA.TIPE.DOMAIN
    const firstDotInDomain = domainPort.indexOf('.');
    if (firstDotInDomain === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan: *nama.tipe.domain*');
        return false;
    }
    
    const name = domainPort.substring(0, firstDotInDomain);
    const remaining = domainPort.substring(firstDotInDomain + 1);
    
    // Step 4: Cari titik berikutnya untuk pisahkan tipe dan domain
    const secondDotInRemaining = remaining.indexOf('.');
    if (secondDotInRemaining === -1) {
        // Format: nama.tipe.domain (tanpa titik tambahan)
        const type = remaining;
        const domain = '';
        await sendAutoDelete(chatId, '❌ Format domain salah! Gunakan: *nama.tipe.domain.com*');
        return false;
    }
    
    const type = remaining.substring(0, secondDotInRemaining);
    const domain = remaining.substring(secondDotInRemaining + 1);
    
    // Validasi
    const validTypes = ['ssh', 'xray', 'zivpn'];
    if (!validTypes.includes(type.toLowerCase())) {
        await sendAutoDelete(chatId, `❌ Tipe server *${type}* tidak dikenal!\n\nTipe yang tersedia:\n🔒 ssh\n📡 xray\n🔥 zivpn`);
        return false;
    }
    
    if (!domain || domain.length < 3) {
        await sendAutoDelete(chatId, '❌ Domain tidak valid!');
        return false;
    }
    
    if (!authKey || authKey.length < 5) {
        await sendAutoDelete(chatId, '❌ Auth key terlalu pendek (minimal 5 karakter)!');
        return false;
    }

    // Buat server baru
    const newId = generateServerId();
    SERVERS[newId] = { 
        id: newId, 
        name: name, 
        apiUrl: `http://${domain}:${port}`,
        authKey: authKey, 
        type: type.toLowerCase()
    };
    saveServers(SERVERS);

    // Pesan sukses
    let typeIcon = '';
    let typeLabel = '';
    if (type === 'ssh') {
        typeIcon = '🔒';
        typeLabel = 'SSH';
    } else if (type === 'xray') {
        typeIcon = '📡';
        typeLabel = 'XRAY';
    } else if (type === 'zivpn') {
        typeIcon = '🔥';
        typeLabel = 'ZiVPN';
    }

    await client.sendMessage(chatId, 
        `✅ *Server berhasil ditambahkan!*\n\n` +
        `${typeIcon} *${name}*\n` +
        `📋 Tipe: ${typeLabel}\n` +
        `🌐 Domain: ${domain}\n` +
        `🔌 Port: ${port}\n` +
        `🔑 Auth: ${authKey}`);
    
    delete processState[userId];
    await showServerMenu(chatId, userId);
    return true;
}

async function handleEditServer(chatId, userId) {
    const servers = Object.values(SERVERS);
    if (servers.length === 0) {
        await sendAutoDelete(chatId, '📭 Tidak ada server untuk diedit.');
        await showServerMenu(chatId, userId);
        return;
    }
    
    let serverList = `${getHeader('✏️ EDIT SERVER')}\n\n`;
    serverList += `📋 *Daftar Server:*\n`;
    serverList += `━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    for (let i = 0; i < servers.length; i++) {
        const s = servers[i];
        let typeIcon = '';
        if (s.type === 'ssh') typeIcon = '🔒';
        else if (s.type === 'xray') typeIcon = '📡';
        else if (s.type === 'zivpn') typeIcon = '🔥';
        
        serverList += `${i+1}. ${typeIcon} *${s.name}*\n`;
        serverList += `   📋 Tipe: ${s.type.toUpperCase()}\n`;
        serverList += `   📡 ${s.apiUrl}\n\n`;
    }
    
    serverList += `━━━━━━━━━━━━━━━━━━━━\n`;
    serverList += `📌 Kirim *NOMOR* server yang akan diedit (1-${servers.length})\n`;
    serverList += `📌 Ketik *cancel* untuk batal\n\n`;
    serverList += `*Format data baru:*\n`;
    serverList += `\`nama.tipe.domain:port.auth_key\`\n\n`;
    serverList += `*Contoh:*\n`;
    serverList += `▸ SSH:   \`server1.ssh.example.com:22.key123\`\n`;
    serverList += `▸ XRAY:  \`server2.xray.example.com:8585.key456\`\n`;
    serverList += `▸ ZiVPN: \`server3.zivpn.example.com:8080.key789\``;
    
    await client.sendMessage(chatId, serverList);
    
    processState[userId] = { 
        action: 'edit_server_select', 
        servers: servers,
        waitingForInput: true 
    };
}

async function processEditServerSelect(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_server_select') return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }

    const choice = parseInt(input);
    if (isNaN(choice) || choice < 1 || choice > state.servers.length) {
        await sendAutoDelete(chatId, `❌ Pilihan tidak valid. Kirim angka 1-${state.servers.length}`);
        return false;
    }

    const selectedServer = state.servers[choice - 1];
    
    await client.sendMessage(chatId, 
        `✏️ *EDIT SERVER: ${selectedServer.name}*\n\n` +
        `📋 *Data Saat Ini:*\n` +
        `📛 Nama: ${selectedServer.name}\n` +
        `🏷️ Tipe: ${selectedServer.type}\n` +
        `🌐 API: ${selectedServer.apiUrl}\n` +
        `🔑 Auth Key: ${selectedServer.authKey}\n\n` +
        `📝 *Kirim data baru dengan FORMAT SAMA:*\n` +
        `\`nama.tipe.domain:port.auth_key\`\n\n` +
        `Ketik *cancel* untuk batal`);
    
    processState[userId] = { 
        action: 'edit_server_data', 
        serverId: selectedServer.id,
        waitingForInput: true 
    };
    
    return true;
}

async function processEditServerData(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'edit_server_data') return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }

    // Parse input sama seperti add server
    const firstDotIndex = input.indexOf('.');
    if (firstDotIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan: *nama.tipe.domain:port.auth_key*');
        return false;
    }
    
    const name = input.substring(0, firstDotIndex).trim();
    const remaining = input.substring(firstDotIndex + 1).trim();
    
    const secondDotIndex = remaining.indexOf('.');
    if (secondDotIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Tipe server tidak ditemukan.');
        return false;
    }
    
    const type = remaining.substring(0, secondDotIndex).toLowerCase();
    const rest = remaining.substring(secondDotIndex + 1);
    
    // Validasi tipe
    const validTypes = ['ssh', 'xray', 'zivpn'];
    if (!validTypes.includes(type)) {
        await sendAutoDelete(chatId, `❌ Tipe server *${type}* tidak dikenal!\n\nTipe yang tersedia: ssh, xray, zivpn`);
        return false;
    }
    
    const lastColonIndex = rest.lastIndexOf(':');
    if (lastColonIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan domain:port.auth_key');
        return false;
    }
    
    const domainPortPart = rest.substring(0, lastColonIndex);
    const authKey = rest.substring(lastColonIndex + 1);
    
    const portColonIndex = domainPortPart.lastIndexOf(':');
    if (portColonIndex === -1) {
        await sendAutoDelete(chatId, '❌ Format salah! Gunakan domain:port');
        return false;
    }
    
    const domain = domainPortPart.substring(0, portColonIndex);
    const port = parseInt(domainPortPart.substring(portColonIndex + 1));
    
    if (isNaN(port)) {
        await sendAutoDelete(chatId, '❌ Port harus berupa angka!');
        return false;
    }
    
    if (!authKey || authKey.length < 5) {
        await sendAutoDelete(chatId, '❌ Auth key terlalu pendek (minimal 5 karakter)!');
        return false;
    }

    // Update server
    const serverId = state.serverId;
    const oldName = SERVERS[serverId].name;
    const oldType = SERVERS[serverId].type;
    
    SERVERS[serverId] = { 
        ...SERVERS[serverId],
        id: serverId,
        name: name, 
        apiUrl: `http://${domain}:${port}`, 
        authKey: authKey, 
        type: type
    };
    saveServers(SERVERS);

    let typeIcon = '';
    let typeLabel = '';
    if (type === 'ssh') {
        typeIcon = '🔒';
        typeLabel = 'SSH';
    } else if (type === 'xray') {
        typeIcon = '📡';
        typeLabel = 'XRAY';
    } else if (type === 'zivpn') {
        typeIcon = '🔥';
        typeLabel = 'ZiVPN';
    }

    await client.sendMessage(chatId, 
        `✅ *Server berhasil diupdate!*\n\n` +
        `📛 Nama: ${oldName} → *${name}*\n` +
        `🏷️ Tipe: ${oldType.toUpperCase()} → ${typeIcon} *${typeLabel}*\n` +
        `🌐 API: http://${domain}:${port}\n` +
        `🔑 Auth Key: ${authKey}`);
    
    delete processState[userId];
    await showServerMenu(chatId, userId);
    return true;
}

async function handleDeleteServer(chatId, userId) {
    processState[userId] = { action: 'delete_server', waitingForInput: true };
    await client.sendMessage(chatId, `${getHeader('🗑️ HAPUS SERVER')}\n\nKirim nama server:\nKetik *cancel* untuk batal`);
}

async function processDeleteServer(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'delete_server') return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showServerMenu(chatId, userId);
        return true;
    }

    let found = null;
    for (const [id, s] of Object.entries(SERVERS)) {
        if (s.name.toLowerCase() === input.toLowerCase()) { found = id; break; }
    }

    if (!found) {
        await sendAutoDelete(chatId, `❌ Server "${input}" tidak ditemukan.`);
        return false;
    }

    const name = SERVERS[found].name;
    delete SERVERS[found];
    saveServers(SERVERS);

    await sendAutoDelete(chatId, `✅ Server *${name}* dihapus.`);
    delete processState[userId];
    await showServerMenu(chatId, userId);
    return true;
}

// ==================== GET ALL USERS FOR SELECTION ====================
async function getAllUsersForSelection() {
    const allUserIds = getAllUserIds();
    const userList = [];
    
    console.log(`📊 Getting users for selection, total unique users: ${allUserIds.size}`);
    
    for (const userId of allUserIds) {
        try {
            const name = await getUserName(userId);
            const saldo = getSaldo(userId);
            const akunCount = getJumlahAkun(userId);
            
            userList.push({
                userId: userId,
                name: name || 'Unknown',
                saldo: saldo || 0,
                akunCount: akunCount || 0
            });
        } catch(e) {
            userList.push({
                userId: userId,
                name: 'User',
                saldo: getSaldo(userId) || 0,
                akunCount: getJumlahAkun(userId) || 0
            });
        }
    }
    
    userList.sort((a, b) => a.name.localeCompare(b.name));
    return userList;
}

// ==================== ADMIN FUNCTIONS ====================
async function showAllUserSaldo(chatId) {
    const allUsers = getAllUsersWithDetails();
    
    if (allUsers.length === 0) {
        await sendAutoDelete(chatId, '📭 Belum ada user yang terdaftar.');
        return;
    }

    const usersWithSaldo = allUsers.filter(u => u.saldo > 0).length;
    const usersWithAkun = allUsers.filter(u => u.totalAkun > 0).length;
    const totalSaldo = allUsers.reduce((sum, u) => sum + u.saldo, 0);

    let msg = `${getHeader('👥 SEMUA USER BOT')}\n`;
    msg += `╭───────────────────╮\n`;
    msg += `│ 📊 Total User        : ${allUsers.length} user\n`;
    msg += `│ 💰 User dengan Saldo : ${usersWithSaldo} user\n`;
    msg += `│ 📦 User dengan Akun  : ${usersWithAkun} user\n`;
    msg += `│ 💎 Total Saldo       : ${formatRp(totalSaldo)}\n`;
    msg += `╰───────────────────╯\n\n`;
    
    msg += `┏━━━━━━━━━━━━━━━━━━━┓\n`;

    for (let i = 0; i < Math.min(30, allUsers.length); i++) {
        const user = allUsers[i];
        const name = await getUserName(user.userId);
        const saldoDisplay = user.saldo > 0 ? formatRp(user.saldo) : 'Rp 0';
        const akunDisplay = user.totalAkun > 0 ? `${user.totalAkun} akun` : '0 akun';
        
        msg += `┃ 👤 *${i+1}. ${name}*\n`;
        msg += `┃    🆔 \`${user.userId}\`\n`;
        msg += `┃    💰 Saldo : ${saldoDisplay}\n`;
        msg += `┃    📦 Akun  : ${akunDisplay}\n`;
        msg += `┃    ─────────────────\n`;
    }

    msg += `┗━━━━━━━━━━━━━━━━━━━┛\n\n`;
    
    if (allUsers.length > 30) {
        msg += `📌 *Catatan:* ${allUsers.length - 30} user lainnya tidak ditampilkan.\n`;
    }
    
    msg += `📅 Diperbarui: ${formatTimestamp()}`;

    await client.sendMessage(chatId, msg);
}

async function showAllUserAkun(chatId) {
    const akun = loadAkun();
    const allUsers = getAllUserIds();
    
    // Buat array dari semua user yang memiliki akun
    const usersWithAkun = [];
    for (const userId of allUsers) {
        const userAkun = akun[userId] || [];
        if (userAkun.length > 0) {
            usersWithAkun.push({
                userId: userId,
                akun: userAkun
            });
        }
    }
    
    usersWithAkun.sort((a, b) => b.akun.length - a.akun.length);

    if (usersWithAkun.length === 0) {
        await sendAutoDelete(chatId, '📭 Belum ada akun yang dibuat.');
        return;
    }

    let msg = `${getHeader('📋 SEMUA AKUN USER')}\n`;
    msg += `╭───────────────────╮\n`;
    msg += `│ 📊 Total User : ${usersWithAkun.length} user\n`;
    msg += `│ 📦 Total Akun : ${getAllAkunCount()}\n`;
    msg += `╰───────────────────╯\n\n`;
    
    msg += `┏━━━━━━━━━━━━━━━━━━━┓\n`;

    for (let i = 0; i < Math.min(20, usersWithAkun.length); i++) {
        const user = usersWithAkun[i];
        const name = await getUserName(user.userId);
        
        msg += `┃ 👤 *${i+1}. ${name}*\n`;
        msg += `┃    🆔 \`${user.userId}\`\n`;
        msg += `┃    📦 ${user.akun.length} akun\n`;
        msg += `┃    ─────────────────\n`;
        
        for (let idx = 0; idx < Math.min(3, user.akun.length); idx++) {
            const ak = user.akun[idx];
            const type = ak.serviceType?.toUpperCase() || 'VPN';
            const identifier = ak.username || ak.password || '-';
            const expired = ak.expired || '-';
            
            msg += `┃    ${idx+1}. ${type} │ ${identifier}\n`;
            msg += `┃       📅 ${expired}\n`;
        }
        
        if (user.akun.length > 3) {
            msg += `┃    └── +${user.akun.length - 3} akun lain\n`;
        }
        msg += `┃\n`;
    }
    
    msg += `┗━━━━━━━━━━━━━━━━━━━━┛\n\n`;
    msg += `📅 Diperbarui: ${formatTimestamp()}`;

    await client.sendMessage(chatId, msg);
}

async function showRiwayatTransaksi(chatId) {
    const transaksi = loadTransaksi();
    if (transaksi.length === 0) {
        await sendAutoDelete(chatId, '📭 Belum ada transaksi.');
        return;
    }

    let msg = `${getHeader('📋 RIWAYAT TRANSAKSI')}\n`;
    msg += `╭───────────────────╮\n│ ├ *Total:* ${transaksi.length}\n╰───────────────────╯\n\n`;

    for (let i = 0; i < Math.min(20, transaksi.length); i++) {
        const t = transaksi[i];
        const date = new Date(t.waktu).toLocaleDateString('id-ID');
        const userName = t.userName || await getUserName(t.userId) || t.userId;
        msg += `${i+1}. [${t.type.toUpperCase()}] ${t.keterangan}\n   ${formatRp(t.amount)} • ${date} • ${userName}\n\n`;
    }

    await client.sendMessage(chatId, msg);
}

// ==================== HANDLE EDIT SALDO ADMIN ====================
async function handleEditSaldoAdmin(chatId, userId, mode) {
    const userList = await getAllUsersForSelection();
    
    if (userList.length === 0) {
        await sendAutoDelete(chatId, '📭 Belum ada user yang terdaftar.\n\nUser akan muncul setelah berinteraksi dengan bot.');
        return;
    }
    
    // Batasi maksimal 10 user per halaman agar polling tidak terlalu panjang
    const itemsPerPage = 10;
    const totalPages = Math.ceil(userList.length / itemsPerPage);
    const currentPage = 0;
    const startIdx = 0;
    const endIdx = Math.min(itemsPerPage, userList.length);
    
    // Buat opsi polling
    const options = [];
    for (let i = startIdx; i < endIdx; i++) {
        const user = userList[i];
        const shortName = user.name.length > 25 ? user.name.substring(0, 25) + '...' : user.name;
        options.push(`👤 ${shortName} | 💰 ${formatRp(user.saldo)} | 📦 ${user.akunCount} akun`);
    }
    
    // Tambahkan navigasi jika perlu
    if (userList.length > itemsPerPage) {
        options.push('📄 Next Page ➡️');
    }
    options.push('❌ Batal');
    
    const modeText = mode === 'add' ? 'TAMBAH SALDO' : 'KURANGI SALDO';
    const headerText = `${getHeader(`💰 ${modeText}`)}\n\n📋 Klik pilihan user di bawah ini:\n\n`;
    
    // Simpan ke state
    processState[userId] = { 
        action: 'select_user_for_saldo', 
        mode: mode,
        userList: userList,
        currentPage: 0,
        itemsPerPage: itemsPerPage,
        totalPages: totalPages
    };
    
    // Kirim polling
    await sendPoll(chatId, userId, headerText, options, 'select_user_for_saldo', {
        mode: mode,
        userList: userList,
        currentPage: 0,
        itemsPerPage: itemsPerPage
    });
}

async function showUserListPage(chatId, userId, page, mode, userList) {
    const itemsPerPage = 10;
    const startIdx = page * itemsPerPage;
    const endIdx = Math.min(startIdx + itemsPerPage, userList.length);
    const totalPages = Math.ceil(userList.length / itemsPerPage);
    
    // Buat teks daftar user
    let userListText = `${getHeader(`💰 ${mode === 'add' ? 'TAMBAH SALDO' : 'KURANGI SALDO'}`)}\n\n`;
    userListText += `📋 Daftar User (Halaman ${page + 1} dari ${totalPages}):\n`;
    userListText += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    for (let i = startIdx; i < endIdx; i++) {
        const user = userList[i];
        const displayNum = i + 1;
        userListText += `${displayNum}. *${user.name}*\n`;
        userListText += `   💰 Saldo: ${formatRp(user.saldo)}\n`;
        userListText += `   📦 Akun: ${user.akunCount} akun\n`;
        userListText += `   🆔 ID: \`${user.userId}\`\n\n`;
    }
    
    userListText += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    userListText += `📌 Kirim *NOMOR* user yang dipilih (contoh: *1*)\n`;
    userListText += `📌 Ketik *cancel* untuk membatalkan\n`;
    
    if (totalPages > 1) {
        userListText += `\n📌 Untuk halaman berikutnya, ketik *next* atau *prev*`;
    }
    
    await client.sendMessage(chatId, userListText);
}

async function showUserSelectionPage(chatId, userId, page, mode, userList) {
    const itemsPerPage = 10;
    const startIdx = page * itemsPerPage;
    const endIdx = Math.min(startIdx + itemsPerPage, userList.length);
    const options = [];
    
    for (let i = startIdx; i < endIdx; i++) {
        const user = userList[i];
        const shortName = user.name.length > 25 ? user.name.substring(0, 25) + '...' : user.name;
        // Format sederhana tanpa titik setelah nomor
        options.push(`${user.userId}|${shortName}|${formatRp(user.saldo)}|${user.akunCount}`);
    }
    
    if (userList.length > itemsPerPage) {
        options.push('NEXT_PAGE');
    }
    if (page > 0) {
        options.push('PREV_PAGE');
    }
    options.push('CANCEL');
    
    const modeText = mode === 'add' ? 'TAMBAH SALDO' : 'KURANGI SALDO';
    const totalPages = Math.ceil(userList.length / itemsPerPage);
    
    // Buat teks daftar user yang rapi
    let userListText = '';
    for (let i = startIdx; i < endIdx; i++) {
        const user = userList[i];
        const displayNum = i + 1;
        userListText += `\n${displayNum}. ${user.name}\n   💰 ${formatRp(user.saldo)} | 📦 ${user.akunCount} akun | 🆔 \`${user.userId}\`\n`;
    }
    
    const headerText = `${getHeader(`💰 ${modeText}`)}\n\n📋 Pilih user yang akan diedit (Halaman ${page + 1} dari ${totalPages}):\n${userListText}\n📌 Kirim *NOMOR* user yang dipilih (contoh: *1*)\n\nKetik *cancel* untuk batal`;
    
    await client.sendMessage(chatId, headerText);
    
    processState[userId] = {
        action: 'select_user_for_saldo',
        mode: mode,
        userList: userList,
        currentPage: page,
        itemsPerPage: itemsPerPage,
        waitingForInput: true
    };
}

async function processAdminEditSaldo(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'input_saldo_amount') return false;

    const input = msg.body.trim();
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showDashboard(chatId, userId);
        return true;
    }

    const amount = parseInt(input.replace(/\D/g, ''));
    if (isNaN(amount) || amount <= 0) {
        await sendAutoDelete(chatId, '❌ Jumlah tidak valid. Masukkan angka positif.\nContoh: *50000*');
        return false;
    }

    const targetUserId = state.targetUserId;
    const targetName = state.targetName;
    const mode = state.mode;

    if (mode === 'add') {
        const currentSaldo = getSaldo(targetUserId);
        const newBal = tambahSaldo(targetUserId, amount);
        
        if (newBal === currentSaldo) {
            await sendAutoDelete(chatId, `❌ Gagal menambah saldo.`);
            delete processState[userId];
            await showDashboard(chatId, userId);
            return true;
        }
        
        simpanTransaksi({ 
            txId: generateTxId(), 
            userId: targetUserId, 
            userName: targetName,
            type: 'admin_add', 
            amount, 
            keterangan: `Admin tambah saldo dari ${userId}`, 
            waktu: new Date().toISOString(), 
            status: 'success' 
        });
        
        await client.sendMessage(chatId, 
            `✅ *TAMBAH SALDO BERHASIL!*\n\n` +
            `👤 *User:* ${targetName}\n` +
            `💰 *Nominal:* +${formatRp(amount)}\n` +
            `💳 *Saldo Baru:* ${formatRp(newBal)}`);
            
    } else {
        const currentSaldo = getSaldo(targetUserId);
        if (currentSaldo < amount) {
            await sendAutoDelete(chatId, 
                `❌ *Saldo tidak cukup!*\n\n` +
                `👤 *User:* ${targetName}\n` +
                `💰 *Saldo Saat Ini:* ${formatRp(currentSaldo)}\n` +
                `📉 *Dikurangi:* ${formatRp(amount)}\n\n` +
                `Saldo tidak mencukupi untuk pengurangan tersebut.`);
            delete processState[userId];
            await showDashboard(chatId, userId);
            return true;
        }
        
        const newBal = kurangiSaldo(targetUserId, amount);
        
        if (newBal === currentSaldo) {
            await sendAutoDelete(chatId, `❌ Gagal mengurangi saldo.`);
            delete processState[userId];
            await showDashboard(chatId, userId);
            return true;
        }
        
        simpanTransaksi({ 
            txId: generateTxId(), 
            userId: targetUserId, 
            userName: targetName,
            type: 'admin_reduce', 
            amount, 
            keterangan: `Admin kurangi saldo dari ${userId}`, 
            waktu: new Date().toISOString(), 
            status: 'success' 
        });
        
        await client.sendMessage(chatId, 
            `✅ *KURANGI SALDO BERHASIL!*\n\n` +
            `👤 *User:* ${targetName}\n` +
            `💰 *Nominal:* -${formatRp(amount)}\n` +
            `💳 *Saldo Baru:* ${formatRp(newBal)}`);
    }

    delete processState[userId];
    await showDashboard(chatId, userId);
    return true;
}

// ==================== PROCESS INPUT SALDO AMOUNT ====================
// ==================== PROCESS INPUT SALDO AMOUNT ====================
async function processInputSaldoAmount(chatId, userId, msg) {
    const state = processState[userId];
    if (!state || state.action !== 'input_saldo_amount') return false;
    
    const input = msg.body.trim();
    
    if (input.toLowerCase() === 'cancel') {
        await sendAutoDelete(chatId, '❌ Dibatalkan');
        delete processState[userId];
        await showDashboard(chatId, userId);
        return true;
    }
    
    const amount = parseInt(input.replace(/\D/g, ''));
    if (isNaN(amount) || amount <= 0) {
        await sendAutoDelete(chatId, '❌ Jumlah tidak valid. Masukkan angka positif.\nContoh: *50000*');
        return false;
    }
    
    const targetUserId = state.targetUserId;
    const targetName = state.targetName;
    const mode = state.mode;
    
    if (mode === 'add') {
        const currentSaldo = getSaldo(targetUserId);
        const newBal = tambahSaldo(targetUserId, amount);
        
        simpanTransaksi({ 
            txId: generateTxId(), 
            userId: targetUserId, 
            userName: targetName,
            type: 'admin_add', 
            amount, 
            keterangan: `Admin tambah saldo dari ${userId}`, 
            waktu: new Date().toISOString(), 
            status: 'success' 
        });
        
        await client.sendMessage(chatId, 
            `✅ *TAMBAH SALDO BERHASIL!*\n\n` +
            `👤 *User:* ${targetName}\n` +
            `💰 *Nominal:* +${formatRp(amount)}\n` +
            `💳 *Saldo Lama:* ${formatRp(currentSaldo)}\n` +
            `💚 *Saldo Baru:* ${formatRp(newBal)}`);
            
    } else {
        const currentSaldo = getSaldo(targetUserId);
        if (currentSaldo < amount) {
            await sendAutoDelete(chatId, 
                `❌ *Saldo tidak cukup!*\n\n` +
                `👤 *User:* ${targetName}\n` +
                `💰 *Saldo Saat Ini:* ${formatRp(currentSaldo)}\n` +
                `📉 *Dikurangi:* ${formatRp(amount)}\n\n` +
                `Saldo tidak mencukupi untuk pengurangan tersebut.`);
            delete processState[userId];
            await showDashboard(chatId, userId);
            return true;
        }
        
        const newBal = kurangiSaldo(targetUserId, amount);
        
        simpanTransaksi({ 
            txId: generateTxId(), 
            userId: targetUserId, 
            userName: targetName,
            type: 'admin_reduce', 
            amount, 
            keterangan: `Admin kurangi saldo dari ${userId}`, 
            waktu: new Date().toISOString(), 
            status: 'success' 
        });
        
        await client.sendMessage(chatId, 
            `✅ *KURANGI SALDO BERHASIL!*\n\n` +
            `👤 *User:* ${targetName}\n` +
            `💰 *Nominal:* -${formatRp(amount)}\n` +
            `💳 *Saldo Lama:* ${formatRp(currentSaldo)}\n` +
            `💚 *Saldo Baru:* ${formatRp(newBal)}`);
    }
    
    delete processState[userId];
    await showDashboard(chatId, userId);
    return true;
}

// ==================== MAIN MESSAGE HANDLER ====================
async function handleMessageWithLock(msg) {
    const messageId = msg.id._serialized;
    const chatId = msg.from;
    const rawUserId = msg.author || msg.from;
    const userId = getCleanUserId(rawUserId);
    const body = msg.body?.trim() || '';

    // Kirim reaction untuk setiap pesan yang masuk
    await sendReaction(msg, '⚡');

    // Update username dari pesan
    try {
        if (msg._data && msg._data.sender && msg._data.sender.pushname) {
            const name = msg._data.sender.pushname.replace(/[^\w\s\-\.]/gi, '').trim();
            if (name && name.length > 0 && name !== 'User') {
                userNamesCache.set(userId, name);
                const savedNames = loadUserNames();
                savedNames[userId] = name;
                saveUserNames(savedNames);
            }
        }
    } catch(e) {}

    // ==================== CEK STATE AKTIF ====================
    const state = processState[userId];
    
    if (state) {
        const action = state.action;  // <-- action didefinisikan DI SINI
        
        // Topup amount
        if (action === 'topup_amount') { 
            await processTopupAmount(chatId, userId, msg); 
            return; 
        }
        
        // Create account
        if (action === 'create') { 
            await processCreate(chatId, userId, msg); 
            return; 
        }
        
        // Renew account
        if (action === 'renew') { 
            await processRenew(chatId, userId, msg); 
            return; 
        }
        
        // Add server
        if (action === 'add_server') { 
            await processAddServer(chatId, userId, msg); 
            return; 
        }
        
        // Edit server select
        if (action === 'edit_server_select') { 
            await processEditServerSelect(chatId, userId, msg); 
            return; 
        }
        
        // Edit server data
        if (action === 'edit_server_data') { 
            await processEditServerData(chatId, userId, msg); 
            return; 
        }
        
        // Delete server
        if (action === 'delete_server') { 
            await processDeleteServer(chatId, userId, msg); 
            return; 
        }

        // Di dalam handleMessageWithLock, setelah pengecekan action lainnya
if (action === 'create_step_username' || action === 'create_step_days' || 
    action === 'create_step_password' || action === 'create_step_confirm') {
    await processCreateStepByStep(chatId, userId, msg);
    return;
}

// ==================== PAYG CREATE STEPS ====================
if (action === 'payg_step_username' || action === 'payg_step_password' || action === 'payg_step_password_only') {
    await processCreatePayg(chatId, userId, msg);
    return;
}

// Di dalam handleMessageWithLock, setelah pengecekan action lainnya
if (action === 'renew_step_username' || action === 'renew_step_days' || action === 'renew_step_confirm') {
    await processRenewStepByStep(chatId, userId, msg);
    return;
}

        // Di dalam handleMessageWithLock, setelah pengecekan action lainnya

if (action === 'edit_server_name') {
    await processEditServerName(chatId, userId, msg);
    return;
}
if (action === 'edit_server_type') {
    await processEditServerType(chatId, userId, msg);
    return;
}
if (action === 'edit_server_domain') {
    await processEditServerDomain(chatId, userId, msg);
    return;
}
if (action === 'edit_server_auth') {
    await processEditServerAuth(chatId, userId, msg);
    return;
}
        
        // ==================== EDIT DATA BOT ====================
        if (action === 'edit_harga') {
            await processEditHarga(chatId, userId, msg);
            return;
        }
        if (action === 'edit_trial_menit') {
            await processEditTrialMenit(chatId, userId, msg);
            return;
        }
        if (action === 'edit_trial_per_hari') {
            await processEditTrialPerHari(chatId, userId, msg);
            return;
        }
        if (action === 'edit_ip_limit') {
            await processEditIpLimit(chatId, userId, msg);
            return;
        }
        if (action === 'edit_min_topup') {
            await processEditMinTopup(chatId, userId, msg);
            return;
        }
        if (action === 'edit_merchant_name') {
            await processEditMerchantName(chatId, userId, msg);
            return;
        }
        if (action === 'edit_quota') {
            await processEditQuota(chatId, userId, msg);
            return;
        }
        
        // ==================== INPUT SALDO AMOUNT ====================
        if (action === 'input_saldo_amount' && state.waitingForInput) {
            await processInputSaldoAmount(chatId, userId, msg);
            return;
        }
        
        // ==================== INPUT TAMBAH ADMIN ====================
        if (action === 'input_tambah_admin' && state.waitingForInput) {
            await processInputTambahAdmin(chatId, userId, msg);
            return;
        }
    }

    // ==================== CEK BUKTI PEMBAYARAN ====================
    const isImage = msg.type === 'image' || (msg.hasMedia === true);
    if (isImage && pendingQRIS[userId]) {
        await handleBuktiPembayaran(chatId, userId, msg);
        return;
    }

    // ==================== COMMANDS ====================
    if (body === '/menu' || body === 'menu' || body === '.menu' || body === '/start') {
        await showMainMenu(chatId, userId);
        return;
    }
    
    if (body === '/saldo') {
        const saldo = getSaldo(userId);
        const jumlahAkun = getJumlahAkun(userId);
        const nama = await getUserName(userId);
        await client.sendMessage(chatId, 
            `💰 *INFORMASI SALDO*\n\n👤 *User:* ${nama}\n💳 *Saldo:* ${formatRp(saldo)}\n📦 *Total Akun:* ${jumlahAkun}`);
        return;
    }
    
    if (body === '/help') {
        await client.sendMessage(chatId, `${getHeader('📖 BANTUAN')}
╭─────────────────╮
│ ├ /menu   - Menu utama
│ ├ /saldo  - Cek saldo
│ ├ /help   - Bantuan ini
╰─────────────────╯

💵 *Harga:* ${formatHarga()}
⏱️ *Trial:* ${CONFIG.MAX_TRIAL_MENIT} menit, ${CONFIG.MAX_TRIAL_PER_USER}x/hari

📝 *Format Create:*
SSH: username.hari.password
Trojan/VLess/VMess: username.hari.password
ZiVPN: password.hari

📝 *Format Renew:*
SSH/Trojan/VLess/VMess: username.tambah_hari
ZiVPN: password.tambah_hari`);
        return;
    }
    
    if (body === '/dashboard' || body === '/admin') {
        await showDashboard(chatId, userId);
        return;
    }

    if (body === '/myname') {
        const name = await getUserName(userId);
        await client.sendMessage(chatId, `📛 *Nama Anda:* ${name}\n🆔 *User ID:* ${userId}`);
        return;
    }
    
    if (pendingQRIS[userId]) {
        await sendAutoDelete(chatId, '📸 Silakan kirim *screenshot bukti pembayaran*.');
        return;
    }
    
    if (body && !body.startsWith('/')) {
        await sendAutoDelete(chatId, '❌ Perintah tidak dikenal.\n\nKetik */menu* untuk melihat menu utama');
    }
}

// ==================== CLIENT EVENTS ====================
client.on('message_create', async (msg) => {
    if (!isReady) return;
    if (msg.fromMe) return;
    
    // TANGKAP NAMA USER DARI PESAN
    const userId = getCleanUserId(msg.author || msg.from);
    let userName = null;
    
    // ========== AUTO CACHE LID -> NOMOR TELEPON ==========
    // WhatsApp terbaru pakai LID. Coba ambil nomor asli dari data pesan
    if (isLID(userId)) {
        let resolvedPhone = null;
        
        // Cara 1: dari msg._data.sender atau msg._data.author (format 628xxx@c.us)
        try {
            const senderRaw = (msg._data && (msg._data.sender?.id?._serialized || msg._data.author)) || '';
            if (senderRaw && senderRaw.includes('@c.us')) {
                const fromSerial = senderRaw.replace('@c.us', '').replace(/[^0-9]/g, '');
                if (fromSerial && !isLID(fromSerial) && fromSerial.length >= 10) {
                    resolvedPhone = fromSerial;
                    console.log(`📞 LID resolved from _data.sender: ${userId} -> ${resolvedPhone}`);
                }
            }
        } catch(e) {}
        
        // Cara 2: dari msg.getContact()
        if (!resolvedPhone) {
            try {
                const contact = await msg.getContact();
                // Coba dari id._serialized yang berformat 628xxx@c.us
                if (contact.id && contact.id._serialized && contact.id._serialized.includes('@c.us')) {
                    const fromSerial = contact.id._serialized.replace('@c.us', '').replace(/[^0-9]/g, '');
                    if (fromSerial && !isLID(fromSerial) && fromSerial.length >= 10) {
                        resolvedPhone = fromSerial;
                        console.log(`📞 LID resolved from contact.id: ${userId} -> ${resolvedPhone}`);
                    }
                }
                // Atau dari contact.number
                if (!resolvedPhone && contact.number && !isLID(contact.number)) {
                    resolvedPhone = contact.number.replace(/[^0-9]/g, '');
                    console.log(`📞 LID resolved from contact.number: ${userId} -> ${resolvedPhone}`);
                }
            } catch(e) {}
        }
        
        // Normalisasi dan cache
        if (resolvedPhone) {
            if (resolvedPhone.startsWith('0')) resolvedPhone = '62' + resolvedPhone.substring(1);
            if (!resolvedPhone.startsWith('62') && resolvedPhone.length >= 9) resolvedPhone = '62' + resolvedPhone;
            cacheLidPhone(userId, resolvedPhone);
        }
    }
    // ========== END AUTO CACHE ==========
    
    // Cara 1: Dari _data
    if (msg._data) {
        if (msg._data.sender && msg._data.sender.pushname) {
            userName = msg._data.sender.pushname;
            console.log(`📝 Captured from _data.sender.pushname: ${userName}`);
        } else if (msg._data.pushName) {
            userName = msg._data.pushName;
            console.log(`📝 Captured from _data.pushName: ${userName}`);
        } else if (msg._data.notifyName) {
            userName = msg._data.notifyName;
            console.log(`📝 Captured from _data.notifyName: ${userName}`);
        }
    }
    
    // Cara 2: Dari contact
    if (!userName) {
        try {
            const contact = await msg.getContact();
            if (contact.pushname) {
                userName = contact.pushname;
                console.log(`📝 Captured from contact.pushname: ${userName}`);
            } else if (contact.name) {
                userName = contact.name;
                console.log(`📝 Captured from contact.name: ${userName}`);
            }
        } catch(e) {}
    }
    
    // Simpan nama jika berhasil
    if (userName && userName !== 'undefined' && userName.trim().length > 0) {
        userName = userName.replace(/[^\w\s\-\.]/gi, '').trim();
        if (userName.length > 0 && userName !== 'User') {
            userNamesCache.set(userId, userName);
            const savedNames = loadUserNames();
            savedNames[userId] = userName;
            saveUserNames(savedNames);
            console.log(`💾 SAVED USERNAME: ${userId} -> "${userName}"`);
        }
    }
    
    // Cek duplicate, rate limit, dll
    if (isDuplicate(msg.id._serialized)) return;
    if (!checkRateLimit(userId)) {
        await sendReaction(msg, '⏳');
        return;
    }
    
    await addToQueue(msg);
});

client.on('qr', (qr) => {
    console.log('📱 Scan QR:');
    qrcodeTerminal.generate(qr, { small: true });
});

client.on('ready', async () => {
    SERVERS = loadServers();
    const stats = getUserStats();
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('🚀 VPN BOT STARTED');
    console.log(`🌐 Servers: ${Object.keys(SERVERS).length}`);
    console.log(`👥 Users: ${stats.jumlahUser}`);
    console.log(`📦 Akun: ${stats.totalAkun}`);
    console.log(`⚡ Max Concurrent: ${MAX_CONCURRENT}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    // ==================== KONVERSI NOMOR ADMIN PERTAMA KALI ====================
    // Pastikan admins.json ada dan nomor sudah dalam format yang benar
    if (!fs.existsSync(ADMIN_FILE)) {
        console.log('🔄 admins.json belum ada, melakukan konversi nomor admin dari .env...');
        const converted = [];
        for (const num of ADMIN_NUMBERS) {
            const clean = num.toString().replace(/[^0-9]/g, '');
            if (!clean) continue;
            
            let normalized = clean;
            if (isLID(clean)) {
                // LID: simpan apa adanya, cocokkan saat cek admin
                console.log(`⚠️ Admin berformat LID: ${clean} (akan di-resolve ke nomor saat pertama pesan masuk)`);
            } else {
                // Nomor telepon: normalisasi ke 62xxx
                if (normalized.startsWith('0')) normalized = '62' + normalized.substring(1);
                if (!normalized.startsWith('62') && normalized.length >= 9) normalized = '62' + normalized;
                console.log(`✅ Admin nomor: ${num} → ${normalized}`);
            }
            
            if (!converted.includes(normalized)) {
                converted.push(normalized);
            }
        }
        fs.writeFileSync(ADMIN_FILE, JSON.stringify({ admins: converted }, null, 2));
        console.log(`✅ admins.json dibuat dengan ${converted.length} admin: ${converted.join(', ')}`);
    } else {
        const existing = getAdminList();
        console.log(`📋 Admin aktif (${existing.length}): ${existing.join(', ')}`);
    }

    isReady = true;

    // Restore auto-delete scheduler untuk trial yang masih aktif (survive restart)
    restoreTrialSchedulers();
    console.log('⏰ [Trial] Auto-delete scheduler restored');

    // Mulai Pay As You Go engine
    startPayAsYouGoInterval();
    console.log(`⚡ [PAYG] Tarif per jam: ${Math.ceil(CONFIG.HARGA_PER_HARI_PER_IP * CONFIG.MAX_IP_LIMIT / 24)}`);
});

client.on('disconnected', (reason) => {
    console.log('❌ Disconnected:', reason);
    isReady = false;
    setTimeout(() => {
        console.log('🔄 Reconnecting...');
        client.initialize();
    }, 5000);
});

client.on('change_state', async (state) => {
    console.log(`📡 State changed: ${state}`);
    if (state === 'CONFLICT') {
        console.log('⚠️ Conflict detected, reinitializing...');
        setTimeout(() => client.initialize(), 3000);
    }
});

process.on('uncaughtException', (err) => {
    console.error('❌ Uncaught Error:', err);
});

// ==================== START ====================
async function start() {
    console.log('🔄 Starting VPN Bot...');
    SERVERS = loadServers();
    try {
        await client.initialize();
    } catch(err) {
        console.error('❌ Start error:', err.message);
        setTimeout(() => start(), 5000);
    }
}

start();